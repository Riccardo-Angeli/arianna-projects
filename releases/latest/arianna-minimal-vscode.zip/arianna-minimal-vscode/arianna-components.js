// components/core/Control.ts
var Control = class {
  /** Root DOM element. */
  el;
  _props = {};
  _bus = /* @__PURE__ */ new Map();
  _cleanup = [];
  _dirty = false;
  _raf = 0;
  constructor(container, tag, defaults = {}) {
    this.el = document.createElement(tag);
    this._props = { ...defaults };
    if (defaults.class) this.el.className = defaults.class;
    if (defaults.theme) this.el.dataset.theme = defaults.theme;
    if (defaults.tabIndex !== void 0) this.el.tabIndex = defaults.tabIndex;
    const parent = typeof container === "string" ? document.querySelector(container) : container;
    if (parent) parent.appendChild(this.el);
    Promise.resolve().then(() => this._flush());
  }
  // ── Props (React-like) ────────────────────────────────────────────────────
  _set(key, value) {
    this._props[key] = value;
    this._schedule();
  }
  _get(key, fallback) {
    return this._props[key] ?? fallback;
  }
  // ── Scheduling ────────────────────────────────────────────────────────────
  _schedule() {
    if (this._dirty) return;
    this._dirty = true;
    this._raf = requestAnimationFrame(() => this._flush());
  }
  _flush() {
    this._dirty = false;
    if (!this._destroyed) {
      this._build();
      this._mounted = true;
    }
  }
  _destroyed = false;
  // ── Lifecycle ─────────────────────────────────────────────────────────────
  /** Force an immediate re-render. */
  refresh() {
    this._build();
    return this;
  }
  /** Remove from DOM and clean up. Safe to call multiple times. */
  destroy() {
    if (this._destroyed) return;
    this._destroyed = true;
    cancelAnimationFrame(this._raf);
    this._cleanup.forEach((fn) => fn());
    this._cleanup.length = 0;
    this.el.parentElement?.removeChild(this.el);
  }
  // ── Events ────────────────────────────────────────────────────────────────
  on(type, cb) {
    if (!this._bus.has(type)) this._bus.set(type, /* @__PURE__ */ new Set());
    this._bus.get(type).add(cb);
    return this;
  }
  off(type, cb) {
    this._bus.get(type)?.delete(cb);
    return this;
  }
  _emit(type, detail, ev) {
    this._bus.get(type)?.forEach((cb) => cb(detail, ev));
  }
  // ── DOM helpers ───────────────────────────────────────────────────────────
  /** Create an element, optionally set class and append to parent. */
  _el(tag, cls, parent) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (parent) parent.appendChild(e);
    return e;
  }
  /** Add a DOM listener that auto-removes on destroy(). */
  _on(target, type, cb, opts) {
    target.addEventListener(type, cb, opts);
    this._cleanup.push(
      () => target.removeEventListener(type, cb, opts)
    );
  }
  /** Register a cleanup callback. */
  _gc(fn) {
    this._cleanup.push(fn);
  }
  // ── State proxy ───────────────────────────────────────────────────────────
  /** Reactive state proxy — read/write props as plain object. */
  get _state() {
    return {
      State: this._props,
      Set: (k, v) => this._set(k, v)
    };
  }
  // ── Lifecycle flags ───────────────────────────────────────────────────────
  /** True after first _build() completes. */
  _mounted = false;
  // ── Fire (alias emit) ─────────────────────────────────────────────────────
  /** Alias of _emit — for Golem API compatibility. */
  _fire(type, detail, ev) {
    this._emit(type, detail, ev);
  }
  // ── Listen helper ─────────────────────────────────────────────────────────
  /** Add a typed DOM listener with auto-cleanup. */
  _listen(target, type, cb, opts) {
    target.addEventListener(type, cb, opts);
    this._cleanup.push(
      () => target.removeEventListener(type, cb, opts)
    );
  }
  // ── onDestroy ─────────────────────────────────────────────────────────────
  /** Register cleanup — alias of _gc. */
  _onDestroy(fn) {
    this._gc(fn);
  }
  // ── Public get<T> ─────────────────────────────────────────────────────────
  /** Read a prop by string key (public). */
  get(key, fallback) {
    return this._props[key] ?? fallback;
  }
};

// additionals/Animation.ts
var Easing = {
  linear: (t) => t,
  easeInQuad: (t) => t * t,
  easeOutQuad: (t) => t * (2 - t),
  easeInOutQuad: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  easeInCubic: (t) => t * t * t,
  easeOutCubic: (t) => --t * t * t + 1,
  easeInOutCubic: (t) => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
  easeInQuart: (t) => t * t * t * t,
  easeOutQuart: (t) => 1 - --t * t * t * t,
  easeInExpo: (t) => t === 0 ? 0 : Math.pow(2, 10 * t - 10),
  easeOutExpo: (t) => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
  easeInOutExpo: (t) => t === 0 ? 0 : t === 1 ? 1 : t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2,
  easeOutBack: (t) => {
    const c1 = 1.70158, c3 = c1 + 1;
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2;
  },
  easeOutBounce: (t) => {
    const n = 7.5625, d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
    if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
    return n * (t -= 2.625 / d) * t + 0.984375;
  },
  easeOutElastic: (t) => {
    if (t === 0 || t === 1) return t;
    return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1;
  }
};

// components/animations/KeyframeEditor.ts
var cbz = (p1x, p1y, p2x, p2y) => {
  const A = (a, b) => 1 - 3 * b + 3 * a;
  const B = (a, b) => 3 * b - 6 * a;
  const C = (a) => 3 * a;
  const bz = (t, a, b) => ((A(a, b) * t + B(a, b)) * t + C(a)) * t;
  const slope = (t, a, b) => 3 * A(a, b) * t * t + 2 * B(a, b) * t + C(a);
  return (x) => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const cx = bz(t, p1x, p2x) - x;
      if (Math.abs(cx) < 1e-5) break;
      const sl = slope(t, p1x, p2x);
      if (Math.abs(sl) < 1e-6) break;
      t -= cx / sl;
    }
    return bz(t, p1y, p2y);
  };
};
var evalEasing = (e, x) => {
  if (!e) return x;
  if (typeof e === "string") {
    if (e === "step") return x < 1 ? 0 : 1;
    const fn = Easing[e];
    return fn ? fn(Math.max(0, Math.min(1, x))) : x;
  }
  if (e.type === "cubic-bezier") return cbz(e.p1x, e.p1y, e.p2x, e.p2y)(x);
  return x;
};
var interp = (a, b, t) => {
  const dur = b.time - a.time;
  if (dur <= 0) return a.values.slice();
  const raw = (t - a.time) / dur;
  const e = evalEasing(a.easing, Math.max(0, Math.min(1, raw)));
  const out = new Array(a.values.length);
  for (let i = 0; i < a.values.length; i++) {
    out[i] = a.values[i] + (b.values[i] - a.values[i]) * e;
  }
  return out;
};
var wrapTime = (t, dur, mode) => {
  if (dur <= 0) return 0;
  if (mode === "clamp-forever") return Math.max(0, Math.min(dur, t));
  if (mode === "loop") return (t % dur + dur) % dur;
  if (mode === "ping-pong") {
    const cycle = dur * 2;
    const m = (t % cycle + cycle) % cycle;
    return m > dur ? cycle - m : m;
  }
  return t;
};
var KeyframeEditor = class extends Control {
  // Public state — read by Physics for sample()/bake() round-trips.
  _clips;
  _activeId;
  _time = 0;
  _playing = false;
  _wrap;
  _speed;
  _view;
  _spacing;
  _selected = /* @__PURE__ */ new Set();
  _selectedNode = "";
  _selectedProp = "";
  _bindings = /* @__PURE__ */ new Map();
  // Callbacks
  _onChange;
  _onKeyframe;
  _onPlay;
  _onStop;
  // Runtime
  _loopRaf = 0;
  _lastT = 0;
  _drag = null;
  // DOM refs
  _elTrackCanvas;
  _elPropCanvas;
  _elTrackCtx;
  _elPropCtx;
  _elTimeReadout;
  _elDurReadout;
  _elClipSelect;
  _elWrapSelect;
  _elViewSelect;
  _elSpeedInput;
  _elSampleInput;
  _elSpacingInput;
  _elPlayBtn;
  constructor(container, opts = {}) {
    super(container, "div", {
      theme: "dark",
      wrapMode: "normal",
      speed: 1,
      view: "time",
      spacing: 1,
      ...opts
    });
    this.el.className = `ar-kfe${opts.class ? " " + opts.class : ""}`;
    this.el.dataset.theme = this._get("theme", "dark");
    this._clips = opts.clips && opts.clips.length ? opts.clips : [{ id: "anim-1", name: "animation1", sampleRate: 60, duration: 0.75, nodes: [] }];
    this._activeId = opts.activeClip ?? this._clips[0].id;
    this._wrap = this._get("wrapMode", "normal");
    this._speed = this._get("speed", 1);
    this._view = this._get("view", "time");
    this._spacing = this._get("spacing", 1);
    this._onChange = opts.onChange;
    this._onKeyframe = opts.onKeyframe;
    this._onPlay = opts.onPlay;
    this._onStop = opts.onStop;
    this._injectStyles();
  }
  // ── Public API ──────────────────────────────────────────────────────────────
  play() {
    if (this._playing) return this;
    this._playing = true;
    this._lastT = performance.now();
    this._tick();
    this._onPlay?.();
    this._emit("play", { time: this._time });
    this._refreshTransport();
    return this;
  }
  pause() {
    if (!this._playing) return this;
    this._playing = false;
    cancelAnimationFrame(this._loopRaf);
    this._emit("pause", { time: this._time });
    this._refreshTransport();
    return this;
  }
  stop() {
    this.pause();
    this._time = 0;
    this._applyBindings();
    this._renderCanvases();
    this._refreshReadouts();
    this._onStop?.();
    this._emit("stop", {});
    return this;
  }
  seek(t) {
    this._time = Math.max(0, t);
    this._applyBindings();
    this._renderCanvases();
    this._refreshReadouts();
    this._emit("seek", { time: this._time });
    return this;
  }
  step(framesDelta) {
    const clip = this._activeClip();
    if (!clip) return this;
    return this.seek(this._time + framesDelta / clip.sampleRate);
  }
  bind(nodeId, target) {
    this._bindings.set(nodeId, target);
    this._applyBindings();
    return this;
  }
  unbind(nodeId) {
    this._bindings.delete(nodeId);
    return this;
  }
  addClip(c) {
    this._clips = [...this._clips, c];
    this.refresh();
    return this;
  }
  setActiveClip(id) {
    this._activeId = id;
    this._time = 0;
    this.refresh();
    return this;
  }
  addKeyframe(nodeId, propertyId, k) {
    const node = this._activeClip()?.nodes.find((n) => n.id === nodeId);
    const prop = node?.properties.find((p) => p.id === propertyId);
    if (!prop) return this;
    prop.keyframes.push({ ...k });
    prop.keyframes.sort((a, b) => a.time - b.time);
    this._onKeyframe?.({ nodeId, propertyId, keyframe: k });
    this._renderCanvases();
    this._notifyChange();
    return this;
  }
  removeKeyframe(nodeId, propertyId, index) {
    const prop = this._activeClip()?.nodes.find((n) => n.id === nodeId)?.properties.find((p) => p.id === propertyId);
    if (!prop) return this;
    prop.keyframes.splice(index, 1);
    this._renderCanvases();
    this._notifyChange();
    return this;
  }
  /** Interpolated values for a property at time t (defaults to current time). */
  sample(nodeId, propertyId, t = this._time) {
    const clip = this._activeClip();
    if (!clip) return null;
    const prop = clip.nodes.find((n) => n.id === nodeId)?.properties.find((p) => p.id === propertyId);
    if (!prop || prop.keyframes.length === 0) return null;
    const ks = prop.keyframes;
    const tt = wrapTime(t, clip.duration, this._wrap);
    if (tt <= ks[0].time) return ks[0].values.slice();
    if (tt >= ks[ks.length - 1].time) return ks[ks.length - 1].values.slice();
    for (let i = 0; i < ks.length - 1; i++) {
      if (tt >= ks[i].time && tt < ks[i + 1].time) return interp(ks[i], ks[i + 1], tt);
    }
    return ks[ks.length - 1].values.slice();
  }
  getState() {
    return {
      activeClipId: this._activeId,
      currentTime: this._time,
      isPlaying: this._playing,
      selectedKeys: [...this._selected].map((k) => {
        const [nodeId, propertyId, idx] = k.split("|");
        return { nodeId, propertyId, index: +idx };
      })
    };
  }
  destroy() {
    cancelAnimationFrame(this._loopRaf);
    this._bindings.clear();
    super.destroy();
  }
  // ── Internals ──────────────────────────────────────────────────────────────
  _activeClip() {
    return this._clips.find((c) => c.id === this._activeId);
  }
  _build() {
    this.el.innerHTML = `
<div class="ar-kfe__tabs">
  <button class="ar-kfe__tab" data-r="tab-assets">Assets Preview</button>
  <button class="ar-kfe__tab" data-r="tab-console">Console</button>
  <button class="ar-kfe__tab ar-kfe__tab--on" data-r="tab-anim">Animation</button>
  <span class="ar-kfe__flex"></span>
  <button class="ar-kfe__icon" data-r="menu" title="Menu">&#9776;</button>
</div>

<div class="ar-kfe__toolbar">
  <label class="ar-kfe__lbl">Clips:</label>
  <select class="ar-kfe__select" data-r="clip-select"></select>

  <span class="ar-kfe__sep"></span>

  <button class="ar-kfe__icon" data-r="t-start" title="Go to start">&#9198;</button>
  <button class="ar-kfe__icon" data-r="t-prev"  title="Previous frame">&#9194;</button>
  <button class="ar-kfe__icon ar-kfe__icon--play" data-r="play" title="Play / pause">&#9654;</button>
  <button class="ar-kfe__icon" data-r="t-next"  title="Next frame">&#9193;</button>
  <button class="ar-kfe__icon" data-r="t-end"   title="Go to end">&#9197;</button>
  <button class="ar-kfe__icon" data-r="t-stop"  title="Stop">&#9209;</button>

  <span class="ar-kfe__sep"></span>

  <select class="ar-kfe__select" data-r="view-select">
    <option value="time">Time</option>
    <option value="frames">Frames</option>
  </select>
  <span class="ar-kfe__readout" data-r="time-readout">0-00</span>

  <span class="ar-kfe__flex"></span>

  <label class="ar-kfe__lbl">Spacing:</label>
  <input class="ar-kfe__num" data-r="spacing-input" type="number" min="1" max="10" step="1" value="1">

  <button class="ar-kfe__icon" data-r="grid"     title="Show grid">&#9783;</button>
  <button class="ar-kfe__icon" data-r="snap"     title="Snap">&#9889;</button>
  <button class="ar-kfe__icon" data-r="settings" title="Settings">&#9881;</button>
  <button class="ar-kfe__icon" data-r="export"   title="Export">&#9167;</button>
</div>

<div class="ar-kfe__row-hd">
  <span class="ar-kfe__col-title">Node List</span>
  <span class="ar-kfe__icon ar-kfe__icon--small" title="Visibility">&#9673;</span>
  <input class="ar-kfe__filter" placeholder="Enter">
</div>

<canvas class="ar-kfe__canvas ar-kfe__canvas--tracks" data-r="track-canvas"></canvas>

<div class="ar-kfe__row-hd">
  <span class="ar-kfe__col-title">Property List</span>
  <button class="ar-kfe__icon ar-kfe__icon--small" data-r="add-prop" title="Add property">+</button>
  <span class="ar-kfe__flex"></span>
  <span class="ar-kfe__prop-name" data-r="prop-channel"></span>
  <input class="ar-kfe__num ar-kfe__num--wide" data-r="prop-value" type="number" step="0.01">
</div>

<canvas class="ar-kfe__canvas ar-kfe__canvas--props" data-r="prop-canvas"></canvas>

<div class="ar-kfe__footer">
  <label class="ar-kfe__lbl">WrapMode</label>
  <select class="ar-kfe__select" data-r="wrap-select">
    <option value="normal">Normal</option>
    <option value="loop">Loop</option>
    <option value="ping-pong">Ping-pong</option>
    <option value="clamp-forever">Clamp forever</option>
  </select>

  <span class="ar-kfe__flex"></span>

  <label class="ar-kfe__lbl">Sample</label>
  <input class="ar-kfe__num" data-r="sample-input" type="number" min="1" max="240" step="1" value="60">

  <label class="ar-kfe__lbl">Speed</label>
  <input class="ar-kfe__num" data-r="speed-input" type="number" min="0.1" max="8" step="0.1" value="1">

  <label class="ar-kfe__lbl">Duration:</label>
  <span class="ar-kfe__readout" data-r="dur-readout">0.00 (0.00)s</span>
</div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elTrackCanvas = r("track-canvas");
    this._elPropCanvas = r("prop-canvas");
    this._elTrackCtx = this._elTrackCanvas.getContext("2d");
    this._elPropCtx = this._elPropCanvas.getContext("2d");
    this._elTimeReadout = r("time-readout");
    this._elDurReadout = r("dur-readout");
    this._elClipSelect = r("clip-select");
    this._elWrapSelect = r("wrap-select");
    this._elViewSelect = r("view-select");
    this._elSpeedInput = r("speed-input");
    this._elSampleInput = r("sample-input");
    this._elSpacingInput = r("spacing-input");
    this._elPlayBtn = r("play");
    this._elClipSelect.innerHTML = "";
    for (const c of this._clips) {
      const o = document.createElement("option");
      o.value = c.id;
      o.textContent = c.name;
      this._elClipSelect.appendChild(o);
    }
    this._elClipSelect.value = this._activeId;
    this._elWrapSelect.value = this._wrap;
    this._elViewSelect.value = this._view;
    this._elSpeedInput.value = String(this._speed);
    this._elSpacingInput.value = String(this._spacing);
    const clip = this._activeClip();
    if (clip) this._elSampleInput.value = String(clip.sampleRate);
    this._wireEvents();
    this._resizeCanvases();
    this._renderCanvases();
    this._refreshReadouts();
    this._refreshTransport();
  }
  _wireEvents() {
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._on(this._elPlayBtn, "click", () => this._playing ? this.pause() : this.play());
    this._on(r("t-stop"), "click", () => this.stop());
    this._on(r("t-prev"), "click", () => this.step(-1));
    this._on(r("t-next"), "click", () => this.step(1));
    this._on(r("t-start"), "click", () => this.seek(0));
    this._on(r("t-end"), "click", () => {
      const c = this._activeClip();
      if (c) this.seek(c.duration);
    });
    this._on(this._elClipSelect, "change", () => this.setActiveClip(this._elClipSelect.value));
    this._on(this._elWrapSelect, "change", () => {
      this._wrap = this._elWrapSelect.value;
      this._notifyChange();
    });
    this._on(this._elViewSelect, "change", () => {
      this._view = this._elViewSelect.value;
      this._renderCanvases();
      this._refreshReadouts();
    });
    this._on(this._elSpeedInput, "input", () => {
      this._speed = +this._elSpeedInput.value || 1;
      this._refreshReadouts();
      this._notifyChange();
    });
    this._on(this._elSpacingInput, "input", () => {
      this._spacing = +this._elSpacingInput.value || 1;
      this._renderCanvases();
    });
    this._on(this._elSampleInput, "input", () => {
      const v = +this._elSampleInput.value || 60;
      const c = this._activeClip();
      if (c) {
        c.sampleRate = v;
        this._refreshReadouts();
        this._notifyChange();
      }
    });
    for (const cv of [this._elTrackCanvas, this._elPropCanvas]) {
      this._on(cv, "mousedown", (e) => this._onMouseDown(e, cv));
      this._on(cv, "dblclick", (e) => this._onDblClick(e, cv));
      this._on(cv, "contextmenu", (e) => this._onContext(e));
    }
    this._on(window, "mousemove", (e) => this._onMouseMove(e));
    this._on(window, "mouseup", () => {
      this._drag = null;
    });
    this._on(window, "resize", () => {
      this._resizeCanvases();
      this._renderCanvases();
    });
  }
  _resizeCanvases() {
    const dpr = window.devicePixelRatio || 1;
    for (const c of [this._elTrackCanvas, this._elPropCanvas]) {
      const rect = c.getBoundingClientRect();
      c.width = Math.max(1, Math.round(rect.width * dpr));
      c.height = Math.max(1, Math.round(rect.height * dpr));
      c.getContext("2d").setTransform(dpr, 0, 0, dpr, 0, 0);
    }
  }
  _tick = () => {
    if (!this._playing) return;
    const now = performance.now();
    const dt = (now - this._lastT) / 1e3;
    this._lastT = now;
    const clip = this._activeClip();
    if (!clip) return;
    const next = this._time + dt * this._speed;
    if (this._wrap === "normal" && next >= clip.duration) {
      this._time = clip.duration;
      this._applyBindings();
      this._renderCanvases();
      this._refreshReadouts();
      this.pause();
      return;
    }
    this._time = wrapTime(next, clip.duration, this._wrap);
    this._applyBindings();
    this._renderCanvases();
    this._refreshReadouts();
    this._loopRaf = requestAnimationFrame(this._tick);
  };
  _applyBindings() {
    const clip = this._activeClip();
    if (!clip) return;
    for (const node of clip.nodes) {
      const target = this._bindings.get(node.id);
      if (!target) continue;
      for (const prop of node.properties) {
        const v = this.sample(node.id, prop.id);
        if (v) target.set(prop.id, v);
      }
    }
  }
  _notifyChange() {
    this._onChange?.(this.getState());
    this._emit("change", this.getState());
  }
  _refreshTransport() {
    if (this._elPlayBtn) this._elPlayBtn.innerHTML = this._playing ? "&#9208;" : "&#9654;";
  }
  _refreshReadouts() {
    const clip = this._activeClip();
    if (!clip) return;
    const frame = Math.round(this._time * clip.sampleRate);
    if (this._elTimeReadout) {
      this._elTimeReadout.textContent = this._view === "time" ? `${this._time.toFixed(2)}s` : `0-${String(frame).padStart(2, "0")}`;
    }
    if (this._elDurReadout) {
      const real = clip.duration / Math.max(1e-4, this._speed);
      this._elDurReadout.textContent = `${real.toFixed(2)} (${clip.duration.toFixed(2)})s`;
    }
  }
  // ── Rendering ──────────────────────────────────────────────────────────────
  _renderCanvases() {
    this._drawTrackLane();
    this._drawPropLane();
  }
  _drawTrackLane() {
    const ctx = this._elTrackCtx;
    const cv = this._elTrackCanvas;
    const W = cv.clientWidth, H = cv.clientHeight;
    const clip = this._activeClip();
    if (!clip) return;
    ctx.clearRect(0, 0, W, H);
    const PAD_L = 140;
    const T_TO_X = (t) => PAD_L + t / clip.duration * (W - PAD_L - 20);
    this._drawRuler(ctx, PAD_L, 0, W - 20, 24, clip.duration, clip.sampleRate);
    let y = 32;
    const ROW = 28;
    for (const node of clip.nodes) {
      ctx.fillStyle = node.id === this._selectedNode ? "rgba(30,74,122,0.7)" : "transparent";
      ctx.fillRect(0, y, PAD_L, ROW);
      ctx.fillStyle = "#dcdcdc";
      ctx.font = "12px sans-serif";
      ctx.textBaseline = "middle";
      ctx.fillText("\u25B8 " + node.label, 16, y + ROW / 2);
      const allTimes = /* @__PURE__ */ new Set();
      for (const p of node.properties) for (const k of p.keyframes) allTimes.add(k.time);
      for (const t of allTimes) this._drawDiamond(ctx, T_TO_X(t), y + ROW / 2, "#2c8df7", 6);
      y += ROW;
    }
    this._drawPlayhead(ctx, T_TO_X(this._time), 0, H);
  }
  _drawPropLane() {
    const ctx = this._elPropCtx;
    const cv = this._elPropCanvas;
    const W = cv.clientWidth, H = cv.clientHeight;
    const clip = this._activeClip();
    if (!clip) return;
    ctx.clearRect(0, 0, W, H);
    const PAD_L = 140;
    const T_TO_X = (t) => PAD_L + t / clip.duration * (W - PAD_L - 20);
    this._drawRuler(ctx, PAD_L, 0, W - 20, 20, clip.duration, clip.sampleRate);
    const node = clip.nodes.find((n) => n.id === this._selectedNode) ?? clip.nodes[0];
    if (!node) return;
    let y = 28;
    const ROW = 28;
    for (const prop of node.properties) {
      ctx.fillStyle = prop.id === this._selectedProp ? "rgba(30,74,122,0.7)" : "transparent";
      ctx.fillRect(0, y, PAD_L, ROW);
      ctx.fillStyle = "#dcdcdc";
      ctx.font = "12px sans-serif";
      ctx.textBaseline = "middle";
      ctx.fillText("\u25B8 " + prop.label, 16, y + ROW / 2);
      if (prop.keyframes.length >= 2) {
        ctx.strokeStyle = "rgba(44,141,247,0.28)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        const steps = 80;
        for (let s = 0; s <= steps; s++) {
          const tt = s / steps * clip.duration;
          const v = this.sample(node.id, prop.id, tt);
          if (!v) continue;
          const x = T_TO_X(tt);
          const yL = y + ROW - 6 - Math.min(18, Math.abs(v[0]) * 4);
          if (s === 0) ctx.moveTo(x, yL);
          else ctx.lineTo(x, yL);
        }
        ctx.stroke();
      }
      for (let i = 0; i < prop.keyframes.length; i++) {
        const k = prop.keyframes[i];
        const key = `${node.id}|${prop.id}|${i}`;
        const sel = this._selected.has(key);
        this._drawDiamond(
          ctx,
          T_TO_X(k.time),
          y + ROW / 2,
          sel ? "#ff3aa1" : "#2c8df7",
          sel ? 8 : 6
        );
      }
      y += ROW;
    }
    this._drawPlayhead(ctx, T_TO_X(this._time), 0, H);
  }
  _drawRuler(ctx, x0, y, x1, y1, dur, fps) {
    const W = x1 - x0;
    ctx.fillStyle = "#262932";
    ctx.fillRect(x0, y, W, y1 - y);
    ctx.fillStyle = "#8a8f98";
    ctx.font = "10px sans-serif";
    ctx.textBaseline = "middle";
    const step = dur / 10;
    for (let i = 0; i <= 10; i++) {
      const t = i * step;
      const xx = x0 + t / dur * W;
      ctx.fillRect(xx, y1 - 6, 1, 6);
      const frame = Math.round(t * fps);
      const label = this._view === "frames" ? `0-${String(frame).padStart(2, "0")}` : `${t.toFixed(2)}`;
      ctx.fillText(label, xx + 4, y + (y1 - y) / 2);
    }
  }
  _drawDiamond(ctx, cx, cy, color, size) {
    ctx.fillStyle = color;
    ctx.strokeStyle = "#0e0e10";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx, cy - size);
    ctx.lineTo(cx + size, cy);
    ctx.lineTo(cx, cy + size);
    ctx.lineTo(cx - size, cy);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  _drawPlayhead(ctx, x, y0, y1) {
    ctx.strokeStyle = "#ff3a3a";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y0);
    ctx.lineTo(x, y1);
    ctx.stroke();
    ctx.fillStyle = "#ff3a3a";
    ctx.beginPath();
    ctx.moveTo(x - 5, y0);
    ctx.lineTo(x + 5, y0);
    ctx.lineTo(x, y0 + 6);
    ctx.closePath();
    ctx.fill();
  }
  // ── Mouse interaction ──────────────────────────────────────────────────────
  _hitTest(e, cv) {
    const rect = cv.getBoundingClientRect();
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    const clip = this._activeClip();
    const PAD_L = 140;
    const W = cv.clientWidth;
    const x_to_t = (xx) => Math.max(0, Math.min(clip.duration, (xx - PAD_L) / (W - PAD_L - 20) * clip.duration));
    return { x, y, t: x_to_t(x), inLabel: x < PAD_L };
  }
  _onMouseDown(e, cv) {
    const clip = this._activeClip();
    if (!clip) return;
    const h = this._hitTest(e, cv);
    if (h.inLabel) {
      if (cv === this._elTrackCanvas) {
        const idx = Math.floor((h.y - 32) / 28);
        const node = clip.nodes[idx];
        if (node) {
          this._selectedNode = node.id;
          this._renderCanvases();
        }
      } else {
        const node = clip.nodes.find((n) => n.id === this._selectedNode) ?? clip.nodes[0];
        if (node) {
          const idx = Math.floor((h.y - 28) / 28);
          const prop = node.properties[idx];
          if (prop) {
            this._selectedProp = prop.id;
            this._renderCanvases();
          }
        }
      }
      return;
    }
    const PAD_L = 140;
    const T_TO_X = (t) => PAD_L + t / clip.duration * (cv.clientWidth - PAD_L - 20);
    const HIT = 7;
    if (cv === this._elPropCanvas) {
      const node = clip.nodes.find((n) => n.id === this._selectedNode) ?? clip.nodes[0];
      if (node) {
        for (let pi = 0; pi < node.properties.length; pi++) {
          const yRow = 28 + pi * 28 + 14;
          if (Math.abs(h.y - yRow) > HIT) continue;
          const prop = node.properties[pi];
          for (let ki = 0; ki < prop.keyframes.length; ki++) {
            const xk = T_TO_X(prop.keyframes[ki].time);
            if (Math.abs(h.x - xk) < HIT) {
              const key = `${node.id}|${prop.id}|${ki}`;
              if (e.shiftKey) {
                if (this._selected.has(key)) this._selected.delete(key);
                else this._selected.add(key);
              } else {
                this._selected.clear();
                this._selected.add(key);
              }
              this._drag = { kind: "keyframe", nodeId: node.id, propId: prop.id, keyIndex: ki };
              this._renderCanvases();
              return;
            }
          }
        }
      }
    }
    this._drag = { kind: "playhead" };
    this.seek(h.t);
  }
  _onMouseMove(e) {
    if (!this._drag) return;
    const cv = this._drag.kind === "keyframe" ? this._elPropCanvas : this._elTrackCanvas;
    const h = this._hitTest(e, cv);
    if (this._drag.kind === "playhead") {
      this.seek(h.t);
      return;
    }
    if (this._drag.kind === "keyframe") {
      const clip = this._activeClip();
      if (!clip) return;
      const prop = clip.nodes.find((n) => n.id === this._drag.nodeId)?.properties.find((p) => p.id === this._drag.propId);
      if (!prop) return;
      const k = prop.keyframes[this._drag.keyIndex];
      if (!k) return;
      k.time = Math.max(0, Math.min(clip.duration, h.t));
      prop.keyframes.sort((a, b) => a.time - b.time);
      this._renderCanvases();
      this._notifyChange();
    }
  }
  _onDblClick(e, cv) {
    const h = this._hitTest(e, cv);
    if (h.inLabel || cv !== this._elPropCanvas) return;
    const clip = this._activeClip();
    if (!clip) return;
    const node = clip.nodes.find((n) => n.id === this._selectedNode) ?? clip.nodes[0];
    if (!node) return;
    const pi = Math.floor((h.y - 28) / 28);
    const prop = node.properties[pi];
    if (!prop) return;
    const v = this.sample(node.id, prop.id, h.t) ?? prop.channels.map(() => 0);
    this.addKeyframe(node.id, prop.id, { time: h.t, values: v });
  }
  _onContext(e) {
    e.preventDefault();
    const menu = document.createElement("div");
    menu.className = "ar-kfe__menu";
    menu.style.left = e.clientX + "px";
    menu.style.top = e.clientY + "px";
    menu.innerHTML = `
      <div data-act="del">Delete keyframe(s)</div>
      <div data-act="copy">Copy</div>
      <div data-act="paste">Paste</div>
      <div class="ar-kfe__menu-sep"></div>
      <div data-act="ease-linear">Easing: Linear</div>
      <div data-act="ease-easeInQuad">Easing: Ease in (quad)</div>
      <div data-act="ease-easeOutQuad">Easing: Ease out (quad)</div>
      <div data-act="ease-easeInOutQuad">Easing: Ease in-out (quad)</div>
      <div data-act="ease-easeOutCubic">Easing: Ease out (cubic)</div>
      <div data-act="ease-easeOutBack">Easing: Ease out (back)</div>
      <div data-act="ease-easeOutBounce">Easing: Ease out (bounce)</div>
      <div data-act="ease-easeOutElastic">Easing: Ease out (elastic)</div>
      <div data-act="ease-step">Easing: Step</div>`;
    document.body.appendChild(menu);
    const close = () => {
      menu.remove();
      window.removeEventListener("click", close);
    };
    setTimeout(() => window.addEventListener("click", close), 0);
    menu.onclick = (ev) => {
      const act = ev.target.dataset.act;
      if (!act) return;
      const sel = [...this._selected];
      const clip = this._activeClip();
      if (!clip) {
        close();
        return;
      }
      if (act === "del") {
        const byProp = /* @__PURE__ */ new Map();
        for (const k of sel) {
          const [n, p, i] = k.split("|");
          const key = `${n}|${p}`;
          if (!byProp.has(key)) byProp.set(key, []);
          byProp.get(key).push(+i);
        }
        for (const [key, idxs] of byProp) {
          const [n, p] = key.split("|");
          const prop = clip.nodes.find((x) => x.id === n)?.properties.find((x) => x.id === p);
          if (!prop) continue;
          idxs.sort((a, b) => b - a).forEach((i) => prop.keyframes.splice(i, 1));
        }
        this._selected.clear();
      } else if (act.startsWith("ease-")) {
        const name = act.slice(5);
        for (const k of sel) {
          const [n, p, i] = k.split("|");
          const prop = clip.nodes.find((x) => x.id === n)?.properties.find((x) => x.id === p);
          if (prop) prop.keyframes[+i].easing = name;
        }
      }
      this._renderCanvases();
      this._notifyChange();
      close();
    };
  }
  // ── Styles ─────────────────────────────────────────────────────────────────
  _injectStyles() {
    if (document.getElementById("ar-kfe-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-kfe-styles";
    s.textContent = `
.ar-kfe {
  display:flex; flex-direction:column;
  background:#1e1e1e; color:#dcdcdc;
  font:12px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  border:1px solid #2a2a2a; border-radius:4px; overflow:hidden;
  min-height:420px; width:100%;
}
.ar-kfe[data-theme="light"] { background:#fafafa; color:#1c1e21; border-color:#d4d6db; }
.ar-kfe button { font:inherit; }
.ar-kfe input, .ar-kfe select {
  background:#2a2a2a; color:#dcdcdc; border:1px solid #3a3a3a;
  border-radius:3px; padding:3px 6px; font:inherit;
}
.ar-kfe[data-theme="light"] input, .ar-kfe[data-theme="light"] select {
  background:#fff; color:#1c1e21; border-color:#d4d6db;
}

.ar-kfe__tabs {
  display:flex; align-items:center; gap:4px;
  padding:4px 8px; background:#181818; border-bottom:1px solid #2a2a2a;
}
.ar-kfe[data-theme="light"] .ar-kfe__tabs { background:#ececec; border-bottom-color:#d4d6db; }
.ar-kfe__tab {
  background:transparent; color:#8a8f98; border:0;
  padding:6px 12px; cursor:pointer; border-radius:3px 3px 0 0;
}
.ar-kfe__tab--on { background:#2c8df7; color:#fff; }

.ar-kfe__toolbar, .ar-kfe__footer, .ar-kfe__row-hd {
  display:flex; align-items:center; gap:6px;
  padding:6px 8px; background:#232323; border-bottom:1px solid #2a2a2a;
}
.ar-kfe[data-theme="light"] .ar-kfe__toolbar,
.ar-kfe[data-theme="light"] .ar-kfe__footer,
.ar-kfe[data-theme="light"] .ar-kfe__row-hd { background:#f0f1f4; border-bottom-color:#d4d6db; }

.ar-kfe__flex { flex:1; }
.ar-kfe__sep  { width:1px; height:18px; background:#3a3a3a; margin:0 4px; }
.ar-kfe__lbl  { color:#8a8f98; font-size:11px; }
.ar-kfe__icon {
  background:transparent; color:#c0c4ca; border:1px solid transparent;
  padding:3px 7px; cursor:pointer; border-radius:3px; min-width:22px;
}
.ar-kfe__icon:hover { background:#2c8df7; color:#fff; }
.ar-kfe__icon--play { background:#2c8df7; color:#fff; }
.ar-kfe__icon--small { padding:1px 5px; font-size:10px; }
.ar-kfe__select { min-width:80px; }
.ar-kfe__num    { width:50px; text-align:right; }
.ar-kfe__num--wide { width:70px; }
.ar-kfe__readout   { font:11px 'SF Mono',Menlo,monospace; color:#8a8f98; }
.ar-kfe__col-title { color:#c0c4ca; font-weight:500; }
.ar-kfe__filter    { width:120px; }
.ar-kfe__prop-name { color:#2c8df7; font-weight:500; padding:2px 6px;
                     background:rgba(44,141,247,0.10); border-radius:3px; }

.ar-kfe__canvas--tracks { width:100%; height:140px; display:block; cursor:pointer; }
.ar-kfe__canvas--props  { width:100%; height:180px; display:block; cursor:pointer; }

.ar-kfe__menu {
  position:fixed; z-index:10000;
  background:#232323; color:#dcdcdc; border:1px solid #3a3a3a;
  border-radius:4px; padding:4px 0; min-width:200px;
  box-shadow:0 8px 24px rgba(0,0,0,.4);
  font:12px -apple-system,sans-serif;
}
.ar-kfe__menu > div { padding:6px 14px; cursor:pointer; }
.ar-kfe__menu > div:hover { background:#2c8df7; color:#fff; }
.ar-kfe__menu-sep { border-top:1px solid #3a3a3a; margin:4px 0;
                    padding:0 !important; cursor:default !important;
                    pointer-events:none; }
`;
    document.head.appendChild(s);
  }
};

// components/audio/AudioComponent.ts
var _sharedCtx;
function getSharedContext() {
  if (!_sharedCtx) {
    const Ctor = window.AudioContext || window.webkitAudioContext;
    _sharedCtx = new Ctor();
  }
  return _sharedCtx;
}
var AudioComponent = class _AudioComponent extends Control {
  /** Static accessor for the shared AudioContext. */
  static get context() {
    return getSharedContext();
  }
  /** Resume the shared context (call after user gesture). */
  static async resume() {
    const ctx = getSharedContext();
    if (ctx.state === "suspended") await ctx.resume();
  }
  /** Per-instance context (defaults to shared). */
  _audioCtx;
  /** Where signals enter this component. */
  _input;
  /** Where signals leave this component. */
  _output;
  /** Track active downstream connections for clean disconnect. */
  _downstream = /* @__PURE__ */ new Set();
  constructor(container, tag, opts) {
    super(container, tag, opts);
    this._audioCtx = opts.audioContext ?? getSharedContext();
  }
  /**
   * Connect this component's output to another audio destination.
   * Returns the destination so calls can chain:
   *   mic.connect(strip).connect(destination)
   */
  connect(target) {
    if (!this._output) {
      console.warn("[AudioComponent] no output node defined; subclass must assign this._output");
      return target;
    }
    const dst = target instanceof _AudioComponent ? target.getInput() : target;
    if (!dst) {
      console.warn("[AudioComponent] target has no input");
      return target;
    }
    this._output.connect(dst);
    this._downstream.add(dst);
    return target;
  }
  /** Disconnect from all downstream targets. */
  disconnect() {
    if (!this._output) return this;
    for (const dst of this._downstream) {
      try {
        this._output.disconnect(dst);
      } catch {
      }
    }
    this._downstream.clear();
    return this;
  }
  /** Get the input node for routing into this component. */
  getInput() {
    return this._input;
  }
  /** Get the output node for routing out of this component. */
  getOutput() {
    return this._output;
  }
  /** Get the shared/instance context. */
  getContext() {
    return this._audioCtx;
  }
};
async function resumeAudio() {
  return AudioComponent.resume();
}
function audioContext() {
  return AudioComponent.context;
}

// components/audio/PianoRoll.ts
var ROW_HEIGHT = 16;
var BEAT_WIDTH = 80;
var BEATS_PER_BAR = 4;
var NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
var BLACK_KEYS = /* @__PURE__ */ new Set([1, 3, 6, 8, 10]);
function noteName(pitch) {
  const oct = Math.floor(pitch / 12) - 1;
  return NOTE_NAMES[pitch % 12] + oct;
}
var PianoRoll = class extends Control {
  // State
  _notes = [];
  _nextId = 1;
  _runState = "idle";
  _tool = "draw";
  _selected = /* @__PURE__ */ new Set();
  _showVel;
  // Playback
  _playhead = 0;
  // beats
  _playStart = 0;
  // performance.now() reference
  _playRAF = 0;
  _activeKeys = /* @__PURE__ */ new Set();
  // pitch+id to track active
  _eventLog = [];
  // Loop state — Task B (Loop selection). Stored in BEATS (the PianoRoll's
  // native time unit), not seconds. Convert via bpm if needed.
  _loop = { start: 0, end: 0, enabled: false };
  _elLoopRange;
  _elLoopHandleLeft;
  _elLoopHandleRight;
  // DOM
  _elKeys;
  _elRuler;
  _elCanvas;
  _elGridBg;
  _elVel;
  _elPlayhead;
  _elEvents;
  _elStatus;
  _elToolBtns = {};
  _elBpm;
  _elBars;
  _elSnap;
  _elVelToggle;
  constructor(container, opts = {}) {
    super(container, "div", {
      bpm: 120,
      bars: 8,
      pitchLow: 36,
      pitchHigh: 96,
      snap: 0.25,
      showToolbar: true,
      showVelocity: true,
      showEvents: true,
      ...opts
    });
    this.el.className = `ar-pianoroll${opts.class ? " " + opts.class : ""}`;
    this._showVel = this._get("showVelocity", true);
    this._injectStyles();
    this._buildShell();
    this._buildKeyboard();
    this._buildRuler();
    this._buildGrid();
    this._renderEvents();
    if (opts.initialSequence) {
      queueMicrotask(() => this.load(opts.initialSequence));
    }
    queueMicrotask(() => {
      this._elCanvas.scrollTop = this._pitchToY(72) - 100;
    });
    this._on(document, "keydown", (e) => {
      if (!this.el.contains(document.activeElement) && document.activeElement !== document.body) return;
      const tg = e.target;
      if (tg.tagName === "INPUT" || tg.tagName === "SELECT") return;
      if (e.key === "d" || e.key === "D") this.setTool("draw");
      if (e.key === "s" || e.key === "S") this.setTool("select");
      if (e.key === "e" || e.key === "E") this.setTool("erase");
      if (e.key === " ") {
        e.preventDefault();
        if (this._runState === "running") this.pause();
        else this.play();
      }
      if (e.key === "Delete" || e.key === "Backspace") {
        for (const id of [...this._selected]) this.removeNote(id);
      }
    });
  }
  // ── Public API ──────────────────────────────────────────────────────────
  /** Add a note. Returns its generated id. */
  addNote(pitch, start, duration, velocity = 100, channel = 1) {
    const note = {
      id: `n${this._nextId++}`,
      pitch,
      start,
      duration,
      velocity,
      channel
    };
    this._notes.push(note);
    this._renderNote(note);
    this._renderVelocity();
    this._emit("change", { reason: "add-note", note });
    return note.id;
  }
  /** Remove a note by id. */
  removeNote(id) {
    this._notes = this._notes.filter((n) => n.id !== id);
    this._selected.delete(id);
    this.el.querySelector(`[data-note-id="${CSS.escape(id)}"]`)?.remove();
    this._renderVelocity();
    this._emit("change", { reason: "remove-note", id });
  }
  /** Update a note's properties. */
  updateNote(id, patch) {
    const note = this._notes.find((n) => n.id === id);
    if (!note) return;
    Object.assign(note, patch);
    const el = this.el.querySelector(`[data-note-id="${CSS.escape(id)}"]`);
    if (el) {
      el.style.left = this._beatToX(note.start) + "px";
      el.style.top = this._pitchToY(note.pitch) + "px";
      el.style.width = this._beatToX(note.duration) + "px";
      el.style.height = ROW_HEIGHT + "px";
      const lbl = el.querySelector(".ar-pianoroll__note-lbl");
      if (lbl) lbl.textContent = noteName(note.pitch);
    }
    this._renderVelocity();
    this._emit("change", { reason: "update-note", id });
  }
  /** Clear all notes. */
  clear() {
    this.el.querySelectorAll(".ar-pianoroll__note").forEach((n) => n.remove());
    this._notes = [];
    this._selected.clear();
    this._renderVelocity();
    this._emit("change", { reason: "clear" });
  }
  /** Set active tool. */
  setTool(t) {
    this._tool = t;
    for (const k of Object.keys(this._elToolBtns)) {
      this._elToolBtns[k].classList.toggle("active", k === t);
    }
    this._elCanvas.style.cursor = t === "draw" ? "crosshair" : t === "erase" ? "not-allowed" : "default";
  }
  getTool() {
    return this._tool;
  }
  /** Start playback. */
  play() {
    if (this._runState === "running") return;
    this._runState = "running";
    this._refreshStatus();
    this._elPlayhead.style.display = "block";
    const bpm = this._get("bpm", 120);
    this._playStart = performance.now() - this._playhead / (bpm / 60) * 1e3;
    this._activeKeys.clear();
    this._tick();
    this._emit("run-state", { state: "running" });
  }
  /** Pause playback. Resume keeps current position. */
  pause() {
    if (this._runState !== "running") return;
    this._runState = "paused";
    this._refreshStatus();
    if (this._playRAF) cancelAnimationFrame(this._playRAF);
    for (const key of this._activeKeys) {
      const pitch = parseInt(key.split(":")[0], 10);
      this._fireMidi("note-off", pitch, 0, 1);
    }
    this._activeKeys.clear();
    this._emit("run-state", { state: "paused" });
  }
  /** Stop and rewind. */
  stop() {
    this._runState = "idle";
    this._refreshStatus();
    this._playhead = 0;
    this._elPlayhead.style.display = "none";
    if (this._playRAF) cancelAnimationFrame(this._playRAF);
    for (const key of this._activeKeys) {
      const pitch = parseInt(key.split(":")[0], 10);
      this._fireMidi("note-off", pitch, 0, 1);
    }
    this._activeKeys.clear();
    this._emit("run-state", { state: "idle" });
  }
  getRunState() {
    return this._runState;
  }
  getNotes() {
    return this._notes.map((n) => ({
      pitch: n.pitch,
      start: n.start,
      duration: n.duration,
      velocity: n.velocity,
      channel: n.channel
    }));
  }
  /** Manually trigger a note (e.g. from UI key click). */
  triggerNote(pitch, velocity = 100, channel = 1) {
    this._fireMidi("note-on", pitch, velocity, channel);
  }
  releaseNote(pitch, channel = 1) {
    this._fireMidi("note-off", pitch, 0, channel);
  }
  /** Export sequence as round-trippable JSON. */
  export() {
    return {
      bpm: this._get("bpm", 120),
      bars: this._get("bars", 8),
      timeSig: [4, 4],
      notes: this._notes.map((n) => ({
        pitch: n.pitch,
        start: n.start,
        duration: n.duration,
        velocity: n.velocity,
        channel: n.channel
      }))
    };
  }
  /** Load a sequence, replacing current notes. */
  load(seq) {
    this.clear();
    this._set("bpm", seq.bpm);
    this._set("bars", seq.bars);
    this._elBpm.value = String(seq.bpm);
    this._elBars.value = String(seq.bars);
    this._buildRuler();
    this._buildGrid();
    for (const n of seq.notes) {
      this.addNote(n.pitch, n.start, n.duration, n.velocity, n.channel ?? 1);
    }
  }
  // ── Coordinate helpers ──────────────────────────────────────────────────
  _pitchToY(p) {
    return (this._get("pitchHigh", 96) - p) * ROW_HEIGHT;
  }
  _yToPitch(y) {
    return this._get("pitchHigh", 96) - Math.floor(y / ROW_HEIGHT);
  }
  _beatToX(b) {
    return b * BEAT_WIDTH;
  }
  _xToBeat(x) {
    return x / BEAT_WIDTH;
  }
  _snapBeat(b) {
    const s = this._get("snap", 0.25);
    return Math.round(b / s) * s;
  }
  // ── DOM construction ────────────────────────────────────────────────────
  _build() {
  }
  _buildShell() {
    const showToolbar = this._get("showToolbar", true);
    this.el.innerHTML = (showToolbar ? `
<div class="ar-pianoroll__toolbar">
  <h3 class="ar-pianoroll__title">PianoRoll</h3>
  <span class="ar-pianoroll__status" data-r="status">\u2014 idle</span>
  <div style="width:14px"></div>
  <button class="ar-pianoroll__tool-btn active" data-r="tool-draw">\u270F Draw</button>
  <button class="ar-pianoroll__tool-btn"        data-r="tool-select">\u2316 Select</button>
  <button class="ar-pianoroll__tool-btn"        data-r="tool-erase">\u232B Erase</button>
  <div style="width:14px"></div>
  <span class="ar-pianoroll__lbl">Snap</span>
  <select class="ar-pianoroll__input" data-r="snap" style="width:auto">
    <option value="0.0625">1/16</option>
    <option value="0.125">1/8</option>
    <option value="0.25" selected>1/4</option>
    <option value="0.5">1/2</option>
    <option value="1">1/1</option>
  </select>
  <span class="ar-pianoroll__lbl">BPM</span>
  <input type="number" class="ar-pianoroll__input" data-r="bpm" min="20" max="300">
  <span class="ar-pianoroll__lbl">Bars</span>
  <input type="number" class="ar-pianoroll__input" data-r="bars" min="1" max="64">
  <div style="flex:1"></div>
  <button class="ar-pianoroll__btn play"  data-r="play">\u25B6 Play</button>
  <button class="ar-pianoroll__btn pause" data-r="pause">\u2016 Pause</button>
  <button class="ar-pianoroll__btn stop"  data-r="stop">\u25A0 Stop</button>
  <div style="width:14px"></div>
  <button class="ar-pianoroll__btn" data-r="clear">Clear</button>
  <button class="ar-pianoroll__btn" data-r="export">Export JSON</button>
</div>
` : "") + `
<div class="ar-pianoroll__grid">
  <div class="ar-pianoroll__corner"></div>
  <div class="ar-pianoroll__ruler" data-r="ruler"></div>
  <div class="ar-pianoroll__keys"  data-r="keys"></div>
  <div class="ar-pianoroll__canvas" data-r="canvas">
    <div class="ar-pianoroll__grid-bg" data-r="grid-bg"></div>
    <div class="ar-pianoroll__vel"     data-r="vel"></div>
    <button class="ar-pianoroll__vel-toggle" data-r="vel-toggle">\u25BC Velocity</button>
    <div class="ar-pianoroll__playhead" data-r="playhead" style="display:none"></div>
  </div>
</div>` + (this._get("showEvents", true) ? `
<div class="ar-pianoroll__events" data-r="events">
  <div class="ar-pianoroll__events-ttl">MIDI Events</div>
  <div data-r="events-list" style="color:#888">(no events yet \u2014 press Play)</div>
</div>` : "");
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elKeys = r("keys");
    this._elRuler = r("ruler");
    this._elCanvas = r("canvas");
    this._elGridBg = r("grid-bg");
    this._elVel = r("vel");
    this._elPlayhead = r("playhead");
    if (this._get("showEvents", true)) this._elEvents = r("events-list");
    if (showToolbar) {
      this._elStatus = r("status");
      this._elBpm = r("bpm");
      this._elBars = r("bars");
      this._elSnap = r("snap");
      this._elVelToggle = r("vel-toggle");
      this._elBpm.value = String(this._get("bpm", 120));
      this._elBars.value = String(this._get("bars", 8));
      this._elSnap.value = String(this._get("snap", 0.25));
      this._elToolBtns = {
        draw: r("tool-draw"),
        select: r("tool-select"),
        erase: r("tool-erase")
      };
      this._elToolBtns.draw.addEventListener("click", () => this.setTool("draw"));
      this._elToolBtns.select.addEventListener("click", () => this.setTool("select"));
      this._elToolBtns.erase.addEventListener("click", () => this.setTool("erase"));
      r("play").addEventListener("click", () => this.play());
      r("pause").addEventListener("click", () => this.pause());
      r("stop").addEventListener("click", () => this.stop());
      r("clear").addEventListener("click", () => {
        if (confirm("Clear all notes?")) this.clear();
      });
      r("export").addEventListener("click", () => this._exportFile());
      this._elBpm.addEventListener("change", () => this._set("bpm", parseInt(this._elBpm.value, 10)));
      this._elBars.addEventListener("change", () => {
        this._set("bars", parseInt(this._elBars.value, 10));
        this._buildRuler();
        this._buildGrid();
      });
      this._elSnap.addEventListener("change", () => {
        this._set("snap", parseFloat(this._elSnap.value));
        this._buildGrid();
      });
      this._elVelToggle?.addEventListener("click", () => {
        this._showVel = !this._showVel;
        this._elVel.style.display = this._showVel ? "block" : "none";
        if (this._elVelToggle)
          this._elVelToggle.textContent = this._showVel ? "\u25BC Velocity" : "\u25B2 Velocity";
      });
    }
    this._elCanvas.addEventListener("pointerdown", (e) => this._onCanvasDown(e));
    this._elRuler.addEventListener("pointerdown", (e) => this._onRulerDown(e));
    this._elCanvas.addEventListener("scroll", () => {
      this._elKeys.scrollTop = this._elCanvas.scrollTop;
      this._elRuler.scrollLeft = this._elCanvas.scrollLeft;
    });
  }
  _buildKeyboard() {
    this._elKeys.innerHTML = "";
    const lo = this._get("pitchLow", 36);
    const hi = this._get("pitchHigh", 96);
    const totalH = (hi - lo + 1) * ROW_HEIGHT;
    this._elKeys.style.height = totalH + "px";
    for (let p = hi; p >= lo; p--) {
      const k = document.createElement("div");
      k.className = "ar-pianoroll__key " + (BLACK_KEYS.has(p % 12) ? "black" : "white");
      k.style.top = this._pitchToY(p) + "px";
      k.style.height = ROW_HEIGHT + "px";
      if (p % 12 === 0 || p % 12 === 7) k.textContent = noteName(p);
      k.dataset.pitch = String(p);
      k.addEventListener("mousedown", (e) => {
        e.preventDefault();
        this.triggerNote(p, 100);
        const onUp = () => {
          this.releaseNote(p);
          document.removeEventListener("mouseup", onUp);
        };
        document.addEventListener("mouseup", onUp);
      });
      this._elKeys.appendChild(k);
    }
  }
  _buildRuler() {
    this._elRuler.innerHTML = "";
    const totalBeats = this._get("bars", 8) * BEATS_PER_BAR;
    this._elRuler.style.width = this._beatToX(totalBeats) + "px";
    for (let beat = 0; beat <= totalBeats; beat++) {
      const tick = document.createElement("div");
      tick.className = "ar-pianoroll__tick" + (beat % BEATS_PER_BAR === 0 ? " bar" : "");
      tick.style.left = this._beatToX(beat) + "px";
      this._elRuler.appendChild(tick);
      if (beat % BEATS_PER_BAR === 0) {
        const lbl = document.createElement("div");
        lbl.className = "ar-pianoroll__tick-lbl";
        lbl.style.left = this._beatToX(beat) + 2 + "px";
        lbl.textContent = String(beat / BEATS_PER_BAR + 1);
        this._elRuler.appendChild(lbl);
      }
    }
    this._renderLoopOverlay();
  }
  /** Render the loop-range overlay + 2 resize handles. Beats-based. */
  _renderLoopOverlay() {
    if (this._elLoopRange) this._elLoopRange.remove();
    if (this._elLoopHandleLeft) this._elLoopHandleLeft.remove();
    if (this._elLoopHandleRight) this._elLoopHandleRight.remove();
    this._elLoopRange = this._elLoopHandleLeft = this._elLoopHandleRight = void 0;
    if (!this._loop.enabled || this._loop.end <= this._loop.start) return;
    const left = this._beatToX(this._loop.start);
    const width = this._beatToX(this._loop.end - this._loop.start);
    const range = document.createElement("div");
    range.className = "ar-pianoroll__loop-range";
    range.style.left = left + "px";
    range.style.width = width + "px";
    this._elRuler.appendChild(range);
    const hL = document.createElement("div");
    hL.className = "ar-pianoroll__loop-handle ar-pianoroll__loop-handle--left";
    hL.style.left = left + "px";
    this._elRuler.appendChild(hL);
    const hR = document.createElement("div");
    hR.className = "ar-pianoroll__loop-handle ar-pianoroll__loop-handle--right";
    hR.style.left = left + width + "px";
    this._elRuler.appendChild(hR);
    this._elLoopRange = range;
    this._elLoopHandleLeft = hL;
    this._elLoopHandleRight = hR;
    hL.addEventListener("pointerdown", (e) => this._onLoopHandleDown(e, "left"));
    hR.addEventListener("pointerdown", (e) => this._onLoopHandleDown(e, "right"));
    range.addEventListener("pointerdown", (e) => this._onLoopRangeDown(e));
  }
  _onLoopHandleDown(e, which) {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startLoop = { ...this._loop };
    const handle = e.currentTarget;
    handle.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const dt = this._xToBeat(ev.clientX - startX);
      if (which === "left") {
        this._loop.start = Math.max(0, Math.min(startLoop.start + dt, this._loop.end - 0.05));
      } else {
        this._loop.end = Math.max(this._loop.start + 0.05, startLoop.end + dt);
      }
      this._renderLoopOverlay();
    };
    const onUp = () => {
      handle.removeEventListener("pointermove", onMove);
      handle.removeEventListener("pointerup", onUp);
      this._emit("change", { kind: "loop", loop: { ...this._loop } });
    };
    handle.addEventListener("pointermove", onMove);
    handle.addEventListener("pointerup", onUp);
  }
  _onLoopRangeDown(e) {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startLoop = { ...this._loop };
    const range = e.currentTarget;
    range.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const dt = this._xToBeat(ev.clientX - startX);
      const len = startLoop.end - startLoop.start;
      this._loop.start = Math.max(0, startLoop.start + dt);
      this._loop.end = this._loop.start + len;
      this._renderLoopOverlay();
    };
    const onUp = () => {
      range.removeEventListener("pointermove", onMove);
      range.removeEventListener("pointerup", onUp);
      this._emit("change", { kind: "loop", loop: { ...this._loop } });
    };
    range.addEventListener("pointermove", onMove);
    range.addEventListener("pointerup", onUp);
  }
  /**
   * Pointer-down on the ruler. Shift+drag → create loop range; plain click
   * → seek the playhead (in beats).
   */
  _onRulerDown(e) {
    const target = e.target;
    if (target.classList.contains("ar-pianoroll__loop-range") || target.classList.contains("ar-pianoroll__loop-handle")) return;
    const rect = this._elRuler.getBoundingClientRect();
    const x0 = e.clientX - rect.left + this._elRuler.scrollLeft;
    const b0 = this._xToBeat(x0);
    if (e.shiftKey) {
      e.preventDefault();
      e.stopPropagation();
      this._loop.start = b0;
      this._loop.end = b0 + 1e-3;
      this._loop.enabled = true;
      this._renderLoopOverlay();
      this._elRuler.setPointerCapture(e.pointerId);
      const onMove = (ev) => {
        const x = ev.clientX - rect.left + this._elRuler.scrollLeft;
        const b = this._xToBeat(x);
        if (b >= b0) {
          this._loop.start = b0;
          this._loop.end = b;
        } else {
          this._loop.start = b;
          this._loop.end = b0;
        }
        this._renderLoopOverlay();
      };
      const onUp = () => {
        this._elRuler.removeEventListener("pointermove", onMove);
        this._elRuler.removeEventListener("pointerup", onUp);
        if (this._loop.end - this._loop.start < 0.05) {
          this._loop = { start: 0, end: 0, enabled: false };
          this._renderLoopOverlay();
        }
        this._emit("change", { kind: "loop", loop: { ...this._loop } });
      };
      this._elRuler.addEventListener("pointermove", onMove);
      this._elRuler.addEventListener("pointerup", onUp);
      return;
    }
    this._playhead = Math.max(0, b0);
    this._elPlayhead.style.left = this._beatToX(this._playhead) + "px";
    this._elPlayhead.style.display = "block";
  }
  // ── Loop API (Task B) ──────────────────────────────────────────────────
  /** Get the current loop range (start, end in beats; enabled flag). */
  getLoop() {
    return { ...this._loop };
  }
  /** Define and enable the loop range. Values are in beats. */
  setLoop(loop) {
    this._loop.start = Math.max(0, loop.start);
    if (loop.end !== void 0) this._loop.end = Math.max(this._loop.start + 0.05, loop.end);
    if (loop.enabled !== void 0) this._loop.enabled = loop.enabled;
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  enableLoop(enabled) {
    this._loop.enabled = enabled;
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  clearLoop() {
    this._loop = { start: 0, end: 0, enabled: false };
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  _buildGrid() {
    const lo = this._get("pitchLow", 36);
    const hi = this._get("pitchHigh", 96);
    const totalBeats = this._get("bars", 8) * BEATS_PER_BAR;
    const totalH = (hi - lo + 1) * ROW_HEIGHT;
    const totalW = this._beatToX(totalBeats);
    this._elGridBg.style.width = totalW + "px";
    this._elGridBg.style.height = totalH + "px";
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("width", String(totalW));
    svg.setAttribute("height", String(totalH));
    svg.style.cssText = "position:absolute;inset:0;pointer-events:none";
    for (let p = hi; p >= lo; p--) {
      if (BLACK_KEYS.has(p % 12)) {
        const r = document.createElementNS(ns, "rect");
        r.setAttribute("x", "0");
        r.setAttribute("y", String(this._pitchToY(p)));
        r.setAttribute("width", String(totalW));
        r.setAttribute("height", String(ROW_HEIGHT));
        r.setAttribute("fill", "#f6f6f6");
        svg.appendChild(r);
      }
    }
    for (let p = lo; p <= hi; p++) {
      const y = this._pitchToY(p);
      const line = document.createElementNS(ns, "line");
      line.setAttribute("x1", "0");
      line.setAttribute("x2", String(totalW));
      line.setAttribute("y1", String(y));
      line.setAttribute("y2", String(y));
      line.setAttribute("stroke", p % 12 === 0 ? "#bbb" : "#eee");
      line.setAttribute("stroke-width", p % 12 === 0 ? "1" : "0.5");
      svg.appendChild(line);
    }
    for (let beat = 0; beat <= totalBeats; beat++) {
      const x = this._beatToX(beat);
      const line = document.createElementNS(ns, "line");
      line.setAttribute("x1", String(x));
      line.setAttribute("x2", String(x));
      line.setAttribute("y1", "0");
      line.setAttribute("y2", String(totalH));
      line.setAttribute("stroke", beat % BEATS_PER_BAR === 0 ? "#bbb" : "#e8e8e8");
      line.setAttribute("stroke-width", beat % BEATS_PER_BAR === 0 ? "1" : "0.5");
      svg.appendChild(line);
    }
    const snap = this._get("snap", 0.25);
    if (snap < 1) {
      for (let beat = 0; beat <= totalBeats; beat += snap) {
        if (Math.abs(beat - Math.round(beat)) < 1e-3) continue;
        const x = this._beatToX(beat);
        const line = document.createElementNS(ns, "line");
        line.setAttribute("x1", String(x));
        line.setAttribute("x2", String(x));
        line.setAttribute("y1", "0");
        line.setAttribute("y2", String(totalH));
        line.setAttribute("stroke", "#f4f4f4");
        line.setAttribute("stroke-width", "0.5");
        svg.appendChild(line);
      }
    }
    this._elGridBg.innerHTML = "";
    this._elGridBg.appendChild(svg);
  }
  // ── Pointer interactions ────────────────────────────────────────────────
  _onCanvasDown(e) {
    const target = e.target;
    if (target.closest(".ar-pianoroll__note")) return;
    const rect = this._elCanvas.getBoundingClientRect();
    const x = e.clientX - rect.left + this._elCanvas.scrollLeft;
    const y = e.clientY - rect.top + this._elCanvas.scrollTop;
    const pitch = this._yToPitch(y);
    const startBeat = this._snapBeat(this._xToBeat(x));
    if (this._tool === "draw") {
      const lo = this._get("pitchLow", 36);
      const hi = this._get("pitchHigh", 96);
      if (pitch < lo || pitch > hi) return;
      const id = this.addNote(pitch, startBeat, this._get("snap", 0.25), 100);
      const note = this._notes.find((n) => n.id === id);
      const noteEl = this.el.querySelector(`[data-note-id="${CSS.escape(id)}"]`);
      this._startResize(note, noteEl, e);
    } else if (this._tool === "select") {
      if (!e.shiftKey) {
        this._selected.clear();
        this.el.querySelectorAll(".ar-pianoroll__note.selected").forEach((n) => n.classList.remove("selected"));
      }
    }
  }
  _renderNote(note) {
    const el = document.createElement("div");
    el.className = "ar-pianoroll__note";
    el.dataset.noteId = note.id;
    el.style.left = this._beatToX(note.start) + "px";
    el.style.top = this._pitchToY(note.pitch) + "px";
    el.style.width = this._beatToX(note.duration) + "px";
    el.style.height = ROW_HEIGHT + "px";
    el.style.opacity = (0.4 + 0.6 * (note.velocity / 127)).toFixed(2);
    const lbl = document.createElement("span");
    lbl.className = "ar-pianoroll__note-lbl";
    lbl.textContent = noteName(note.pitch);
    el.appendChild(lbl);
    const handle = document.createElement("div");
    handle.className = "ar-pianoroll__note-resize";
    el.appendChild(handle);
    if (this._selected.has(note.id)) el.classList.add("selected");
    el.addEventListener("pointerdown", (e) => this._onNoteDown(e, note, el, handle));
    this._elCanvas.appendChild(el);
  }
  _onNoteDown(e, note, el, handle) {
    e.preventDefault();
    e.stopPropagation();
    if (this._tool === "erase") {
      this.removeNote(note.id);
      return;
    }
    if (e.target === handle) {
      this._startResize(note, el, e);
      return;
    }
    if (!this._selected.has(note.id)) {
      if (!e.shiftKey) {
        this._selected.clear();
        this.el.querySelectorAll(".ar-pianoroll__note.selected").forEach((n) => n.classList.remove("selected"));
      }
      this._selected.add(note.id);
      el.classList.add("selected");
    }
    const startMouseX = e.clientX, startMouseY = e.clientY;
    const startBeat = note.start, startPitch = note.pitch;
    el.setPointerCapture(e.pointerId);
    const lo = this._get("pitchLow", 36);
    const hi = this._get("pitchHigh", 96);
    const onMove = (ev) => {
      const dx = ev.clientX - startMouseX;
      const dy = ev.clientY - startMouseY;
      const newBeat = this._snapBeat(startBeat + this._xToBeat(dx));
      const newPitch = startPitch + Math.round(-dy / ROW_HEIGHT);
      if (newPitch < lo || newPitch > hi) return;
      this.updateNote(note.id, { start: Math.max(0, newBeat), pitch: newPitch });
    };
    const onUp = () => {
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onUp);
    };
    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerup", onUp);
  }
  _startResize(note, el, e) {
    e.preventDefault();
    const startMouseX = e.clientX;
    const startDur = note.duration;
    const minDur = this._get("snap", 0.25);
    el.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const dx = ev.clientX - startMouseX;
      const newDur = this._snapBeat(Math.max(minDur, startDur + this._xToBeat(dx)));
      this.updateNote(note.id, { duration: newDur });
    };
    const onUp = () => {
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onUp);
    };
    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerup", onUp);
  }
  // ── Velocity lane ───────────────────────────────────────────────────────
  _renderVelocity() {
    this._elVel.innerHTML = "";
    if (!this._showVel) return;
    const totalBeats = this._get("bars", 8) * BEATS_PER_BAR;
    this._elVel.style.width = this._beatToX(totalBeats) + "px";
    for (const note of this._notes) {
      const bar = document.createElement("div");
      bar.className = "ar-pianoroll__vel-bar";
      bar.style.left = this._beatToX(note.start) + "px";
      bar.style.height = note.velocity / 127 * 60 + "px";
      bar.title = `vel ${note.velocity}`;
      this._elVel.appendChild(bar);
    }
  }
  // ── Playback ────────────────────────────────────────────────────────────
  _tick = () => {
    const bpm = this._get("bpm", 120);
    const totalBeats = this._get("bars", 8) * BEATS_PER_BAR;
    const now = performance.now();
    const elapsed = (now - this._playStart) / 1e3;
    this._playhead = elapsed * (bpm / 60);
    if (this._loop.enabled && this._loop.end > this._loop.start && this._playhead >= this._loop.end) {
      for (const key of this._activeKeys) {
        const [p] = key.split(":");
        this._fireMidi("note-off", parseInt(p, 10), 0, 1);
      }
      this._activeKeys.clear();
      const beatToSec = 60 / bpm;
      this._playStart = now - this._loop.start * beatToSec * 1e3;
      this._playhead = this._loop.start;
      this._emit("loop-wrap", { start: this._loop.start, end: this._loop.end });
    }
    if (this._playhead >= totalBeats) {
      this.stop();
      return;
    }
    this._elPlayhead.style.left = this._beatToX(this._playhead) + "px";
    for (const note of this._notes) {
      const key = note.pitch + ":" + note.id;
      const inRange = this._playhead >= note.start && this._playhead < note.start + note.duration;
      if (inRange && !this._activeKeys.has(key)) {
        this._fireMidi("note-on", note.pitch, note.velocity, note.channel ?? 1);
        this._activeKeys.add(key);
      } else if (!inRange && this._activeKeys.has(key)) {
        this._fireMidi("note-off", note.pitch, 0, note.channel ?? 1);
        this._activeKeys.delete(key);
      }
    }
    this._playRAF = requestAnimationFrame(this._tick);
  };
  // ── MIDI events ─────────────────────────────────────────────────────────
  _fireMidi(type, pitch, velocity, channel) {
    const evt = { type, pitch, velocity, channel, time: performance.now() };
    this._eventLog.unshift(evt);
    if (this._eventLog.length > 30) this._eventLog.length = 30;
    this._renderEvents();
    this._emit("midi", evt);
  }
  _renderEvents() {
    if (!this._elEvents) return;
    if (this._eventLog.length === 0) {
      this._elEvents.innerHTML = '<span style="color:#888">(no events yet)</span>';
      return;
    }
    this._elEvents.innerHTML = this._eventLog.map((e) => {
      const t = (e.time / 1e3 % 100).toFixed(2);
      const color = e.type === "note-on" ? "#ffab40" : "#888";
      return `<div class="ar-pianoroll__events-row"><span class="t">${t}</span><span class="ev" style="color:${color}">${e.type} ${noteName(e.pitch)} v${e.velocity}</span></div>`;
    }).join("");
  }
  // ── Status & file export ────────────────────────────────────────────────
  _refreshStatus() {
    if (!this._elStatus) return;
    const map = {
      idle: ["\u2014 idle", "#888"],
      running: ["\u2014 running", "#16a34a"],
      paused: ["\u2014 paused", "#eab308"]
    };
    const [t, c] = map[this._runState];
    this._elStatus.textContent = t;
    this._elStatus.style.color = c;
  }
  _exportFile() {
    const blob = new Blob(
      [JSON.stringify(this.export(), null, 2)],
      { type: "application/json" }
    );
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "sequence.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 0);
  }
  // ── Stylesheet (auto-injected once) ─────────────────────────────────────
  _injectStyles() {
    if (document.getElementById("ar-pianoroll-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-pianoroll-styles";
    s.textContent = `
.ar-pianoroll { font:13px -apple-system,system-ui,sans-serif; color:#222; height:100%; display:flex; flex-direction:column; position:relative; background:#fff; }
.ar-pianoroll__toolbar { background:#1e1e1e; color:#d4d4d4; display:flex; align-items:center; padding:0 16px; gap:10px; height:44px; flex-shrink:0; border-bottom:1px solid #333; }
.ar-pianoroll__title { font-size:13px; margin:0; font-weight:500; color:#e40c88; }
.ar-pianoroll__status { font:11px ui-monospace,monospace; color:#888; }
.ar-pianoroll__lbl { font:11px sans-serif; color:#888; }
.ar-pianoroll__btn,.ar-pianoroll__tool-btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 12px; font:12px sans-serif; border-radius:3px; cursor:pointer; }
.ar-pianoroll__tool-btn { padding:4px 8px; min-width:32px; }
.ar-pianoroll__btn:hover,.ar-pianoroll__tool-btn:hover { background:#2a2a2a; }
.ar-pianoroll__tool-btn.active { background:#e40c88; border-color:#e40c88; color:#fff; }
.ar-pianoroll__btn.play { background:#16a34a; border-color:#16a34a; color:#fff; } .ar-pianoroll__btn.play:hover { background:#15803d; }
.ar-pianoroll__btn.stop { background:#dc2626; border-color:#dc2626; color:#fff; } .ar-pianoroll__btn.stop:hover { background:#b91c1c; }
.ar-pianoroll__btn.pause { background:#eab308; border-color:#eab308; color:#1f1f1f; } .ar-pianoroll__btn.pause:hover { background:#ca8a04; }
.ar-pianoroll__input { background:transparent; border:1px solid #444; color:#d4d4d4; padding:3px 8px; font:12px ui-monospace,monospace; border-radius:3px; width:60px; }

.ar-pianoroll__grid { display:grid; grid-template-columns:64px 1fr; grid-template-rows:22px 1fr; flex:1; min-height:0; background:#fff; }
.ar-pianoroll__corner { background:#f0f0f0; border-right:1px solid #ddd; border-bottom:1px solid #ddd; }
.ar-pianoroll__ruler { background:#f0f0f0; border-bottom:1px solid #ddd; position:relative; overflow:hidden; font:10px ui-monospace,monospace; color:#666; }
.ar-pianoroll__tick { position:absolute; top:0; bottom:0; width:1px; background:#ccc; }
.ar-pianoroll__tick.bar { background:#888; }
.ar-pianoroll__tick-lbl { position:absolute; top:4px; font-size:10px; color:#555; padding-left:3px; user-select:none; }
.ar-pianoroll__keys { background:#fff; border-right:1px solid #ddd; position:relative; overflow:hidden; user-select:none; }
.ar-pianoroll__key { position:absolute; left:0; right:0; border-bottom:1px solid #eee; font:9px ui-monospace,monospace; color:#888; padding-left:4px; line-height:1; display:flex; align-items:center; cursor:pointer; }
.ar-pianoroll__key.black { background:#2a2a2a; color:#ccc; right:28%; z-index:2; }
.ar-pianoroll__key.white { background:#fff; }
.ar-pianoroll__key:hover { background:#fde7f3; }
.ar-pianoroll__key.black:hover { background:#4a3040; }

.ar-pianoroll__canvas { position:relative; overflow:auto; background:#fff; cursor:crosshair; }
.ar-pianoroll__grid-bg { position:absolute; inset:0; pointer-events:none; }
.ar-pianoroll__note { position:absolute; background:#e40c88; border:1px solid #b80b6f; border-radius:2px; cursor:move; font:9px ui-monospace,monospace; color:#fff; padding:1px 4px; line-height:1.2; overflow:hidden; white-space:nowrap; box-shadow:0 1px 2px rgba(0,0,0,.15); transition:filter .1s; }
.ar-pianoroll__note.selected { background:#f06ab1; border-color:#fff; box-shadow:0 0 0 2px #e40c88,0 1px 4px rgba(0,0,0,.25); }
.ar-pianoroll__note:hover { filter:brightness(1.08); }
.ar-pianoroll__note-resize { position:absolute; right:0; top:0; bottom:0; width:6px; cursor:ew-resize; background:rgba(255,255,255,.2); }
.ar-pianoroll__playhead { position:absolute; top:0; bottom:0; width:2px; background:#16a34a; pointer-events:none; box-shadow:0 0 4px rgba(22,163,74,.5); }

/* Loop selection \u2014 overlay on the ruler (Task B) */
.ar-pianoroll__loop-range  { position:absolute; top:0; bottom:0; background:rgba(228,12,136,0.18); border-top:2px solid #e40c88; border-bottom:2px solid #e40c88; cursor:grab; z-index:5; }
.ar-pianoroll__loop-range:active { cursor:grabbing; }
.ar-pianoroll__loop-handle { position:absolute; top:0; bottom:0; width:6px; margin-left:-3px; background:#e40c88; cursor:ew-resize; z-index:6; }
.ar-pianoroll__loop-handle::after { content:''; position:absolute; top:50%; left:50%; width:2px; height:8px; margin:-4px 0 0 -1px; background:rgba(255,255,255,0.7); border-radius:1px; }

.ar-pianoroll__vel { position:absolute; bottom:0; left:0; right:0; height:60px; background:rgba(245,245,245,.95); border-top:1px solid #ddd; pointer-events:none; }
.ar-pianoroll__vel-bar { position:absolute; bottom:0; width:3px; background:#e40c88; border-radius:1px 1px 0 0; opacity:.7; }
.ar-pianoroll__vel-toggle { position:absolute; right:6px; bottom:60px; background:#1e1e1e; color:#d4d4d4; border:0; font:10px sans-serif; padding:2px 8px; border-radius:3px 3px 0 0; cursor:pointer; pointer-events:auto; z-index:5; }

.ar-pianoroll__events { position:absolute; right:12px; top:80px; width:240px; max-height:200px; background:#1e1e1e; color:#d4d4d4; border-radius:6px; padding:8px 10px; font:10px ui-monospace,monospace; overflow-y:auto; z-index:10; box-shadow:0 4px 12px rgba(0,0,0,.15); }
.ar-pianoroll__events-ttl { color:#c3e88d; font-weight:600; margin-bottom:4px; text-transform:uppercase; font-size:9px; letter-spacing:.5px; }
.ar-pianoroll__events-row { display:flex; justify-content:space-between; padding:1px 0; border-bottom:1px solid #333; }
.ar-pianoroll__events-row .t { color:#6cb6ff; }
.ar-pianoroll__events-row .ev { color:#ffab40; }
`;
    document.head.appendChild(s);
  }
};

// components/audio/AudioPlayer.ts
var AudioPlayer = class extends AudioComponent {
  _audio;
  _source;
  _gain;
  _elPlay;
  _elTime;
  _elBar;
  _elVolume;
  _elDuration;
  constructor(container, opts = {}) {
    super(container, "div", {
      loop: false,
      volume: 1,
      autoplay: false,
      showControls: true,
      ...opts
    });
    this.el.className = `ar-audioplayer${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._buildAudioGraph();
    this._buildShell();
    if (opts.src) this.load(opts.src);
  }
  // ── Public API ──────────────────────────────────────────────────────────
  load(src) {
    this._audio.src = src;
    this._audio.load();
    return this;
  }
  play() {
    AudioComponent.resume();
    return this._audio.play();
  }
  pause() {
    this._audio.pause();
    return this;
  }
  stop() {
    this._audio.pause();
    this._audio.currentTime = 0;
    return this;
  }
  seek(time) {
    this._audio.currentTime = Math.max(0, Math.min(time, this._audio.duration || 0));
    return this;
  }
  setVolume(v) {
    const clamped = Math.max(0, Math.min(1, v));
    this._audio.volume = clamped;
    this._gain.gain.value = clamped;
    if (this._elVolume) this._elVolume.value = String(clamped);
    return this;
  }
  setLoop(loop) {
    this._audio.loop = loop;
    return this;
  }
  getCurrentTime() {
    return this._audio.currentTime;
  }
  getDuration() {
    return this._audio.duration || 0;
  }
  isPlaying() {
    return !this._audio.paused;
  }
  // ── Internal ────────────────────────────────────────────────────────────
  _buildAudioGraph() {
    this._audio = document.createElement("audio");
    this._audio.crossOrigin = "anonymous";
    this._audio.loop = this._get("loop", false);
    this._audio.volume = this._get("volume", 1);
    this._audio.autoplay = this._get("autoplay", false);
    this._source = this._audioCtx.createMediaElementSource(this._audio);
    this._gain = this._audioCtx.createGain();
    this._gain.gain.value = this._get("volume", 1);
    this._source.connect(this._gain);
    this._gain.connect(this._audioCtx.destination);
    this._output = this._gain;
    this._audio.addEventListener("play", () => this._emit("play", {}));
    this._audio.addEventListener("pause", () => this._emit("pause", {}));
    this._audio.addEventListener("ended", () => this._emit("ended", {}));
    this._audio.addEventListener("timeupdate", () => {
      this._refreshTime();
      this._emit("timeupdate", { time: this._audio.currentTime, duration: this._audio.duration });
    });
    this._audio.addEventListener("loadedmetadata", () => {
      this._refreshTime();
      this._emit("loaded", { duration: this._audio.duration });
    });
  }
  _build() {
  }
  _buildShell() {
    if (!this._get("showControls", true)) {
      this.el.appendChild(this._audio);
      return;
    }
    this.el.innerHTML = `
<div class="ar-audioplayer__row">
  <button class="ar-audioplayer__btn play" data-r="play" title="Play / Pause">\u25B6</button>
  <button class="ar-audioplayer__btn"      data-r="stop" title="Stop">\u25A0</button>
  <span class="ar-audioplayer__time" data-r="time">0:00</span>
  <input  class="ar-audioplayer__bar"  data-r="bar"  type="range" min="0" max="1000" value="0">
  <span class="ar-audioplayer__time" data-r="duration">0:00</span>
  <span class="ar-audioplayer__lbl">Vol</span>
  <input  class="ar-audioplayer__vol" data-r="volume" type="range" min="0" max="1" step="0.01">
</div>`;
    this.el.appendChild(this._audio);
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elPlay = r("play");
    this._elTime = r("time");
    this._elDuration = r("duration");
    this._elBar = r("bar");
    this._elVolume = r("volume");
    this._elVolume.value = String(this._get("volume", 1));
    this._elPlay.addEventListener("click", () => {
      if (this.isPlaying()) this.pause();
      else this.play();
    });
    r("stop").addEventListener("click", () => this.stop());
    this._elBar.addEventListener("input", () => {
      const frac = parseInt(this._elBar.value, 10) / 1e3;
      this.seek(frac * (this._audio.duration || 0));
    });
    this._elVolume.addEventListener("input", () => {
      this.setVolume(parseFloat(this._elVolume.value));
    });
    this._audio.addEventListener("play", () => this._elPlay.textContent = "\u2016");
    this._audio.addEventListener("pause", () => this._elPlay.textContent = "\u25B6");
    this._audio.addEventListener("ended", () => this._elPlay.textContent = "\u25B6");
  }
  _refreshTime() {
    if (!this._elTime) return;
    const cur = this._audio.currentTime || 0;
    const dur = this._audio.duration || 0;
    this._elTime.textContent = formatTime(cur);
    this._elDuration.textContent = formatTime(dur);
    if (dur > 0 && this._elBar) {
      this._elBar.value = String(Math.round(cur / dur * 1e3));
    }
  }
  _injectStyles() {
    if (document.getElementById("ar-audioplayer-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-audioplayer-styles";
    s.textContent = `
.ar-audioplayer { font:13px -apple-system,system-ui,sans-serif; background:#1e1e1e; color:#d4d4d4; padding:8px 12px; border-radius:6px; }
.ar-audioplayer__row { display:flex; align-items:center; gap:10px; }
.ar-audioplayer__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:14px sans-serif; border-radius:3px; cursor:pointer; min-width:32px; }
.ar-audioplayer__btn:hover { background:#2a2a2a; }
.ar-audioplayer__btn.play { background:#16a34a; border-color:#16a34a; color:#fff; }
.ar-audioplayer__btn.play:hover { background:#15803d; }
.ar-audioplayer__time { font:11px ui-monospace,monospace; color:#888; min-width:40px; text-align:center; }
.ar-audioplayer__bar { flex:1; -webkit-appearance:none; height:4px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-audioplayer__bar::-webkit-slider-thumb { -webkit-appearance:none; width:12px; height:12px; border-radius:50%; background:#e40c88; cursor:pointer; }
.ar-audioplayer__bar::-moz-range-thumb     { width:12px; height:12px; border-radius:50%; background:#e40c88; cursor:pointer; border:0; }
.ar-audioplayer__lbl { font:10px sans-serif; color:#888; }
.ar-audioplayer__vol { width:80px; -webkit-appearance:none; height:3px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-audioplayer__vol::-webkit-slider-thumb { -webkit-appearance:none; width:10px; height:10px; border-radius:50%; background:#d4d4d4; cursor:pointer; }
.ar-audioplayer__vol::-moz-range-thumb     { width:10px; height:10px; border-radius:50%; background:#d4d4d4; cursor:pointer; border:0; }
`;
    document.head.appendChild(s);
  }
};
function formatTime(s) {
  if (!isFinite(s) || s < 0) return "0:00";
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

// components/audio/ChannelStrip.ts
var dbToGain = (db) => Math.pow(10, db / 20);
var ChannelStrip = class extends AudioComponent {
  // Web Audio nodes
  _gainNode;
  _eqLow;
  _eqMid;
  _eqHigh;
  _panNode;
  _faderNode;
  _analyser;
  // State
  _muted = false;
  _solo = false;
  _faderDb;
  // DOM refs
  _elFader;
  _elGain;
  _elPan;
  _elMute;
  _elSolo;
  _elFaderVal;
  _elGainVal;
  _elPanVal;
  _elMeterFill;
  _elName;
  _eqInputs = {};
  // Meter loop
  _meterRAF = 0;
  constructor(container, opts = {}) {
    super(container, "div", {
      name: "Channel",
      color: "#e40c88",
      fader: 0,
      gain: 0,
      pan: 0,
      showMeter: true,
      ...opts
    });
    this.el.className = `ar-channelstrip${opts.class ? " " + opts.class : ""}`;
    this._faderDb = this._get("fader", 0);
    this._injectStyles();
    this._buildAudioGraph();
    this._buildShell();
    this._startMeter();
    this._gc(() => {
      if (this._meterRAF) cancelAnimationFrame(this._meterRAF);
    });
  }
  // ── Public API ──────────────────────────────────────────────────────────
  setGain(db) {
    this._gainNode.gain.value = dbToGain(db);
    if (this._elGain) this._elGain.value = String(db);
    if (this._elGainVal) this._elGainVal.textContent = formatDb(db);
    this._emit("change", { kind: "gain", value: db });
    return this;
  }
  setFader(db) {
    this._faderDb = db;
    this._applyFader();
    if (this._elFader) this._elFader.value = String(db);
    if (this._elFaderVal) this._elFaderVal.textContent = formatDb(db);
    this._emit("change", { kind: "fader", value: db });
    return this;
  }
  setPan(value) {
    const c = Math.max(-1, Math.min(1, value));
    this._panNode.pan.value = c;
    if (this._elPan) this._elPan.value = String(c);
    if (this._elPanVal) this._elPanVal.textContent = formatPan(c);
    this._emit("change", { kind: "pan", value: c });
    return this;
  }
  setEQ(band, settings) {
    const node = band === "low" ? this._eqLow : band === "mid" ? this._eqMid : this._eqHigh;
    if (settings.gain !== void 0) node.gain.value = settings.gain;
    if (settings.freq !== void 0) node.frequency.value = settings.freq;
    if (settings.q !== void 0 && band === "mid") node.Q.value = settings.q;
    const i = this._eqInputs[band];
    if (i) {
      if (settings.gain !== void 0) i.gain.value = String(settings.gain);
      if (settings.freq !== void 0) i.freq.value = String(settings.freq);
    }
    this._emit("change", { kind: "eq", band, settings });
    return this;
  }
  setMute(muted) {
    this._muted = muted;
    this._applyFader();
    if (this._elMute) this._elMute.classList.toggle("active", muted);
    this._emit("change", { kind: "mute", value: muted });
    return this;
  }
  setSolo(solo) {
    this._solo = solo;
    if (this._elSolo) this._elSolo.classList.toggle("active", solo);
    this._emit("change", { kind: "solo", value: solo });
    return this;
  }
  setName(n) {
    if (this._elName) this._elName.textContent = n;
    return this;
  }
  getMute() {
    return this._muted;
  }
  getSolo() {
    return this._solo;
  }
  getFader() {
    return this._faderDb;
  }
  // ── Internal ────────────────────────────────────────────────────────────
  _buildAudioGraph() {
    const ctx = this._audioCtx;
    this._gainNode = ctx.createGain();
    this._gainNode.gain.value = dbToGain(this._get("gain", 0));
    this._eqLow = ctx.createBiquadFilter();
    this._eqLow.type = "lowshelf";
    this._eqLow.frequency.value = 200;
    this._eqLow.gain.value = 0;
    this._eqMid = ctx.createBiquadFilter();
    this._eqMid.type = "peaking";
    this._eqMid.frequency.value = 1e3;
    this._eqMid.Q.value = 1;
    this._eqMid.gain.value = 0;
    this._eqHigh = ctx.createBiquadFilter();
    this._eqHigh.type = "highshelf";
    this._eqHigh.frequency.value = 5e3;
    this._eqHigh.gain.value = 0;
    this._panNode = ctx.createStereoPanner();
    this._panNode.pan.value = this._get("pan", 0);
    this._faderNode = ctx.createGain();
    this._faderNode.gain.value = dbToGain(this._faderDb);
    this._analyser = ctx.createAnalyser();
    this._analyser.fftSize = 256;
    this._analyser.smoothingTimeConstant = 0.7;
    const eq = this._get("eq", {});
    if (eq?.low) Object.assign(this._eqLow, this._toApply(eq.low));
    if (eq?.mid) Object.assign(this._eqMid, this._toApply(eq.mid));
    if (eq?.high) Object.assign(this._eqHigh, this._toApply(eq.high));
    this._gainNode.connect(this._eqLow);
    this._eqLow.connect(this._eqMid);
    this._eqMid.connect(this._eqHigh);
    this._eqHigh.connect(this._panNode);
    this._panNode.connect(this._faderNode);
    this._faderNode.connect(this._analyser);
    this._input = this._gainNode;
    this._output = this._analyser;
  }
  _toApply(s) {
    const obj = {};
    if (s.gain !== void 0) obj.gain = { value: s.gain };
    if (s.freq !== void 0) obj.frequency = { value: s.freq };
    if (s.q !== void 0) obj.Q = { value: s.q };
    return obj;
  }
  _applyFader() {
    const db = this._muted ? -Infinity : this._faderDb;
    this._faderNode.gain.value = isFinite(db) ? dbToGain(db) : 0;
  }
  _build() {
  }
  _buildShell() {
    const color = this._get("color", "#e40c88");
    const name = this._get("name", "Channel");
    this.el.innerHTML = `
<div class="ar-channelstrip__hd" style="border-top:3px solid ${color}">
  <span class="ar-channelstrip__name" data-r="name">${name}</span>
</div>

<div class="ar-channelstrip__body">
  <div class="ar-channelstrip__sec">
    <div class="ar-channelstrip__sec-ttl">Input</div>
    <div class="ar-channelstrip__row">
      <input type="range" class="ar-channelstrip__knob" data-r="gain" min="-24" max="24" step="0.1" value="0">
      <span class="ar-channelstrip__val" data-r="gain-val">0.0 dB</span>
    </div>
  </div>

  <div class="ar-channelstrip__sec">
    <div class="ar-channelstrip__sec-ttl">EQ</div>
    <div class="ar-channelstrip__eq-band">
      <span class="ar-channelstrip__eq-lbl">Hi</span>
      <input type="range" class="ar-channelstrip__eq-gain" data-r="eq-high-gain" min="-18" max="18" step="0.1" value="0">
      <input type="number" class="ar-channelstrip__eq-freq" data-r="eq-high-freq" value="5000" min="500" max="20000">
    </div>
    <div class="ar-channelstrip__eq-band">
      <span class="ar-channelstrip__eq-lbl">Mid</span>
      <input type="range" class="ar-channelstrip__eq-gain" data-r="eq-mid-gain" min="-18" max="18" step="0.1" value="0">
      <input type="number" class="ar-channelstrip__eq-freq" data-r="eq-mid-freq" value="1000" min="100" max="10000">
    </div>
    <div class="ar-channelstrip__eq-band">
      <span class="ar-channelstrip__eq-lbl">Lo</span>
      <input type="range" class="ar-channelstrip__eq-gain" data-r="eq-low-gain" min="-18" max="18" step="0.1" value="0">
      <input type="number" class="ar-channelstrip__eq-freq" data-r="eq-low-freq" value="200" min="20" max="500">
    </div>
  </div>

  <div class="ar-channelstrip__sec">
    <div class="ar-channelstrip__sec-ttl">Pan</div>
    <div class="ar-channelstrip__row">
      <input type="range" class="ar-channelstrip__knob" data-r="pan" min="-1" max="1" step="0.01" value="0">
      <span class="ar-channelstrip__val" data-r="pan-val">C</span>
    </div>
  </div>

  <div class="ar-channelstrip__sec ar-channelstrip__fader-wrap">
    <div class="ar-channelstrip__sec-ttl">Fader</div>
    <div class="ar-channelstrip__fader-row">
      ${this._get("showMeter", true) ? '<div class="ar-channelstrip__meter"><div class="ar-channelstrip__meter-fill" data-r="meter-fill"></div></div>' : ""}
      <input type="range" class="ar-channelstrip__fader" data-r="fader" min="-60" max="12" step="0.1" value="0" orient="vertical">
    </div>
    <span class="ar-channelstrip__val" data-r="fader-val">0.0 dB</span>
  </div>

  <div class="ar-channelstrip__btn-row">
    <button class="ar-channelstrip__btn mute" data-r="mute">M</button>
    <button class="ar-channelstrip__btn solo" data-r="solo">S</button>
  </div>
</div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elName = r("name");
    this._elGain = r("gain");
    this._elGainVal = r("gain-val");
    this._elPan = r("pan");
    this._elPanVal = r("pan-val");
    this._elFader = r("fader");
    this._elFaderVal = r("fader-val");
    this._elMute = r("mute");
    this._elSolo = r("solo");
    if (this._get("showMeter", true)) this._elMeterFill = r("meter-fill");
    for (const band of ["low", "mid", "high"]) {
      this._eqInputs[band] = {
        gain: r(`eq-${band}-gain`),
        freq: r(`eq-${band}-freq`)
      };
    }
    this._elGain.value = String(this._get("gain", 0));
    this._elFader.value = String(this._faderDb);
    this._elPan.value = String(this._get("pan", 0));
    this._elFaderVal.textContent = formatDb(this._faderDb);
    this._elGain.addEventListener("input", () => this.setGain(parseFloat(this._elGain.value)));
    this._elFader.addEventListener("input", () => this.setFader(parseFloat(this._elFader.value)));
    this._elPan.addEventListener("input", () => this.setPan(parseFloat(this._elPan.value)));
    this._elMute.addEventListener("click", () => this.setMute(!this._muted));
    this._elSolo.addEventListener("click", () => this.setSolo(!this._solo));
    for (const band of ["low", "mid", "high"]) {
      this._eqInputs[band].gain.addEventListener("input", () => this.setEQ(band, { gain: parseFloat(this._eqInputs[band].gain.value) }));
      this._eqInputs[band].freq.addEventListener("change", () => this.setEQ(band, { freq: parseFloat(this._eqInputs[band].freq.value) }));
    }
  }
  _startMeter() {
    if (!this._get("showMeter", true)) return;
    const buf = new Uint8Array(this._analyser.frequencyBinCount);
    const tick = () => {
      this._analyser.getByteTimeDomainData(buf);
      let peak = 0;
      for (let i = 0; i < buf.length; i++) {
        const v = Math.abs(buf[i] - 128) / 128;
        if (v > peak) peak = v;
      }
      const pct = Math.min(100, peak * 100);
      if (this._elMeterFill) {
        this._elMeterFill.style.height = pct + "%";
        this._elMeterFill.style.background = pct > 90 ? "#dc2626" : pct > 70 ? "#eab308" : "#16a34a";
      }
      this._meterRAF = requestAnimationFrame(tick);
    };
    tick();
  }
  _injectStyles() {
    if (document.getElementById("ar-channelstrip-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-channelstrip-styles";
    s.textContent = `
.ar-channelstrip { font:11px -apple-system,system-ui,sans-serif; background:#1e1e1e; color:#d4d4d4; border-radius:4px; padding:0; width:100px; height:520px; display:flex; flex-direction:column; box-shadow:0 1px 3px rgba(0,0,0,.3); user-select:none; }
.ar-channelstrip__hd { padding:6px 8px; border-bottom:1px solid #333; text-align:center; }
.ar-channelstrip__name { font-weight:600; color:#fff; font-size:11px; }
.ar-channelstrip__body { flex:1; display:flex; flex-direction:column; gap:6px; padding:8px 6px; min-height:0; }
.ar-channelstrip__sec { background:#252525; border-radius:3px; padding:6px; }
.ar-channelstrip__sec-ttl { font-size:9px; color:#666; text-transform:uppercase; letter-spacing:.5px; margin-bottom:4px; text-align:center; }
.ar-channelstrip__row { display:flex; align-items:center; gap:4px; flex-direction:column; }
.ar-channelstrip__knob { width:100%; -webkit-appearance:none; height:3px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-channelstrip__knob::-webkit-slider-thumb { -webkit-appearance:none; width:10px; height:10px; border-radius:50%; background:#e40c88; cursor:pointer; }
.ar-channelstrip__knob::-moz-range-thumb     { width:10px; height:10px; border-radius:50%; background:#e40c88; cursor:pointer; border:0; }
.ar-channelstrip__val { font:10px ui-monospace,monospace; color:#aaa; text-align:center; }
.ar-channelstrip__eq-band { display:flex; align-items:center; gap:4px; margin:2px 0; }
.ar-channelstrip__eq-lbl  { font-size:9px; color:#888; width:18px; }
.ar-channelstrip__eq-gain { flex:1; -webkit-appearance:none; height:3px; background:#444; border-radius:2px; outline:none; cursor:pointer; min-width:0; }
.ar-channelstrip__eq-gain::-webkit-slider-thumb { -webkit-appearance:none; width:8px; height:8px; border-radius:50%; background:#3b82f6; cursor:pointer; }
.ar-channelstrip__eq-gain::-moz-range-thumb     { width:8px; height:8px; border-radius:50%; background:#3b82f6; cursor:pointer; border:0; }
.ar-channelstrip__eq-freq { width:36px; font:9px ui-monospace,monospace; background:#1a1a1a; border:1px solid #333; color:#d4d4d4; padding:1px 2px; border-radius:2px; }
.ar-channelstrip__fader-wrap { flex:1; display:flex; flex-direction:column; align-items:center; min-height:0; }
.ar-channelstrip__fader-row { flex:1; display:flex; gap:4px; align-items:stretch; min-height:0; }
.ar-channelstrip__meter { width:8px; background:#0a0a0a; border:1px solid #333; border-radius:1px; position:relative; overflow:hidden; }
.ar-channelstrip__meter-fill { position:absolute; bottom:0; left:0; right:0; background:#16a34a; height:0; transition:height .05s linear; }
.ar-channelstrip__fader { writing-mode:bt-lr; -webkit-appearance:slider-vertical; width:24px; height:auto; flex:1; outline:none; cursor:ns-resize; }
.ar-channelstrip__btn-row { display:flex; gap:4px; }
.ar-channelstrip__btn { flex:1; background:transparent; border:1px solid #444; color:#d4d4d4; padding:3px 0; font:10px sans-serif; font-weight:600; border-radius:2px; cursor:pointer; }
.ar-channelstrip__btn:hover { background:#2a2a2a; }
.ar-channelstrip__btn.mute.active { background:#dc2626; border-color:#dc2626; color:#fff; }
.ar-channelstrip__btn.solo.active { background:#eab308; border-color:#eab308; color:#1f1f1f; }
`;
    document.head.appendChild(s);
  }
};
function formatDb(db) {
  if (!isFinite(db)) return "-\u221E";
  return (db >= 0 ? "+" : "") + db.toFixed(1) + " dB";
}
function formatPan(p) {
  if (Math.abs(p) < 0.01) return "C";
  return p < 0 ? `L${Math.round(-p * 100)}` : `R${Math.round(p * 100)}`;
}

// components/audio/AudioTrackEditor.ts
var TRACK_HEIGHT = 80;
var AudioTrackEditor = class extends AudioComponent {
  _tracks = [];
  _clips = [];
  _nextId = 1;
  _zoom;
  _pxPerSec;
  _selected = /* @__PURE__ */ new Set();
  _selectedTracks = /* @__PURE__ */ new Set();
  _clipboard = [];
  // Loop state — Task B (Loop selection)
  _loop = { start: 0, end: 0, enabled: false };
  _elLoopRange;
  _elLoopHandleLeft;
  _elLoopHandleRight;
  _activeSources = [];
  _playing = false;
  _playStart = 0;
  _playRAF = 0;
  _playhead = 0;
  // seconds
  // DOM
  _elTrackHeads;
  _elTrackBodies;
  _elRuler;
  _elPlayhead;
  _elScroller;
  constructor(container, opts = {}) {
    super(container, "div", {
      tracks: 4,
      bpm: 120,
      pxPerSec: 50,
      zoom: 1,
      ...opts
    });
    this.el.className = `ar-audiotrack${opts.class ? " " + opts.class : ""}`;
    this._zoom = this._get("zoom", 1);
    this._pxPerSec = this._get("pxPerSec", 50);
    this._injectStyles();
    this._buildAudioGraph();
    this._buildShell();
    const n = this._get("tracks", 4);
    for (let i = 0; i < n; i++) {
      this.addTrack({ id: `t${i + 1}`, name: `Track ${i + 1}` });
    }
    this._on(document, "keydown", (e) => {
      if (!this.el.contains(document.activeElement) && document.activeElement !== document.body) return;
      const tg = e.target;
      if (tg.tagName === "INPUT" || tg.tagName === "TEXTAREA") return;
      if ((e.metaKey || e.ctrlKey) && (e.key === "c" || e.key === "C")) {
        this.copy();
        e.preventDefault();
      }
      if ((e.metaKey || e.ctrlKey) && (e.key === "v" || e.key === "V")) {
        this.paste(this._playhead);
        e.preventDefault();
      }
      if ((e.metaKey || e.ctrlKey) && (e.key === "x" || e.key === "X")) {
        this.cut();
        e.preventDefault();
      }
      if (e.key === "Delete" || e.key === "Backspace") {
        this.deleteSelection();
        e.preventDefault();
      }
      if (e.key === " ") {
        e.preventDefault();
        this._playing ? this.stop() : this.play();
      }
    });
  }
  // ── Track / Clip API ────────────────────────────────────────────────────
  addTrack(t) {
    const tk = { color: "#e40c88", muted: false, soloed: false, ...t };
    this._tracks.push(tk);
    this._renderTracks();
    this._emit("change", { kind: "add-track", track: tk });
    return tk;
  }
  removeTrack(id) {
    this._tracks = this._tracks.filter((t) => t.id !== id);
    this._clips = this._clips.filter((c) => c.trackId !== id);
    this._renderTracks();
    this._renderClips();
    this._emit("change", { kind: "remove-track", id });
  }
  addClip(trackId, opts) {
    const clip = {
      id: `c${this._nextId++}`,
      trackId,
      buffer: opts.buffer,
      start: opts.start,
      offset: opts.offset ?? 0,
      duration: opts.duration ?? opts.buffer.duration,
      name: opts.name
    };
    this._clips.push(clip);
    this._renderClips();
    this._emit("change", { kind: "add-clip", clip });
    return clip;
  }
  removeClip(id) {
    this._clips = this._clips.filter((c) => c.id !== id);
    this._selected.delete(id);
    this._renderClips();
    this._emit("change", { kind: "remove-clip", id });
  }
  /** Load an audio file URL or a File object into an AudioBuffer. */
  async loadFile(src) {
    let arr;
    if (typeof src === "string") arr = await (await fetch(src)).arrayBuffer();
    else if (src instanceof File) arr = await src.arrayBuffer();
    else arr = src;
    return await this._audioCtx.decodeAudioData(arr);
  }
  // ── Edit operations ─────────────────────────────────────────────────────
  copy() {
    this._clipboard = [...this._selected].map((id) => {
      const c = this._clips.find((x) => x.id === id);
      return c ? { ...c } : null;
    }).filter(Boolean);
  }
  cut() {
    this.copy();
    this.deleteSelection();
  }
  paste(atTime) {
    if (this._clipboard.length === 0) return;
    const baseTime = Math.min(...this._clipboard.map((c) => c.start));
    const offset = atTime - baseTime;
    for (const c of this._clipboard) {
      this._clips.push({ ...c, id: `c${this._nextId++}`, start: c.start + offset });
    }
    this._renderClips();
    this._emit("change", { kind: "paste" });
  }
  deleteSelection() {
    const trackIds = this._selectedTracks;
    this._clips = this._clips.filter((c) => !this._selected.has(c.id) && !trackIds.has(c.trackId));
    this._selected.clear();
    if (trackIds.size > 0) {
      this._tracks = this._tracks.filter((t) => !trackIds.has(t.id));
      this._selectedTracks.clear();
      this._renderTracks();
    } else {
      this._renderClips();
    }
    this._emit("change", { kind: "delete-selection" });
  }
  /** Split a clip at given time (timeline seconds). */
  splitClip(id, atTime) {
    const c = this._clips.find((x) => x.id === id);
    if (!c) return null;
    const local = atTime - c.start;
    if (local <= 0 || local >= c.duration) return null;
    const left = { ...c, duration: local };
    const right = { ...c, id: `c${this._nextId++}`, start: c.start + local, offset: c.offset + local, duration: c.duration - local };
    this._clips = this._clips.filter((x) => x.id !== id);
    this._clips.push(left, right);
    this._renderClips();
    this._emit("change", { kind: "split", original: id, parts: [left, right] });
    return [left, right];
  }
  setZoom(z) {
    this._zoom = Math.max(0.1, Math.min(8, z));
    this._renderRuler();
    this._renderClips();
    this._emit("change", { kind: "zoom", value: this._zoom });
    return this;
  }
  // ── Playback ────────────────────────────────────────────────────────────
  play() {
    if (this._playing) return this;
    AudioComponent.resume();
    this._playing = true;
    this._playStart = this._audioCtx.currentTime - this._playhead;
    const soloed = this._tracks.filter((t) => t.soloed).map((t) => t.id);
    const isAudible = (trackId) => {
      const t = this._tracks.find((x) => x.id === trackId);
      if (!t) return false;
      if (soloed.length > 0) return soloed.includes(trackId);
      return !t.muted;
    };
    for (const c of this._clips) {
      if (!isAudible(c.trackId)) continue;
      const src = this._audioCtx.createBufferSource();
      src.buffer = c.buffer;
      src.connect(this._output);
      const startAt = Math.max(0, c.start - this._playhead);
      const offsetIn = c.start < this._playhead ? c.offset + (this._playhead - c.start) : c.offset;
      const dur = c.duration - (offsetIn - c.offset);
      if (dur > 0) src.start(this._audioCtx.currentTime + startAt, offsetIn, dur);
      this._activeSources.push(src);
    }
    this._tickPlayhead();
    this._emit("play", {});
    return this;
  }
  pause() {
    if (!this._playing) return this;
    this._playing = false;
    for (const s of this._activeSources) {
      try {
        s.stop();
      } catch {
      }
    }
    this._activeSources = [];
    if (this._playRAF) cancelAnimationFrame(this._playRAF);
    this._emit("pause", {});
    return this;
  }
  stop() {
    this.pause();
    this._playhead = 0;
    this._renderPlayhead();
    return this;
  }
  _tickPlayhead = () => {
    if (!this._playing) return;
    let pos = this._audioCtx.currentTime - this._playStart;
    if (this._loop.enabled && this._loop.end > this._loop.start && pos >= this._loop.end) {
      const overshoot = pos - this._loop.start;
      this._playStart = this._audioCtx.currentTime - this._loop.start;
      pos = this._audioCtx.currentTime - this._playStart;
      this._emit("loop-wrap", { start: this._loop.start, end: this._loop.end, overshoot });
    }
    this._playhead = pos;
    this._renderPlayhead();
    this._playRAF = requestAnimationFrame(this._tickPlayhead);
  };
  // ── Internal ────────────────────────────────────────────────────────────
  _buildAudioGraph() {
    this._output = this._audioCtx.createGain();
    this._output.connect(this._audioCtx.destination);
  }
  _build() {
  }
  _buildShell() {
    this.el.innerHTML = `
<div class="ar-audiotrack__toolbar">
  <button class="ar-audiotrack__btn" data-r="play">\u25B6 Play</button>
  <button class="ar-audiotrack__btn" data-r="stop">\u25A0 Stop</button>
  <button class="ar-audiotrack__btn" data-r="add-track">+ Track</button>
  <span class="ar-audiotrack__lbl">Zoom</span>
  <input type="range" class="ar-audiotrack__zoom" data-r="zoom" min="0.1" max="4" step="0.1" value="1">
</div>
<div class="ar-audiotrack__main" data-r="scroller">
  <div class="ar-audiotrack__heads" data-r="heads"></div>
  <div class="ar-audiotrack__rest">
    <div class="ar-audiotrack__ruler" data-r="ruler"></div>
    <div class="ar-audiotrack__bodies" data-r="bodies">
      <div class="ar-audiotrack__playhead" data-r="playhead" style="display:none"></div>
    </div>
  </div>
</div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elTrackHeads = r("heads");
    this._elTrackBodies = r("bodies");
    this._elRuler = r("ruler");
    this._elPlayhead = r("playhead");
    this._elScroller = r("scroller");
    r("play").addEventListener("click", () => this._playing ? this.pause() : this.play());
    r("stop").addEventListener("click", () => this.stop());
    r("add-track").addEventListener("click", () => {
      const i = this._tracks.length + 1;
      this.addTrack({ id: `t${this._nextId++}`, name: `Track ${i}` });
    });
    const elZoom = r("zoom");
    elZoom.addEventListener("input", () => this.setZoom(parseFloat(elZoom.value)));
    this._elRuler.addEventListener("pointerdown", (e) => this._onRulerDown(e));
    this._renderRuler();
  }
  _renderTracks() {
    this._elTrackHeads.innerHTML = "";
    for (const t of this._tracks) {
      const head = document.createElement("div");
      head.className = "ar-audiotrack__head";
      if (this._selectedTracks.has(t.id)) head.classList.add("selected");
      head.dataset.trackId = t.id;
      head.style.borderLeft = `4px solid ${t.color}`;
      head.innerHTML = `
<div class="ar-audiotrack__head-row">
  <span class="ar-audiotrack__head-name">${t.name}</span>
  <button class="ar-audiotrack__head-x" data-act="remove" aria-label="Remove track">\xD7</button>
</div>
<div class="ar-audiotrack__head-row">
  <button class="ar-audiotrack__btn-sm mute ${t.muted ? "active" : ""}" data-act="mute">M</button>
  <button class="ar-audiotrack__btn-sm solo ${t.soloed ? "active" : ""}" data-act="solo">S</button>
  <label class="ar-audiotrack__btn-sm" style="cursor:pointer">+
    <input type="file" accept="audio/*" data-act="upload" style="display:none">
  </label>
</div>`;
      head.addEventListener("pointerdown", (e) => {
        const tgt = e.target;
        if (tgt.closest("button, input, label")) return;
        if (!e.shiftKey) this._selectedTracks.clear();
        if (this._selectedTracks.has(t.id)) this._selectedTracks.delete(t.id);
        else this._selectedTracks.add(t.id);
        this._renderTracks();
        this._emit("change", { kind: "select-tracks", ids: [...this._selectedTracks] });
      });
      head.querySelector('[data-act="remove"]').addEventListener("click", (e) => {
        e.stopPropagation();
        this.removeTrack(t.id);
      });
      head.querySelector('[data-act="mute"]').addEventListener("click", (e) => {
        e.stopPropagation();
        t.muted = !t.muted;
        this._renderTracks();
      });
      head.querySelector('[data-act="solo"]').addEventListener("click", (e) => {
        e.stopPropagation();
        t.soloed = !t.soloed;
        this._renderTracks();
      });
      head.querySelector('[data-act="upload"]').addEventListener("change", async (e) => {
        e.stopPropagation();
        const f = e.target.files?.[0];
        if (!f) return;
        const buf = await this.loadFile(f);
        this.addClip(t.id, { buffer: buf, start: 0, name: f.name });
      });
      this._elTrackHeads.appendChild(head);
    }
    for (const t of this._tracks) {
      let body = this._elTrackBodies.querySelector(`[data-track-row="${t.id}"]`);
      if (!body) {
        body = document.createElement("div");
        body.className = "ar-audiotrack__body";
        body.dataset.trackRow = t.id;
        this._elTrackBodies.insertBefore(body, this._elPlayhead);
      }
    }
    this._elTrackBodies.querySelectorAll("[data-track-row]").forEach((el) => {
      if (!this._tracks.find((t) => t.id === el.dataset.trackRow)) el.remove();
    });
    this._renderClips();
  }
  _renderRuler() {
    this._elRuler.innerHTML = "";
    const totalSec = 120;
    const px = this._pxPerSec * this._zoom;
    this._elRuler.style.width = totalSec * px + "px";
    this._elTrackBodies.style.width = totalSec * px + "px";
    for (let s = 0; s <= totalSec; s++) {
      if (s % 5 === 0) {
        const t = document.createElement("div");
        t.className = "ar-audiotrack__ruler-tick";
        t.style.left = s * px + "px";
        this._elRuler.appendChild(t);
        const lbl = document.createElement("div");
        lbl.className = "ar-audiotrack__ruler-lbl";
        lbl.style.left = s * px + 2 + "px";
        lbl.textContent = formatTime2(s);
        this._elRuler.appendChild(lbl);
      }
    }
    this._renderLoopOverlay();
  }
  /**
   * Render the loop-range overlay and resize handles on the ruler.
   * Visible only when `_loop.enabled && start < end`. Re-rendered after
   * every zoom / pxPerSec change to stay aligned with the timeline.
   */
  _renderLoopOverlay() {
    if (this._elLoopRange) this._elLoopRange.remove();
    if (this._elLoopHandleLeft) this._elLoopHandleLeft.remove();
    if (this._elLoopHandleRight) this._elLoopHandleRight.remove();
    this._elLoopRange = this._elLoopHandleLeft = this._elLoopHandleRight = void 0;
    if (!this._loop.enabled || this._loop.end <= this._loop.start) return;
    const px = this._pxPerSec * this._zoom;
    const left = this._loop.start * px;
    const width = (this._loop.end - this._loop.start) * px;
    const range = document.createElement("div");
    range.className = "ar-audiotrack__loop-range";
    range.style.left = left + "px";
    range.style.width = width + "px";
    this._elRuler.appendChild(range);
    const hL = document.createElement("div");
    hL.className = "ar-audiotrack__loop-handle ar-audiotrack__loop-handle--left";
    hL.style.left = left + "px";
    this._elRuler.appendChild(hL);
    const hR = document.createElement("div");
    hR.className = "ar-audiotrack__loop-handle ar-audiotrack__loop-handle--right";
    hR.style.left = left + width + "px";
    this._elRuler.appendChild(hR);
    this._elLoopRange = range;
    this._elLoopHandleLeft = hL;
    this._elLoopHandleRight = hR;
    hL.addEventListener("pointerdown", (e) => this._onLoopHandleDown(e, "left"));
    hR.addEventListener("pointerdown", (e) => this._onLoopHandleDown(e, "right"));
    range.addEventListener("pointerdown", (e) => this._onLoopRangeDown(e));
  }
  _onLoopHandleDown(e, which) {
    e.preventDefault();
    e.stopPropagation();
    const px = this._pxPerSec * this._zoom;
    const startX = e.clientX;
    const startLoop = { ...this._loop };
    const handle = e.currentTarget;
    handle.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const dt = (ev.clientX - startX) / px;
      if (which === "left") {
        this._loop.start = Math.max(0, Math.min(startLoop.start + dt, this._loop.end - 0.05));
      } else {
        this._loop.end = Math.max(this._loop.start + 0.05, startLoop.end + dt);
      }
      this._renderLoopOverlay();
    };
    const onUp = () => {
      handle.removeEventListener("pointermove", onMove);
      handle.removeEventListener("pointerup", onUp);
      this._emit("change", { kind: "loop", loop: { ...this._loop } });
    };
    handle.addEventListener("pointermove", onMove);
    handle.addEventListener("pointerup", onUp);
  }
  _onLoopRangeDown(e) {
    e.preventDefault();
    e.stopPropagation();
    const px = this._pxPerSec * this._zoom;
    const startX = e.clientX;
    const startLoop = { ...this._loop };
    const range = e.currentTarget;
    range.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const dt = (ev.clientX - startX) / px;
      const len = startLoop.end - startLoop.start;
      this._loop.start = Math.max(0, startLoop.start + dt);
      this._loop.end = this._loop.start + len;
      this._renderLoopOverlay();
    };
    const onUp = () => {
      range.removeEventListener("pointermove", onMove);
      range.removeEventListener("pointerup", onUp);
      this._emit("change", { kind: "loop", loop: { ...this._loop } });
    };
    range.addEventListener("pointermove", onMove);
    range.addEventListener("pointerup", onUp);
  }
  /**
   * Pointer-down on the timeline ruler: shift+drag → create loop range,
   * plain click → seek the playhead.
   */
  _onRulerDown(e) {
    const target = e.target;
    if (target.classList.contains("ar-audiotrack__loop-range") || target.classList.contains("ar-audiotrack__loop-handle")) return;
    const px = this._pxPerSec * this._zoom;
    const rect = this._elRuler.getBoundingClientRect();
    const x0 = e.clientX - rect.left + this._elRuler.scrollLeft;
    const t0 = x0 / px;
    if (e.shiftKey) {
      e.preventDefault();
      e.stopPropagation();
      this._loop.start = t0;
      this._loop.end = t0 + 1e-3;
      this._loop.enabled = true;
      this._renderLoopOverlay();
      this._elRuler.setPointerCapture(e.pointerId);
      const onMove = (ev) => {
        const x = ev.clientX - rect.left + this._elRuler.scrollLeft;
        const t = x / px;
        if (t >= t0) {
          this._loop.start = t0;
          this._loop.end = t;
        } else {
          this._loop.start = t;
          this._loop.end = t0;
        }
        this._renderLoopOverlay();
      };
      const onUp = () => {
        this._elRuler.removeEventListener("pointermove", onMove);
        this._elRuler.removeEventListener("pointerup", onUp);
        if (this._loop.end - this._loop.start < 0.05) {
          this._loop = { start: 0, end: 0, enabled: false };
          this._renderLoopOverlay();
        }
        this._emit("change", { kind: "loop", loop: { ...this._loop } });
      };
      this._elRuler.addEventListener("pointermove", onMove);
      this._elRuler.addEventListener("pointerup", onUp);
      return;
    }
    this.setPlayhead(t0);
  }
  // ── Loop API (Task B) ──────────────────────────────────────────────────
  getLoop() {
    return { ...this._loop };
  }
  setLoop(loop) {
    this._loop.start = Math.max(0, loop.start);
    if (loop.end !== void 0) this._loop.end = Math.max(this._loop.start + 0.05, loop.end);
    if (loop.enabled !== void 0) this._loop.enabled = loop.enabled;
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  enableLoop(enabled) {
    this._loop.enabled = enabled;
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  clearLoop() {
    this._loop = { start: 0, end: 0, enabled: false };
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  /**
   * Programmatically move the playhead. If a loop range is active and the
   * new position is past `loop.end`, wraps to `loop.start` and emits
   * `loop-wrap` so the host playback engine can resync. This is also called
   * automatically by `_tickPlayhead` during real-time playback.
   */
  setPlayhead(t) {
    let pos = Math.max(0, t);
    if (this._loop.enabled && this._loop.end > this._loop.start && pos >= this._loop.end) {
      pos = this._loop.start;
      this._emit("loop-wrap", { start: this._loop.start, end: this._loop.end });
    }
    this._playhead = pos;
    this._renderPlayhead();
    return this;
  }
  _renderClips() {
    this._elTrackBodies.querySelectorAll(".ar-audiotrack__clip").forEach((n) => n.remove());
    const px = this._pxPerSec * this._zoom;
    for (const c of this._clips) {
      const row = this._elTrackBodies.querySelector(`[data-track-row="${c.trackId}"]`);
      if (!row) continue;
      const t = this._tracks.find((x) => x.id === c.trackId);
      const el = document.createElement("div");
      el.className = "ar-audiotrack__clip";
      el.dataset.clipId = c.id;
      el.style.left = c.start * px + "px";
      el.style.width = Math.max(20, c.duration * px) + "px";
      el.style.background = (t?.color || "#e40c88") + "33";
      el.style.borderColor = t?.color || "#e40c88";
      if (this._selected.has(c.id)) el.classList.add("selected");
      const canvas = document.createElement("canvas");
      canvas.className = "ar-audiotrack__wave";
      const w = Math.max(20, c.duration * px) | 0;
      canvas.width = w;
      canvas.height = TRACK_HEIGHT - 22;
      this._drawWaveform(canvas, c);
      el.appendChild(canvas);
      const lbl = document.createElement("div");
      lbl.className = "ar-audiotrack__clip-lbl";
      lbl.textContent = c.name || c.id;
      el.appendChild(lbl);
      const lh = document.createElement("div");
      lh.className = "ar-audiotrack__clip-h left";
      el.appendChild(lh);
      const rh = document.createElement("div");
      rh.className = "ar-audiotrack__clip-h right";
      el.appendChild(rh);
      el.addEventListener("pointerdown", (e) => this._onClipDown(e, c, el, lh, rh));
      row.appendChild(el);
    }
  }
  _onClipDown(e, c, el, lh, rh) {
    e.preventDefault();
    e.stopPropagation();
    const px = this._pxPerSec * this._zoom;
    if (!this._selected.has(c.id)) {
      if (!e.shiftKey) {
        this._selected.clear();
        this.el.querySelectorAll(".ar-audiotrack__clip.selected").forEach((n) => n.classList.remove("selected"));
      }
      this._selected.add(c.id);
      el.classList.add("selected");
    }
    const mode = e.target === lh ? "resize-left" : e.target === rh ? "resize-right" : "move";
    const startX = e.clientX;
    const startStart = c.start, startDur = c.duration, startOffset = c.offset;
    const startTrackId = c.trackId;
    let rowRects = [];
    const captureRowRects = () => {
      rowRects = [];
      this._elTrackBodies.querySelectorAll("[data-track-row]").forEach((row) => {
        const rect = row.getBoundingClientRect();
        rowRects.push({ id: row.dataset.trackRow, top: rect.top, bottom: rect.bottom });
      });
    };
    captureRowRects();
    let autoCreatedThisDrag = false;
    const autoCreateTrackBelow = () => {
      const idx = this._tracks.length + 1;
      let bump = idx;
      let unique = `t${bump}`;
      while (this._tracks.find((t) => t.id === unique)) {
        bump += 1;
        unique = `t${bump}`;
      }
      const parent = el.parentElement;
      if (parent) parent.removeChild(el);
      const newTrack = this.addTrack({ id: unique, name: `Track ${idx}` });
      const newRow = this._elTrackBodies.querySelector(`[data-track-row="${newTrack.id}"]`);
      if (newRow) newRow.appendChild(el);
      captureRowRects();
      autoCreatedThisDrag = true;
      return newTrack.id;
    };
    const rowAt = (clientY) => {
      for (const r of rowRects) if (clientY >= r.top && clientY < r.bottom) return r.id;
      if (rowRects.length === 0) return null;
      if (clientY < rowRects[0].top) return rowRects[0].id;
      return null;
    };
    let highlightedRow = null;
    const setHighlight = (rowId) => {
      if (highlightedRow) highlightedRow.classList.remove("ar-audiotrack__body--dropping");
      highlightedRow = rowId ? this._elTrackBodies.querySelector(`[data-track-row="${rowId}"]`) : null;
      if (highlightedRow) highlightedRow.classList.add("ar-audiotrack__body--dropping");
    };
    try {
      el.setPointerCapture(e.pointerId);
    } catch {
    }
    const onMove = (ev) => {
      if (ev.pointerId !== e.pointerId) return;
      const dx = (ev.clientX - startX) / px;
      if (mode === "move") {
        c.start = Math.max(0, startStart + dx);
      } else if (mode === "resize-right") {
        c.duration = Math.max(0.05, startDur + dx);
      } else if (mode === "resize-left") {
        const newStart = Math.max(0, startStart + dx);
        const delta = newStart - startStart;
        c.start = newStart;
        c.offset = startOffset + delta;
        c.duration = Math.max(0.05, startDur - delta);
      }
      el.style.left = c.start * px + "px";
      el.style.width = Math.max(20, c.duration * px) + "px";
      if (mode === "move") {
        let targetTrackId = rowAt(ev.clientY);
        const lastBottom = rowRects.length ? rowRects[rowRects.length - 1].bottom : 0;
        if (!targetTrackId && !autoCreatedThisDrag && ev.clientY >= lastBottom) {
          targetTrackId = autoCreateTrackBelow();
        }
        if (targetTrackId && rowRects.length > 0 && ev.clientY < lastBottom - 4) {
          autoCreatedThisDrag = false;
        }
        if (targetTrackId && targetTrackId !== c.trackId) {
          c.trackId = targetTrackId;
          const newRow = this._elTrackBodies.querySelector(`[data-track-row="${targetTrackId}"]`);
          if (newRow && el.parentElement !== newRow) newRow.appendChild(el);
          const t = this._tracks.find((x) => x.id === targetTrackId);
          if (t) {
            el.style.background = (t.color || "#3b82f6") + "33";
            el.style.borderColor = t.color || "#3b82f6";
          }
          setHighlight(targetTrackId);
        } else if (!targetTrackId) {
          setHighlight(null);
        } else {
          setHighlight(targetTrackId);
        }
      }
    };
    const cleanup = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      try {
        el.releasePointerCapture(e.pointerId);
      } catch {
      }
    };
    const onUp = (ev) => {
      if (ev.pointerId !== e.pointerId) return;
      cleanup();
      setHighlight(null);
      this._renderClips();
      if (mode === "move" && c.trackId !== startTrackId) {
        this._emit("change", { kind: "move-clip-track", clip: c, fromTrack: startTrackId, toTrack: c.trackId });
      }
      this._emit("change", { kind: mode + "-clip", clip: c });
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
  }
  _drawWaveform(canvas, c) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const w = canvas.width, h = canvas.height;
    const data = c.buffer.getChannelData(0);
    const startSample = Math.floor(c.offset * c.buffer.sampleRate);
    const endSample = Math.min(data.length, startSample + Math.floor(c.duration * c.buffer.sampleRate));
    const samplesPerPx = (endSample - startSample) / w;
    ctx.fillStyle = "rgba(255,255,255,.7)";
    const mid = h / 2;
    for (let x = 0; x < w; x++) {
      const i = startSample + Math.floor(x * samplesPerPx);
      const j = Math.min(endSample, i + Math.ceil(samplesPerPx));
      let min = 1, max = -1;
      for (let k = i; k < j; k++) {
        const v = data[k] || 0;
        if (v < min) min = v;
        if (v > max) max = v;
      }
      const y1 = mid - max * mid;
      const y2 = mid - min * mid;
      ctx.fillRect(x, y1, 1, Math.max(1, y2 - y1));
    }
  }
  _renderPlayhead() {
    const px = this._pxPerSec * this._zoom;
    this._elPlayhead.style.display = "block";
    this._elPlayhead.style.left = this._playhead * px + "px";
  }
  _injectStyles() {
    if (document.getElementById("ar-audiotrack-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-audiotrack-styles";
    s.textContent = `
.ar-audiotrack { font:12px -apple-system,system-ui,sans-serif; background:#1e1e1e; color:#d4d4d4; border-radius:4px; display:flex; flex-direction:column; height:100%; min-height:300px; user-select:none; }
.ar-audiotrack__toolbar { background:#252525; padding:6px 10px; display:flex; gap:8px; align-items:center; border-bottom:1px solid #333; flex-shrink:0; }
.ar-audiotrack__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:12px sans-serif; border-radius:3px; cursor:pointer; }
.ar-audiotrack__btn:hover { background:#2a2a2a; }
.ar-audiotrack__lbl { font:11px sans-serif; color:#888; }
.ar-audiotrack__zoom { width:120px; -webkit-appearance:none; height:3px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-audiotrack__zoom::-webkit-slider-thumb { -webkit-appearance:none; width:10px; height:10px; border-radius:50%; background:#e40c88; cursor:pointer; }
.ar-audiotrack__main { flex:1; display:flex; min-height:0; overflow:hidden; }
.ar-audiotrack__heads { width:140px; background:#252525; border-right:1px solid #333; overflow-y:auto; flex-shrink:0; }
.ar-audiotrack__head { height:80px; padding:6px 8px; border-bottom:1px solid #333; box-sizing:border-box; cursor:pointer; touch-action:manipulation; }
.ar-audiotrack__head.selected { background:rgba(228,12,136,0.12); box-shadow:inset 0 0 0 2px #e40c88; }
.ar-audiotrack__head-row { display:flex; align-items:center; gap:4px; margin:2px 0; }
.ar-audiotrack__head-name { flex:1; font-weight:600; font-size:11px; }
.ar-audiotrack__head-x { background:transparent; border:0; color:#666; font-size:18px; line-height:1; cursor:pointer; padding:6px 10px; min-width:32px; min-height:28px; border-radius:3px; touch-action:manipulation; }
.ar-audiotrack__head-x:hover { color:#dc2626; background:rgba(220,38,38,0.1); }
.ar-audiotrack__btn-sm { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:10px sans-serif; font-weight:600; border-radius:2px; cursor:pointer; touch-action:manipulation; min-height:24px; }
.ar-audiotrack__btn-sm.mute.active { background:#dc2626; border-color:#dc2626; color:#fff; }
.ar-audiotrack__btn-sm.solo.active { background:#eab308; border-color:#eab308; color:#1f1f1f; }
.ar-audiotrack__rest { flex:1; overflow:auto; }
.ar-audiotrack__ruler { background:#252525; border-bottom:1px solid #333; height:22px; position:relative; touch-action:none; }
.ar-audiotrack__ruler-tick { position:absolute; top:0; bottom:0; width:1px; background:#555; }
.ar-audiotrack__ruler-lbl  { position:absolute; top:4px; font:10px ui-monospace,monospace; color:#999; }
.ar-audiotrack__bodies { position:relative; min-height:200px; }
.ar-audiotrack__body { height:80px; border-bottom:1px solid #333; position:relative; }
.ar-audiotrack__clip { position:absolute; top:4px; bottom:4px; border:1.5px solid #e40c88; border-radius:3px; background:rgba(228,12,136,.2); cursor:move; overflow:hidden; touch-action:none; }
.ar-audiotrack__clip.selected { box-shadow:0 0 0 2px #fff inset; }
.ar-audiotrack__clip-lbl { position:absolute; top:2px; left:6px; font:10px sans-serif; color:#fff; pointer-events:none; }
.ar-audiotrack__clip-h { position:absolute; top:0; bottom:0; width:10px; cursor:ew-resize; touch-action:none; }
.ar-audiotrack__clip-h.left { left:0; }
.ar-audiotrack__clip-h.right { right:0; }
.ar-audiotrack__wave { position:absolute; left:0; top:18px; pointer-events:none; }
.ar-audiotrack__playhead { position:absolute; top:0; bottom:0; width:2px; background:#16a34a; pointer-events:none; box-shadow:0 0 4px rgba(22,163,74,.5); z-index:10; }

/* Cross-track drag \u2014 destination row highlight (Task A) */
.ar-audiotrack__body--dropping { background:rgba(228,12,136,0.10); outline:1px dashed #e40c88; outline-offset:-1px; }

/* Loop selection \u2014 overlay on the ruler (Task B) */
.ar-audiotrack__loop-range  { position:absolute; top:0; bottom:0; background:rgba(228,12,136,0.18); border-top:2px solid #e40c88; border-bottom:2px solid #e40c88; cursor:grab; z-index:5; }
.ar-audiotrack__loop-range:active { cursor:grabbing; }
.ar-audiotrack__loop-handle { position:absolute; top:0; bottom:0; width:6px; margin-left:-3px; background:#e40c88; cursor:ew-resize; z-index:6; }
.ar-audiotrack__loop-handle::after { content:''; position:absolute; top:50%; left:50%; width:2px; height:8px; margin:-4px 0 0 -1px; background:rgba(255,255,255,0.7); border-radius:1px; }
`;
    document.head.appendChild(s);
  }
};
function formatTime2(s) {
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

// components/audio/AudioEditor.ts
var AudioEditor = class extends AudioComponent {
  // Audio data — flattened mutable buffer
  _channels = [];
  _sampleRate = 44100;
  _numChannels = 1;
  // View state
  _zoom;
  _basePxPerSample;
  _scrollSamples = 0;
  // first visible sample index
  _selection = { start: 0, end: 0 };
  // Undo
  _undoStack = [];
  _redoStack = [];
  // Playback
  _activeSource;
  _outputGain;
  _playStart = 0;
  // ctx time at play start
  _playFromSample = 0;
  _playRAF = 0;
  _playing = false;
  // Clipboard (in-memory)
  _clipboard = null;
  // DOM
  _elCanvas;
  _elScroll;
  _elInfo;
  _elPlayhead;
  _elZoom;
  constructor(container, opts = {}) {
    super(container, "div", {
      pxPerSample: 0.05,
      zoom: 1,
      maxUndo: 50,
      ...opts
    });
    this.el.className = `ar-audioeditor${opts.class ? " " + opts.class : ""}`;
    this._zoom = this._get("zoom", 1);
    this._basePxPerSample = this._get("pxPerSample", 0.05);
    this._injectStyles();
    this._buildAudioGraph();
    this._buildShell();
    if (opts.src) {
      if (opts.src instanceof AudioBuffer) {
        this.setBuffer(opts.src);
      } else {
        queueMicrotask(async () => {
          const buf = await this.loadFile(opts.src);
          this.setBuffer(buf);
        });
      }
    }
    this._on(document, "keydown", (e) => {
      if (!this.el.contains(document.activeElement) && document.activeElement !== document.body) return;
      const tg = e.target;
      if (tg.tagName === "INPUT" || tg.tagName === "TEXTAREA") return;
      const meta = e.metaKey || e.ctrlKey;
      if (meta && e.key === "z" && !e.shiftKey) {
        this.undo();
        e.preventDefault();
      } else if (meta && (e.key === "Z" || e.key === "z" && e.shiftKey)) {
        this.redo();
        e.preventDefault();
      } else if (meta && (e.key === "c" || e.key === "C")) {
        this.copy();
        e.preventDefault();
      } else if (meta && (e.key === "x" || e.key === "X")) {
        this.cut();
        e.preventDefault();
      } else if (meta && (e.key === "v" || e.key === "V")) {
        this.paste();
        e.preventDefault();
      } else if (meta && (e.key === "a" || e.key === "A")) {
        this._selection = { start: 0, end: this._totalSamples() };
        this._redraw();
        e.preventDefault();
      } else if (e.key === "Delete" || e.key === "Backspace") {
        this.delete();
        e.preventDefault();
      } else if (e.key === " ") {
        e.preventDefault();
        this._playing ? this.stop() : this.play();
      }
    });
  }
  // ── Public API ──────────────────────────────────────────────────────────
  /** Load a file or URL into an AudioBuffer (does not set it). */
  async loadFile(src) {
    let arr;
    if (typeof src === "string") arr = await (await fetch(src)).arrayBuffer();
    else if (src instanceof File) arr = await src.arrayBuffer();
    else arr = src;
    return await this._audioCtx.decodeAudioData(arr);
  }
  /** Set the buffer to edit. Replaces current data; clears undo. */
  setBuffer(buf) {
    this._sampleRate = buf.sampleRate;
    this._numChannels = buf.numberOfChannels;
    this._channels = [];
    for (let c = 0; c < buf.numberOfChannels; c++) {
      this._channels.push(new Float32Array(buf.getChannelData(c)));
    }
    this._selection = { start: 0, end: 0 };
    this._undoStack = [];
    this._redoStack = [];
    this._scrollSamples = 0;
    this._redraw();
    this._refreshInfo();
    this._emit("change", { kind: "load" });
    return this;
  }
  /** Build a fresh AudioBuffer from current state. */
  getBuffer() {
    if (this._channels.length === 0) return null;
    const buf = this._audioCtx.createBuffer(
      this._numChannels,
      this._channels[0].length,
      this._sampleRate
    );
    for (let c = 0; c < this._numChannels; c++) {
      buf.getChannelData(c).set(this._channels[c]);
    }
    return buf;
  }
  /** Set selection in seconds. */
  setSelectionTime(start, end) {
    this._selection = {
      start: Math.max(0, Math.floor(start * this._sampleRate)),
      end: Math.min(this._totalSamples(), Math.floor(end * this._sampleRate))
    };
    this._redraw();
    this._emit("selection", this.getSelectionTime());
    return this;
  }
  /** Get selection in seconds. */
  getSelectionTime() {
    return {
      start: this._selection.start / this._sampleRate,
      end: this._selection.end / this._sampleRate
    };
  }
  setZoom(z) {
    this._zoom = Math.max(0.05, Math.min(50, z));
    if (this._elZoom) this._elZoom.value = String(this._zoom);
    this._redraw();
    return this;
  }
  // ── Edit operations (all destructive, all push undo) ───────────────────
  cut() {
    if (this._channels.length === 0) return this;
    if (this._selection.start === this._selection.end) return this;
    this.copy();
    this.delete();
    return this;
  }
  copy() {
    const sel = this._selection;
    if (sel.start === sel.end) return this;
    this._clipboard = {
      channels: this._channels.map((ch) => new Float32Array(ch.subarray(sel.start, sel.end))),
      sampleRate: this._sampleRate
    };
    this._emit("change", { kind: "copy" });
    return this;
  }
  paste() {
    if (!this._clipboard) return this;
    if (this._channels.length === 0) {
      this._sampleRate = this._clipboard.sampleRate;
      this._numChannels = this._clipboard.channels.length;
      this._channels = this._clipboard.channels.map((c) => new Float32Array(c));
      this._selection = { start: 0, end: this._channels[0].length };
      this._refreshInfo();
      this._redraw();
      this._emit("change", { kind: "paste" });
      return this;
    }
    this._pushUndo();
    const insertAt = this._selection.start;
    const sel = this._selection;
    const replaceLen = sel.end - sel.start;
    const pasteLen = this._clipboard.channels[0].length;
    for (let c = 0; c < this._numChannels; c++) {
      const ch = this._channels[c];
      const clip = this._clipboard.channels[Math.min(c, this._clipboard.channels.length - 1)];
      const out = new Float32Array(ch.length - replaceLen + pasteLen);
      out.set(ch.subarray(0, insertAt));
      out.set(clip, insertAt);
      out.set(ch.subarray(insertAt + replaceLen), insertAt + pasteLen);
      this._channels[c] = out;
    }
    this._selection = { start: insertAt, end: insertAt + pasteLen };
    this._refreshInfo();
    this._redraw();
    this._emit("change", { kind: "paste" });
    return this;
  }
  delete() {
    const sel = this._selection;
    if (sel.start === sel.end || this._channels.length === 0) return this;
    this._pushUndo();
    const len = sel.end - sel.start;
    for (let c = 0; c < this._numChannels; c++) {
      const ch = this._channels[c];
      const out = new Float32Array(ch.length - len);
      out.set(ch.subarray(0, sel.start));
      out.set(ch.subarray(sel.end), sel.start);
      this._channels[c] = out;
    }
    this._selection = { start: sel.start, end: sel.start };
    this._refreshInfo();
    this._redraw();
    this._emit("change", { kind: "delete" });
    return this;
  }
  /** Insert N seconds of silence at selection start. */
  insertSilence(seconds) {
    if (this._channels.length === 0) return this;
    this._pushUndo();
    const insertAt = this._selection.start;
    const len = Math.floor(seconds * this._sampleRate);
    for (let c = 0; c < this._numChannels; c++) {
      const ch = this._channels[c];
      const out = new Float32Array(ch.length + len);
      out.set(ch.subarray(0, insertAt));
      out.set(ch.subarray(insertAt), insertAt + len);
      this._channels[c] = out;
    }
    this._selection = { start: insertAt, end: insertAt + len };
    this._refreshInfo();
    this._redraw();
    this._emit("change", { kind: "silence" });
    return this;
  }
  /** Apply linear fade-in to current selection. */
  fadeIn() {
    const sel = this._selection;
    if (sel.start === sel.end) return this;
    this._pushUndo();
    const len = sel.end - sel.start;
    for (const ch of this._channels) {
      for (let i = 0; i < len; i++) {
        ch[sel.start + i] *= i / len;
      }
    }
    this._redraw();
    this._emit("change", { kind: "fade-in" });
    return this;
  }
  /** Apply linear fade-out to current selection. */
  fadeOut() {
    const sel = this._selection;
    if (sel.start === sel.end) return this;
    this._pushUndo();
    const len = sel.end - sel.start;
    for (const ch of this._channels) {
      for (let i = 0; i < len; i++) {
        ch[sel.start + i] *= 1 - i / len;
      }
    }
    this._redraw();
    this._emit("change", { kind: "fade-out" });
    return this;
  }
  /** Normalize selection (or whole file if no selection) to peak target. */
  normalize(targetDb = 0) {
    if (this._channels.length === 0) return this;
    this._pushUndo();
    const sel = this._selection.start === this._selection.end ? { start: 0, end: this._totalSamples() } : this._selection;
    let peak = 0;
    for (const ch of this._channels) {
      for (let i = sel.start; i < sel.end; i++) {
        const v = Math.abs(ch[i]);
        if (v > peak) peak = v;
      }
    }
    if (peak === 0) return this;
    const target = Math.pow(10, targetDb / 20);
    const factor = target / peak;
    for (const ch of this._channels) {
      for (let i = sel.start; i < sel.end; i++) {
        ch[i] *= factor;
      }
    }
    this._redraw();
    this._emit("change", { kind: "normalize", factor });
    return this;
  }
  /** Apply gain (dB) to selection or whole. */
  gain(db) {
    if (this._channels.length === 0) return this;
    this._pushUndo();
    const sel = this._selection.start === this._selection.end ? { start: 0, end: this._totalSamples() } : this._selection;
    const factor = Math.pow(10, db / 20);
    for (const ch of this._channels) {
      for (let i = sel.start; i < sel.end; i++) {
        ch[i] *= factor;
      }
    }
    this._redraw();
    this._emit("change", { kind: "gain", db });
    return this;
  }
  /** Reverse selection in-place. */
  reverse() {
    if (this._channels.length === 0) return this;
    this._pushUndo();
    const sel = this._selection.start === this._selection.end ? { start: 0, end: this._totalSamples() } : this._selection;
    for (const ch of this._channels) {
      const seg = ch.subarray(sel.start, sel.end);
      seg.reverse();
    }
    this._redraw();
    this._emit("change", { kind: "reverse" });
    return this;
  }
  // ── Undo / Redo ─────────────────────────────────────────────────────────
  _pushUndo() {
    const max = this._get("maxUndo", 50);
    this._undoStack.push({
      channels: this._channels.map((c) => new Float32Array(c)),
      sampleRate: this._sampleRate,
      numChannels: this._numChannels,
      selection: { ...this._selection }
    });
    if (this._undoStack.length > max) this._undoStack.shift();
    this._redoStack = [];
  }
  undo() {
    const f = this._undoStack.pop();
    if (!f) return this;
    this._redoStack.push({
      channels: this._channels.map((c) => new Float32Array(c)),
      sampleRate: this._sampleRate,
      numChannels: this._numChannels,
      selection: { ...this._selection }
    });
    this._channels = f.channels.map((c) => new Float32Array(c));
    this._sampleRate = f.sampleRate;
    this._numChannels = f.numChannels;
    this._selection = { ...f.selection };
    this._refreshInfo();
    this._redraw();
    this._emit("change", { kind: "undo" });
    return this;
  }
  redo() {
    const f = this._redoStack.pop();
    if (!f) return this;
    this._undoStack.push({
      channels: this._channels.map((c) => new Float32Array(c)),
      sampleRate: this._sampleRate,
      numChannels: this._numChannels,
      selection: { ...this._selection }
    });
    this._channels = f.channels.map((c) => new Float32Array(c));
    this._sampleRate = f.sampleRate;
    this._numChannels = f.numChannels;
    this._selection = { ...f.selection };
    this._refreshInfo();
    this._redraw();
    this._emit("change", { kind: "redo" });
    return this;
  }
  // ── Playback ────────────────────────────────────────────────────────────
  play() {
    if (this._playing || this._channels.length === 0) return this;
    AudioComponent.resume();
    this._playing = true;
    const buf = this.getBuffer();
    if (!buf) return this;
    const fromSample = this._selection.start;
    this._playFromSample = fromSample;
    this._playStart = this._audioCtx.currentTime;
    const src = this._audioCtx.createBufferSource();
    src.buffer = buf;
    src.connect(this._outputGain);
    src.start(0, fromSample / this._sampleRate);
    src.onended = () => {
      if (this._activeSource === src) {
        this._playing = false;
        if (this._playRAF) cancelAnimationFrame(this._playRAF);
        this._elPlayhead.style.display = "none";
      }
    };
    this._activeSource = src;
    this._elPlayhead.style.display = "block";
    this._tickPlayhead();
    this._emit("play", {});
    return this;
  }
  stop() {
    if (this._activeSource) {
      try {
        this._activeSource.stop();
      } catch {
      }
      this._activeSource = void 0;
    }
    this._playing = false;
    if (this._playRAF) cancelAnimationFrame(this._playRAF);
    this._elPlayhead.style.display = "none";
    this._emit("stop", {});
    return this;
  }
  _tickPlayhead = () => {
    if (!this._playing) return;
    const elapsed = this._audioCtx.currentTime - this._playStart;
    const sample = this._playFromSample + elapsed * this._sampleRate;
    if (sample >= this._totalSamples()) {
      this.stop();
      return;
    }
    const px = this._sampleToPixel(sample);
    this._elPlayhead.style.left = px + "px";
    this._playRAF = requestAnimationFrame(this._tickPlayhead);
  };
  // ── Internal ────────────────────────────────────────────────────────────
  _buildAudioGraph() {
    this._outputGain = this._audioCtx.createGain();
    this._outputGain.connect(this._audioCtx.destination);
    this._output = this._outputGain;
  }
  _build() {
  }
  _buildShell() {
    this.el.innerHTML = `
<div class="ar-audioeditor__toolbar">
  <label class="ar-audioeditor__btn" style="cursor:pointer">+ Load
    <input type="file" accept="audio/*" data-r="upload" style="display:none">
  </label>
  <button class="ar-audioeditor__btn" data-r="play">\u25B6</button>
  <button class="ar-audioeditor__btn" data-r="stop">\u25A0</button>
  <span class="ar-audioeditor__sep">|</span>
  <button class="ar-audioeditor__btn" data-r="cut"   title="Cut (\u2318X)">Cut</button>
  <button class="ar-audioeditor__btn" data-r="copy"  title="Copy (\u2318C)">Copy</button>
  <button class="ar-audioeditor__btn" data-r="paste" title="Paste (\u2318V)">Paste</button>
  <button class="ar-audioeditor__btn" data-r="del"   title="Delete (\u232B)">Del</button>
  <span class="ar-audioeditor__sep">|</span>
  <button class="ar-audioeditor__btn" data-r="fadein">Fade In</button>
  <button class="ar-audioeditor__btn" data-r="fadeout">Fade Out</button>
  <button class="ar-audioeditor__btn" data-r="norm">Normalize</button>
  <button class="ar-audioeditor__btn" data-r="rev">Reverse</button>
  <span class="ar-audioeditor__sep">|</span>
  <button class="ar-audioeditor__btn" data-r="undo" title="Undo (\u2318Z)">\u21B6</button>
  <button class="ar-audioeditor__btn" data-r="redo" title="Redo (\u2318\u21E7Z)">\u21B7</button>
  <span class="ar-audioeditor__sep">|</span>
  <span class="ar-audioeditor__lbl">Zoom</span>
  <input type="range" class="ar-audioeditor__zoom" data-r="zoom" min="0.05" max="50" step="0.05" value="1">
  <span class="ar-audioeditor__info" data-r="info">no audio</span>
</div>
<div class="ar-audioeditor__canvas-wrap" data-r="scroll">
  <canvas class="ar-audioeditor__canvas" data-r="canvas"></canvas>
  <div class="ar-audioeditor__playhead" data-r="playhead" style="display:none"></div>
</div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elCanvas = r("canvas");
    this._elScroll = r("scroll");
    this._elInfo = r("info");
    this._elPlayhead = r("playhead");
    this._elZoom = r("zoom");
    const upload = r("upload");
    upload.addEventListener("change", async () => {
      const f = upload.files?.[0];
      if (!f) return;
      this._elInfo.textContent = "\u23F3 decoding...";
      const buf = await this.loadFile(f);
      this.setBuffer(buf);
    });
    r("play").addEventListener("click", () => this.play());
    r("stop").addEventListener("click", () => this.stop());
    r("cut").addEventListener("click", () => this.cut());
    r("copy").addEventListener("click", () => this.copy());
    r("paste").addEventListener("click", () => this.paste());
    r("del").addEventListener("click", () => this.delete());
    r("fadein").addEventListener("click", () => this.fadeIn());
    r("fadeout").addEventListener("click", () => this.fadeOut());
    r("norm").addEventListener("click", () => this.normalize());
    r("rev").addEventListener("click", () => this.reverse());
    r("undo").addEventListener("click", () => this.undo());
    r("redo").addEventListener("click", () => this.redo());
    this._elZoom.addEventListener("input", () => this.setZoom(parseFloat(this._elZoom.value)));
    this._elCanvas.addEventListener("pointerdown", (e) => this._onCanvasDown(e));
    new ResizeObserver(() => this._redraw()).observe(this._elScroll);
  }
  _onCanvasDown(e) {
    if (this._channels.length === 0) return;
    e.preventDefault();
    const rect = this._elCanvas.getBoundingClientRect();
    const x0 = e.clientX - rect.left;
    const startSample = this._pixelToSample(x0);
    this._selection = { start: startSample, end: startSample };
    this._redraw();
    this._elCanvas.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const x = ev.clientX - rect.left;
      const s = this._pixelToSample(x);
      this._selection = {
        start: Math.min(startSample, s),
        end: Math.max(startSample, s)
      };
      this._redraw();
    };
    const onUp = () => {
      this._elCanvas.removeEventListener("pointermove", onMove);
      this._elCanvas.removeEventListener("pointerup", onUp);
      this._emit("selection", this.getSelectionTime());
    };
    this._elCanvas.addEventListener("pointermove", onMove);
    this._elCanvas.addEventListener("pointerup", onUp);
  }
  _totalSamples() {
    return this._channels.length > 0 ? this._channels[0].length : 0;
  }
  _sampleToPixel(s) {
    return s * this._basePxPerSample * this._zoom;
  }
  _pixelToSample(x) {
    return Math.max(0, Math.min(
      this._totalSamples(),
      Math.floor(x / (this._basePxPerSample * this._zoom))
    ));
  }
  _redraw() {
    if (this._channels.length === 0) {
      const ctx2 = this._elCanvas.getContext("2d");
      if (ctx2) {
        this._elCanvas.width = this._elScroll.clientWidth;
        this._elCanvas.height = this._elScroll.clientHeight;
        ctx2.fillStyle = "#1e1e1e";
        ctx2.fillRect(0, 0, this._elCanvas.width, this._elCanvas.height);
        ctx2.fillStyle = "#666";
        ctx2.font = "14px sans-serif";
        ctx2.textAlign = "center";
        ctx2.fillText("Drop or load an audio file", this._elCanvas.width / 2, this._elCanvas.height / 2);
      }
      return;
    }
    const totalPx = Math.max(this._elScroll.clientWidth, this._sampleToPixel(this._totalSamples()));
    this._elCanvas.width = Math.ceil(totalPx);
    this._elCanvas.height = this._elScroll.clientHeight;
    const ctx = this._elCanvas.getContext("2d");
    if (!ctx) return;
    const w = this._elCanvas.width, h = this._elCanvas.height;
    ctx.fillStyle = "#1e1e1e";
    ctx.fillRect(0, 0, w, h);
    if (this._selection.start !== this._selection.end) {
      const x1 = this._sampleToPixel(this._selection.start);
      const x2 = this._sampleToPixel(this._selection.end);
      ctx.fillStyle = "rgba(228, 12, 136, 0.2)";
      ctx.fillRect(x1, 0, x2 - x1, h);
    }
    ctx.strokeStyle = "#333";
    ctx.lineWidth = 1;
    const channelH = h / this._numChannels;
    for (let c = 0; c < this._numChannels; c++) {
      const mid = c * channelH + channelH / 2;
      ctx.beginPath();
      ctx.moveTo(0, mid);
      ctx.lineTo(w, mid);
      ctx.stroke();
    }
    const totalSamples = this._totalSamples();
    const samplesPerPx = totalSamples / w;
    ctx.fillStyle = "#e40c88";
    for (let c = 0; c < this._numChannels; c++) {
      const data = this._channels[c];
      const mid = c * channelH + channelH / 2;
      if (samplesPerPx >= 1) {
        for (let x = 0; x < w; x++) {
          const i = Math.floor(x * samplesPerPx);
          const j = Math.min(totalSamples, Math.floor((x + 1) * samplesPerPx));
          let min = 1, max = -1;
          for (let k = i; k < j; k++) {
            const v = data[k];
            if (v < min) min = v;
            if (v > max) max = v;
          }
          const y1 = mid - max * (channelH / 2);
          const y2 = mid - min * (channelH / 2);
          ctx.fillRect(x, y1, 1, Math.max(1, y2 - y1));
        }
      } else {
        ctx.strokeStyle = "#e40c88";
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let x = 0; x < w; x++) {
          const i = Math.floor(x * samplesPerPx);
          const v = data[i] || 0;
          const y = mid - v * (channelH / 2);
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
    }
    if (this._selection.start !== this._selection.end) {
      const x1 = this._sampleToPixel(this._selection.start);
      const x2 = this._sampleToPixel(this._selection.end);
      ctx.strokeStyle = "#e40c88";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x1, 0);
      ctx.lineTo(x1, h);
      ctx.moveTo(x2, 0);
      ctx.lineTo(x2, h);
      ctx.stroke();
    }
  }
  _refreshInfo() {
    if (this._channels.length === 0) {
      this._elInfo.textContent = "no audio";
      return;
    }
    const dur = this._totalSamples() / this._sampleRate;
    const sel = this._selection;
    const selDur = (sel.end - sel.start) / this._sampleRate;
    let txt = `${this._numChannels}ch \xB7 ${this._sampleRate}Hz \xB7 ${formatTime3(dur)}`;
    if (selDur > 0) txt += ` \xB7 sel ${formatTime3(selDur)}`;
    this._elInfo.textContent = txt;
  }
  _injectStyles() {
    if (document.getElementById("ar-audioeditor-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-audioeditor-styles";
    s.textContent = `
.ar-audioeditor { font:12px -apple-system,system-ui,sans-serif; background:#1e1e1e; color:#d4d4d4; border-radius:4px; display:flex; flex-direction:column; height:100%; min-height:300px; user-select:none; }
.ar-audioeditor__toolbar { background:#252525; padding:6px 10px; display:flex; gap:6px; align-items:center; border-bottom:1px solid #333; flex-shrink:0; flex-wrap:wrap; }
.ar-audioeditor__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:12px sans-serif; border-radius:3px; cursor:pointer; }
.ar-audioeditor__btn:hover { background:#2a2a2a; }
.ar-audioeditor__sep { color:#444; padding:0 4px; }
.ar-audioeditor__lbl { font:11px sans-serif; color:#888; }
.ar-audioeditor__zoom { width:120px; -webkit-appearance:none; height:3px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-audioeditor__zoom::-webkit-slider-thumb { -webkit-appearance:none; width:10px; height:10px; border-radius:50%; background:#e40c88; cursor:pointer; }
.ar-audioeditor__zoom::-moz-range-thumb     { width:10px; height:10px; border-radius:50%; background:#e40c88; cursor:pointer; border:0; }
.ar-audioeditor__info { font:10px ui-monospace,monospace; color:#888; margin-left:auto; }
.ar-audioeditor__canvas-wrap { flex:1; overflow-x:auto; overflow-y:hidden; position:relative; min-height:0; }
.ar-audioeditor__canvas { display:block; cursor:crosshair; }
.ar-audioeditor__playhead { position:absolute; top:0; bottom:0; width:2px; background:#16a34a; pointer-events:none; box-shadow:0 0 4px rgba(22,163,74,.5); }
`;
    document.head.appendChild(s);
  }
};
function formatTime3(s) {
  if (!isFinite(s) || s < 0) return "0:00";
  const m = Math.floor(s / 60);
  const r = (s % 60).toFixed(2);
  return `${m}:${r.padStart(5, "0")}`;
}

// components/audio/TransportBar.ts
var TransportBar = class extends Control {
  // State
  _playing = false;
  _recording = false;
  _loop = false;
  _time = 0;
  // current position in seconds
  _bpm = 120;
  _ppqn = 480;
  _framerate = 30;
  _timeSig = [4, 4];
  _sampleRate = 48e3;
  _mode = "bars";
  // DOM refs
  _elRewind;
  _elPlay;
  _elStop;
  _elForward;
  _elRecord;
  _elLoop;
  _elCounter;
  _elModeBtn;
  _elBpm;
  _elTimeSig;
  constructor(container, opts = {}) {
    super(container, "div", {
      mode: "bars",
      bpm: 120,
      timeSignature: "4/4",
      sampleRate: 48e3,
      ppqn: 480,
      framerate: 30,
      showIndicators: true,
      showRecord: true,
      loopEnabled: false,
      playing: false,
      ...opts
    });
    this.el.className = `ar-transportbar${opts.class ? " " + opts.class : ""}`;
    this._mode = this._get("mode", "bars");
    this._bpm = this._get("bpm", 120);
    this._ppqn = this._get("ppqn", 480);
    this._framerate = this._get("framerate", 30);
    this._sampleRate = this._get("sampleRate", 48e3);
    this._loop = this._get("loopEnabled", false);
    this._playing = this._get("playing", false);
    this._timeSig = parseTimeSig(this._get("timeSignature", "4/4"));
    this._injectStyles();
    this._build();
  }
  // ── Public API: state setters (host → bar) ─────────────────────────────
  /** Update displayed playback state without firing events. */
  setPlaying(playing) {
    this._playing = playing;
    this._refreshPlayButton();
    return this;
  }
  /** Update displayed counter (host drives this on every audio frame / tick). */
  setTime(seconds) {
    this._time = Math.max(0, seconds);
    this._refreshCounter();
    return this;
  }
  /** Update record-armed state without firing events. */
  setRecording(rec) {
    this._recording = rec;
    this._refreshRecordButton();
    return this;
  }
  /** Update loop-enabled state without firing events. */
  setLoop(enabled) {
    this._loop = enabled;
    this._refreshLoopButton();
    return this;
  }
  /** Programmatically change BPM (also updates the input). */
  setBpm(bpm) {
    this._bpm = Math.max(1, bpm);
    if (this._elBpm) this._elBpm.value = String(this._bpm);
    this._refreshCounter();
    return this;
  }
  /** Programmatically change time signature (e.g. "3/4", "7/8"). */
  setTimeSignature(sig) {
    this._timeSig = parseTimeSig(sig);
    if (this._elTimeSig) this._elTimeSig.value = sig;
    this._refreshCounter();
    return this;
  }
  /** Switch between SMPTE and bars display. */
  setMode(mode) {
    this._mode = mode;
    this._elModeBtn.textContent = mode === "smpte" ? "SMPTE" : "BARS";
    this._refreshCounter();
    this._emit("mode", { mode });
    return this;
  }
  // ── Public API: getters ────────────────────────────────────────────────
  getTime() {
    return this._time;
  }
  getBpm() {
    return this._bpm;
  }
  getMode() {
    return this._mode;
  }
  isPlaying() {
    return this._playing;
  }
  isRecording() {
    return this._recording;
  }
  isLooping() {
    return this._loop;
  }
  // ── Building ──────────────────────────────────────────────────────────
  _build() {
    const showIndicators = this._get("showIndicators", true);
    const showRecord = this._get("showRecord", true);
    this.el.innerHTML = `
<div class="ar-transportbar__group ar-transportbar__group--ctrl">
  <button class="ar-transportbar__btn" data-r="rewind"  title="Rewind">\u23EE</button>
  <button class="ar-transportbar__btn ar-transportbar__btn--play" data-r="play" title="Play">\u25B6</button>
  <button class="ar-transportbar__btn" data-r="stop"    title="Stop">\u25A0</button>
  <button class="ar-transportbar__btn" data-r="forward" title="Fast forward">\u23ED</button>
  ${showRecord ? `<button class="ar-transportbar__btn ar-transportbar__btn--rec" data-r="record" title="Record">\u25CF</button>` : ""}
  <button class="ar-transportbar__btn" data-r="loop"   title="Toggle loop">\u{1F501}</button>
</div>

<div class="ar-transportbar__counter" data-r="counter" title="Click to switch mode">0.1.0</div>
<button class="ar-transportbar__mode" data-r="mode" title="Switch SMPTE / BARS">${this._mode.toUpperCase()}</button>

${showIndicators ? `
<div class="ar-transportbar__group ar-transportbar__group--meta">
  <label class="ar-transportbar__lbl">BPM</label>
  <input  class="ar-transportbar__num" data-r="bpm" type="number" min="1" max="999" step="1" value="${this._bpm}">
  <label class="ar-transportbar__lbl">Sig</label>
  <input  class="ar-transportbar__sig" data-r="timesig" type="text" maxlength="5" value="${this._timeSig[0]}/${this._timeSig[1]}">
  <span class="ar-transportbar__sr">${formatSampleRate(this._sampleRate)}</span>
</div>` : ""}
`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elRewind = r("rewind");
    this._elPlay = r("play");
    this._elStop = r("stop");
    this._elForward = r("forward");
    this._elLoop = r("loop");
    this._elCounter = r("counter");
    this._elModeBtn = r("mode");
    if (showRecord) this._elRecord = r("record");
    if (showIndicators) {
      this._elBpm = r("bpm");
      this._elTimeSig = r("timesig");
    }
    this._wireEvents();
    this._refreshPlayButton();
    this._refreshLoopButton();
    this._refreshRecordButton();
    this._refreshCounter();
  }
  _wireEvents() {
    this._elRewind.addEventListener("click", () => {
      this._time = 0;
      this._refreshCounter();
      this._emit("rewind", { time: this._time });
      this._emit("seek", { time: this._time });
    });
    this._elPlay.addEventListener("click", () => {
      if (this._playing) {
        this._playing = false;
        this._emit("pause", {});
      } else {
        this._playing = true;
        this._emit("play", {});
      }
      this._refreshPlayButton();
    });
    this._elStop.addEventListener("click", () => {
      this._playing = false;
      this._time = 0;
      this._refreshPlayButton();
      this._refreshCounter();
      this._emit("stop", {});
    });
    this._elForward.addEventListener("click", () => {
      this._time += 1;
      this._refreshCounter();
      this._emit("forward", { time: this._time });
      this._emit("seek", { time: this._time });
    });
    if (this._elRecord) {
      this._elRecord.addEventListener("click", () => {
        this._recording = !this._recording;
        this._refreshRecordButton();
        this._emit("record", { enabled: this._recording });
      });
    }
    this._elLoop.addEventListener("click", () => {
      this._loop = !this._loop;
      this._refreshLoopButton();
      this._emit("loop", { enabled: this._loop });
    });
    this._elCounter.addEventListener("click", () => this._toggleMode());
    this._elModeBtn.addEventListener("click", () => this._toggleMode());
    if (this._elBpm) {
      this._elBpm.addEventListener("change", () => {
        const v = parseFloat(this._elBpm.value);
        if (Number.isFinite(v) && v > 0) {
          this._bpm = v;
          this._refreshCounter();
          this._emit("bpm", { bpm: this._bpm });
        }
      });
    }
    if (this._elTimeSig) {
      this._elTimeSig.addEventListener("change", () => {
        const sig = this._elTimeSig.value.trim();
        this._timeSig = parseTimeSig(sig);
        this._refreshCounter();
        this._emit("timeSignature", { numerator: this._timeSig[0], denominator: this._timeSig[1] });
      });
    }
  }
  _toggleMode() {
    this.setMode(this._mode === "smpte" ? "bars" : "smpte");
  }
  // ── Refresh helpers ────────────────────────────────────────────────────
  _refreshPlayButton() {
    if (this._playing) {
      this._elPlay.textContent = "\u2016";
      this._elPlay.classList.add("ar-transportbar__btn--active");
      this._elPlay.title = "Pause";
    } else {
      this._elPlay.textContent = "\u25B6";
      this._elPlay.classList.remove("ar-transportbar__btn--active");
      this._elPlay.title = "Play";
    }
  }
  _refreshRecordButton() {
    if (!this._elRecord) return;
    this._elRecord.classList.toggle("ar-transportbar__btn--armed", this._recording);
  }
  _refreshLoopButton() {
    this._elLoop.classList.toggle("ar-transportbar__btn--active", this._loop);
  }
  _refreshCounter() {
    if (this._mode === "smpte") {
      this._elCounter.textContent = formatSMPTE(this._time, this._framerate);
    } else {
      this._elCounter.textContent = formatBars(this._time, this._bpm, this._timeSig, this._ppqn);
    }
  }
  // ── Styles ─────────────────────────────────────────────────────────────
  _injectStyles() {
    if (document.getElementById("ar-transportbar-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-transportbar-styles";
    s.textContent = `
.ar-transportbar { display:flex; flex-wrap:wrap; align-items:center; gap:14px; padding:8px 14px; background:#1e1e1e; border:1px solid #333; border-radius:6px; color:#d4d4d4; font:13px -apple-system,system-ui,sans-serif; user-select:none; box-sizing:border-box; max-width:100%; }
.ar-transportbar__group { display:flex; align-items:center; gap:4px; flex-wrap:wrap; }
/* Push the indicators block to the right when there is room; on narrow
   stages the wrap takes over and the auto-margin is harmless. */
.ar-transportbar__group--meta { gap:6px; margin-left:auto; }
.ar-transportbar__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:13px sans-serif; border-radius:3px; cursor:pointer; min-width:34px; transition:background .12s, border-color .12s; }
.ar-transportbar__btn:hover { background:#2a2a2a; }
.ar-transportbar__btn--play { background:#16a34a; border-color:#16a34a; color:#fff; }
.ar-transportbar__btn--play:hover { background:#15803d; }
.ar-transportbar__btn--play.ar-transportbar__btn--active { background:#15803d; }
.ar-transportbar__btn--rec { color:#ef4444; }
.ar-transportbar__btn--rec.ar-transportbar__btn--armed { background:#ef4444; color:#fff; border-color:#ef4444; animation:ar-pulse 1.2s ease-in-out infinite; }
@keyframes ar-pulse { 0%,100% { opacity:1; } 50% { opacity:.55; } }
.ar-transportbar__btn--active { background:#e40c88; border-color:#e40c88; color:#fff; }
.ar-transportbar__counter { font:600 18px ui-monospace,SFMono-Regular,Menlo,monospace; color:#fff; background:#0d0d0d; border:1px solid #333; border-radius:4px; padding:4px 12px; min-width:120px; text-align:center; cursor:pointer; letter-spacing:.06em; }
.ar-transportbar__counter:hover { border-color:#e40c88; }
.ar-transportbar__mode { background:transparent; border:1px solid #555; color:#888; font:600 10px sans-serif; padding:4px 8px; border-radius:3px; cursor:pointer; letter-spacing:.08em; }
.ar-transportbar__mode:hover { color:#e40c88; border-color:#e40c88; }
.ar-transportbar__lbl { font:10px sans-serif; color:#888; text-transform:uppercase; letter-spacing:.04em; }
.ar-transportbar__num { width:54px; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:3px 6px; font:13px ui-monospace,monospace; border-radius:3px; }
.ar-transportbar__sig { width:48px; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:3px 6px; font:13px ui-monospace,monospace; text-align:center; border-radius:3px; }
.ar-transportbar__sr { font:10px ui-monospace,monospace; color:#888; padding-left:6px; border-left:1px solid #333; }
/* On very narrow containers the meta row drops below the controls row
   instead of being pushed to the right edge; the auto-margin still wins
   on its own line, so there's no extra rule needed. */
@media (max-width: 600px) {
  .ar-transportbar { gap:8px; padding:6px 10px; }
  .ar-transportbar__counter { font-size:16px; min-width:100px; padding:3px 10px; }
}
`;
    document.head.appendChild(s);
  }
};
function parseTimeSig(s) {
  const m = (s || "").match(/^\s*(\d+)\s*\/\s*(\d+)\s*$/);
  if (!m) return [4, 4];
  return [parseInt(m[1], 10) || 4, parseInt(m[2], 10) || 4];
}
function formatSampleRate(hz) {
  if (hz >= 1e3) return `${(hz / 1e3).toFixed(hz % 1e3 === 0 ? 0 : 1)} kHz`;
  return `${hz} Hz`;
}
function formatSMPTE(seconds, framerate = 30) {
  if (!isFinite(seconds) || seconds < 0) seconds = 0;
  const totalFrames = Math.floor(seconds * framerate);
  const ff = totalFrames % Math.round(framerate);
  const totS = Math.floor(totalFrames / framerate);
  const ss = totS % 60;
  const mm = Math.floor(totS / 60) % 60;
  const hh = Math.floor(totS / 3600);
  return [hh, mm, ss, ff].map((n) => String(n).padStart(2, "0")).join(":");
}
function formatBars(seconds, bpm, timeSig = [4, 4], ppqn = 480) {
  if (!isFinite(seconds) || seconds < 0) seconds = 0;
  const [num, den] = timeSig;
  const beatsPerSecond = bpm / 60 * (den / 4);
  const beatsTotal = seconds * beatsPerSecond;
  const beatIdx = Math.floor(beatsTotal);
  const beatFrac = beatsTotal - beatIdx;
  const tick = Math.floor(beatFrac * ppqn);
  const bar = Math.floor(beatIdx / num) + 1;
  const beatInBar = beatIdx % num + 1;
  return `${bar}.${beatInBar}.${tick}`;
}

// components/composite/Chat.ts
var Chat = class extends Control {
  _me;
  _conversations = /* @__PURE__ */ new Map();
  _open = null;
  _replyTo = null;
  // DOM
  _elSidebar;
  _elThread;
  _elHeader;
  _elMessages;
  _elComposer;
  _elInput;
  _elReplyChip;
  constructor(container, opts) {
    super(container, "div", {
      showSidebar: true,
      ...opts
    });
    if (!opts.me) throw new Error("Chat requires `me` option");
    this._me = opts.me;
    this.el.className = `ar-chat${opts.class ? " " + opts.class : ""}`;
    for (const c of opts.conversations ?? [])
      this._conversations.set(c.id, this._cloneConversation(c));
    this._injectStyles();
    this._build();
    const initial = opts.initialOpen ?? this._conversations.keys().next().value;
    if (initial) this.openConversation(initial);
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** All conversations, sorted by last-activity desc. */
  getConversations() {
    return [...this._conversations.values()].map((c) => this._cloneConversation(c)).sort((a, b) => this._lastAt(b) - this._lastAt(a));
  }
  /** Single conversation by id, or null. */
  getConversation(id) {
    const c = this._conversations.get(id);
    return c ? this._cloneConversation(c) : null;
  }
  /** Active (open) conversation id, or null. */
  getOpen() {
    return this._open;
  }
  /** Add or replace a conversation. */
  addConversation(c) {
    const conv = {
      id: c.id,
      name: c.name,
      avatar: c.avatar,
      group: c.group,
      presence: c.presence,
      messages: (c.messages ?? []).map((m) => this._cloneMessage(m)),
      unread: c.unread ?? 0
    };
    this._conversations.set(conv.id, conv);
    this._renderSidebar();
    return this._cloneConversation(conv);
  }
  /** Remove a conversation. */
  removeConversation(id) {
    if (!this._conversations.has(id)) return this;
    this._conversations.delete(id);
    if (this._open === id) this._open = null;
    this._renderSidebar();
    this._renderThread();
    return this;
  }
  /** Open a conversation in the thread pane. Resets its unread count. */
  openConversation(id) {
    const c = this._conversations.get(id);
    if (!c) return this;
    this._open = id;
    c.unread = 0;
    this._replyTo = null;
    this._renderSidebar();
    this._renderThread();
    this._emit("open", { conversationId: id });
    return this;
  }
  /**
   * Add a message to a conversation. Bumps unread if the conversation is
   * not currently open and the message is from someone else.
   */
  addMessage(conversationId, m) {
    const c = this._conversations.get(conversationId);
    if (!c) throw new Error(`Chat.addMessage: unknown conversation: ${conversationId}`);
    c.messages.push(this._cloneMessage(m));
    if (this._open !== conversationId && m.from !== this._me.id && !m.system)
      c.unread++;
    this._renderSidebar();
    if (this._open === conversationId) this._renderThread();
    this._emit("message", { conversationId, message: m });
    return m;
  }
  /** Update a message's fields (status changes, reactions, edits, ...). */
  updateMessage(conversationId, messageId, patch) {
    const c = this._conversations.get(conversationId);
    if (!c) return this;
    const i = c.messages.findIndex((m) => m.id === messageId);
    if (i < 0) return this;
    c.messages[i] = { ...c.messages[i], ...patch };
    if (patch.reactions) c.messages[i].reactions = patch.reactions.map((r) => ({ ...r, by: [...r.by] }));
    if (this._open === conversationId) this._renderThread();
    this._renderSidebar();
    return this;
  }
  /** Add or remove a reaction. */
  toggleReaction(conversationId, messageId, emoji, userId) {
    const c = this._conversations.get(conversationId);
    if (!c) return this;
    const m = c.messages.find((x) => x.id === messageId);
    if (!m) return this;
    m.reactions = m.reactions ?? [];
    const r = m.reactions.find((x) => x.emoji === emoji);
    if (!r) {
      m.reactions.push({ emoji, by: [userId] });
    } else {
      const idx = r.by.indexOf(userId);
      if (idx >= 0) r.by.splice(idx, 1);
      else r.by.push(userId);
      if (r.by.length === 0)
        m.reactions.splice(m.reactions.indexOf(r), 1);
    }
    if (this._open === conversationId) this._renderThread();
    this._emit("reaction", { conversationId, messageId, emoji, userId });
    return this;
  }
  /** Set the reply-to message for the composer (chip appears above input). */
  setReplyTo(messageId) {
    this._replyTo = messageId;
    this._renderReplyChip();
    return this;
  }
  /** Set or clear the per-conversation `presence` (e.g. "typing"). */
  setPresence(conversationId, presence) {
    const c = this._conversations.get(conversationId);
    if (!c) return this;
    c.presence = presence;
    if (this._open === conversationId) this._renderHeader();
    this._renderSidebar();
    return this;
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _build() {
    const showSidebar = this._get("showSidebar", true);
    this.el.innerHTML = `
${showSidebar ? `<aside class="ar-chat__sidebar" data-r="sidebar"></aside>` : ""}
<section class="ar-chat__thread" data-r="thread">
  <header class="ar-chat__header"   data-r="header"></header>
  <div    class="ar-chat__messages" data-r="messages"></div>
  <footer class="ar-chat__composer" data-r="composer">
    <div class="ar-chat__reply-chip" data-r="reply-chip" style="display:none"></div>
    <div class="ar-chat__composer-row">
      <textarea class="ar-chat__input" data-r="input" rows="1" placeholder="Message\u2026"></textarea>
      <button class="ar-chat__btn ar-chat__btn--icon" data-act="attach" title="Attach">\u{1F4CE}</button>
      <button class="ar-chat__btn ar-chat__btn--icon" data-act="emoji"  title="Emoji">\u{1F60A}</button>
      <button class="ar-chat__btn ar-chat__btn--send" data-act="send"   title="Send">\u27A4</button>
    </div>
  </footer>
</section>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    if (showSidebar) this._elSidebar = r("sidebar");
    this._elThread = r("thread");
    this._elHeader = r("header");
    this._elMessages = r("messages");
    this._elComposer = r("composer");
    this._elInput = r("input");
    this._elReplyChip = r("reply-chip");
    this._elInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        this._send();
      }
    });
    this._elInput.addEventListener("input", () => {
      this._autosize();
      this._emit("typing", { conversationId: this._open });
    });
    this._elComposer.querySelector('[data-act="send"]')?.addEventListener("click", () => this._send());
    this._elComposer.querySelector('[data-act="attach"]')?.addEventListener("click", () => this._emit("attach", { conversationId: this._open }));
    this._elComposer.querySelector('[data-act="emoji"]')?.addEventListener("click", () => this._emit("emoji-pick", { conversationId: this._open }));
    this._renderSidebar();
  }
  _renderSidebar() {
    if (!this._elSidebar) return;
    this._elSidebar.innerHTML = "";
    const items = [...this._conversations.values()].sort((a, b) => this._lastAt(b) - this._lastAt(a));
    for (const c of items) {
      const row = document.createElement("div");
      row.className = "ar-chat__sidebar-row" + (c.id === this._open ? " ar-chat__sidebar-row--active" : "");
      row.dataset.id = c.id;
      const last = c.messages[c.messages.length - 1];
      const preview = last ? (last.from === this._me.id ? "You: " : "") + (last.text || (last.attachments?.length ? "\u{1F4CE} attachment" : "")) : "";
      row.innerHTML = `
<div class="ar-chat__avatar">${avatarHtml(c.name, c.avatar)}</div>
<div class="ar-chat__sidebar-mid">
  <div class="ar-chat__sidebar-name">${escapeHtml(c.name)}</div>
  <div class="ar-chat__sidebar-preview">${escapeHtml(preview).slice(0, 60)}</div>
</div>
<div class="ar-chat__sidebar-meta">
  ${last ? `<div class="ar-chat__sidebar-time">${formatShortTime(last.at, this._get("locale", ""))}</div>` : ""}
  ${c.unread > 0 ? `<div class="ar-chat__badge">${c.unread > 99 ? "99+" : c.unread}</div>` : ""}
</div>`;
      row.addEventListener("click", () => this.openConversation(c.id));
      this._elSidebar.appendChild(row);
    }
  }
  _renderHeader() {
    const c = this._open ? this._conversations.get(this._open) : null;
    if (!c) {
      this._elHeader.innerHTML = "";
      return;
    }
    this._elHeader.innerHTML = `
<div class="ar-chat__avatar">${avatarHtml(c.name, c.avatar)}</div>
<div class="ar-chat__header-mid">
  <div class="ar-chat__header-name">${escapeHtml(c.name)}</div>
  ${c.presence ? `<div class="ar-chat__presence ar-chat__presence--${c.presence}">${escapeHtml(c.presence)}</div>` : ""}
</div>`;
  }
  _renderThread() {
    this._renderHeader();
    this._renderReplyChip();
    this._elMessages.innerHTML = "";
    const c = this._open ? this._conversations.get(this._open) : null;
    if (!c) return;
    let prevAuthor = null;
    let prevAt = 0;
    const GAP_MS = 5 * 6e4;
    for (const m of c.messages) {
      if (!sameDay(prevAt, m.at) && prevAt > 0) {
        const sep = document.createElement("div");
        sep.className = "ar-chat__day";
        sep.textContent = formatDay(m.at, this._get("locale", ""));
        this._elMessages.appendChild(sep);
      }
      if (m.system) {
        const sys = document.createElement("div");
        sys.className = "ar-chat__system";
        sys.textContent = m.text;
        this._elMessages.appendChild(sys);
        prevAuthor = null;
        prevAt = m.at;
        continue;
      }
      const mine = m.from === this._me.id;
      const grouped = m.from === prevAuthor && m.at - prevAt < GAP_MS;
      const wrap = document.createElement("div");
      wrap.className = "ar-chat__msg" + (mine ? " ar-chat__msg--mine" : "") + (grouped ? " ar-chat__msg--grouped" : "");
      wrap.dataset.id = m.id;
      const bubble = document.createElement("div");
      bubble.className = "ar-chat__bubble";
      if (m.replyTo) {
        const parent = c.messages.find((x) => x.id === m.replyTo);
        if (parent) {
          const quote = document.createElement("div");
          quote.className = "ar-chat__quote";
          quote.innerHTML = `<span class="ar-chat__quote-author">${escapeHtml(this._authorName(parent.from, c))}</span>${escapeHtml(parent.text.slice(0, 80))}`;
          bubble.appendChild(quote);
        }
      }
      if (m.attachments && m.attachments.length > 0) {
        for (const a of m.attachments) {
          if (a.kind === "image") {
            const img = document.createElement("img");
            img.className = "ar-chat__att-image";
            img.src = a.url;
            if (a.width) img.width = a.width;
            if (a.height) img.height = a.height;
            bubble.appendChild(img);
          } else {
            const f = document.createElement("div");
            f.className = "ar-chat__att-file";
            f.textContent = (a.kind === "audio" ? "\u{1F3B5} " : a.kind === "video" ? "\u{1F3AC} " : "\u{1F4C4} ") + (a.name || a.url);
            bubble.appendChild(f);
          }
        }
      }
      if (m.text) {
        const t = document.createElement("div");
        t.className = "ar-chat__text";
        t.textContent = m.text;
        bubble.appendChild(t);
      }
      const meta = document.createElement("div");
      meta.className = "ar-chat__meta";
      meta.innerHTML = `
<span class="ar-chat__time">${formatShortTime(m.at, this._get("locale", ""))}</span>
${mine ? `<span class="ar-chat__status ar-chat__status--${m.status || "sent"}">${statusIcon(m.status)}</span>` : ""}
`;
      bubble.appendChild(meta);
      if (m.reactions && m.reactions.length > 0) {
        const rx = document.createElement("div");
        rx.className = "ar-chat__reactions";
        for (const r of m.reactions) {
          const chip = document.createElement("span");
          chip.className = "ar-chat__reaction";
          chip.textContent = `${r.emoji} ${r.by.length}`;
          chip.addEventListener("click", () => this.toggleReaction(c.id, m.id, r.emoji, this._me.id));
          rx.appendChild(chip);
        }
        bubble.appendChild(rx);
      }
      if (!mine && c.group && !grouped) {
        const lbl = document.createElement("div");
        lbl.className = "ar-chat__author";
        lbl.textContent = this._authorName(m.from, c);
        wrap.appendChild(lbl);
      }
      wrap.appendChild(bubble);
      this._elMessages.appendChild(wrap);
      prevAuthor = m.from;
      prevAt = m.at;
    }
    this._elMessages.scrollTop = this._elMessages.scrollHeight;
  }
  _renderReplyChip() {
    if (!this._elReplyChip) return;
    if (!this._replyTo || !this._open) {
      this._elReplyChip.style.display = "none";
      return;
    }
    const c = this._conversations.get(this._open);
    const m = c?.messages.find((x) => x.id === this._replyTo);
    if (!m) {
      this._elReplyChip.style.display = "none";
      return;
    }
    this._elReplyChip.innerHTML = `
<span class="ar-chat__reply-chip-text">
  <strong>${escapeHtml(this._authorName(m.from, c))}</strong>: ${escapeHtml(m.text.slice(0, 60))}
</span>
<button class="ar-chat__btn ar-chat__btn--icon" data-act="cancel-reply" title="Cancel reply">\xD7</button>`;
    this._elReplyChip.style.display = "";
    this._elReplyChip.querySelector('[data-act="cancel-reply"]')?.addEventListener("click", () => this.setReplyTo(null));
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _send() {
    const text = this._elInput.value.trim();
    if (!text || !this._open) return;
    const replyTo = this._replyTo ?? void 0;
    this._emit("send", { conversationId: this._open, text, replyTo });
    this._elInput.value = "";
    this._autosize();
    this._replyTo = null;
    this._renderReplyChip();
  }
  _autosize() {
    const ta = this._elInput;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 120) + "px";
  }
  _authorName(userId, c) {
    if (userId === this._me.id) return this._me.name;
    if (!c.group) return c.name;
    return userId;
  }
  _lastAt(c) {
    const last = c.messages[c.messages.length - 1];
    return last ? last.at : 0;
  }
  _cloneConversation(c) {
    return {
      id: c.id,
      name: c.name,
      avatar: c.avatar,
      group: c.group,
      presence: c.presence,
      unread: c.unread,
      messages: c.messages.map((m) => this._cloneMessage(m))
    };
  }
  _cloneMessage(m) {
    return {
      ...m,
      attachments: m.attachments?.map((a) => ({ ...a })),
      reactions: m.reactions?.map((r) => ({ ...r, by: [...r.by] }))
    };
  }
  _injectStyles() {
    if (document.getElementById("ar-chat-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-chat-styles";
    s.textContent = `
.ar-chat { display:flex; height:600px; background:#1e1e1e; border:1px solid #333; border-radius:6px; overflow:hidden; color:#d4d4d4; font:13px -apple-system,system-ui,sans-serif; }
.ar-chat__sidebar { width:280px; flex-shrink:0; background:#181818; border-right:1px solid #333; overflow:auto; }
.ar-chat__sidebar-row { display:flex; gap:10px; padding:10px 12px; cursor:pointer; align-items:center; border-bottom:1px solid #2a2a2a; }
.ar-chat__sidebar-row:hover { background:#222; }
.ar-chat__sidebar-row--active { background:#252525; border-left:3px solid #e40c88; padding-left:9px; }
.ar-chat__avatar { width:40px; height:40px; border-radius:50%; background:#444; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-weight:600; color:#fff; overflow:hidden; }
.ar-chat__avatar img { width:100%; height:100%; object-fit:cover; }
.ar-chat__sidebar-mid { flex:1; min-width:0; }
.ar-chat__sidebar-name { font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ar-chat__sidebar-preview { font-size:12px; color:#888; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ar-chat__sidebar-meta { display:flex; flex-direction:column; align-items:flex-end; gap:4px; }
.ar-chat__sidebar-time { font-size:11px; color:#666; }
.ar-chat__badge { background:#e40c88; color:#fff; font:600 10px sans-serif; padding:2px 6px; border-radius:10px; min-width:18px; text-align:center; }

.ar-chat__thread { flex:1; display:flex; flex-direction:column; min-width:0; }
.ar-chat__header { display:flex; gap:10px; padding:10px 16px; border-bottom:1px solid #333; align-items:center; flex-shrink:0; }
.ar-chat__header-mid { display:flex; flex-direction:column; }
.ar-chat__header-name { font-weight:600; }
.ar-chat__presence { font-size:11px; color:#888; font-style:italic; }
.ar-chat__presence--online { color:#22c55e; font-style:normal; }
.ar-chat__presence--typing { color:#e40c88; }

.ar-chat__messages { flex:1; overflow:auto; padding:12px 16px; display:flex; flex-direction:column; gap:6px; }
.ar-chat__day { align-self:center; padding:4px 12px; background:#0d0d0d; border-radius:10px; font-size:11px; color:#888; margin:8px 0; }
.ar-chat__system { align-self:center; font-size:11px; color:#666; padding:4px 12px; }
.ar-chat__msg { display:flex; flex-direction:column; align-items:flex-start; max-width:75%; }
.ar-chat__msg--mine { align-self:flex-end; align-items:flex-end; }
.ar-chat__msg--grouped { margin-top:-3px; }
.ar-chat__author { font:600 11px sans-serif; color:#e40c88; padding:2px 12px 0; }
.ar-chat__bubble { background:#2a2a2a; padding:6px 10px; border-radius:12px; max-width:100%; word-wrap:break-word; }
.ar-chat__msg--mine .ar-chat__bubble { background:#e40c88; color:#fff; }
.ar-chat__quote { border-left:3px solid rgba(228,12,136,0.6); padding:2px 8px; margin-bottom:4px; font-size:12px; opacity:.85; }
.ar-chat__quote-author { display:block; font-weight:600; color:#e40c88; }
.ar-chat__msg--mine .ar-chat__quote-author { color:#fff; }
.ar-chat__text { white-space:pre-wrap; }
.ar-chat__att-image { max-width:300px; max-height:300px; border-radius:8px; margin-bottom:4px; display:block; }
.ar-chat__att-file { background:#0d0d0d; padding:6px 10px; border-radius:4px; font-size:12px; margin-bottom:4px; }
.ar-chat__msg--mine .ar-chat__att-file { background:rgba(0,0,0,0.3); }
.ar-chat__meta { display:flex; gap:6px; align-items:center; justify-content:flex-end; font-size:10px; color:#888; margin-top:2px; }
.ar-chat__msg--mine .ar-chat__meta { color:rgba(255,255,255,0.7); }
.ar-chat__status--read { color:#3b82f6 !important; }
.ar-chat__status--failed { color:#dc2626 !important; }
.ar-chat__reactions { display:flex; flex-wrap:wrap; gap:3px; margin-top:4px; }
.ar-chat__reaction { background:#0d0d0d; padding:2px 6px; border-radius:10px; font-size:11px; cursor:pointer; border:1px solid #333; }
.ar-chat__msg--mine .ar-chat__reaction { background:rgba(0,0,0,0.3); border-color:transparent; color:#fff; }

.ar-chat__composer { border-top:1px solid #333; padding:8px 12px; flex-shrink:0; }
.ar-chat__reply-chip { background:#0d0d0d; padding:6px 10px; border-radius:4px; margin-bottom:6px; display:flex; align-items:center; justify-content:space-between; gap:8px; font-size:12px; border-left:3px solid #e40c88; }
.ar-chat__reply-chip-text { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.ar-chat__composer-row { display:flex; gap:6px; align-items:flex-end; }
.ar-chat__input { flex:1; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:8px 10px; font:13px sans-serif; border-radius:18px; resize:none; max-height:120px; }
.ar-chat__input:focus { border-color:#e40c88; outline:none; }
.ar-chat__btn { background:transparent; border:0; color:#888; cursor:pointer; padding:8px; font-size:18px; border-radius:50%; flex-shrink:0; }
.ar-chat__btn:hover { background:#2a2a2a; color:#fff; }
.ar-chat__btn--icon { width:36px; height:36px; }
.ar-chat__btn--send { background:#e40c88; color:#fff; width:36px; height:36px; }
.ar-chat__btn--send:hover { background:#c30b75; color:#fff; }
`;
    document.head.appendChild(s);
  }
};
function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}
function avatarHtml(name, src) {
  if (src) return `<img src="${src}" alt="">`;
  const safeName = (name ?? "").toString();
  if (!safeName.trim()) return "?";
  const initials = safeName.split(/\s+/).map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return escapeHtml(initials || "?");
}
function formatShortTime(at, locale) {
  const d = new Date(at);
  return d.toLocaleTimeString(locale || void 0, { hour: "2-digit", minute: "2-digit" });
}
function formatDay(at, locale) {
  const d = new Date(at);
  const today = /* @__PURE__ */ new Date();
  if (sameDay(at, today.getTime())) return "Today";
  const yest = new Date(today);
  yest.setDate(today.getDate() - 1);
  if (sameDay(at, yest.getTime())) return "Yesterday";
  return d.toLocaleDateString(locale || void 0, { weekday: "long", day: "numeric", month: "short" });
}
function sameDay(a, b) {
  const da = new Date(a), db = new Date(b);
  return da.getFullYear() === db.getFullYear() && da.getMonth() === db.getMonth() && da.getDate() === db.getDate();
}
function statusIcon(s) {
  switch (s) {
    case "sending":
      return "\u25CC";
    case "sent":
      return "\u2713";
    case "delivered":
      return "\u2713\u2713";
    case "read":
      return "\u2713\u2713";
    case "failed":
      return "\u26A0";
    default:
      return "\u2713";
  }
}

// components/composite/NodeEditor.ts
var defaultTypeCheck = (srcType, dstType) => {
  if (srcType === dstType) return "ok";
  if (srcType === "any" || dstType === "any") return "ok";
  if (srcType === "number" && dstType === "string") return "warn";
  if (srcType === "string" && dstType === "number") return "warn";
  if (srcType === "json" && dstType === "string") return "warn";
  return "error";
};
var NodeEditor = class extends Control {
  // Internal state
  _nodes = [];
  _wires = [];
  _nextId = 1;
  _runState = "idle";
  _typeCheck;
  // DOM refs
  _elPalette;
  _elCanvas;
  _elWires;
  _elInspector;
  _elStatus;
  // Drag state
  _wireDrag = null;
  _resizeObs;
  constructor(container, opts = {}) {
    super(container, "div", {
      schemas: [],
      showPalette: true,
      showToolbar: true,
      showInspector: true,
      width: "100%",
      height: "100%",
      ...opts
    });
    this._typeCheck = opts.typeCheck ?? defaultTypeCheck;
    this.el.className = `ar-nodeed${opts.class ? " " + opts.class : ""}`;
    this.el.style.cssText = `width:${opts.width ?? "100%"};height:${opts.height ?? "100%"}`;
    this._injectStyles();
    this._buildShell();
    this._resizeObs = new ResizeObserver(() => this._redrawWires());
    this._resizeObs.observe(this.el);
    this._gc(() => this._resizeObs?.disconnect());
    if (opts.initialGraph) {
      queueMicrotask(() => this._loadGraph(opts.initialGraph));
    }
  }
  // ── Public API ──────────────────────────────────────────────────────────
  /** Add a node by schema type. Returns the created instance. */
  addNode(schemaType, x, y) {
    const schema = this._schemas().find((s) => s.type === schemaType);
    if (!schema) {
      console.warn(`NodeEditor: unknown schema type '${schemaType}'`);
      return null;
    }
    const id = `n${this._nextId++}`;
    const node = { id, type: schemaType, x, y, schema, params: {} };
    this._nodes.push(node);
    this._renderNode(node);
    this._refreshInspector();
    this._emit("graph-change", { reason: "add-node", node });
    return node;
  }
  /** Remove a node by id. Cascades: also removes incoming/outgoing wires. */
  removeNode(id) {
    this._nodes = this._nodes.filter((n) => n.id !== id);
    this._wires = this._wires.filter((w) => w.srcNodeId !== id && w.dstNodeId !== id);
    this._elCanvas.querySelector(`#${CSS.escape(id)}`)?.remove();
    this._redrawWires();
    this._refreshInspector();
    this._emit("graph-change", { reason: "remove-node", id });
  }
  /** Connect two ports. Returns the wire if connection was made. */
  addWire(srcNodeId, srcPortId, dstNodeId, dstPortId) {
    const srcNode = this._nodes.find((n) => n.id === srcNodeId);
    const dstNode = this._nodes.find((n) => n.id === dstNodeId);
    if (!srcNode || !dstNode) return null;
    const srcPort = srcNode.schema.outputs.find((p) => p.id === srcPortId);
    const dstPort = dstNode.schema.inputs.find((p) => p.id === dstPortId);
    if (!srcPort || !dstPort) return null;
    this._wires = this._wires.filter((w) => !(w.dstNodeId === dstNodeId && w.dstPortId === dstPortId));
    const compat = this._typeCheck(srcPort.type, dstPort.type);
    const status = compat === "ok" ? "connected-ok" : compat === "warn" ? "connected-warn" : "connected-error";
    const wire = {
      id: `w${this._nextId++}`,
      srcNodeId,
      srcPortId,
      srcType: srcPort.type,
      dstNodeId,
      dstPortId,
      dstType: dstPort.type,
      status
    };
    this._wires.push(wire);
    this._updatePortStatus();
    this._redrawWires();
    this._refreshInspector();
    this._emit("graph-change", { reason: "add-wire", wire });
    return wire;
  }
  /** Remove a wire by id. */
  removeWire(id) {
    this._wires = this._wires.filter((w) => w.id !== id);
    this._updatePortStatus();
    this._redrawWires();
    this._refreshInspector();
    this._emit("graph-change", { reason: "remove-wire", id });
  }
  /** Update wire status (from the runtime — error/warn after run). */
  setWireStatus(id, status) {
    const w = this._wires.find((x) => x.id === id);
    if (!w) return;
    w.status = status;
    this._updatePortStatus();
    this._redrawWires();
  }
  /** Clear all nodes and wires. */
  clear() {
    this._nodes = [];
    this._wires = [];
    this._elCanvas.innerHTML = "";
    this._redrawWires();
    this._refreshInspector();
    this._emit("graph-change", { reason: "clear" });
  }
  /** Export the current graph as serializable JSON. */
  export() {
    return {
      nodes: this._nodes.map((n) => ({
        id: n.id,
        type: n.type,
        x: n.x,
        y: n.y,
        params: n.params
      })),
      wires: this._wires.map((w) => ({
        from: { node: w.srcNodeId, port: w.srcPortId },
        to: { node: w.dstNodeId, port: w.dstPortId }
      }))
    };
  }
  /** Replace the current graph with the given one. */
  load(graph) {
    this.clear();
    this._loadGraph(graph);
  }
  /** Set the run state (idle/running/paused) — emits 'run-state' event. */
  setRunState(s) {
    this._runState = s;
    this._refreshStatus();
    this._refreshInspector();
    this._emit("run-state", { state: s });
  }
  getRunState() {
    return this._runState;
  }
  getNodes() {
    return this._nodes;
  }
  getWires() {
    return this._wires;
  }
  // ── Internal ────────────────────────────────────────────────────────────
  _schemas() {
    return this._get("schemas", []);
  }
  _loadGraph(g) {
    const idMap = {};
    for (const n of g.nodes) {
      const created = this.addNode(n.type, n.x, n.y);
      if (created) {
        idMap[n.id] = created.id;
        if (n.params) created.params = { ...n.params };
      }
    }
    queueMicrotask(() => {
      for (const w of g.wires) {
        const srcId = idMap[w.from.node];
        const dstId = idMap[w.to.node];
        if (srcId && dstId) this.addWire(srcId, w.from.port, dstId, w.to.port);
      }
    });
  }
  _build() {
  }
  _buildShell() {
    const showPalette = this._get("showPalette", true);
    const showToolbar = this._get("showToolbar", true);
    const showInspector = this._get("showInspector", true);
    const cols = showPalette ? "200px 1fr" : "1fr";
    const rows = showToolbar ? "44px 1fr" : "1fr";
    this.el.style.display = "grid";
    this.el.style.gridTemplateColumns = cols;
    this.el.style.gridTemplateRows = rows;
    if (showToolbar) {
      const tb = this._el("div", "ar-nodeed__toolbar", this.el);
      tb.style.gridColumn = showPalette ? "1 / 3" : "1";
      const title = this._el("h3", "ar-nodeed__title", tb);
      title.textContent = "NodeEditor";
      this._elStatus = this._el("span", "ar-nodeed__status", tb);
      this._elStatus.textContent = "\u2014 idle";
      const spacer = this._el("div", "ar-nodeed__spacer", tb);
      spacer.style.flex = "1";
      const mkBtn = (label, kind, click) => {
        const b = this._el("button", `ar-nodeed__btn ${kind}`, tb);
        b.type = "button";
        b.textContent = label;
        b.addEventListener("click", click);
        return b;
      };
      mkBtn("\u25B6 Play", "play", () => this.setRunState("running"));
      mkBtn("\u2016 Pause", "pause", () => this.setRunState("paused"));
      mkBtn("\u25A0 Stop", "stop", () => this.setRunState("idle"));
      const sep = this._el("div", "", tb);
      sep.style.width = "14px";
      mkBtn("Clear all", "", () => {
        if (confirm("Clear all nodes and wires?")) this.clear();
      });
      mkBtn("Export JSON", "", () => {
        const blob = new Blob(
          [JSON.stringify(this.export(), null, 2)],
          { type: "application/json" }
        );
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "graph.json";
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 0);
      });
    }
    if (showPalette) {
      this._elPalette = this._el("div", "ar-nodeed__palette", this.el);
      this._buildPalette();
    }
    const wrap = this._el("div", "ar-nodeed__canvas-wrap", this.el);
    this._elCanvas = this._el("div", "ar-nodeed__canvas", wrap);
    const ns = "http://www.w3.org/2000/svg";
    this._elWires = document.createElementNS(ns, "svg");
    this._elWires.classList.add("ar-nodeed__wires");
    wrap.appendChild(this._elWires);
    if (showInspector) {
      this._elInspector = this._el("div", "ar-nodeed__inspector", wrap);
      this._refreshInspector();
    }
    this._on(wrap, "dragover", (e) => {
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
    });
    this._on(wrap, "drop", (e) => {
      e.preventDefault();
      const type = e.dataTransfer?.getData("application/x-arianna-node");
      if (!type) return;
      const rect = wrap.getBoundingClientRect();
      this.addNode(type, e.clientX - rect.left - 80, e.clientY - rect.top - 16);
    });
  }
  _buildPalette() {
    this._elPalette.innerHTML = "";
    const cats = {};
    for (const s of this._schemas()) {
      if (!cats[s.category]) cats[s.category] = [];
      cats[s.category].push(s);
    }
    for (const [cat, items] of Object.entries(cats)) {
      const t = this._el("div", "ar-nodeed__cat-title", this._elPalette);
      t.textContent = cat;
      for (const s of items) {
        const row = this._el("div", "ar-nodeed__pal-item", this._elPalette);
        row.draggable = true;
        if (s.description) row.title = s.description;
        row.innerHTML = `<span class="ar-nodeed__pal-icon" style="color:${s.color || "#888"}">${s.icon || "\u25C6"}</span><span>${s.name}</span>`;
        row.addEventListener("dragstart", (e) => {
          e.dataTransfer?.setData("application/x-arianna-node", s.type);
          if (e.dataTransfer) e.dataTransfer.effectAllowed = "copy";
        });
      }
    }
  }
  _renderNode(node) {
    const s = node.schema;
    const el = this._el("div", "ar-nodeed__node", this._elCanvas);
    el.id = node.id;
    el.style.left = node.x + "px";
    el.style.top = node.y + "px";
    const hd = this._el("div", "ar-nodeed__node-hd", el);
    hd.innerHTML = `<span class="ar-nodeed__n-color" style="background:${s.color || "#888"}"></span><span>${s.icon || "\u25C6"}</span><span>${s.name}</span>`;
    const closeBtn = this._el("button", "ar-nodeed__node-close", el);
    closeBtn.type = "button";
    closeBtn.textContent = "\xD7";
    closeBtn.title = "Delete node";
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.removeNode(node.id);
    });
    const body = this._el("div", "ar-nodeed__node-body", el);
    const rows = Math.max(s.inputs.length, s.outputs.length);
    for (let i = 0; i < rows; i++) {
      const row = this._el("div", "ar-nodeed__node-row", body);
      const inWrap = this._el("div", "", row);
      inWrap.style.cssText = "display:flex;align-items:center;gap:6px;flex:1";
      const outWrap = this._el("div", "", row);
      outWrap.style.cssText = "display:flex;align-items:center;gap:6px;flex:1;justify-content:flex-end";
      const inSpec = s.inputs[i];
      const outSpec = s.outputs[i];
      if (inSpec) {
        const port = this._createPort(node.id, inSpec, "in");
        const lbl = this._el("span", "ar-nodeed__port-lbl", inWrap);
        inWrap.insertBefore(port, lbl);
        lbl.textContent = inSpec.label || inSpec.id;
      }
      if (outSpec) {
        const lbl = this._el("span", "ar-nodeed__port-lbl", outWrap);
        lbl.textContent = outSpec.label || outSpec.id;
        const port = this._createPort(node.id, outSpec, "out");
        outWrap.appendChild(port);
      }
    }
    hd.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      const startX = e.clientX, startY = e.clientY;
      const startLeft = node.x, startTop = node.y;
      hd.setPointerCapture(e.pointerId);
      const onMove = (ev) => {
        node.x = startLeft + (ev.clientX - startX);
        node.y = startTop + (ev.clientY - startY);
        el.style.left = node.x + "px";
        el.style.top = node.y + "px";
        this._redrawWires();
      };
      const onUp = () => {
        hd.removeEventListener("pointermove", onMove);
        hd.removeEventListener("pointerup", onUp);
        this._emit("graph-change", { reason: "move-node", id: node.id });
      };
      hd.addEventListener("pointermove", onMove);
      hd.addEventListener("pointerup", onUp);
    });
  }
  _createPort(nodeId, portSpec, dir) {
    const p = document.createElement("div");
    p.className = `ar-nodeed__port ${dir}`;
    p.dataset.nodeId = nodeId;
    p.dataset.portId = portSpec.id;
    p.dataset.dir = dir;
    p.dataset.type = portSpec.type;
    p.title = `${portSpec.label || portSpec.id}: ${portSpec.type}`;
    p.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      this._startWireDrag(p, e);
    });
    return p;
  }
  // ── Wire dragging ───────────────────────────────────────────────────────
  _startWireDrag(srcPortEl, e) {
    const srcRect = srcPortEl.getBoundingClientRect();
    const wrapRect = this._elCanvas.parentElement.getBoundingClientRect();
    this._wireDrag = {
      srcPortEl,
      srcDir: srcPortEl.dataset.dir,
      srcPos: {
        x: srcRect.left + srcRect.width / 2 - wrapRect.left,
        y: srcRect.top + srcRect.height / 2 - wrapRect.top
      },
      cursor: { x: e.clientX - wrapRect.left, y: e.clientY - wrapRect.top },
      hoverTarget: null
    };
    const onMove = (ev) => this._onWireDrag(ev);
    const onUp = () => {
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerup", onUp);
      this._onWireDrop();
    };
    document.addEventListener("pointermove", onMove);
    document.addEventListener("pointerup", onUp);
    this._redrawWires();
  }
  _onWireDrag(e) {
    if (!this._wireDrag) return;
    const wrapRect = this._elCanvas.parentElement.getBoundingClientRect();
    this._wireDrag.cursor.x = e.clientX - wrapRect.left;
    this._wireDrag.cursor.y = e.clientY - wrapRect.top;
    const prevPE = this._elWires.style.pointerEvents;
    this._elWires.style.pointerEvents = "none";
    const elUnder = document.elementFromPoint(e.clientX, e.clientY);
    this._elWires.style.pointerEvents = prevPE;
    this.el.querySelectorAll(".ar-nodeed__port.hover-target").forEach((p) => p.classList.remove("hover-target"));
    if (elUnder?.classList.contains("ar-nodeed__port") && elUnder !== this._wireDrag.srcPortEl) {
      const dstDir = elUnder.dataset.dir;
      const sameNode = elUnder.dataset.nodeId === this._wireDrag.srcPortEl.dataset.nodeId;
      if (this._wireDrag.srcDir !== dstDir && !sameNode) {
        elUnder.classList.add("hover-target");
        this._wireDrag.hoverTarget = elUnder;
      } else {
        this._wireDrag.hoverTarget = null;
      }
    } else {
      this._wireDrag.hoverTarget = null;
    }
    this._redrawWires();
  }
  _onWireDrop() {
    if (!this._wireDrag) return;
    const target = this._wireDrag.hoverTarget;
    if (target) {
      let srcEl, dstEl;
      if (this._wireDrag.srcDir === "out") {
        srcEl = this._wireDrag.srcPortEl;
        dstEl = target;
      } else {
        srcEl = target;
        dstEl = this._wireDrag.srcPortEl;
      }
      this.addWire(
        srcEl.dataset.nodeId,
        srcEl.dataset.portId,
        dstEl.dataset.nodeId,
        dstEl.dataset.portId
      );
    }
    this.el.querySelectorAll(".ar-nodeed__port.hover-target").forEach((p) => p.classList.remove("hover-target"));
    this._wireDrag = null;
    this._redrawWires();
  }
  // ── Wire rendering (Manhattan routing) ──────────────────────────────────
  _portCenter(nodeId, portId) {
    const p = this.el.querySelector(
      `#${CSS.escape(nodeId)} .ar-nodeed__port[data-port-id="${CSS.escape(portId)}"]`
    );
    if (!p) return null;
    const r = p.getBoundingClientRect();
    const wr = this._elCanvas.parentElement.getBoundingClientRect();
    return { x: r.left + r.width / 2 - wr.left, y: r.top + r.height / 2 - wr.top };
  }
  _manhattanPath(srcX, srcY, dstX, dstY) {
    const M = 24;
    const sx2 = srcX + M;
    const dx2 = dstX - M;
    const midX = (sx2 + dx2) / 2;
    return `M ${srcX} ${srcY} L ${sx2} ${srcY} L ${midX} ${srcY} L ${midX} ${dstY} L ${dx2} ${dstY} L ${dstX} ${dstY}`;
  }
  _statusColor(status) {
    switch (status) {
      case "connected-ok":
        return "#16a34a";
      case "connected-warn":
        return "#f59e0b";
      case "connected-error":
        return "#dc2626";
    }
  }
  _redrawWires() {
    while (this._elWires.firstChild) this._elWires.removeChild(this._elWires.firstChild);
    const wrap = this._elCanvas.parentElement;
    this._elWires.setAttribute("width", String(wrap.clientWidth));
    this._elWires.setAttribute("height", String(wrap.clientHeight));
    for (const w of this._wires) {
      const src = this._portCenter(w.srcNodeId, w.srcPortId);
      const dst = this._portCenter(w.dstNodeId, w.dstPortId);
      if (!src || !dst) continue;
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", this._manhattanPath(src.x, src.y, dst.x, dst.y));
      path.setAttribute("stroke", this._statusColor(w.status));
      path.classList.add("editable");
      path.dataset.wireId = w.id;
      path.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        this.removeWire(w.id);
      });
      path.addEventListener("mouseenter", () => path.setAttribute("stroke-width", "3.5"));
      path.addEventListener("mouseleave", () => path.setAttribute("stroke-width", "2"));
      this._elWires.appendChild(path);
    }
    if (this._wireDrag) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      const fromOut = this._wireDrag.srcDir === "out";
      const sx = this._wireDrag.srcPos.x, sy = this._wireDrag.srcPos.y;
      const dx = this._wireDrag.cursor.x, dy = this._wireDrag.cursor.y;
      path.setAttribute("d", this._manhattanPath(
        fromOut ? sx : dx,
        fromOut ? sy : dy,
        fromOut ? dx : sx,
        fromOut ? dy : sy
      ));
      path.setAttribute("stroke", this._wireDrag.hoverTarget ? "#eab308" : "#999");
      path.setAttribute("stroke-dasharray", "4 4");
      this._elWires.appendChild(path);
    }
  }
  _updatePortStatus() {
    this.el.querySelectorAll(".ar-nodeed__port").forEach((p) => {
      p.classList.remove("connected-ok", "connected-warn", "connected-error");
    });
    for (const w of this._wires) {
      const src = this.el.querySelector(
        `#${CSS.escape(w.srcNodeId)} .ar-nodeed__port[data-port-id="${CSS.escape(w.srcPortId)}"]`
      );
      const dst = this.el.querySelector(
        `#${CSS.escape(w.dstNodeId)} .ar-nodeed__port[data-port-id="${CSS.escape(w.dstPortId)}"]`
      );
      src?.classList.add(w.status);
      dst?.classList.add(w.status);
    }
  }
  // ── Status & inspector ──────────────────────────────────────────────────
  _refreshStatus() {
    if (!this._elStatus) return;
    const map = {
      idle: ["\u2014 idle", "#888"],
      running: ["\u2014 running", "#16a34a"],
      paused: ["\u2014 paused", "#eab308"]
    };
    const [txt, color] = map[this._runState];
    this._elStatus.textContent = txt;
    this._elStatus.style.color = color;
  }
  _refreshInspector() {
    if (!this._elInspector) return;
    this._elInspector.innerHTML = `<div class="ar-nodeed__ins-ttl">Inspector</div><div><span class="ar-nodeed__ins-k">Nodes</span><span class="ar-nodeed__ins-v">${this._nodes.length}</span></div><hr><div><span class="ar-nodeed__ins-k">Wires</span><span class="ar-nodeed__ins-v">${this._wires.length}</span></div><hr><div><span class="ar-nodeed__ins-k">State</span><span class="ar-nodeed__ins-v">${this._runState}</span></div><div class="ar-nodeed__ins-help">Drag from palette. Click a port (LED) to start a wire. Right-click a wire to delete.</div>`;
  }
  // ── Stylesheet (auto-injected once) ─────────────────────────────────────
  _injectStyles() {
    if (document.getElementById("ar-nodeed-styles")) return;
    const style = document.createElement("style");
    style.id = "ar-nodeed-styles";
    style.textContent = `
.ar-nodeed { font: 13px -apple-system, system-ui, sans-serif; color: #222; overflow: hidden; }
.ar-nodeed__toolbar { background: #1e1e1e; color: #d4d4d4; display: flex; align-items: center; padding: 0 16px; gap: 10px; border-bottom: 1px solid #333; }
.ar-nodeed__title { font-size: 13px; margin: 0; font-weight: 500; color: #e40c88; }
.ar-nodeed__status { font: 11px ui-monospace, monospace; color: #888; margin-left: 8px; }
.ar-nodeed__btn { background: transparent; border: 1px solid #444; color: #d4d4d4; padding: 4px 12px; font: 12px sans-serif; border-radius: 3px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; }
.ar-nodeed__btn:hover { background: #2a2a2a; }
.ar-nodeed__btn.play  { background: #16a34a; border-color: #16a34a; color: #fff; }
.ar-nodeed__btn.play:hover  { background: #15803d; }
.ar-nodeed__btn.stop  { background: #dc2626; border-color: #dc2626; color: #fff; }
.ar-nodeed__btn.stop:hover  { background: #b91c1c; }
.ar-nodeed__btn.pause { background: #eab308; border-color: #eab308; color: #1f1f1f; }
.ar-nodeed__btn.pause:hover { background: #ca8a04; }

.ar-nodeed__palette { background: #f0f0f0; border-right: 1px solid #ddd; padding: 12px 0; overflow-y: auto; }
.ar-nodeed__cat-title { font: 600 11px sans-serif; text-transform: uppercase; letter-spacing: 0.5px; color: #666; padding: 8px 14px 4px; }
.ar-nodeed__pal-item { padding: 8px 14px; cursor: grab; font: 13px sans-serif; user-select: none; display: flex; align-items: center; gap: 8px; border-left: 3px solid transparent; transition: background 0.15s, border-left-color 0.15s; }
.ar-nodeed__pal-item:hover { background: #fff; border-left-color: #e40c88; }
.ar-nodeed__pal-item:active { cursor: grabbing; }
.ar-nodeed__pal-icon { width: 18px; text-align: center; }

.ar-nodeed__canvas-wrap { position: relative; overflow: hidden; background-color: #fff; background-image: linear-gradient(#eee 1px, transparent 1px), linear-gradient(90deg, #eee 1px, transparent 1px); background-size: 20px 20px; }
.ar-nodeed__canvas { position: absolute; inset: 0; }
.ar-nodeed__wires { position: absolute; inset: 0; pointer-events: none; }
.ar-nodeed__wires path { fill: none; stroke-width: 2; pointer-events: stroke; }
.ar-nodeed__wires path.editable { cursor: pointer; }

.ar-nodeed__node { position: absolute; background: #fff; border: 1.5px solid #d4d4d4; border-radius: 6px; min-width: 160px; font: 12px sans-serif; user-select: none; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05); }
.ar-nodeed__node-hd { background: #f3f3f3; padding: 6px 28px 6px 10px; border-bottom: 1px solid #e2e2e2; cursor: move; font-weight: 600; border-radius: 4px 4px 0 0; display: flex; align-items: center; gap: 6px; }
.ar-nodeed__n-color { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.ar-nodeed__node-close { position: absolute; right: 4px; top: 4px; width: 18px; height: 18px; border: 0; background: transparent; font: 14px monospace; color: #999; cursor: pointer; border-radius: 3px; }
.ar-nodeed__node-close:hover { background: #fee; color: #dc2626; }
.ar-nodeed__node-body { padding: 8px 10px; }
.ar-nodeed__node-row { display: flex; align-items: center; margin: 3px 0; position: relative; gap: 8px; justify-content: space-between; }

.ar-nodeed__port { width: 12px; height: 12px; border-radius: 50%; background: #dc2626; border: 2px solid #fff; box-shadow: 0 0 0 1px #999; cursor: crosshair; flex-shrink: 0; transition: background 0.12s, box-shadow 0.12s; }
.ar-nodeed__port.in  { margin-left: -16px; }
.ar-nodeed__port.out { margin-right: -16px; }
.ar-nodeed__port:hover { box-shadow: 0 0 0 1px #eab308, 0 0 6px rgba(234, 179, 8, 0.5); }
.ar-nodeed__port.hover-target { background: #eab308; box-shadow: 0 0 0 2px #eab308, 0 0 8px rgba(234, 179, 8, 0.6); }
.ar-nodeed__port.connected-ok    { background: #16a34a; box-shadow: 0 0 0 1px #16a34a; }
.ar-nodeed__port.connected-warn  { background: #f59e0b; box-shadow: 0 0 0 1px #f59e0b; }
.ar-nodeed__port.connected-error { background: #dc2626; box-shadow: 0 0 0 1px #dc2626; animation: ar-nodeed-blink 0.8s infinite alternate; }
@keyframes ar-nodeed-blink {
    from { box-shadow: 0 0 0 1px #dc2626, 0 0 4px rgba(220, 38, 38, 0.4); }
    to   { box-shadow: 0 0 0 2px #dc2626, 0 0 12px rgba(220, 38, 38, 0.8); }
}
.ar-nodeed__port-lbl { font: 11px sans-serif; color: #555; }

.ar-nodeed__inspector { position: absolute; right: 12px; bottom: 12px; width: 260px; max-height: 60vh; background: #1e1e1e; color: #d4d4d4; border-radius: 6px; padding: 10px 12px; font: 11px ui-monospace, monospace; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); overflow-y: auto; }
.ar-nodeed__ins-ttl { color: #c3e88d; font-weight: 600; margin-bottom: 4px; text-transform: uppercase; font-size: 10px; letter-spacing: 0.5px; }
.ar-nodeed__ins-k { color: #6cb6ff; display: inline-block; width: 80px; }
.ar-nodeed__ins-v { color: #ffab40; }
.ar-nodeed__inspector hr { border: 0; border-top: 1px solid #333; margin: 6px 0; }
.ar-nodeed__ins-help { color: #888; margin-top: 8px; }
`;
    document.head.appendChild(style);
  }
};

// components/graphics/2D/Canvas2D.ts
var Canvas2D = class extends Control {
  // Camera state
  _zoom;
  _panX;
  _panY;
  _zoomMin;
  _zoomMax;
  // DOM refs
  _elViewport;
  /** Public: consumer code mounts world content here. */
  world;
  _elGrid;
  _elRulerTop;
  _elRulerLeft;
  _elInfoTag;
  // Interaction state
  _spaceHeld = false;
  _panning = false;
  _panStartX = 0;
  _panStartY = 0;
  _panOrigX = 0;
  _panOrigY = 0;
  constructor(container, opts = {}) {
    super(container, "div", {
      width: "100%",
      height: "600px",
      panX: 0,
      panY: 0,
      zoom: 1,
      zoomMin: 0.05,
      zoomMax: 32,
      gridSize: 20,
      gridMajorEvery: 5,
      showRulers: true,
      background: "#0d0d0d",
      ...opts
    });
    this.el.className = `ar-canvas2d${opts.class ? " " + opts.class : ""}`;
    this._zoom = this._get("zoom", 1);
    this._panX = this._get("panX", 0);
    this._panY = this._get("panY", 0);
    this._zoomMin = this._get("zoomMin", 0.05);
    this._zoomMax = this._get("zoomMax", 32);
    this._injectStyles();
    this._build();
  }
  // ── Public API: camera ──────────────────────────────────────────────────
  /** Current zoom factor. */
  getZoom() {
    return this._zoom;
  }
  /** Current pan in world units. */
  getPan() {
    return { x: this._panX, y: this._panY };
  }
  /**
   * Set zoom around an optional pivot in screen pixels (defaults to viewport
   * centre). World point under the pivot stays fixed during the zoom.
   */
  zoomTo(zoom, pivot) {
    const newZoom = Math.max(this._zoomMin, Math.min(this._zoomMax, zoom));
    const rect = this._elViewport.getBoundingClientRect();
    const px = pivot ? pivot.x : rect.width / 2;
    const py = pivot ? pivot.y : rect.height / 2;
    const worldBefore = this._screenToWorldRaw(px, py);
    this._zoom = newZoom;
    const worldAfter = this._screenToWorldRaw(px, py);
    this._panX += worldAfter.x - worldBefore.x;
    this._panY += worldAfter.y - worldBefore.y;
    this._applyTransform();
    this._emit("viewport", { zoom: this._zoom, panX: this._panX, panY: this._panY });
    return this;
  }
  /** Multiply current zoom by `factor` around an optional screen pivot. */
  zoomBy(factor, pivot) {
    return this.zoomTo(this._zoom * factor, pivot);
  }
  /** Set pan in world units. */
  panTo(x, y) {
    this._panX = x;
    this._panY = y;
    this._applyTransform();
    this._emit("viewport", { zoom: this._zoom, panX: this._panX, panY: this._panY });
    return this;
  }
  /** Adjust pan by a delta in world units. */
  panBy(dx, dy) {
    return this.panTo(this._panX + dx, this._panY + dy);
  }
  /**
   * Compute and apply a viewport that frames all child elements of `world`
   * with the given padding (world units).
   */
  fitContent(padding = 40) {
    const bbox = this._worldBoundingBox();
    if (!bbox) return this;
    const rect = this._elViewport.getBoundingClientRect();
    const sx = rect.width / (bbox.width + padding * 2);
    const sy = rect.height / (bbox.height + padding * 2);
    const z = Math.min(sx, sy);
    this._zoom = Math.max(this._zoomMin, Math.min(this._zoomMax, z));
    this._panX = -(bbox.x + bbox.width / 2) + rect.width / 2 / this._zoom;
    this._panY = -(bbox.y + bbox.height / 2) + rect.height / 2 / this._zoom;
    this._applyTransform();
    this._emit("viewport", { zoom: this._zoom, panX: this._panX, panY: this._panY });
    return this;
  }
  /** Reset to identity (zoom=1, pan=0,0). */
  resetView() {
    this._zoom = 1;
    this._panX = 0;
    this._panY = 0;
    this._applyTransform();
    this._emit("viewport", { zoom: this._zoom, panX: this._panX, panY: this._panY });
    return this;
  }
  // ── Public API: coordinate conversion ──────────────────────────────────
  /** Screen pixel (relative to viewport top-left) → world coordinates. */
  screenToWorld(p) {
    return this._screenToWorldRaw(p.x, p.y);
  }
  /** World coordinates → screen pixel (relative to viewport top-left). */
  worldToScreen(p) {
    return {
      x: (p.x + this._panX) * this._zoom,
      y: (p.y + this._panY) * this._zoom
    };
  }
  _screenToWorldRaw(sx, sy) {
    return { x: sx / this._zoom - this._panX, y: sy / this._zoom - this._panY };
  }
  /** Bounding box of all children of `world` in world coordinates. */
  _worldBoundingBox() {
    if (!this.world.children.length) return null;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const c of Array.from(this.world.children)) {
      const left = parseFloat(c.style.left || "0");
      const top = parseFloat(c.style.top || "0");
      const width = parseFloat(c.style.width || (c.getAttribute("width") || "0"));
      const height = parseFloat(c.style.height || (c.getAttribute("height") || "0"));
      if (!Number.isFinite(width) || !Number.isFinite(height)) continue;
      minX = Math.min(minX, left);
      minY = Math.min(minY, top);
      maxX = Math.max(maxX, left + width);
      maxY = Math.max(maxY, top + height);
    }
    if (!Number.isFinite(minX)) return null;
    return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
  }
  // ── Internal: build + transform ────────────────────────────────────────
  _build() {
    this.el.style.width = this._get("width", "100%");
    this.el.style.height = this._get("height", "600px");
    this.el.style.background = this._get("background", "#0d0d0d");
    const showR = this._get("showRulers", true);
    this.el.innerHTML = `
${showR ? '<div class="ar-canvas2d__ruler ar-canvas2d__ruler--top"  data-r="rulerTop"></div>' : ""}
${showR ? '<div class="ar-canvas2d__ruler ar-canvas2d__ruler--left" data-r="rulerLeft"></div>' : ""}
<div class="ar-canvas2d__viewport" data-r="viewport">
  <div class="ar-canvas2d__grid"  data-r="grid"></div>
  <div class="ar-canvas2d__world" data-r="world"></div>
</div>
<div class="ar-canvas2d__info" data-r="info">100%</div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elViewport = r("viewport");
    this.world = r("world");
    this._elGrid = r("grid");
    this._elInfoTag = r("info");
    if (showR) {
      this._elRulerTop = r("rulerTop");
      this._elRulerLeft = r("rulerLeft");
    }
    this._wireEvents();
    this._applyTransform();
  }
  _wireEvents() {
    this._elViewport.addEventListener("wheel", (e) => {
      e.preventDefault();
      const rect = this._elViewport.getBoundingClientRect();
      const pivot = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      if (e.ctrlKey || e.metaKey) {
        const factor = Math.exp(-e.deltaY * 5e-3);
        this.zoomBy(factor, pivot);
      } else {
        const dx = (e.shiftKey ? e.deltaY : e.deltaX) / this._zoom;
        const dy = (e.shiftKey ? 0 : e.deltaY) / this._zoom;
        this.panBy(-dx, -dy);
      }
    }, { passive: false });
    window.addEventListener("keydown", (e) => {
      if (e.key === " ") this._spaceHeld = true;
    });
    window.addEventListener("keyup", (e) => {
      if (e.key === " ") this._spaceHeld = false;
    });
    this._elViewport.addEventListener("pointerdown", (e) => {
      const wantsPan = e.button === 1 || e.button === 0 && this._spaceHeld;
      if (!wantsPan) return;
      e.preventDefault();
      this._panning = true;
      this._panStartX = e.clientX;
      this._panStartY = e.clientY;
      this._panOrigX = this._panX;
      this._panOrigY = this._panY;
      this._elViewport.style.cursor = "grabbing";
      this._elViewport.setPointerCapture(e.pointerId);
    });
    this._elViewport.addEventListener("pointermove", (e) => {
      if (!this._panning) return;
      const dx = (e.clientX - this._panStartX) / this._zoom;
      const dy = (e.clientY - this._panStartY) / this._zoom;
      this.panTo(this._panOrigX + dx, this._panOrigY + dy);
    });
    this._elViewport.addEventListener("pointerup", (e) => {
      if (!this._panning) return;
      this._panning = false;
      this._elViewport.style.cursor = "";
      try {
        this._elViewport.releasePointerCapture(e.pointerId);
      } catch {
      }
    });
  }
  /** Apply current camera state to the world and grid via CSS transforms. */
  _applyTransform() {
    const z = this._zoom, px = this._panX, py = this._panY;
    this.world.style.transform = `scale(${z}) translate(${px}px, ${py}px)`;
    this.world.style.transformOrigin = "0 0";
    this._renderGrid();
    this._renderRulers();
    if (this._elInfoTag)
      this._elInfoTag.textContent = Math.round(z * 100) + "%";
  }
  /**
   * Render the grid using a CSS `background-image` so we don't pay the cost
   * of laying out individual divs. The background is sized in world units
   * and offset by the current pan.
   */
  _renderGrid() {
    const g = this._get("gridSize", 20);
    if (g <= 0) {
      this._elGrid.style.display = "none";
      return;
    }
    this._elGrid.style.display = "block";
    const z = this._zoom;
    const major = this._get("gridMajorEvery", 5);
    const stepMinor = g * z;
    const stepMajor = g * z * major;
    const ofX = (this._panX * z % stepMinor + stepMinor) % stepMinor;
    const ofY = (this._panY * z % stepMinor + stepMinor) % stepMinor;
    this._elGrid.style.backgroundImage = `linear-gradient(to right, rgba(255,255,255,0.06) 1px, transparent 1px),
             linear-gradient(to bottom, rgba(255,255,255,0.06) 1px, transparent 1px),
             linear-gradient(to right, rgba(255,255,255,0.14) 1px, transparent 1px),
             linear-gradient(to bottom, rgba(255,255,255,0.14) 1px, transparent 1px)`;
    this._elGrid.style.backgroundSize = `${stepMinor}px ${stepMinor}px,
             ${stepMinor}px ${stepMinor}px,
             ${stepMajor}px ${stepMajor}px,
             ${stepMajor}px ${stepMajor}px`;
    this._elGrid.style.backgroundPosition = `${ofX}px 0, 0 ${ofY}px, ${ofX}px 0, 0 ${ofY}px`;
  }
  _renderRulers() {
    if (!this._elRulerTop || !this._elRulerLeft) return;
    const z = this._zoom;
    const g = this._get("gridSize", 20);
    const stepMinor = g * z;
    const stepMajor = stepMinor * this._get("gridMajorEvery", 5);
    const ofX = (this._panX * z % stepMinor + stepMinor) % stepMinor;
    const ofY = (this._panY * z % stepMinor + stepMinor) % stepMinor;
    this._elRulerTop.style.backgroundImage = `linear-gradient(to right,  #555 1px, transparent 1px), linear-gradient(to right,  #888 1px, transparent 1px)`;
    this._elRulerTop.style.backgroundSize = `${stepMinor}px 100%, ${stepMajor}px 100%`;
    this._elRulerTop.style.backgroundPosition = `${ofX}px 0, ${ofX}px 0`;
    this._elRulerLeft.style.backgroundImage = `linear-gradient(to bottom, #555 1px, transparent 1px), linear-gradient(to bottom, #888 1px, transparent 1px)`;
    this._elRulerLeft.style.backgroundSize = `100% ${stepMinor}px, 100% ${stepMajor}px`;
    this._elRulerLeft.style.backgroundPosition = `0 ${ofY}px, 0 ${ofY}px`;
  }
  _injectStyles() {
    if (document.getElementById("ar-canvas2d-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-canvas2d-styles";
    s.textContent = `
.ar-canvas2d { position:relative; overflow:hidden; user-select:none; font:12px -apple-system,system-ui,sans-serif; color:#d4d4d4; }
.ar-canvas2d__ruler { position:absolute; background:#1a1a1a; pointer-events:none; }
.ar-canvas2d__ruler--top  { top:0; left:20px; right:0; height:20px; border-bottom:1px solid #333; }
.ar-canvas2d__ruler--left { top:20px; left:0; bottom:0; width:20px; border-right:1px solid #333; }
.ar-canvas2d__viewport { position:absolute; top:20px; left:20px; right:0; bottom:0; overflow:hidden; cursor:default; }
.ar-canvas2d__grid  { position:absolute; inset:0; pointer-events:none; }
.ar-canvas2d__world { position:absolute; top:0; left:0; transform-origin:0 0; pointer-events:auto; }
.ar-canvas2d__info  { position:absolute; bottom:8px; right:10px; background:rgba(0,0,0,0.6); padding:3px 8px; border-radius:3px; font:11px ui-monospace,monospace; pointer-events:none; }
`;
    document.head.appendChild(s);
  }
};

// components/graphics/2D/BezierEditor.ts
var BezierEditor = class extends Control {
  _anchors = [];
  _closed = false;
  _mode;
  _selected = null;
  // selected anchor index
  _draggingAnchor = null;
  // index being dragged
  _draggingHandle = null;
  // DOM
  _svg;
  _gPath;
  _gOverlay;
  // anchors + handles overlay
  constructor(container, opts = {}) {
    super(container, "div", {
      width: 600,
      height: 400,
      mode: "pen",
      anchors: [],
      closed: false,
      stroke: "#e40c88",
      strokeWidth: 2,
      fill: "none",
      ...opts
    });
    this.el.className = `ar-bezier${opts.class ? " " + opts.class : ""}`;
    this._mode = this._get("mode", "pen");
    this._anchors = (this._get("anchors", []) || []).map((a) => this._cloneAnchor(a));
    this._closed = this._get("closed", false);
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** All current anchors (deep-cloned, safe to mutate). */
  getAnchors() {
    return this._anchors.map((a) => this._cloneAnchor(a));
  }
  /** Replace all anchors. */
  setAnchors(arr) {
    this._anchors = arr.map((a) => this._cloneAnchor(a));
    this._render();
    this._emitChange("replace");
    return this;
  }
  /** Add an anchor at the end of the path. */
  addAnchor(opts) {
    const a = {
      x: opts.x,
      y: opts.y,
      hIn: opts.hIn ? { ...opts.hIn } : { x: 0, y: 0 },
      hOut: opts.hOut ? { ...opts.hOut } : { x: 0, y: 0 },
      kind: opts.kind ?? "corner"
    };
    this._anchors.push(a);
    this._selected = this._anchors.length - 1;
    this._render();
    this._emitChange("add", { index: this._selected });
    return a;
  }
  /** Remove an anchor by index. */
  removeAnchor(index) {
    if (index < 0 || index >= this._anchors.length) return this;
    this._anchors.splice(index, 1);
    if (this._selected === index) this._selected = null;
    else if (this._selected !== null && this._selected > index) this._selected--;
    this._render();
    this._emitChange("remove", { index });
    return this;
  }
  /** Update a single anchor's fields. */
  updateAnchor(index, patch) {
    if (index < 0 || index >= this._anchors.length) return this;
    const a = this._anchors[index];
    if (patch.x !== void 0) a.x = patch.x;
    if (patch.y !== void 0) a.y = patch.y;
    if (patch.hIn) a.hIn = { ...patch.hIn };
    if (patch.hOut) a.hOut = { ...patch.hOut };
    if (patch.kind) a.kind = patch.kind;
    this._render();
    this._emitChange("update", { index });
    return this;
  }
  /** Close the path (last anchor connects back to first). */
  closePath() {
    this._closed = true;
    this._render();
    this._emitChange("close");
    return this;
  }
  /** Open a previously-closed path. */
  openPath() {
    this._closed = false;
    this._render();
    this._emitChange("open");
    return this;
  }
  /** Is the path closed? */
  isClosed() {
    return this._closed;
  }
  /** Set the editing mode (pen / edit / delete). */
  setMode(mode) {
    this._mode = mode;
    this._svg.setAttribute("data-mode", mode);
    this._emit("mode", { mode });
    return this;
  }
  getMode() {
    return this._mode;
  }
  /**
   * Render the path as an SVG `d` attribute string. Supports both open
   * and closed paths, with cubic Bézier segments between anchors that
   * have handle points.
   */
  toSVGPath() {
    if (!this._anchors.length) return "";
    const a0 = this._anchors[0];
    const parts = [`M ${fmt(a0.x)} ${fmt(a0.y)}`];
    const segs = this._closed ? this._anchors.length : this._anchors.length - 1;
    for (let i = 0; i < segs; i++) {
      const a = this._anchors[i];
      const b = this._anchors[(i + 1) % this._anchors.length];
      const c1 = { x: a.x + a.hOut.x, y: a.y + a.hOut.y };
      const c2 = { x: b.x + b.hIn.x, y: b.y + b.hIn.y };
      parts.push(`C ${fmt(c1.x)} ${fmt(c1.y)} ${fmt(c2.x)} ${fmt(c2.y)} ${fmt(b.x)} ${fmt(b.y)}`);
    }
    if (this._closed) parts.push("Z");
    return parts.join(" ");
  }
  /** Index of the currently selected anchor, or null. */
  getSelected() {
    return this._selected;
  }
  /** Programmatically select an anchor. */
  select(index) {
    this._selected = index;
    this._render();
    return this;
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _build() {
    const w = this._get("width", 600);
    const h = this._get("height", 400);
    const svgNS = "http://www.w3.org/2000/svg";
    this._svg = document.createElementNS(svgNS, "svg");
    this._svg.setAttribute("width", String(w));
    this._svg.setAttribute("height", String(h));
    this._svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
    this._svg.setAttribute("class", "ar-bezier__svg");
    this._svg.setAttribute("data-mode", this._mode);
    const bg = document.createElementNS(svgNS, "rect");
    bg.setAttribute("x", "0");
    bg.setAttribute("y", "0");
    bg.setAttribute("width", String(w));
    bg.setAttribute("height", String(h));
    bg.setAttribute("fill", "transparent");
    bg.setAttribute("class", "ar-bezier__bg");
    bg.addEventListener("pointerdown", (e) => this._onBgDown(e));
    this._svg.appendChild(bg);
    this._gPath = document.createElementNS(svgNS, "g");
    this._gOverlay = document.createElementNS(svgNS, "g");
    this._gPath.setAttribute("class", "ar-bezier__path-g");
    this._gOverlay.setAttribute("class", "ar-bezier__overlay-g");
    this._svg.appendChild(this._gPath);
    this._svg.appendChild(this._gOverlay);
    this.el.appendChild(this._svg);
    this._render();
  }
  _render() {
    this._gPath.innerHTML = "";
    this._gOverlay.innerHTML = "";
    if (!this._anchors.length) return;
    const svgNS = "http://www.w3.org/2000/svg";
    const stroke = this._get("stroke", "#e40c88");
    const sw = this._get("strokeWidth", 2);
    const fill = this._get("fill", "none");
    const path = document.createElementNS(svgNS, "path");
    path.setAttribute("d", this.toSVGPath());
    path.setAttribute("stroke", stroke);
    path.setAttribute("stroke-width", String(sw));
    path.setAttribute("fill", fill);
    this._gPath.appendChild(path);
    for (let i = 0; i < this._anchors.length; i++) {
      const a = this._anchors[i];
      const isSel = this._selected === i;
      if (isSel || a.hIn.x !== 0 || a.hIn.y !== 0) {
        const lin = document.createElementNS(svgNS, "line");
        lin.setAttribute("x1", fmt(a.x));
        lin.setAttribute("y1", fmt(a.y));
        lin.setAttribute("x2", fmt(a.x + a.hIn.x));
        lin.setAttribute("y2", fmt(a.y + a.hIn.y));
        lin.setAttribute("class", "ar-bezier__handle-line");
        this._gOverlay.appendChild(lin);
      }
      if (isSel || a.hOut.x !== 0 || a.hOut.y !== 0) {
        const lout = document.createElementNS(svgNS, "line");
        lout.setAttribute("x1", fmt(a.x));
        lout.setAttribute("y1", fmt(a.y));
        lout.setAttribute("x2", fmt(a.x + a.hOut.x));
        lout.setAttribute("y2", fmt(a.y + a.hOut.y));
        lout.setAttribute("class", "ar-bezier__handle-line");
        this._gOverlay.appendChild(lout);
      }
      if (isSel) {
        if (a.hIn.x !== 0 || a.hIn.y !== 0) {
          const hin = document.createElementNS(svgNS, "circle");
          hin.setAttribute("cx", fmt(a.x + a.hIn.x));
          hin.setAttribute("cy", fmt(a.y + a.hIn.y));
          hin.setAttribute("r", "4");
          hin.setAttribute("class", "ar-bezier__handle");
          hin.dataset.role = "h-in";
          hin.dataset.idx = String(i);
          hin.addEventListener("pointerdown", (e) => this._onHandleDown(e, i, "in"));
          this._gOverlay.appendChild(hin);
        }
        if (a.hOut.x !== 0 || a.hOut.y !== 0) {
          const hout = document.createElementNS(svgNS, "circle");
          hout.setAttribute("cx", fmt(a.x + a.hOut.x));
          hout.setAttribute("cy", fmt(a.y + a.hOut.y));
          hout.setAttribute("r", "4");
          hout.setAttribute("class", "ar-bezier__handle");
          hout.dataset.role = "h-out";
          hout.dataset.idx = String(i);
          hout.addEventListener("pointerdown", (e) => this._onHandleDown(e, i, "out"));
          this._gOverlay.appendChild(hout);
        }
      }
      const dot = document.createElementNS(svgNS, isSel ? "rect" : "circle");
      if (isSel) {
        dot.setAttribute("x", fmt(a.x - 4));
        dot.setAttribute("y", fmt(a.y - 4));
        dot.setAttribute("width", "8");
        dot.setAttribute("height", "8");
      } else {
        dot.setAttribute("cx", fmt(a.x));
        dot.setAttribute("cy", fmt(a.y));
        dot.setAttribute("r", "4");
      }
      dot.setAttribute("class", "ar-bezier__anchor" + (isSel ? " selected" : "") + (a.kind === "corner" ? " corner" : ""));
      dot.dataset.idx = String(i);
      dot.addEventListener("pointerdown", (e) => this._onAnchorDown(e, i));
      dot.addEventListener("dblclick", () => this._onAnchorDblClick(i));
      this._gOverlay.appendChild(dot);
    }
  }
  // ── Event handlers ─────────────────────────────────────────────────────
  _onBgDown(e) {
    if (this._mode !== "pen") {
      this._selected = null;
      this._render();
      return;
    }
    e.preventDefault();
    const pt = this._svgCoord(e);
    const newAnchor = this.addAnchor({ x: pt.x, y: pt.y });
    this._selected = this._anchors.length - 1;
    const idx = this._selected;
    const startX = e.clientX, startY = e.clientY;
    e.target.setPointerCapture?.(e.pointerId);
    const onMove = (ev) => {
      const cur = this._svgCoord(ev);
      const dx = cur.x - newAnchor.x, dy = cur.y - newAnchor.y;
      this.updateAnchor(idx, {
        hOut: { x: dx, y: dy },
        hIn: { x: -dx, y: -dy },
        // mirrored
        kind: "smooth"
      });
      void (ev.clientX - startX);
      void (ev.clientY - startY);
    };
    const onUp = () => {
      this._svg.removeEventListener("pointermove", onMove);
      this._svg.removeEventListener("pointerup", onUp);
    };
    this._svg.addEventListener("pointermove", onMove);
    this._svg.addEventListener("pointerup", onUp);
  }
  _onAnchorDown(e, idx) {
    e.preventDefault();
    e.stopPropagation();
    if (this._mode === "delete") {
      this.removeAnchor(idx);
      return;
    }
    this._selected = idx;
    this._render();
    const a = this._anchors[idx];
    const start = { x: a.x, y: a.y };
    const startEv = this._svgCoord(e);
    e.target.setPointerCapture?.(e.pointerId);
    const onMove = (ev) => {
      const cur = this._svgCoord(ev);
      this.updateAnchor(idx, {
        x: start.x + (cur.x - startEv.x),
        y: start.y + (cur.y - startEv.y)
      });
    };
    const onUp = () => {
      this._svg.removeEventListener("pointermove", onMove);
      this._svg.removeEventListener("pointerup", onUp);
    };
    this._svg.addEventListener("pointermove", onMove);
    this._svg.addEventListener("pointerup", onUp);
  }
  _onHandleDown(e, idx, which) {
    e.preventDefault();
    e.stopPropagation();
    const a = this._anchors[idx];
    const startEv = this._svgCoord(e);
    const startHandle = which === "in" ? { ...a.hIn } : { ...a.hOut };
    const breakSym = e.altKey;
    e.target.setPointerCapture?.(e.pointerId);
    const onMove = (ev) => {
      const cur = this._svgCoord(ev);
      const newH = {
        x: startHandle.x + (cur.x - startEv.x),
        y: startHandle.y + (cur.y - startEv.y)
      };
      const patch = which === "in" ? { hIn: newH } : { hOut: newH };
      if (!breakSym && a.kind !== "corner") {
        if (which === "in") patch.hOut = { x: -newH.x, y: -newH.y };
        else patch.hIn = { x: -newH.x, y: -newH.y };
      } else if (breakSym) {
        patch.kind = "corner";
      }
      this.updateAnchor(idx, patch);
    };
    const onUp = () => {
      this._svg.removeEventListener("pointermove", onMove);
      this._svg.removeEventListener("pointerup", onUp);
    };
    this._svg.addEventListener("pointermove", onMove);
    this._svg.addEventListener("pointerup", onUp);
  }
  _onAnchorDblClick(idx) {
    const a = this._anchors[idx];
    const next = a.kind === "corner" ? "smooth" : "corner";
    if (next === "corner") {
      this.updateAnchor(idx, { kind: "corner" });
    } else {
      const prev = this._anchors[(idx - 1 + this._anchors.length) % this._anchors.length];
      const nxt = this._anchors[(idx + 1) % this._anchors.length];
      const dx = (nxt.x - prev.x) / 4;
      const dy = (nxt.y - prev.y) / 4;
      this.updateAnchor(idx, {
        kind: "smooth",
        hIn: { x: -dx, y: -dy },
        hOut: { x: dx, y: dy }
      });
    }
  }
  // ── Helpers ────────────────────────────────────────────────────────────
  /** Map a DOM pointer event to SVG-internal coordinates. */
  _svgCoord(e) {
    const rect = this._svg.getBoundingClientRect();
    const w = this._get("width", 600);
    const h = this._get("height", 400);
    const sx = w / (rect.width || w);
    const sy = h / (rect.height || h);
    return { x: (e.clientX - rect.left) * sx, y: (e.clientY - rect.top) * sy };
  }
  _cloneAnchor(a) {
    return { x: a.x, y: a.y, hIn: { ...a.hIn }, hOut: { ...a.hOut }, kind: a.kind };
  }
  _emitChange(kind, extra) {
    this._emit("change", { kind, ...extra || {} });
  }
  _injectStyles() {
    if (document.getElementById("ar-bezier-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-bezier-styles";
    s.textContent = `
.ar-bezier { display:inline-block; background:#0d0d0d; border:1px solid #333; border-radius:4px; }
.ar-bezier__svg { display:block; cursor:crosshair; }
.ar-bezier__svg[data-mode="edit"]   { cursor:default; }
.ar-bezier__svg[data-mode="delete"] { cursor:not-allowed; }
.ar-bezier__bg     { cursor:inherit; }
.ar-bezier__handle-line { stroke:rgba(228,12,136,0.5); stroke-width:1; }
.ar-bezier__handle      { fill:#fff; stroke:#e40c88; stroke-width:1.5; cursor:move; }
.ar-bezier__handle:hover { fill:#e40c88; }
.ar-bezier__anchor      { fill:#fff; stroke:#e40c88; stroke-width:1.5; cursor:move; }
.ar-bezier__anchor.corner { fill:#1e1e1e; }
.ar-bezier__anchor.selected { fill:#e40c88; stroke:#fff; }
`;
    document.head.appendChild(s);
  }
};
function fmt(n) {
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

// components/graphics/2D/LayersPanel.ts
var LayersPanel = class extends Control {
  _tree = [];
  _selected = /* @__PURE__ */ new Set();
  _active;
  // anchor for shift-range selection
  _nextId = 1;
  // DOM
  _elList;
  _elFooter;
  constructor(container, opts = {}) {
    super(container, "div", {
      tree: [],
      thumbnails: false,
      title: "Layers",
      readonly: false,
      ...opts
    });
    this.el.className = `ar-layers${opts.class ? " " + opts.class : ""}`;
    this._tree = this._cloneTree(this._get("tree", []));
    this._injectStyles();
    this._build();
    this._render();
  }
  // ── Public API: tree ops ───────────────────────────────────────────────
  /** Returns a deep clone of the current tree (safe to mutate). */
  getTree() {
    return this._cloneTree(this._tree);
  }
  /** Replace the whole tree. */
  setTree(tree) {
    this._tree = this._cloneTree(tree);
    this._render();
    this._emitChange({ kind: "set-tree" });
    return this;
  }
  /** Add a new layer. If `parentId` is given, appends inside that group. */
  addLayer(opts = {}) {
    const node = this._mkNode("layer", opts);
    this._insertNode(node, opts.parentId);
    this._render();
    this._emitChange({ kind: "add", node });
    return node;
  }
  /** Add a new (initially empty) group. */
  addGroup(opts = {}) {
    const node = this._mkNode("group", opts);
    node.children = [];
    node.expanded = opts.expanded ?? true;
    this._insertNode(node, opts.parentId);
    this._render();
    this._emitChange({ kind: "add", node });
    return node;
  }
  /** Remove a node by id (removes group's children too). */
  remove(id) {
    const removed = this._removeFromTree(id);
    if (removed) {
      this._selected.delete(id);
      this._render();
      this._emitChange({ kind: "remove", id });
    }
    return this;
  }
  /** Remove all currently selected nodes. */
  removeSelected() {
    const ids = [...this._selected];
    for (const id of ids) this._removeFromTree(id);
    this._selected.clear();
    this._render();
    this._emitChange({ kind: "remove-many", ids });
    return this;
  }
  /** Duplicate a node (and its children if it's a group). */
  duplicate(id) {
    const found = this._findWithParent(id);
    if (!found) return null;
    const clone = this._cloneNode(found.node);
    clone.id = this._mkId();
    clone.name = found.node.name + " copy";
    if (clone.children) this._reidRecursive(clone.children);
    const arr = found.parent ? found.parent.children : this._tree;
    arr.splice(found.index + 1, 0, clone);
    this._render();
    this._emitChange({ kind: "duplicate", id, newNode: clone });
    return clone;
  }
  /** Group the selected nodes into a new group at the position of the first. */
  groupSelected() {
    const ids = [...this._selected];
    if (ids.length === 0) return null;
    const nodes = [];
    let firstParent = null;
    let firstIndex = Infinity;
    for (const id of ids) {
      const f = this._findWithParent(id);
      if (!f) continue;
      const arr = f.parent ? f.parent.children : this._tree;
      if (firstIndex === Infinity || f.parent === firstParent && f.index < firstIndex) {
        firstParent = f.parent;
        firstIndex = f.index;
      }
      arr.splice(f.index, 1);
      nodes.push(f.node);
    }
    if (!nodes.length) return null;
    const grp = this._mkNode("group", { name: "Group" });
    grp.children = nodes;
    grp.expanded = true;
    const target = firstParent ? firstParent.children : this._tree;
    target.splice(Math.min(firstIndex, target.length), 0, grp);
    this._selected.clear();
    this._selected.add(grp.id);
    this._render();
    this._emitChange({ kind: "group", groupId: grp.id, ids });
    return grp;
  }
  /** Ungroup a group: move children up one level. */
  ungroup(id) {
    const f = this._findWithParent(id);
    if (!f || f.node.kind !== "group" || !f.node.children) return this;
    const target = f.parent ? f.parent.children : this._tree;
    target.splice(f.index, 1, ...f.node.children);
    this._selected.delete(id);
    this._render();
    this._emitChange({ kind: "ungroup", id });
    return this;
  }
  /** Set visibility (eye toggle). Cascades to children when on a group. */
  setVisible(id, visible) {
    const f = this._findWithParent(id);
    if (!f) return this;
    f.node.visible = visible;
    this._render();
    this._emitChange({ kind: "visibility", id, visible });
    return this;
  }
  /** Set lock (padlock toggle). */
  setLocked(id, locked) {
    const f = this._findWithParent(id);
    if (!f) return this;
    f.node.locked = locked;
    this._render();
    this._emitChange({ kind: "lock", id, locked });
    return this;
  }
  /** Rename a node. */
  rename(id, name) {
    const f = this._findWithParent(id);
    if (!f) return this;
    f.node.name = name;
    this._render();
    this._emitChange({ kind: "rename", id, name });
    return this;
  }
  /** Toggle expand/collapse for a group. */
  toggleExpand(id) {
    const f = this._findWithParent(id);
    if (!f || f.node.kind !== "group") return this;
    f.node.expanded = !f.node.expanded;
    this._render();
    return this;
  }
  /** Replace selection. Pass [] to clear. */
  select(ids) {
    this._selected = new Set(ids);
    if (ids.length > 0) this._active = ids[ids.length - 1];
    this._render();
    this._emit("select", { ids: [...this._selected] });
    return this;
  }
  /** Currently selected ids. */
  getSelection() {
    return [...this._selected];
  }
  /**
   * Move a node into another parent at a given index. Used by drag-and-drop
   * but also exposed publicly so consumers can re-order programmatically.
   */
  move(id, newParentId, newIndex) {
    const f = this._findWithParent(id);
    if (!f) return this;
    if (newParentId) {
      if (id === newParentId) return this;
      if (this._isDescendant(newParentId, id)) return this;
    }
    const fromArr = f.parent ? f.parent.children : this._tree;
    fromArr.splice(f.index, 1);
    const toParent = newParentId ? this._findWithParent(newParentId)?.node : null;
    const toArr = toParent && toParent.children ? toParent.children : this._tree;
    const clamped = Math.max(0, Math.min(newIndex, toArr.length));
    toArr.splice(clamped, 0, f.node);
    this._render();
    this._emitChange({ kind: "reorder", movedId: id, newParentId, newIndex: clamped });
    this._emit("reorder", { movedId: id, newParentId, newIndex: clamped });
    return this;
  }
  // ── Internal helpers ────────────────────────────────────────────────────
  _mkId() {
    return `lp-${this._nextId++}`;
  }
  _mkNode(kind, opts = {}) {
    return {
      id: opts.id ?? this._mkId(),
      kind,
      name: opts.name ?? (kind === "group" ? "Group" : "Layer"),
      visible: opts.visible ?? true,
      locked: opts.locked ?? false,
      expanded: opts.expanded ?? true,
      thumbnail: opts.thumbnail
    };
  }
  _insertNode(node, parentId) {
    if (!parentId) {
      this._tree.push(node);
      return;
    }
    const f = this._findWithParent(parentId);
    if (f && f.node.kind === "group") {
      f.node.children = f.node.children || [];
      f.node.children.push(node);
    } else {
      this._tree.push(node);
    }
  }
  _removeFromTree(id) {
    const f = this._findWithParent(id);
    if (!f) return false;
    const arr = f.parent ? f.parent.children : this._tree;
    arr.splice(f.index, 1);
    return true;
  }
  /**
   * Walk the tree finding a node by id. Returns the node, its parent (null
   * if at root), and its index within the parent's children array.
   */
  _findWithParent(id) {
    const search = (arr, parent) => {
      for (let i = 0; i < arr.length; i++) {
        const n = arr[i];
        if (n.id === id) return { node: n, parent, index: i };
        if (n.children) {
          const r = search(n.children, n);
          if (r) return r;
        }
      }
      return null;
    };
    return search(this._tree, null);
  }
  /** Is `descendantId` inside the subtree rooted at `ancestorId`? */
  _isDescendant(descendantId, ancestorId) {
    const f = this._findWithParent(ancestorId);
    if (!f || !f.node.children) return false;
    const walk = (arr) => {
      for (const n of arr) {
        if (n.id === descendantId) return true;
        if (n.children && walk(n.children)) return true;
      }
      return false;
    };
    return walk(f.node.children);
  }
  _cloneNode(n) {
    const out = { ...n };
    if (n.children) out.children = n.children.map((c) => this._cloneNode(c));
    return out;
  }
  _cloneTree(tree) {
    return tree.map((n) => this._cloneNode(n));
  }
  _reidRecursive(arr) {
    for (const n of arr) {
      n.id = this._mkId();
      if (n.children) this._reidRecursive(n.children);
    }
  }
  _emitChange(detail) {
    this._emit("change", detail);
  }
  /** Flat list of nodes in display order (for shift-range selection). */
  _flatten() {
    const out = [];
    const walk = (arr) => {
      for (const n of arr) {
        out.push(n);
        if (n.kind === "group" && n.expanded && n.children) walk(n.children);
      }
    };
    walk(this._tree);
    return out;
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _build() {
    const title = this._get("title", "Layers");
    const ro = this._get("readonly", false);
    this.el.innerHTML = `
<div class="ar-layers__head">
  <span class="ar-layers__title">${escapeHtml2(title)}</span>
</div>
<div class="ar-layers__list" data-r="list"></div>
${ro ? "" : `
<div class="ar-layers__footer" data-r="footer">
  <button class="ar-layers__btn" data-act="add-layer"     title="Add layer">+ Layer</button>
  <button class="ar-layers__btn" data-act="add-group"     title="Add group">+ Group</button>
  <button class="ar-layers__btn" data-act="duplicate"     title="Duplicate">\u2398</button>
  <button class="ar-layers__btn" data-act="group"         title="Group selected">\u229E</button>
  <button class="ar-layers__btn" data-act="ungroup"       title="Ungroup">\u229F</button>
  <button class="ar-layers__btn ar-layers__btn--danger" data-act="delete" title="Delete">\xD7</button>
</div>`}`;
    this._elList = this.el.querySelector('[data-r="list"]');
    if (!ro) {
      this._elFooter = this.el.querySelector('[data-r="footer"]');
      this._elFooter.querySelector('[data-act="add-layer"]').addEventListener("click", () => this.addLayer());
      this._elFooter.querySelector('[data-act="add-group"]').addEventListener("click", () => this.addGroup());
      this._elFooter.querySelector('[data-act="duplicate"]').addEventListener("click", () => {
        for (const id of this._selected) this.duplicate(id);
      });
      this._elFooter.querySelector('[data-act="group"]').addEventListener("click", () => this.groupSelected());
      this._elFooter.querySelector('[data-act="ungroup"]').addEventListener("click", () => {
        for (const id of this._selected) this.ungroup(id);
      });
      this._elFooter.querySelector('[data-act="delete"]').addEventListener("click", () => this.removeSelected());
    }
  }
  _render() {
    this._elList.innerHTML = "";
    this._renderArr(this._tree, 0);
  }
  _renderArr(arr, depth) {
    const showThumbs = this._get("thumbnails", false);
    for (const n of arr) {
      const row = document.createElement("div");
      row.className = "ar-layers__row" + (this._selected.has(n.id) ? " ar-layers__row--selected" : "");
      row.dataset.id = n.id;
      row.draggable = true;
      row.style.paddingLeft = 8 + depth * 14 + "px";
      const eye = `<span class="ar-layers__icon ar-layers__eye${n.visible ? "" : " off"}" data-act="vis" title="Toggle visibility">${n.visible ? "\u{1F441}" : "\u2298"}</span>`;
      const lock = `<span class="ar-layers__icon ar-layers__lock${n.locked ? " on" : ""}" data-act="lock" title="Toggle lock">${n.locked ? "\u{1F512}" : "\u{1F513}"}</span>`;
      const chevron = n.kind === "group" ? `<span class="ar-layers__chev" data-act="exp">${n.expanded ? "\u25BC" : "\u25B6"}</span>` : `<span class="ar-layers__chev ar-layers__chev--leaf">\u2022</span>`;
      const thumb = showThumbs && n.thumbnail ? `<img class="ar-layers__thumb" src="${n.thumbnail}" alt="">` : "";
      const name = `<span class="ar-layers__name" data-act="name">${escapeHtml2(n.name)}</span>`;
      row.innerHTML = eye + lock + chevron + thumb + name;
      this._wireRow(row, n);
      this._elList.appendChild(row);
      if (n.kind === "group" && n.expanded && n.children) {
        this._renderArr(n.children, depth + 1);
      }
    }
  }
  _wireRow(row, n) {
    row.querySelector('[data-act="vis"]')?.addEventListener("click", (e) => {
      e.stopPropagation();
      this.setVisible(n.id, !n.visible);
    });
    row.querySelector('[data-act="lock"]')?.addEventListener("click", (e) => {
      e.stopPropagation();
      this.setLocked(n.id, !n.locked);
    });
    row.querySelector('[data-act="exp"]')?.addEventListener("click", (e) => {
      e.stopPropagation();
      this.toggleExpand(n.id);
    });
    row.addEventListener("click", (e) => {
      const target = e.target;
      if (target.closest("[data-act]") && target.dataset.act !== "name") return;
      this._handleRowClick(n.id, e);
    });
    const nameEl = row.querySelector('[data-act="name"]');
    nameEl.addEventListener("dblclick", (e) => {
      e.stopPropagation();
      this._startRename(nameEl, n);
    });
    row.addEventListener("dragstart", (e) => {
      e.dataTransfer?.setData("text/plain", n.id);
      row.classList.add("ar-layers__row--dragging");
    });
    row.addEventListener("dragend", () => {
      row.classList.remove("ar-layers__row--dragging");
      this._elList.querySelectorAll(".ar-layers__row--drop-before, .ar-layers__row--drop-after, .ar-layers__row--drop-into").forEach((el) => el.classList.remove(
        "ar-layers__row--drop-before",
        "ar-layers__row--drop-after",
        "ar-layers__row--drop-into"
      ));
    });
    row.addEventListener("dragover", (e) => {
      e.preventDefault();
      const rect = row.getBoundingClientRect();
      const y = e.clientY - rect.top;
      row.classList.remove("ar-layers__row--drop-before", "ar-layers__row--drop-after", "ar-layers__row--drop-into");
      if (n.kind === "group" && y > rect.height * 0.33 && y < rect.height * 0.66)
        row.classList.add("ar-layers__row--drop-into");
      else if (y < rect.height / 2)
        row.classList.add("ar-layers__row--drop-before");
      else
        row.classList.add("ar-layers__row--drop-after");
    });
    row.addEventListener("drop", (e) => {
      e.preventDefault();
      const draggedId = e.dataTransfer?.getData("text/plain");
      if (!draggedId || draggedId === n.id) return;
      const intoGroup = row.classList.contains("ar-layers__row--drop-into");
      const before = row.classList.contains("ar-layers__row--drop-before");
      if (intoGroup && n.kind === "group") {
        const len = n.children?.length ?? 0;
        this.move(draggedId, n.id, len);
      } else {
        const f = this._findWithParent(n.id);
        if (!f) return;
        const newParentId = f.parent ? f.parent.id : null;
        this.move(draggedId, newParentId, before ? f.index : f.index + 1);
      }
    });
  }
  _handleRowClick(id, e) {
    if (e.shiftKey && this._active) {
      const flat = this._flatten().map((n) => n.id);
      const a = flat.indexOf(this._active);
      const b = flat.indexOf(id);
      if (a !== -1 && b !== -1) {
        const [lo, hi] = a < b ? [a, b] : [b, a];
        this._selected = new Set(flat.slice(lo, hi + 1));
      }
    } else if (e.metaKey || e.ctrlKey) {
      if (this._selected.has(id)) this._selected.delete(id);
      else this._selected.add(id);
      this._active = id;
    } else {
      this._selected = /* @__PURE__ */ new Set([id]);
      this._active = id;
    }
    this._render();
    this._emit("select", { ids: [...this._selected] });
  }
  _startRename(span, n) {
    const inp = document.createElement("input");
    inp.type = "text";
    inp.value = n.name;
    inp.className = "ar-layers__rename-inp";
    span.replaceWith(inp);
    inp.focus();
    inp.select();
    const finish = (commit) => {
      if (commit) this.rename(n.id, inp.value.trim() || n.name);
      else this._render();
    };
    inp.addEventListener("blur", () => finish(true));
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        finish(true);
      } else if (e.key === "Escape") {
        finish(false);
      }
    });
  }
  _injectStyles() {
    if (document.getElementById("ar-layers-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-layers-styles";
    s.textContent = `
.ar-layers { display:flex; flex-direction:column; background:#1e1e1e; border:1px solid #333; border-radius:6px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; min-width:240px; user-select:none; }
.ar-layers__head { display:flex; align-items:center; padding:8px 12px; border-bottom:1px solid #333; }
.ar-layers__title { font:600 12px sans-serif; letter-spacing:.04em; text-transform:uppercase; color:#e40c88; }
.ar-layers__list { flex:1; overflow:auto; max-height:400px; }
.ar-layers__row { display:flex; align-items:center; gap:6px; padding:4px 8px; cursor:pointer; border-left:2px solid transparent; }
.ar-layers__row:hover { background:#2a2a2a; }
.ar-layers__row--selected { background:rgba(228,12,136,0.2); border-left-color:#e40c88; }
.ar-layers__row--dragging { opacity:0.5; }
.ar-layers__row--drop-before { box-shadow:inset 0 2px 0 #e40c88; }
.ar-layers__row--drop-after  { box-shadow:inset 0 -2px 0 #e40c88; }
.ar-layers__row--drop-into   { background:rgba(228,12,136,0.35); }
.ar-layers__icon { font-size:13px; width:16px; text-align:center; cursor:pointer; opacity:.85; }
.ar-layers__icon:hover { opacity:1; }
.ar-layers__eye.off { opacity:.35; }
.ar-layers__lock.on { color:#eab308; }
.ar-layers__chev { width:14px; text-align:center; font-size:9px; color:#888; cursor:pointer; }
.ar-layers__chev--leaf { color:#444; cursor:default; }
.ar-layers__thumb { width:24px; height:24px; object-fit:cover; border-radius:2px; flex-shrink:0; }
.ar-layers__name { flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ar-layers__rename-inp { flex:1; background:#0d0d0d; border:1px solid #e40c88; color:#fff; padding:1px 4px; font:12px sans-serif; border-radius:2px; }
.ar-layers__footer { display:flex; gap:4px; padding:6px; border-top:1px solid #333; flex-wrap:wrap; }
.ar-layers__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:3px 8px; font:11px sans-serif; border-radius:3px; cursor:pointer; }
.ar-layers__btn:hover { background:#2a2a2a; }
.ar-layers__btn--danger:hover { background:#dc2626; border-color:#dc2626; color:#fff; }
`;
    document.head.appendChild(s);
  }
};
function escapeHtml2(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/graphics/2D/ToolsPalette.ts
var BUILTIN_TOOLS = [
  { id: "select", label: "Selection", icon: "\u25B6", shortcut: "V", group: "select" },
  { id: "direct-select", label: "Direct select", icon: "\u25C7", shortcut: "A", group: "select" },
  { id: "magic-wand", label: "Magic wand", icon: "\u2726", shortcut: "Y", group: "select" },
  { id: "pen", label: "Pen", icon: "\u270E", shortcut: "P", group: "draw" },
  { id: "pencil", label: "Pencil", icon: "\u270F", shortcut: "N", group: "draw" },
  { id: "line", label: "Line", icon: "\u2571", shortcut: "\\", group: "draw" },
  { id: "rect", label: "Rectangle", icon: "\u25AD", shortcut: "M", group: "shape" },
  { id: "ellipse", label: "Ellipse", icon: "\u25EF", shortcut: "L", group: "shape" },
  { id: "polygon", label: "Polygon", icon: "\u2605", shortcut: "*", group: "shape" },
  { id: "eraser", label: "Eraser", icon: "\u232B", shortcut: "E", group: "edit" },
  { id: "knife", label: "Knife", icon: "\u2702", shortcut: "C", group: "edit" },
  { id: "crop", label: "Crop", icon: "\u25FB", shortcut: "X", group: "edit" },
  { id: "eyedropper", label: "Eyedropper", icon: "\u{1F3A8}", shortcut: "I", group: "view" },
  { id: "zoom", label: "Zoom", icon: "\u{1F50D}", shortcut: "Z", group: "view" },
  { id: "hand", label: "Hand", icon: "\u270B", shortcut: "H", group: "view" }
];
var ToolsPalette = class extends Control {
  _tools = [];
  _active = null;
  _btns = /* @__PURE__ */ new Map();
  _onKeyBound = (e) => this._onKey(e);
  constructor(container, opts = {}) {
    super(container, "div", {
      activeTool: "select",
      layout: "vertical",
      showShortcuts: true,
      useBuiltins: true,
      disableHotkeys: false,
      ...opts
    });
    this.el.className = `ar-palette ar-palette--${this._get("layout", "vertical")}${opts.class ? " " + opts.class : ""}`;
    if (this._get("useBuiltins", true)) this._tools.push(...BUILTIN_TOOLS);
    this._injectStyles();
    this._build();
    const initial = this._get("activeTool", "select");
    if (initial && this._tools.find((t) => t.id === initial)) this.setTool(initial);
    if (!this._get("disableHotkeys", false))
      window.addEventListener("keydown", this._onKeyBound);
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Currently active tool id, or null if none. */
  getTool() {
    return this._active;
  }
  /**
   * Set the active tool. Pass null to deactivate. Returns this for chaining.
   * Emits `tool` event { tool, prev }.
   */
  setTool(id) {
    if (id !== null && !this._tools.find((t) => t.id === id)) {
      console.warn("[ToolsPalette] unknown tool:", id);
      return this;
    }
    const prev = this._active;
    this._active = id;
    this._refreshButtons();
    this._emit("tool", { tool: id, prev });
    return this;
  }
  /** All tools currently in the palette (in display order). */
  getTools() {
    return this._tools.slice();
  }
  /** Add a custom tool to the palette. */
  addTool(tool) {
    if (this._tools.find((t) => t.id === tool.id)) {
      console.warn("[ToolsPalette] tool id already exists:", tool.id);
      return this;
    }
    this._tools.push(tool);
    this._build();
    return this;
  }
  /** Remove a tool from the palette. */
  removeTool(id) {
    const i = this._tools.findIndex((t) => t.id === id);
    if (i < 0) return this;
    this._tools.splice(i, 1);
    if (this._active === id) this._active = null;
    this._build();
    return this;
  }
  /** Detach all listeners. Call when removing the palette from the DOM. */
  destroy() {
    if (!this._get("disableHotkeys", false))
      window.removeEventListener("keydown", this._onKeyBound);
  }
  // ── Internal: build + render ───────────────────────────────────────────
  _build() {
    const showShortcuts = this._get("showShortcuts", true);
    this.el.innerHTML = "";
    this._btns.clear();
    let lastGroup;
    for (const t of this._tools) {
      if (t.group && t.group !== lastGroup && lastGroup !== void 0) {
        const sep = document.createElement("div");
        sep.className = "ar-palette__sep";
        this.el.appendChild(sep);
      }
      lastGroup = t.group;
      const b = document.createElement("button");
      b.className = "ar-palette__btn";
      b.dataset.tool = t.id;
      b.innerHTML = `<span class="ar-palette__icon">${escapeHtml3(t.icon)}</span>`;
      b.title = showShortcuts && t.shortcut ? `${t.label} (${t.shortcut})` : t.label;
      b.addEventListener("click", () => this.setTool(t.id));
      this.el.appendChild(b);
      this._btns.set(t.id, b);
    }
    this._refreshButtons();
  }
  _refreshButtons() {
    for (const [id, btn] of this._btns) {
      btn.classList.toggle("ar-palette__btn--active", id === this._active);
    }
  }
  _onKey(e) {
    const tg = e.target;
    if (tg && (tg.tagName === "INPUT" || tg.tagName === "TEXTAREA" || tg.isContentEditable)) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key.toUpperCase();
    const t = this._tools.find((x) => x.shortcut?.toUpperCase() === k);
    if (t) {
      e.preventDefault();
      this.setTool(t.id);
    }
  }
  _injectStyles() {
    if (document.getElementById("ar-palette-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-palette-styles";
    s.textContent = `
.ar-palette { display:inline-flex; gap:2px; padding:6px; background:#1e1e1e; border:1px solid #333; border-radius:6px; user-select:none; }
.ar-palette--vertical   { flex-direction:column; }
.ar-palette--horizontal { flex-direction:row; }
.ar-palette__btn { background:transparent; border:1px solid transparent; color:#d4d4d4; width:34px; height:34px; padding:0; cursor:pointer; border-radius:3px; font:18px sans-serif; display:flex; align-items:center; justify-content:center; transition:background .12s, border-color .12s; }
.ar-palette__btn:hover  { background:#2a2a2a; }
.ar-palette__btn--active { background:#e40c88; border-color:#e40c88; color:#fff; }
.ar-palette__icon { line-height:1; pointer-events:none; }
.ar-palette__sep { background:#333; }
.ar-palette--vertical   .ar-palette__sep { height:1px; margin:4px 4px; }
.ar-palette--horizontal .ar-palette__sep { width:1px;  margin:4px 4px; }
`;
    document.head.appendChild(s);
  }
};
function escapeHtml3(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/graphics/2D/LinesPalette2D.ts
var BUILTIN = [
  // Drawing primitives
  { id: "line", label: "Line", icon: "\u2571", shortcut: "L", behaviour: "tool", group: "draw" },
  { id: "arc", label: "Arc", icon: "\u25DC", shortcut: "A", behaviour: "tool", group: "draw" },
  { id: "polyline", label: "Polyline", icon: "\u2307", shortcut: "P", behaviour: "tool", group: "draw" },
  { id: "spline", label: "Spline", icon: "\u223F", shortcut: "S", behaviour: "tool", group: "draw" },
  { id: "freehand", label: "Freehand", icon: "\u270E", shortcut: "F", behaviour: "tool", group: "draw" },
  { id: "rect", label: "Rect", icon: "\u25AD", shortcut: "R", behaviour: "tool", group: "draw" },
  { id: "ellipse", label: "Ellipse", icon: "\u25EF", shortcut: "O", behaviour: "tool", group: "draw" },
  { id: "polygon", label: "Polygon", icon: "\u2B21", shortcut: "G", behaviour: "tool", group: "draw" },
  // Path-closure actions
  { id: "close", label: "Close", icon: "\u2299", shortcut: "C", behaviour: "action", group: "close" },
  { id: "open", label: "Open", icon: "\u25CC", behaviour: "action", group: "close" },
  { id: "reverse", label: "Reverse", icon: "\u21CC", behaviour: "action", group: "close" },
  // 2D → 3D conversions
  { id: "extrude", label: "Extrude", icon: "\u2B1A", behaviour: "to-3d", group: "to-3d" },
  { id: "revolve", label: "Revolve", icon: "\u27F3", behaviour: "to-3d", group: "to-3d" },
  { id: "sweep", label: "Sweep", icon: "\u21AA", behaviour: "to-3d", group: "to-3d" },
  { id: "loft", label: "Loft", icon: "\u2637", behaviour: "to-3d", group: "to-3d" }
];
var LinesPalette2D = class extends Control {
  _tools = BUILTIN.slice();
  _active = null;
  _btns = /* @__PURE__ */ new Map();
  _onKeyBound = (e) => this._onKey(e);
  constructor(container, opts = {}) {
    super(container, "div", {
      activeTool: "line",
      layout: "vertical",
      showShortcuts: true,
      disableHotkeys: false,
      ...opts
    });
    this.el.className = `ar-pal2d ar-pal2d--${this._get("layout", "vertical")}${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
    const init = this._get("activeTool", "line");
    if (init && this._tools.find((t) => t.id === init && t.behaviour === "tool"))
      this.setTool(init);
    if (!this._get("disableHotkeys", false))
      window.addEventListener("keydown", this._onKeyBound);
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Currently active drawing tool, or null. */
  getTool() {
    return this._active;
  }
  /**
   * Set the active drawing tool. Only `behaviour: 'tool'` items can be
   * "active". Pass null to deactivate. Returns this for chaining.
   */
  setTool(id) {
    if (id !== null) {
      const t = this._tools.find((x) => x.id === id);
      if (!t) {
        console.warn("[LinesPalette2D] unknown tool:", id);
        return this;
      }
      if (t.behaviour !== "tool") {
        console.warn(`[LinesPalette2D] '${id}' is a ${t.behaviour}, use trigger() instead`);
        return this;
      }
    }
    const prev = this._active;
    this._active = id;
    this._refreshButtons();
    this._emit("tool", { tool: id, prev });
    return this;
  }
  /**
   * Trigger an action or to-3d conversion. Actions don't change the active
   * tool. Emits the appropriate event ('action' or 'to-3d') with the id.
   */
  trigger(id, params) {
    const t = this._tools.find((x) => x.id === id);
    if (!t) {
      console.warn("[LinesPalette2D] unknown tool:", id);
      return this;
    }
    if (t.behaviour === "tool") {
      console.warn(`[LinesPalette2D] '${id}' is a tool, use setTool() instead`);
      return this;
    }
    this._emit(
      t.behaviour === "to-3d" ? "to-3d" : "action",
      { kind: id, action: id, params: params || {} }
    );
    return this;
  }
  /** All tools (drawing + actions + to-3d). */
  getTools() {
    return this._tools.slice();
  }
  /** Detach listeners. */
  destroy() {
    if (!this._get("disableHotkeys", false))
      window.removeEventListener("keydown", this._onKeyBound);
  }
  // ── Internal: build + render ───────────────────────────────────────────
  _build() {
    const showShortcuts = this._get("showShortcuts", true);
    this.el.innerHTML = "";
    this._btns.clear();
    let lastGroup;
    for (const t of this._tools) {
      if (t.group !== lastGroup && lastGroup !== void 0) {
        const sep = document.createElement("div");
        sep.className = "ar-pal2d__sep";
        this.el.appendChild(sep);
      }
      lastGroup = t.group;
      const b = document.createElement("button");
      b.className = `ar-pal2d__btn ar-pal2d__btn--${t.behaviour}`;
      b.dataset.tool = t.id;
      b.innerHTML = `<span class="ar-pal2d__icon">${escapeHtml4(t.icon)}</span>`;
      b.title = showShortcuts && t.shortcut ? `${t.label} (${t.shortcut})` : t.label;
      b.addEventListener("click", () => {
        if (t.behaviour === "tool") this.setTool(t.id);
        else this.trigger(t.id);
      });
      this.el.appendChild(b);
      this._btns.set(t.id, b);
    }
    this._refreshButtons();
  }
  _refreshButtons() {
    for (const [id, btn] of this._btns)
      btn.classList.toggle("ar-pal2d__btn--active", id === this._active);
  }
  _onKey(e) {
    const tg = e.target;
    if (tg && (tg.tagName === "INPUT" || tg.tagName === "TEXTAREA" || tg.isContentEditable)) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key.toUpperCase();
    const t = this._tools.find((x) => x.shortcut?.toUpperCase() === k);
    if (!t) return;
    e.preventDefault();
    if (t.behaviour === "tool") this.setTool(t.id);
    else this.trigger(t.id);
  }
  _injectStyles() {
    if (document.getElementById("ar-pal2d-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-pal2d-styles";
    s.textContent = `
.ar-pal2d { display:inline-flex; gap:2px; padding:6px; background:#1e1e1e; border:1px solid #333; border-radius:6px; user-select:none; }
.ar-pal2d--vertical   { flex-direction:column; }
.ar-pal2d--horizontal { flex-direction:row; }
.ar-pal2d__btn { background:transparent; border:1px solid transparent; color:#d4d4d4; width:34px; height:34px; padding:0; cursor:pointer; border-radius:3px; font:18px sans-serif; display:flex; align-items:center; justify-content:center; transition:background .12s, border-color .12s; }
.ar-pal2d__btn:hover { background:#2a2a2a; }
.ar-pal2d__btn--active { background:#e40c88; border-color:#e40c88; color:#fff; }
.ar-pal2d__btn--action { color:#22c55e; }
.ar-pal2d__btn--to-3d  { color:#f59e0b; }
.ar-pal2d__icon { line-height:1; pointer-events:none; }
.ar-pal2d__sep { background:#333; }
.ar-pal2d--vertical   .ar-pal2d__sep { height:1px; margin:4px 4px; }
.ar-pal2d--horizontal .ar-pal2d__sep { width:1px;  margin:4px 4px; }
`;
    document.head.appendChild(s);
  }
};
function escapeHtml4(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/graphics/3D/CameraViewer3D.ts
var DEFAULT_CAMERAS = {
  top: { position: { x: 0, y: 10, z: 0 }, target: { x: 0, y: 0, z: 0 }, zoom: 1, kind: "orthographic" },
  front: { position: { x: 0, y: 0, z: 10 }, target: { x: 0, y: 0, z: 0 }, zoom: 1, kind: "orthographic" },
  side: { position: { x: 10, y: 0, z: 0 }, target: { x: 0, y: 0, z: 0 }, zoom: 1, kind: "orthographic" },
  perspective: { position: { x: 6, y: 5, z: 6 }, target: { x: 0, y: 0, z: 0 }, zoom: 1, kind: "perspective" }
};
var PANE_LABELS = {
  top: "TOP",
  front: "FRONT",
  side: "SIDE",
  perspective: "PERSPECTIVE"
};
var CameraViewer3D = class extends Control {
  _panes = /* @__PURE__ */ new Map();
  _active = "perspective";
  _maximized = null;
  _elGrid;
  constructor(container, opts = {}) {
    super(container, "div", {
      width: "100%",
      height: "600px",
      showAxes: true,
      showLabels: true,
      ...opts
    });
    this.el.className = `ar-camera3d${opts.class ? " " + opts.class : ""}`;
    this.el.style.width = this._get("width", "100%");
    this.el.style.height = this._get("height", "600px");
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Get a pane (with `surface` to mount renderers, `camera`, etc.). */
  getPane(id) {
    const p = this._panes.get(id);
    if (!p) throw new Error(`unknown pane: ${id}`);
    return p;
  }
  /** Currently active (focused) pane id. */
  getActive() {
    return this._active;
  }
  /** Focus a pane programmatically (mouse interactions update this). */
  setActive(id) {
    if (this._active === id) return this;
    this._active = id;
    this._refreshFocus();
    this._emit("focus", { pane: id });
    return this;
  }
  /** Maximize a pane to fill the whole viewer; passing same id again = restore. */
  toggleMaximize(id) {
    const t = id ?? this._active;
    this._maximized = this._maximized === t ? null : t;
    this._refreshLayout();
    this._emit("maximize", { pane: this._maximized });
    return this;
  }
  /** Update a pane's camera. Emits `camera` so consumers can sync renderers. */
  setCamera(id, camera) {
    const p = this._panes.get(id);
    if (!p) return this;
    if (camera.position) p.camera.position = { ...camera.position };
    if (camera.target) p.camera.target = { ...camera.target };
    if (camera.zoom !== void 0) p.camera.zoom = camera.zoom;
    if (camera.kind) p.camera.kind = camera.kind;
    this._refreshOverlay(p);
    this._emit("camera", { pane: id, ...p.camera });
    return this;
  }
  /** Get a pane's camera (deep-cloned). */
  getCamera(id) {
    const p = this._panes.get(id);
    if (!p) throw new Error(`unknown pane: ${id}`);
    return {
      position: { ...p.camera.position },
      target: { ...p.camera.target },
      zoom: p.camera.zoom,
      kind: p.camera.kind
    };
  }
  /** Reset all cameras to default positions. */
  resetCameras() {
    for (const id of Object.keys(DEFAULT_CAMERAS)) {
      this.setCamera(id, DEFAULT_CAMERAS[id]);
    }
    return this;
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = `<div class="ar-camera3d__grid" data-r="grid"></div>`;
    this._elGrid = this.el.querySelector('[data-r="grid"]');
    for (const id of Object.keys(DEFAULT_CAMERAS)) {
      const paneEl = document.createElement("div");
      paneEl.className = "ar-camera3d__pane";
      paneEl.dataset.pane = id;
      const surface = document.createElement("div");
      surface.className = "ar-camera3d__surface";
      const overlay = document.createElement("div");
      overlay.className = "ar-camera3d__overlay";
      paneEl.appendChild(surface);
      paneEl.appendChild(overlay);
      this._elGrid.appendChild(paneEl);
      const pane = {
        id,
        label: PANE_LABELS[id],
        surface,
        overlay,
        camera: { ...DEFAULT_CAMERAS[id], position: { ...DEFAULT_CAMERAS[id].position }, target: { ...DEFAULT_CAMERAS[id].target } }
      };
      this._panes.set(id, pane);
      this._buildOverlay(pane);
      this._wirePane(paneEl, pane);
    }
    this._refreshFocus();
    this._refreshLayout();
  }
  _buildOverlay(pane) {
    const showAxes = this._get("showAxes", true);
    const showLabels = this._get("showLabels", true);
    pane.overlay.innerHTML = `
${showLabels ? `<div class="ar-camera3d__label">${pane.label}</div>` : ""}
<div class="ar-camera3d__info" data-r="info"></div>
${showAxes ? `<div class="ar-camera3d__axes" data-r="axes"></div>` : ""}
`;
    this._refreshOverlay(pane);
  }
  _refreshOverlay(pane) {
    const info = pane.overlay.querySelector('[data-r="info"]');
    if (info) {
      const z = pane.camera.zoom;
      const k = pane.camera.kind === "perspective" ? "persp" : "ortho";
      info.textContent = `${k} \xB7 ${Math.round(z * 100)}%`;
    }
    const axes = pane.overlay.querySelector('[data-r="axes"]');
    if (axes) this._renderAxesGizmo(pane, axes);
  }
  /**
   * Render the per-pane XYZ axis gizmo. The gizmo's orientation depends on
   * the camera direction:
   *
   *   • Top         camera looks down -Y → X right, Z down
   *   • Front       camera looks down -Z → X right, Y up
   *   • Side        camera looks down +X → Z right, Y up (mirrored)
   *   • Perspective camera arbitrary    → project the world axes to screen
   */
  _renderAxesGizmo(pane, root) {
    const id = pane.id;
    let axes;
    if (id === "top") {
      axes = [
        { name: "X", x: 1, y: 0, color: "#ef4444" },
        { name: "Z", x: 0, y: 1, color: "#3b82f6" },
        { name: "Y", x: 0, y: 0, color: "#22c55e" }
        // hidden / dot
      ];
    } else if (id === "front") {
      axes = [
        { name: "X", x: 1, y: 0, color: "#ef4444" },
        { name: "Y", x: 0, y: -1, color: "#22c55e" },
        { name: "Z", x: 0, y: 0, color: "#3b82f6" }
        // dot
      ];
    } else if (id === "side") {
      axes = [
        { name: "Z", x: -1, y: 0, color: "#3b82f6" },
        { name: "Y", x: 0, y: -1, color: "#22c55e" },
        { name: "X", x: 0, y: 0, color: "#ef4444" }
        // dot
      ];
    } else {
      const tilt = -0.45;
      axes = [
        { name: "X", x: Math.cos(tilt), y: -Math.sin(tilt) * 0.4, color: "#ef4444" },
        { name: "Y", x: 0, y: -1, color: "#22c55e" },
        { name: "Z", x: -Math.cos(tilt), y: -Math.sin(tilt) * 0.4, color: "#3b82f6" }
      ];
    }
    const r = 26;
    const svgNS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(svgNS, "svg");
    svg.setAttribute("width", "64");
    svg.setAttribute("height", "64");
    svg.setAttribute("viewBox", "-32 -32 64 64");
    for (const a of axes) {
      if (a.x === 0 && a.y === 0) {
        const dot = document.createElementNS(svgNS, "circle");
        dot.setAttribute("cx", "0");
        dot.setAttribute("cy", "0");
        dot.setAttribute("r", "4");
        dot.setAttribute("fill", a.color);
        svg.appendChild(dot);
        continue;
      }
      const line = document.createElementNS(svgNS, "line");
      line.setAttribute("x1", "0");
      line.setAttribute("y1", "0");
      line.setAttribute("x2", String(a.x * r));
      line.setAttribute("y2", String(a.y * r));
      line.setAttribute("stroke", a.color);
      line.setAttribute("stroke-width", "2");
      svg.appendChild(line);
      const lbl = document.createElementNS(svgNS, "text");
      lbl.setAttribute("x", String(a.x * (r + 6)));
      lbl.setAttribute("y", String(a.y * (r + 6) + 3));
      lbl.setAttribute("fill", a.color);
      lbl.setAttribute("font-size", "10");
      lbl.setAttribute("font-family", "ui-monospace,monospace");
      lbl.setAttribute("text-anchor", "middle");
      lbl.textContent = a.name;
      svg.appendChild(lbl);
    }
    root.innerHTML = "";
    root.appendChild(svg);
  }
  _wirePane(paneEl, pane) {
    paneEl.addEventListener("pointerdown", () => this.setActive(pane.id));
    paneEl.addEventListener("dblclick", () => this.toggleMaximize(pane.id));
    paneEl.addEventListener("wheel", (e) => {
      e.preventDefault();
      const factor = Math.exp(-e.deltaY * 5e-3);
      this.setCamera(pane.id, { zoom: pane.camera.zoom * factor });
    }, { passive: false });
    paneEl.addEventListener("pointermove", (e) => {
      if (e.buttons === 0) return;
      const orbit = (e.buttons & 2) !== 0 || e.altKey;
      const pan = (e.buttons & 4) !== 0 || e.shiftKey;
      if (!orbit && !pan) return;
      this._emit(orbit ? "orbit" : "pan", {
        pane: pane.id,
        dx: e.movementX,
        dy: e.movementY
      });
    });
    paneEl.addEventListener("contextmenu", (e) => e.preventDefault());
  }
  _refreshFocus() {
    for (const [id, pane] of this._panes) {
      const el = pane.surface.parentElement;
      el.classList.toggle("ar-camera3d__pane--active", id === this._active);
    }
  }
  _refreshLayout() {
    if (this._maximized) {
      this._elGrid.classList.add("ar-camera3d__grid--maximized");
      for (const [id, pane] of this._panes) {
        pane.surface.parentElement.style.display = id === this._maximized ? "block" : "none";
      }
    } else {
      this._elGrid.classList.remove("ar-camera3d__grid--maximized");
      for (const [, pane] of this._panes)
        pane.surface.parentElement.style.display = "";
    }
  }
  _injectStyles() {
    if (document.getElementById("ar-camera3d-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-camera3d-styles";
    s.textContent = `
.ar-camera3d { position:relative; background:#0d0d0d; border:1px solid #333; border-radius:6px; overflow:hidden; }
.ar-camera3d__grid { display:grid; grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; gap:1px; background:#333; height:100%; }
.ar-camera3d__grid--maximized { grid-template-columns:1fr; grid-template-rows:1fr; }
.ar-camera3d__pane { position:relative; background:#1e1e1e; overflow:hidden; cursor:default; }
.ar-camera3d__pane--active { outline:2px solid #e40c88; outline-offset:-2px; }
.ar-camera3d__surface { position:absolute; inset:0; }
.ar-camera3d__overlay { position:absolute; inset:0; pointer-events:none; }
.ar-camera3d__label { position:absolute; top:8px; left:10px; font:600 10px ui-monospace,monospace; color:#888; letter-spacing:.08em; pointer-events:auto; }
.ar-camera3d__pane--active .ar-camera3d__label { color:#e40c88; }
.ar-camera3d__info { position:absolute; bottom:8px; left:10px; font:10px ui-monospace,monospace; color:#666; }
.ar-camera3d__axes { position:absolute; bottom:8px; right:8px; width:64px; height:64px; pointer-events:none; }
`;
    document.head.appendChild(s);
  }
};

// components/graphics/3D/Modifiers3DPalette.ts
var CATALOGUE = [
  {
    kind: "array",
    label: "Array",
    icon: "\u{1F501}",
    params: [
      { key: "count", label: "Count", type: "number", min: 1, max: 100, step: 1, default: 3 },
      { key: "offset", label: "Offset", type: "number", min: 0, max: 100, step: 0.1, default: 1 },
      { key: "axis", label: "Axis", type: "enum", options: ["X", "Y", "Z"], default: "X" }
    ]
  },
  {
    kind: "bend",
    label: "Bend",
    icon: "\u21A9",
    params: [
      { key: "angle", label: "Angle", type: "angle", min: -360, max: 360, step: 1, default: 90 },
      { key: "axis", label: "Axis", type: "enum", options: ["X", "Y", "Z"], default: "Y" }
    ]
  },
  {
    kind: "bevel",
    label: "Bevel",
    icon: "\u25C6",
    params: [
      { key: "width", label: "Width", type: "number", min: 0, max: 1, step: 0.01, default: 0.05 },
      { key: "segments", label: "Segments", type: "number", min: 1, max: 16, step: 1, default: 2 }
    ]
  },
  {
    kind: "billboard",
    label: "Billboard",
    icon: "\u{1FAA7}",
    params: [
      { key: "lockY", label: "Lock Y", type: "boolean", default: false }
    ]
  },
  {
    kind: "decimate",
    label: "Decimate",
    icon: "\u25BD",
    params: [
      { key: "ratio", label: "Ratio", type: "number", min: 0.01, max: 1, step: 0.01, default: 0.5 }
    ]
  },
  {
    kind: "drag",
    label: "Drag",
    icon: "\u{1F32C}",
    params: [
      { key: "damping", label: "Damping", type: "number", min: 0, max: 1, step: 0.01, default: 0.1 }
    ]
  },
  {
    kind: "fade",
    label: "Fade",
    icon: "\u25D0",
    params: [
      { key: "distance", label: "Distance", type: "number", min: 0, max: 1e3, step: 1, default: 50 }
    ]
  },
  {
    kind: "inflate",
    label: "Inflate",
    icon: "\u{1F388}",
    params: [
      { key: "amount", label: "Amount", type: "number", min: -1, max: 1, step: 0.01, default: 0.1 }
    ]
  },
  {
    kind: "lod",
    label: "LOD",
    icon: "\u{1F50D}",
    params: [
      { key: "levels", label: "Levels", type: "number", min: 1, max: 8, step: 1, default: 3 },
      { key: "distance", label: "Distance", type: "number", min: 1, max: 1e3, step: 1, default: 100 }
    ]
  },
  {
    kind: "mirror",
    label: "Mirror",
    icon: "\u27F7",
    params: [
      { key: "axis", label: "Axis", type: "enum", options: ["X", "Y", "Z"], default: "X" },
      { key: "merge", label: "Merge", type: "boolean", default: true }
    ]
  },
  {
    kind: "smooth",
    label: "Smooth",
    icon: "\u25CE",
    params: [
      { key: "iterations", label: "Iter", type: "number", min: 1, max: 16, step: 1, default: 1 },
      { key: "factor", label: "Factor", type: "number", min: 0, max: 1, step: 0.05, default: 0.5 }
    ]
  },
  {
    kind: "snap",
    label: "Snap",
    icon: "\u{1F517}",
    params: [
      { key: "distance", label: "Distance", type: "number", min: 1e-3, max: 10, step: 1e-3, default: 0.01 }
    ]
  },
  {
    kind: "subdivision",
    label: "Subdivision",
    icon: "\u229E",
    params: [
      { key: "levels", label: "Levels", type: "number", min: 1, max: 6, step: 1, default: 2 }
    ]
  },
  {
    kind: "twist",
    label: "Twist",
    icon: "\u{1F300}",
    params: [
      { key: "angle", label: "Angle", type: "angle", min: -720, max: 720, step: 1, default: 180 },
      { key: "axis", label: "Axis", type: "enum", options: ["X", "Y", "Z"], default: "Y" }
    ]
  },
  {
    kind: "wave",
    label: "Wave",
    icon: "\u3030",
    params: [
      { key: "amplitude", label: "Amp", type: "number", min: 0, max: 1, step: 0.01, default: 0.1 },
      { key: "frequency", label: "Freq", type: "number", min: 0, max: 20, step: 0.1, default: 1 }
    ]
  }
];
var PaletteModifiers3D = class extends Control {
  _stack = [];
  _nextId = 1;
  _elList;
  _elFooter;
  constructor(container, opts = {}) {
    super(container, "div", { stack: [], title: "Modifiers", ...opts });
    this.el.className = `ar-palmod${opts.class ? " " + opts.class : ""}`;
    this._stack = (this._get("stack", []) || []).map((s) => ({ ...s, params: { ...s.params } }));
    this._injectStyles();
    this._build();
    this._renderStack();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Get current stack (deep cloned). */
  getStack() {
    return this._stack.map((s) => ({ ...s, params: { ...s.params } }));
  }
  /** Add a modifier to the bottom of the stack. */
  addModifier(kind, params = {}) {
    const spec = CATALOGUE.find((c) => c.kind === kind);
    if (!spec) throw new Error(`unknown modifier kind: ${kind}`);
    const defaults = {};
    for (const p of spec.params) defaults[p.key] = p.default;
    const item = {
      id: `mod-${this._nextId++}`,
      kind,
      enabled: true,
      params: { ...defaults, ...params },
      expanded: true
    };
    this._stack.push(item);
    this._renderStack();
    this._emit("add", { id: item.id, kind, params: item.params, index: this._stack.length - 1 });
    return item;
  }
  /** Remove a modifier by id. */
  removeModifier(id) {
    const i = this._stack.findIndex((s) => s.id === id);
    if (i < 0) return this;
    this._stack.splice(i, 1);
    this._renderStack();
    this._emit("remove", { id, index: i });
    return this;
  }
  /** Update a modifier's params. */
  updateParams(id, patch) {
    const item = this._stack.find((s) => s.id === id);
    if (!item) return this;
    item.params = { ...item.params, ...patch };
    this._renderStack();
    this._emit("update", { id, params: item.params });
    return this;
  }
  /** Toggle enabled flag (consumer can hide effect without removing item). */
  setEnabled(id, enabled) {
    const item = this._stack.find((s) => s.id === id);
    if (!item) return this;
    item.enabled = enabled;
    this._renderStack();
    this._emit("toggle", { id, enabled });
    return this;
  }
  /** Reorder a modifier within the stack. */
  reorder(id, toIndex) {
    const i = this._stack.findIndex((s) => s.id === id);
    if (i < 0) return this;
    const [item] = this._stack.splice(i, 1);
    const clamped = Math.max(0, Math.min(toIndex, this._stack.length));
    this._stack.splice(clamped, 0, item);
    this._renderStack();
    this._emit("reorder", { id, fromIndex: i, toIndex: clamped });
    return this;
  }
  /** Catalogue of all available modifiers. */
  static getCatalogue() {
    return CATALOGUE.map((c) => ({ kind: c.kind, label: c.label, icon: c.icon }));
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = `
<div class="ar-palmod__head">
  <span class="ar-palmod__title">${escapeHtml5(this._get("title", "Modifiers"))}</span>
</div>
<div class="ar-palmod__list" data-r="list"></div>
<div class="ar-palmod__footer" data-r="footer">
  <select class="ar-palmod__sel" data-r="sel">
    <option value="">+ Add modifier</option>
    ${CATALOGUE.map((c) => `<option value="${c.kind}">${c.icon} ${c.label}</option>`).join("")}
  </select>
</div>`;
    this._elList = this.el.querySelector('[data-r="list"]');
    this._elFooter = this.el.querySelector('[data-r="footer"]');
    const sel = this._elFooter.querySelector('[data-r="sel"]');
    sel.addEventListener("change", () => {
      if (!sel.value) return;
      this.addModifier(sel.value);
      sel.value = "";
    });
  }
  _renderStack() {
    this._elList.innerHTML = "";
    for (const item of this._stack) {
      const spec = CATALOGUE.find((c) => c.kind === item.kind);
      const card = document.createElement("div");
      card.className = "ar-palmod__card" + (item.enabled ? "" : " ar-palmod__card--off");
      card.dataset.id = item.id;
      const head = document.createElement("div");
      head.className = "ar-palmod__card-head";
      head.innerHTML = `
<span class="ar-palmod__chev" data-act="exp">${item.expanded ? "\u25BC" : "\u25B6"}</span>
<span class="ar-palmod__icon">${escapeHtml5(spec.icon)}</span>
<span class="ar-palmod__name">${escapeHtml5(spec.label)}</span>
<span class="ar-palmod__spacer"></span>
<button class="ar-palmod__btn" data-act="vis" title="Toggle">${item.enabled ? "\u{1F441}" : "\u2298"}</button>
<button class="ar-palmod__btn" data-act="up"  title="Move up">\u25B2</button>
<button class="ar-palmod__btn" data-act="dn"  title="Move down">\u25BC</button>
<button class="ar-palmod__btn ar-palmod__btn--danger" data-act="rm" title="Remove">\xD7</button>
`;
      card.appendChild(head);
      if (item.expanded) {
        const body = document.createElement("div");
        body.className = "ar-palmod__card-body";
        for (const p of spec.params) {
          body.appendChild(this._buildParamRow(item, p));
        }
        card.appendChild(body);
      }
      this._wireCard(card, item);
      this._elList.appendChild(card);
    }
  }
  _buildParamRow(item, p) {
    const row = document.createElement("div");
    row.className = "ar-palmod__row";
    const lbl = document.createElement("label");
    lbl.className = "ar-palmod__lbl";
    lbl.textContent = p.label;
    row.appendChild(lbl);
    let inp;
    const cur = item.params[p.key];
    if (p.type === "enum") {
      const sel = document.createElement("select");
      sel.className = "ar-palmod__inp";
      for (const o of p.options || []) {
        const opt = document.createElement("option");
        opt.value = o;
        opt.textContent = o;
        if (cur === o) opt.selected = true;
        sel.appendChild(opt);
      }
      sel.addEventListener("change", () => this.updateParams(item.id, { [p.key]: sel.value }));
      inp = sel;
    } else if (p.type === "boolean") {
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = !!cur;
      cb.addEventListener("change", () => this.updateParams(item.id, { [p.key]: cb.checked }));
      inp = cb;
    } else {
      const n = document.createElement("input");
      n.type = "number";
      n.className = "ar-palmod__inp";
      n.value = String(cur ?? 0);
      if (p.min !== void 0) n.min = String(p.min);
      if (p.max !== void 0) n.max = String(p.max);
      if (p.step !== void 0) n.step = String(p.step);
      n.addEventListener("change", () => this.updateParams(item.id, { [p.key]: parseFloat(n.value) || 0 }));
      inp = n;
    }
    row.appendChild(inp);
    return row;
  }
  _wireCard(card, item) {
    card.querySelector('[data-act="exp"]')?.addEventListener("click", () => {
      item.expanded = !item.expanded;
      this._renderStack();
    });
    card.querySelector('[data-act="vis"]')?.addEventListener("click", () => {
      this.setEnabled(item.id, !item.enabled);
    });
    card.querySelector('[data-act="rm"]')?.addEventListener("click", () => {
      this.removeModifier(item.id);
    });
    card.querySelector('[data-act="up"]')?.addEventListener("click", () => {
      const i = this._stack.findIndex((s) => s.id === item.id);
      if (i > 0) this.reorder(item.id, i - 1);
    });
    card.querySelector('[data-act="dn"]')?.addEventListener("click", () => {
      const i = this._stack.findIndex((s) => s.id === item.id);
      if (i < this._stack.length - 1) this.reorder(item.id, i + 1);
    });
  }
  _injectStyles() {
    if (document.getElementById("ar-palmod-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-palmod-styles";
    s.textContent = `
.ar-palmod { display:flex; flex-direction:column; min-width:280px; background:#1e1e1e; border:1px solid #333; border-radius:6px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; user-select:none; }
.ar-palmod__head { padding:8px 12px; border-bottom:1px solid #333; }
.ar-palmod__title { font:600 12px sans-serif; color:#e40c88; letter-spacing:.04em; text-transform:uppercase; }
.ar-palmod__list { flex:1; overflow:auto; max-height:480px; padding:4px; display:flex; flex-direction:column; gap:4px; }
.ar-palmod__card { background:#252525; border:1px solid #333; border-radius:4px; }
.ar-palmod__card--off { opacity:0.5; }
.ar-palmod__card-head { display:flex; align-items:center; gap:6px; padding:6px 8px; border-bottom:1px solid #333; }
.ar-palmod__card:not(:has(.ar-palmod__card-body)) > .ar-palmod__card-head { border-bottom:0; }
.ar-palmod__chev { font-size:9px; color:#888; cursor:pointer; width:12px; }
.ar-palmod__icon { font-size:14px; }
.ar-palmod__name { font:600 12px sans-serif; }
.ar-palmod__spacer { flex:1; }
.ar-palmod__btn { background:transparent; border:0; color:#888; cursor:pointer; padding:2px 6px; font-size:12px; border-radius:2px; }
.ar-palmod__btn:hover { background:#333; color:#fff; }
.ar-palmod__btn--danger:hover { background:#dc2626; color:#fff; }
.ar-palmod__card-body { padding:6px 8px; display:flex; flex-direction:column; gap:4px; }
.ar-palmod__row { display:flex; align-items:center; gap:8px; }
.ar-palmod__lbl { min-width:60px; font:10px ui-monospace,monospace; color:#888; }
.ar-palmod__inp { flex:1; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:3px 6px; font:11px ui-monospace,monospace; border-radius:2px; }
.ar-palmod__footer { padding:8px; border-top:1px solid #333; }
.ar-palmod__sel { width:100%; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:5px 8px; font:11px sans-serif; border-radius:3px; cursor:pointer; }
.ar-palmod__sel:hover { border-color:#e40c88; }
`;
    document.head.appendChild(s);
  }
};
function escapeHtml5(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/graphics/3D/MaterialsPalette.ts
var TEMPLATES = [
  { name: "Metal", kind: "pbr-standard", albedo: "#8a8a8a", metalness: 0.9, roughness: 0.25, emissive: "#000", emissiveIntensity: 0, alpha: 1, maps: {} },
  { name: "Plastic", kind: "pbr-standard", albedo: "#3b82f6", metalness: 0.05, roughness: 0.5, emissive: "#000", emissiveIntensity: 0, alpha: 1, maps: {} },
  { name: "Wood", kind: "pbr-standard", albedo: "#8b5a2b", metalness: 0, roughness: 0.85, emissive: "#000", emissiveIntensity: 0, alpha: 1, maps: {} },
  { name: "Glass", kind: "pbr-clearcoat", albedo: "#ffffff", metalness: 0, roughness: 0.05, emissive: "#000", emissiveIntensity: 0, alpha: 0.3, maps: {} },
  { name: "Emissive", kind: "unlit", albedo: "#e40c88", metalness: 0, roughness: 1, emissive: "#e40c88", emissiveIntensity: 2, alpha: 1, maps: {} },
  { name: "Fabric", kind: "pbr-standard", albedo: "#dc2626", metalness: 0, roughness: 0.95, emissive: "#000", emissiveIntensity: 0, alpha: 1, maps: {} },
  { name: "Stone", kind: "pbr-standard", albedo: "#525252", metalness: 0, roughness: 0.8, emissive: "#000", emissiveIntensity: 0, alpha: 1, maps: {} }
];
var PaletteMaterials = class extends Control {
  _library = [];
  _selected = null;
  _nextId = 1;
  _elList;
  _elProps;
  constructor(container, opts = {}) {
    super(container, "div", { library: [], title: "Materials", ...opts });
    this.el.className = `ar-palmat${opts.class ? " " + opts.class : ""}`;
    const lib = opts.library;
    if (lib === void 0) {
      for (const t of TEMPLATES) this._library.push({ ...t, id: this._mkId(), maps: { ...t.maps } });
    } else {
      this._library = lib.map((m) => ({ ...m, maps: { ...m.maps } }));
    }
    this._injectStyles();
    this._build();
    const initSel = this._get("selected", "");
    this.select(initSel || this._library[0]?.id || null);
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Library (deep-cloned). */
  getLibrary() {
    return this._library.map((m) => ({ ...m, maps: { ...m.maps } }));
  }
  /** Currently selected material (deep-cloned), or null. */
  getSelected() {
    if (!this._selected) return null;
    const m = this._library.find((x) => x.id === this._selected);
    return m ? { ...m, maps: { ...m.maps } } : null;
  }
  /** Select a material by id, or pass null to deselect. */
  select(id) {
    this._selected = id;
    this._renderList();
    this._renderProps();
    const m = this.getSelected();
    if (m) this._emit("apply", { id: m.id, material: m });
    return this;
  }
  /** Add a new material to the library (returns the created spec). */
  addMaterial(partial = {}) {
    const m = {
      id: this._mkId(),
      name: partial.name ?? "New Material",
      kind: partial.kind ?? "pbr-standard",
      albedo: partial.albedo ?? "#888888",
      metalness: partial.metalness ?? 0,
      roughness: partial.roughness ?? 0.5,
      emissive: partial.emissive ?? "#000000",
      emissiveIntensity: partial.emissiveIntensity ?? 0,
      alpha: partial.alpha ?? 1,
      maps: { ...partial.maps ?? {} }
    };
    this._library.push(m);
    this._renderList();
    this._emit("add", { id: m.id, material: m });
    return m;
  }
  /** Update properties of an existing material. */
  updateMaterial(id, patch) {
    const i = this._library.findIndex((m) => m.id === id);
    if (i < 0) return this;
    const cur = this._library[i];
    const updated = {
      ...cur,
      ...patch,
      maps: { ...cur.maps, ...patch.maps ?? {} }
    };
    this._library[i] = updated;
    this._renderList();
    if (this._selected === id) this._renderProps();
    this._emit("change", { id, material: updated });
    return this;
  }
  /** Remove a material. If it was selected, selection is cleared. */
  removeMaterial(id) {
    const i = this._library.findIndex((m) => m.id === id);
    if (i < 0) return this;
    this._library.splice(i, 1);
    if (this._selected === id) this._selected = null;
    this._renderList();
    this._renderProps();
    this._emit("remove", { id });
    return this;
  }
  /** All built-in template names — useful for "From template" dropdowns. */
  static getTemplates() {
    return TEMPLATES.map((t) => ({ ...t, maps: { ...t.maps } }));
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _mkId() {
    return `mat-${this._nextId++}`;
  }
  _build() {
    this.el.innerHTML = `
<div class="ar-palmat__head">
  <span class="ar-palmat__title">${escapeHtml6(this._get("title", "Materials"))}</span>
</div>
<div class="ar-palmat__body">
  <div class="ar-palmat__library" data-r="library"></div>
  <div class="ar-palmat__props"   data-r="props"></div>
</div>
<div class="ar-palmat__footer">
  <button class="ar-palmat__btn" data-act="new">+ New</button>
  <button class="ar-palmat__btn ar-palmat__btn--danger" data-act="remove">\xD7 Delete</button>
</div>
`;
    this._elList = this.el.querySelector('[data-r="library"]');
    this._elProps = this.el.querySelector('[data-r="props"]');
    this.el.querySelector('[data-act="new"]')?.addEventListener(
      "click",
      () => {
        const m = this.addMaterial();
        this.select(m.id);
      }
    );
    this.el.querySelector('[data-act="remove"]')?.addEventListener(
      "click",
      () => {
        if (this._selected) this.removeMaterial(this._selected);
      }
    );
    this._renderList();
  }
  _renderList() {
    this._elList.innerHTML = "";
    for (const m of this._library) {
      const item = document.createElement("div");
      item.className = "ar-palmat__item" + (m.id === this._selected ? " ar-palmat__item--selected" : "");
      item.dataset.id = m.id;
      item.innerHTML = `
<div class="ar-palmat__swatch" style="background:${m.albedo}"></div>
<span class="ar-palmat__item-name">${escapeHtml6(m.name)}</span>
`;
      item.addEventListener("click", () => this.select(m.id));
      this._elList.appendChild(item);
    }
  }
  _renderProps() {
    const m = this._selected ? this._library.find((x) => x.id === this._selected) : null;
    if (!m) {
      this._elProps.innerHTML = `<div class="ar-palmat__empty">No material selected</div>`;
      return;
    }
    this._elProps.innerHTML = `
<div class="ar-palmat__prop">
  <label>Name</label>
  <input data-prop="name"  type="text"   value="${escapeHtml6(m.name)}">
</div>
<div class="ar-palmat__prop">
  <label>Type</label>
  <select data-prop="kind">
    <option value="pbr-standard"${m.kind === "pbr-standard" ? " selected" : ""}>PBR Standard</option>
    <option value="pbr-clearcoat"${m.kind === "pbr-clearcoat" ? " selected" : ""}>PBR Clearcoat</option>
    <option value="unlit"${m.kind === "unlit" ? " selected" : ""}>Unlit</option>
    <option value="toon"${m.kind === "toon" ? " selected" : ""}>Toon</option>
  </select>
</div>
<div class="ar-palmat__prop">
  <label>Albedo</label>
  <input data-prop="albedo"   type="color"  value="${m.albedo}">
</div>
<div class="ar-palmat__prop">
  <label>Metalness</label>
  <input data-prop="metalness" type="number" min="0" max="1" step="0.01" value="${m.metalness}">
</div>
<div class="ar-palmat__prop">
  <label>Roughness</label>
  <input data-prop="roughness" type="number" min="0" max="1" step="0.01" value="${m.roughness}">
</div>
<div class="ar-palmat__prop">
  <label>Emissive</label>
  <input data-prop="emissive"  type="color"  value="${m.emissive}">
</div>
<div class="ar-palmat__prop">
  <label>Em.Intensity</label>
  <input data-prop="emissiveIntensity" type="number" min="0" max="10" step="0.1" value="${m.emissiveIntensity}">
</div>
<div class="ar-palmat__prop">
  <label>Alpha</label>
  <input data-prop="alpha" type="number" min="0" max="1" step="0.01" value="${m.alpha}">
</div>
<div class="ar-palmat__sep">Texture maps</div>
${this._mapField("Albedo", "albedo", m.maps.albedo)}
${this._mapField("Normal", "normal", m.maps.normal)}
${this._mapField("Roughness", "roughness", m.maps.roughness)}
${this._mapField("Metalness", "metalness", m.maps.metalness)}
${this._mapField("Emissive", "emissive", m.maps.emissive)}
`;
    const props = ["name", "kind", "albedo", "metalness", "roughness", "emissive", "emissiveIntensity", "alpha"];
    for (const p of props) {
      const inp = this._elProps.querySelector(`[data-prop="${p}"]`);
      if (!inp) continue;
      inp.addEventListener("change", () => {
        const raw = inp.value;
        const v = inp.type === "number" ? parseFloat(raw) || 0 : raw;
        this.updateMaterial(m.id, { [p]: v });
      });
    }
    for (const k of ["albedo", "normal", "roughness", "metalness", "emissive"]) {
      const inp = this._elProps.querySelector(`[data-map="${k}"]`);
      if (!inp) continue;
      inp.addEventListener("change", () => {
        const newMaps = { ...m.maps, [k]: inp.value };
        this.updateMaterial(m.id, { maps: newMaps });
      });
      const clear = this._elProps.querySelector(`[data-map-clear="${k}"]`);
      clear?.addEventListener("click", () => {
        const newMaps = { ...m.maps, [k]: void 0 };
        this.updateMaterial(m.id, { maps: newMaps });
      });
    }
  }
  _mapField(label, key, value) {
    return `
<div class="ar-palmat__prop ar-palmat__prop--map">
  <label>${escapeHtml6(label)}</label>
  <input data-map="${key}" type="text" placeholder="(no map)" value="${escapeHtml6(value || "")}">
  <button class="ar-palmat__map-clear" data-map-clear="${key}" title="Clear">\u2298</button>
</div>`;
  }
  _injectStyles() {
    if (document.getElementById("ar-palmat-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-palmat-styles";
    s.textContent = `
.ar-palmat { display:flex; flex-direction:column; min-width:480px; background:#1e1e1e; border:1px solid #333; border-radius:6px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; user-select:none; }
.ar-palmat__head { padding:8px 12px; border-bottom:1px solid #333; }
.ar-palmat__title { font:600 12px sans-serif; color:#e40c88; letter-spacing:.04em; text-transform:uppercase; }
.ar-palmat__body { display:flex; flex:1; min-height:300px; max-height:520px; }
.ar-palmat__library { width:160px; border-right:1px solid #333; overflow:auto; padding:4px; display:flex; flex-direction:column; gap:2px; }
.ar-palmat__item { display:flex; align-items:center; gap:8px; padding:4px 8px; cursor:pointer; border-radius:3px; }
.ar-palmat__item:hover { background:#2a2a2a; }
.ar-palmat__item--selected { background:rgba(228,12,136,0.2); border-left:2px solid #e40c88; }
.ar-palmat__swatch { width:24px; height:24px; border-radius:3px; border:1px solid #444; flex-shrink:0; }
.ar-palmat__item-name { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ar-palmat__props { flex:1; overflow:auto; padding:8px; display:flex; flex-direction:column; gap:6px; }
.ar-palmat__prop { display:flex; align-items:center; gap:8px; }
.ar-palmat__prop label { width:90px; font:10px ui-monospace,monospace; color:#888; flex-shrink:0; }
.ar-palmat__prop input, .ar-palmat__prop select { flex:1; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:3px 6px; font:11px ui-monospace,monospace; border-radius:2px; }
.ar-palmat__prop input[type="color"] { width:40px; flex:none; padding:0; cursor:pointer; height:22px; }
.ar-palmat__prop--map input { font:10px ui-monospace,monospace; }
.ar-palmat__map-clear { background:transparent; border:1px solid #444; color:#888; padding:2px 6px; font-size:11px; cursor:pointer; border-radius:2px; flex:none; }
.ar-palmat__map-clear:hover { background:#dc2626; border-color:#dc2626; color:#fff; }
.ar-palmat__sep { font:10px sans-serif; color:#888; text-transform:uppercase; padding-top:8px; padding-bottom:2px; border-top:1px solid #333; margin-top:4px; }
.ar-palmat__empty { padding:20px; text-align:center; color:#666; }
.ar-palmat__footer { padding:6px; border-top:1px solid #333; display:flex; gap:4px; }
.ar-palmat__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:11px sans-serif; border-radius:3px; cursor:pointer; }
.ar-palmat__btn:hover { background:#2a2a2a; }
.ar-palmat__btn--danger:hover { background:#dc2626; border-color:#dc2626; color:#fff; }
`;
    document.head.appendChild(s);
  }
};
function escapeHtml6(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/maps/MapEmbed.ts
var MapEmbed = class extends Control {
  _iframe;
  _center;
  _zoom;
  _marker;
  constructor(container, opts) {
    super(container, "div", {
      center: { lat: 51.4779, lng: -15e-4 },
      zoom: 13,
      marker: true,
      aspectRatio: "16/9",
      ...opts
    });
    const self = this;
    this._center = self._get("center", { lat: 51.4779, lng: -15e-4 });
    this._zoom = self._get("zoom", 13);
    this._marker = self._get("marker", true);
    self.el.className = `ar-map ar-map--${this.getProvider()}${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  setLocation(center) {
    this._center = { ...center };
    this._refresh();
    return this;
  }
  setZoom(z) {
    this._zoom = Math.max(1, Math.min(20, z));
    this._refresh();
    return this;
  }
  setMarker(on) {
    this._marker = on;
    this._refresh();
    return this;
  }
  reload() {
    this._refresh();
    return this;
  }
  getCenter() {
    return { ...this._center };
  }
  getZoom() {
    return this._zoom;
  }
  // ── Build + refresh ────────────────────────────────────────────────────
  _build() {
    const self = this;
    const aspect = self._get("aspectRatio", "16/9");
    self.el.innerHTML = `
<div class="ar-map__stage" style="aspect-ratio:${aspect}">
  <iframe class="ar-map__iframe"
          data-r="iframe"
          frameborder="0"
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
          allowfullscreen></iframe>
</div>
<div class="ar-map__chrome">
  <span class="ar-map__badge">${this.getProvider().toUpperCase()}</span>
  <a class="ar-map__open" data-r="open" target="_blank" rel="noopener">Open \u2197</a>
</div>`;
    this._iframe = self.el.querySelector('[data-r="iframe"]');
    this._refresh();
  }
  _refresh() {
    if (!this._iframe) return;
    const self = this;
    this._iframe.src = this._embedUrl();
    const open = self.el.querySelector('[data-r="open"]');
    if (open) open.href = this._openUrl();
  }
  /** Public link in a new tab; subclasses may override. */
  _openUrl() {
    const { lat, lng } = this._center;
    return `https://www.google.com/maps/@${lat},${lng},${this._zoom}z`;
  }
  _injectStyles() {
    if (document.getElementById("ar-map-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-map-styles";
    s.textContent = `
.ar-map { position:relative; display:flex; flex-direction:column; background:#1e1e1e; border:1px solid #333; border-radius:8px; overflow:hidden; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; }
.ar-map__stage { position:relative; background:#0d0d0d; min-height:200px; }
.ar-map__iframe { width:100%; height:100%; border:0; display:block; }
.ar-map__chrome { display:flex; align-items:center; justify-content:space-between; padding:6px 10px; background:#161616; border-top:1px solid #333; }
.ar-map__badge  { font:10px ui-monospace,monospace; letter-spacing:.08em; color:#e40c88; text-transform:uppercase; padding:2px 8px; border:1px solid rgba(228,12,136,.4); border-radius:10px; }
.ar-map__open   { font:11px sans-serif; color:#d4d4d4; text-decoration:none; padding:3px 8px; border:1px solid #333; border-radius:3px; }
.ar-map__open:hover { background:#2a2a2a; }
.ar-map__fallback { display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; padding:24px; text-align:center; color:#888; }
.ar-map__fallback a { color:#e40c88; text-decoration:none; font-weight:600; }
@media (max-width: 600px) {
  .ar-map__stage { min-height:160px; }
  .ar-map__chrome { padding:4px 8px; }
  .ar-map__badge  { font-size:9px; padding:1px 6px; }
}
`;
    document.head.appendChild(s);
  }
};
var GoogleMap = class extends MapEmbed {
  getProvider() {
    return "google";
  }
  _embedUrl() {
    const { lat, lng } = this._center;
    const q = this._get("address", "");
    const query = q ? encodeURIComponent(q) : `${lat},${lng}`;
    return `https://www.google.com/maps?q=${query}&z=${this._zoom}&output=embed`;
  }
  _openUrl() {
    const { lat, lng } = this._center;
    return `https://www.google.com/maps/@${lat},${lng},${this._zoom}z`;
  }
};
var OpenStreetMap = class extends MapEmbed {
  getProvider() {
    return "osm";
  }
  _embedUrl() {
    const { lat, lng } = this._center;
    const span = 0.6 / Math.pow(2, this._zoom - 8);
    const bbox = `${lng - span},${lat - span / 2},${lng + span},${lat + span / 2}`;
    const layer = "mapnik";
    const marker = this._marker ? `&marker=${lat}%2C${lng}` : "";
    return `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=${layer}${marker}`;
  }
  _openUrl() {
    const { lat, lng } = this._center;
    return `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lng}#map=${this._zoom}/${lat}/${lng}`;
  }
};
var AppleMap = class extends MapEmbed {
  getProvider() {
    return "apple";
  }
  _build() {
    super._build();
    if (!this._isAppleCapable()) {
      const self = this;
      const stage = self.el.querySelector(".ar-map__stage");
      if (stage) {
        stage.innerHTML = `
<div class="ar-map__fallback">
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity:.4">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
    <circle cx="12" cy="10" r="3"/>
  </svg>
  <div>Apple Maps embeds render only on Apple platforms.</div>
  <a data-r="open-fb" target="_blank" rel="noopener">Open in Apple Maps</a>
</div>`;
        const fb = stage.querySelector('[data-r="open-fb"]');
        if (fb) fb.href = this._openUrl();
      }
    }
  }
  _embedUrl() {
    const { lat, lng } = this._center;
    const q = this._get("address", "");
    const params = [`ll=${lat},${lng}`, `z=${this._zoom}`, "t=m"];
    if (q) params.push(`q=${encodeURIComponent(q)}`);
    return `https://maps.apple.com/?${params.join("&")}`;
  }
  _openUrl() {
    return this._embedUrl();
  }
  _isAppleCapable() {
    if (typeof navigator === "undefined") return false;
    return /(Macintosh|iPhone|iPad|iPod)/.test(navigator.userAgent);
  }
};
var BingMap = class extends MapEmbed {
  getProvider() {
    return "bing";
  }
  _embedUrl() {
    const { lat, lng } = this._center;
    return `https://www.bing.com/maps/embed?h=400&w=600&cp=${lat}~${lng}&lvl=${this._zoom}&typ=d&sty=r&src=SHELL&FORM=MBEDV8`;
  }
  _openUrl() {
    const { lat, lng } = this._center;
    return `https://www.bing.com/maps?cp=${lat}~${lng}&lvl=${this._zoom}`;
  }
};

// components/modifiers/2D/Base.ts
function _resolveTargets(input) {
  const inputs = Array.isArray(input) ? input : [input];
  const result = [];
  for (const t of inputs) {
    if (typeof t === "string") {
      document.querySelectorAll(t).forEach((el) => result.push(el));
    } else if (t instanceof HTMLElement) {
      result.push(t);
    } else if (typeof t.render === "function") {
      const el = t.render();
      if (el instanceof HTMLElement) result.push(el);
    }
  }
  return result;
}
var Modifier2D = class {
  elements = [];
  enabled = true;
  cleanups = [];
  constructor(input) {
    this.elements = _resolveTargets(input);
    for (const el of this.elements) this._applyTo(el);
  }
  enable() {
    this.enabled = true;
    return this;
  }
  disable() {
    this.enabled = false;
    return this;
  }
  destroy() {
    this.cleanups.forEach((fn) => fn());
    this.cleanups = [];
  }
};

// components/modifiers/2D/Resizer.ts
function _handlePos(dir, hs) {
  const h = hs / 2;
  const map = {
    n: `top:-${h}px;left:50%;transform:translateX(-50%);cursor:n-resize;`,
    s: `bottom:-${h}px;left:50%;transform:translateX(-50%);cursor:s-resize;`,
    e: `right:-${h}px;top:50%;transform:translateY(-50%);cursor:e-resize;`,
    w: `left:-${h}px;top:50%;transform:translateY(-50%);cursor:w-resize;`,
    ne: `top:-${h}px;right:-${h}px;cursor:ne-resize;`,
    nw: `top:-${h}px;left:-${h}px;cursor:nw-resize;`,
    se: `bottom:-${h}px;right:-${h}px;cursor:se-resize;`,
    sw: `bottom:-${h}px;left:-${h}px;cursor:sw-resize;`
  };
  return map[dir] ?? "";
}
var Resizer = class extends Modifier2D {
  #opts;
  #callbacks = [];
  constructor(input, opts = {}) {
    super(input);
    const allowCross = opts.allowCross ?? true;
    this.#opts = {
      minWidth: opts.minWidth ?? (allowCross ? 0 : 40),
      minHeight: opts.minHeight ?? (allowCross ? 0 : 40),
      maxWidth: opts.maxWidth ?? 9999,
      maxHeight: opts.maxHeight ?? 9999,
      handles: opts.handles ?? ["n", "s", "e", "w", "ne", "nw", "se", "sw"],
      handleSize: opts.handleSize ?? 8,
      handleColor: opts.handleColor ?? "#e40c88",
      allowCross
    };
  }
  onResize(cb) {
    this.#callbacks.push(cb);
    return this;
  }
  _applyTo(el) {
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    const {
      handleSize: hs,
      handleColor: hc,
      allowCross,
      minWidth: minW,
      minHeight: minH,
      maxWidth: maxW,
      maxHeight: maxH
    } = this.#opts;
    for (const dir of this.#opts.handles) {
      const handle = document.createElement("div");
      handle.dataset["resizeDir"] = dir;
      handle.style.cssText = `position:absolute;width:${hs}px;height:${hs}px;background:${hc};border-radius:50%;z-index:9999;touch-action:none;` + _handlePos(dir, hs);
      el.appendChild(handle);
      let pointerId = -1;
      let startPx = 0, startPy = 0;
      let anchorX = 0, pointerStartX = 0;
      let anchorY = 0, pointerStartY = 0;
      let movesX = false, movesY = false;
      const onDown = (e) => {
        if (!this.enabled) return;
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        pointerId = e.pointerId;
        startPx = e.clientX;
        startPy = e.clientY;
        const w = el.offsetWidth;
        const h = el.offsetHeight;
        const l = el.offsetLeft;
        const t = el.offsetTop;
        if (dir.includes("e")) {
          anchorX = l;
          pointerStartX = l + w;
          movesX = true;
        } else if (dir.includes("w")) {
          anchorX = l + w;
          pointerStartX = l;
          movesX = true;
        } else {
          movesX = false;
        }
        if (dir.includes("s")) {
          anchorY = t;
          pointerStartY = t + h;
          movesY = true;
        } else if (dir.includes("n")) {
          anchorY = t + h;
          pointerStartY = t;
          movesY = true;
        } else {
          movesY = false;
        }
        try {
          handle.setPointerCapture(pointerId);
        } catch {
        }
        handle.addEventListener("pointermove", onMove);
        handle.addEventListener("pointerup", onUp);
        handle.addEventListener("pointercancel", onUp);
      };
      const onMove = (ev) => {
        if (ev.pointerId !== pointerId) return;
        const dx = ev.clientX - startPx;
        const dy = ev.clientY - startPy;
        let w = el.offsetWidth;
        let h = el.offsetHeight;
        let nl = el.offsetLeft;
        let nt = el.offsetTop;
        if (movesX) {
          let pointerX = pointerStartX + dx;
          if (allowCross) {
            const signed = pointerX - anchorX;
            if (Math.abs(signed) > maxW) {
              pointerX = anchorX + (signed < 0 ? -maxW : maxW);
            }
          } else {
            const startSigned = pointerStartX - anchorX;
            const origSign = startSigned > 0 ? 1 : -1;
            const signed = pointerX - anchorX;
            if (origSign * signed < minW) {
              pointerX = anchorX + origSign * minW;
            } else if (Math.abs(signed) > maxW) {
              pointerX = anchorX + origSign * maxW;
            }
          }
          w = Math.round(Math.abs(pointerX - anchorX));
          nl = Math.round(Math.min(anchorX, pointerX));
        }
        if (movesY) {
          let pointerY = pointerStartY + dy;
          if (allowCross) {
            const signed = pointerY - anchorY;
            if (Math.abs(signed) > maxH) {
              pointerY = anchorY + (signed < 0 ? -maxH : maxH);
            }
          } else {
            const startSigned = pointerStartY - anchorY;
            const origSign = startSigned > 0 ? 1 : -1;
            const signed = pointerY - anchorY;
            if (origSign * signed < minH) {
              pointerY = anchorY + origSign * minH;
            } else if (Math.abs(signed) > maxH) {
              pointerY = anchorY + origSign * maxH;
            }
          }
          h = Math.round(Math.abs(pointerY - anchorY));
          nt = Math.round(Math.min(anchorY, pointerY));
        }
        el.style.width = `${w}px`;
        el.style.height = `${h}px`;
        el.style.left = `${nl}px`;
        el.style.top = `${nt}px`;
        this.#callbacks.forEach((cb) => cb(el, w, h));
      };
      const onUp = (ev) => {
        if (ev.pointerId !== pointerId) return;
        try {
          handle.releasePointerCapture(pointerId);
        } catch {
        }
        handle.removeEventListener("pointermove", onMove);
        handle.removeEventListener("pointerup", onUp);
        handle.removeEventListener("pointercancel", onUp);
        pointerId = -1;
      };
      handle.addEventListener("pointerdown", onDown);
      this.cleanups.push(() => {
        handle.removeEventListener("pointerdown", onDown);
        handle.remove();
      });
    }
  }
};

// components/modifiers/2D/Rotator.ts
var Rotator = class extends Modifier2D {
  #opts;
  #angles = /* @__PURE__ */ new Map();
  #callbacks = [];
  constructor(input, opts = {}) {
    super(input);
    this.#opts = { handleOffset: 24, handleColor: "#e40c88", handleSize: 10, snap: 0, ...opts };
  }
  _applyTo(el) {
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    this.#angles.set(el, 0);
    const { handleSize: hs, handleColor: hc, handleOffset: ho } = this.#opts;
    const line = document.createElement("div");
    line.style.cssText = `position:absolute;top:-${ho}px;left:50%;width:1px;height:${ho}px;background:${hc};transform-origin:bottom;pointer-events:none;`;
    el.appendChild(line);
    const h = document.createElement("div");
    h.style.cssText = `position:absolute;top:-${ho + hs}px;left:50%;transform:translateX(-50%);width:${hs}px;height:${hs}px;background:${hc};border-radius:50%;cursor:grab;z-index:9999;`;
    el.appendChild(h);
    const onDown = (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
      const startAngle = this.#angles.get(el) ?? 0;
      const startMouse = Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI;
      const onMove = (ev) => {
        let angle = startAngle + (Math.atan2(ev.clientY - cy, ev.clientX - cx) * 180 / Math.PI - startMouse);
        if (this.#opts.snap > 0) angle = Math.round(angle / this.#opts.snap) * this.#opts.snap;
        this.#angles.set(el, angle);
        el.style.transform = `rotate(${angle}deg)`;
        this.#callbacks.forEach((cb) => cb(el, angle));
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
      };
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    };
    h.addEventListener("mousedown", onDown);
    this.cleanups.push(() => {
      h.removeEventListener("mousedown", onDown);
      h.remove();
      line.remove();
    });
  }
  getAngle(el) {
    return this.#angles.get(el) ?? 0;
  }
  setAngle(el, angle) {
    this.#angles.set(el, angle);
    el.style.transform = `rotate(${angle}deg)`;
    return this;
  }
  onRotate(cb) {
    this.#callbacks.push(cb);
    return this;
  }
};

// components/modifiers/2D/Skewer.ts
var Skewer = class extends Modifier2D {
  #opts;
  #skews = /* @__PURE__ */ new Map();
  #callbacks = [];
  constructor(input, opts = {}) {
    super(input);
    this.#opts = { axis: "both", maxAngle: 45, handleColor: "#e40c88", ...opts };
  }
  _applyTo(el) {
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    this.#skews.set(el, [0, 0]);
    const h = document.createElement("div");
    h.style.cssText = `position:absolute;bottom:-10px;right:-10px;width:10px;height:10px;background:${this.#opts.handleColor};border-radius:50%;cursor:crosshair;z-index:9999;`;
    el.appendChild(h);
    let startX = 0, startY = 0;
    const onDown = (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      startX = e.clientX;
      startY = e.clientY;
      const [sx0, sy0] = this.#skews.get(el) ?? [0, 0];
      const max = this.#opts.maxAngle;
      const onMove = (ev) => {
        const dx = (ev.clientX - startX) / 4, dy = (ev.clientY - startY) / 4;
        const skewX = this.#opts.axis !== "y" ? Math.max(-max, Math.min(max, sx0 + dx)) : sx0;
        const skewY = this.#opts.axis !== "x" ? Math.max(-max, Math.min(max, sy0 + dy)) : sy0;
        this.#skews.set(el, [skewX, skewY]);
        el.style.transform = `skew(${skewX}deg,${skewY}deg)`;
        this.#callbacks.forEach((cb) => cb(el, skewX, skewY));
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
      };
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    };
    h.addEventListener("mousedown", onDown);
    this.cleanups.push(() => {
      h.removeEventListener("mousedown", onDown);
      h.remove();
    });
  }
  onSkew(cb) {
    this.#callbacks.push(cb);
    return this;
  }
  reset(el) {
    this.#skews.set(el, [0, 0]);
    el.style.transform = "";
    return this;
  }
};

// components/modifiers/2D/Rounder.ts
function _cornerHandleStyle(c) {
  const off = "6px";
  switch (c) {
    case "topLeft":
      return `top:${off};left:${off};cursor:nwse-resize;`;
    case "topRight":
      return `top:${off};right:${off};cursor:nesw-resize;`;
    case "bottomLeft":
      return `bottom:${off};left:${off};cursor:nesw-resize;`;
    case "bottomRight":
      return `bottom:${off};right:${off};cursor:nwse-resize;`;
  }
}
function _renderRadii(el, s) {
  el.style.borderRadius = `${s.topLeft}px ${s.topRight}px ${s.bottomRight}px ${s.bottomLeft}px`;
}
var Rounder = class extends Modifier2D {
  #optsR;
  #optsMax;
  #optsHandleColor;
  #optsCorners;
  #optsInitial;
  #perCorner;
  #states = /* @__PURE__ */ new Map();
  #callbacks = [];
  constructor(input, opts = {}) {
    super(input);
    const r0 = opts.r ?? opts.radius ?? 0;
    this.#perCorner = opts.topLeft !== void 0 || opts.topRight !== void 0 || opts.bottomLeft !== void 0 || opts.bottomRight !== void 0;
    this.#optsR = r0;
    this.#optsMax = opts.max ?? 100;
    this.#optsHandleColor = opts.handleColor ?? "#e40c88";
    this.#optsCorners = opts.corners ?? ["topLeft", "topRight", "bottomLeft", "bottomRight"];
    this.#optsInitial = {
      topLeft: opts.topLeft,
      topRight: opts.topRight,
      bottomLeft: opts.bottomLeft,
      bottomRight: opts.bottomRight
    };
    for (const el of this.elements) this._wire(el);
  }
  // ── Public API ────────────────────────────────────────────────────────
  onRound(cb) {
    this.#callbacks.push(cb);
    return this;
  }
  /** Set a uniform radius on all corners of the given element. */
  setRadius(el, r) {
    const s = this.#states.get(el);
    if (!s) return this;
    const v = Math.max(0, Math.min(this.#optsMax, r));
    s.topLeft = s.topRight = s.bottomLeft = s.bottomRight = v;
    _renderRadii(el, s);
    this.#callbacks.forEach((cb) => cb(el, v, "all"));
    return this;
  }
  /** Set the radius of a specific corner of the given element. */
  setCorner(el, corner, r) {
    const s = this.#states.get(el);
    if (!s) return this;
    const v = Math.max(0, Math.min(this.#optsMax, r));
    s[corner] = v;
    _renderRadii(el, s);
    this.#callbacks.forEach((cb) => cb(el, v, corner));
    return this;
  }
  /** Read current corner state of an element. */
  getCorners(el) {
    const s = this.#states.get(el);
    if (!s) return null;
    return { ...s };
  }
  // ── Modifier2D template ───────────────────────────────────────────────
  _applyTo(_el) {
  }
  // ── Internal wiring ───────────────────────────────────────────────────
  _wire(el) {
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    const init = {
      topLeft: this.#optsInitial.topLeft ?? this.#optsR,
      topRight: this.#optsInitial.topRight ?? this.#optsR,
      bottomLeft: this.#optsInitial.bottomLeft ?? this.#optsR,
      bottomRight: this.#optsInitial.bottomRight ?? this.#optsR
    };
    this.#states.set(el, init);
    _renderRadii(el, init);
    if (this.#perCorner) {
      for (const c of this.#optsCorners) this._addCornerHandle(el, c);
    } else {
      this._addUniformHandle(el);
    }
  }
  _addUniformHandle(el) {
    const h = document.createElement("div");
    h.style.cssText = `position:absolute;top:6px;left:6px;width:10px;height:10px;background:${this.#optsHandleColor};border-radius:50%;cursor:ew-resize;z-index:9999;touch-action:none;`;
    h.title = "Drag to round all corners";
    el.appendChild(h);
    let pointerId = -1;
    let startX = 0;
    let startR = 0;
    const onDown = (e) => {
      if (!this.enabled) return;
      if (e.button !== 0) return;
      e.preventDefault();
      pointerId = e.pointerId;
      startX = e.clientX;
      const s = this.#states.get(el);
      startR = s.topLeft;
      try {
        h.setPointerCapture(pointerId);
      } catch {
      }
      h.addEventListener("pointermove", onMove);
      h.addEventListener("pointerup", onUp);
      h.addEventListener("pointercancel", onUp);
    };
    const onMove = (ev) => {
      if (ev.pointerId !== pointerId) return;
      const newR = Math.max(0, Math.min(this.#optsMax, startR + (ev.clientX - startX) / 2));
      const s = this.#states.get(el);
      s.topLeft = s.topRight = s.bottomLeft = s.bottomRight = newR;
      _renderRadii(el, s);
      this.#callbacks.forEach((cb) => cb(el, newR, "all"));
    };
    const onUp = (ev) => {
      if (ev.pointerId !== pointerId) return;
      try {
        h.releasePointerCapture(pointerId);
      } catch {
      }
      h.removeEventListener("pointermove", onMove);
      h.removeEventListener("pointerup", onUp);
      h.removeEventListener("pointercancel", onUp);
      pointerId = -1;
    };
    h.addEventListener("pointerdown", onDown);
    this.cleanups.push(() => {
      h.removeEventListener("pointerdown", onDown);
      h.remove();
    });
  }
  _addCornerHandle(el, corner) {
    const h = document.createElement("div");
    h.dataset["rounderCorner"] = corner;
    h.style.cssText = `position:absolute;width:10px;height:10px;background:${this.#optsHandleColor};border-radius:50%;z-index:9999;touch-action:none;` + _cornerHandleStyle(corner);
    h.title = `Drag vertically to round ${corner}`;
    el.appendChild(h);
    let pointerId = -1;
    let startY = 0;
    let startR = 0;
    const onDown = (e) => {
      if (!this.enabled) return;
      if (e.button !== 0) return;
      e.preventDefault();
      pointerId = e.pointerId;
      startY = e.clientY;
      const s = this.#states.get(el);
      startR = s[corner];
      try {
        h.setPointerCapture(pointerId);
      } catch {
      }
      h.addEventListener("pointermove", onMove);
      h.addEventListener("pointerup", onUp);
      h.addEventListener("pointercancel", onUp);
    };
    const onMove = (ev) => {
      if (ev.pointerId !== pointerId) return;
      const newR = Math.max(0, Math.min(this.#optsMax, startR + (ev.clientY - startY) / 2));
      const s = this.#states.get(el);
      s[corner] = newR;
      _renderRadii(el, s);
      this.#callbacks.forEach((cb) => cb(el, newR, corner));
    };
    const onUp = (ev) => {
      if (ev.pointerId !== pointerId) return;
      try {
        h.releasePointerCapture(pointerId);
      } catch {
      }
      h.removeEventListener("pointermove", onMove);
      h.removeEventListener("pointerup", onUp);
      h.removeEventListener("pointercancel", onUp);
      pointerId = -1;
    };
    h.addEventListener("pointerdown", onDown);
    this.cleanups.push(() => {
      h.removeEventListener("pointerdown", onDown);
      h.remove();
    });
  }
};

// components/modifiers/2D/Reflector.ts
var Reflector = class extends Modifier2D {
  #opts;
  #state = /* @__PURE__ */ new Map();
  constructor(input, opts = {}) {
    super(input);
    this.#opts = { axis: "x", handleColor: "#e40c88", animate: true, ...opts };
  }
  _applyTo(el) {
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    this.#state.set(el, { x: false, y: false });
    if (this.#opts.animate) el.style.transition = "transform 0.2s ease";
    if (this.#opts.axis === "x" || this.#opts.axis === "both") {
      const hx = this.#makeBtn(el, "H", "right:-28px;top:50%;transform:translateY(-50%);");
      hx.addEventListener("click", () => {
        const s = this.#state.get(el);
        s.x = !s.x;
        this.#applyTransform(el);
      });
      this.cleanups.push(() => hx.remove());
    }
    if (this.#opts.axis === "y" || this.#opts.axis === "both") {
      const hy = this.#makeBtn(el, "V", "top:-28px;left:50%;transform:translateX(-50%);");
      hy.addEventListener("click", () => {
        const s = this.#state.get(el);
        s.y = !s.y;
        this.#applyTransform(el);
      });
      this.cleanups.push(() => hy.remove());
    }
  }
  #makeBtn(el, label, pos) {
    const h = document.createElement("button");
    h.textContent = label;
    h.style.cssText = `position:absolute;${pos}background:${this.#opts.handleColor};color:#fff;border:none;border-radius:4px;width:22px;height:22px;cursor:pointer;font-size:10px;font-weight:700;z-index:9999;`;
    el.appendChild(h);
    return h;
  }
  #applyTransform(el) {
    const s = this.#state.get(el) ?? { x: false, y: false };
    el.style.transform = `scale(${s.x ? -1 : 1},${s.y ? -1 : 1})`;
  }
  flipX(el) {
    const s = this.#state.get(el);
    if (s) {
      s.x = !s.x;
      this.#applyTransform(el);
    }
    return this;
  }
  flipY(el) {
    const s = this.#state.get(el);
    if (s) {
      s.y = !s.y;
      this.#applyTransform(el);
    }
    return this;
  }
  reset(el) {
    this.#state.set(el, { x: false, y: false });
    el.style.transform = "";
    return this;
  }
};

// components/modifiers/2D/Mover.ts
function _parseTransform(el) {
  const t = getComputedStyle(el).transform;
  if (!t || t === "none") return { x: 0, y: 0 };
  const m = t.match(/matrix.*\(([^)]+)\)/);
  if (!m) return { x: 0, y: 0 };
  const parts = m[1].split(",").map((s) => parseFloat(s.trim()));
  if (parts.length === 6) return { x: parts[4] || 0, y: parts[5] || 0 };
  if (parts.length === 16) return { x: parts[12] || 0, y: parts[13] || 0 };
  return { x: 0, y: 0 };
}
function _applyTransform(el, x, y) {
  el.style.transform = `translate3d(${x}px, ${y}px, 0)`;
}
function _resolveBounds(target, bounds) {
  if (bounds === null || bounds === void 0) return null;
  const tr = target.getBoundingClientRect();
  if (bounds === "parent") {
    const parent = target.parentElement;
    if (!parent) return null;
    const r = parent.getBoundingClientRect();
    return {
      left: r.left - tr.left,
      top: r.top - tr.top,
      right: r.right - tr.right,
      bottom: r.bottom - tr.bottom
    };
  }
  if (bounds === "viewport") {
    return {
      left: -tr.left,
      top: -tr.top,
      right: window.innerWidth - tr.right,
      bottom: window.innerHeight - tr.bottom
    };
  }
  if (bounds instanceof HTMLElement) {
    const r = bounds.getBoundingClientRect();
    return {
      left: r.left - tr.left,
      top: r.top - tr.top,
      right: r.right - tr.right,
      bottom: r.bottom - tr.bottom
    };
  }
  if (typeof DOMRect !== "undefined" && bounds instanceof DOMRect) {
    return {
      left: bounds.left - tr.left,
      top: bounds.top - tr.top,
      right: bounds.right - tr.right,
      bottom: bounds.bottom - tr.bottom
    };
  }
  const b = bounds;
  return {
    left: b.left ?? -Infinity,
    top: b.top ?? -Infinity,
    right: b.right ?? Infinity,
    bottom: b.bottom ?? Infinity
  };
}
function _clampToBounds(x, y, originX, originY, bounds) {
  if (!bounds) return { x, y };
  let cx = x, cy = y;
  const dx = x - originX;
  const dy = y - originY;
  if (bounds.left !== void 0 && bounds.left !== -Infinity && dx < bounds.left) cx = originX + bounds.left;
  if (bounds.right !== void 0 && bounds.right !== Infinity && dx > bounds.right) cx = originX + bounds.right;
  if (bounds.top !== void 0 && bounds.top !== -Infinity && dy < bounds.top) cy = originY + bounds.top;
  if (bounds.bottom !== void 0 && bounds.bottom !== Infinity && dy > bounds.bottom) cy = originY + bounds.bottom;
  return { x: cx, y: cy };
}
function _applySnap(x, y, snapX, snapY, points) {
  if (points && points.points && points.points.length) {
    const threshold = points.threshold ?? 8;
    let best = null;
    let bestD = Infinity;
    for (const p of points.points) {
      const d = Math.hypot(p.x - x, p.y - y);
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    if (best && bestD <= threshold) {
      return { x: best.x, y: best.y, snapped: true };
    }
  }
  let snapped = false;
  if (snapX != null && snapX > 0) {
    x = Math.round(x / snapX) * snapX;
    snapped = true;
  }
  if (snapY != null && snapY > 0) {
    y = Math.round(y / snapY) * snapY;
    snapped = true;
  }
  return { x, y, snapped };
}
var Mover = class extends Modifier2D {
  axis;
  handle;
  bounds;
  snapX;
  snapY;
  snapPoints;
  dragCursor;
  threshold;
  activeZIndex;
  disableSelect;
  // Physics-ready properties (placeholders for the upcoming engine)
  mass;
  damping;
  stiffness;
  #startCallbacks = [];
  #moveCallbacks = [];
  #endCallbacks = [];
  #snapCallbacks = [];
  #states = /* @__PURE__ */ new WeakMap();
  constructor(input, opts = {}) {
    super(input);
    this.axis = opts.axis ?? "both";
    this.handle = opts.handle ?? null;
    this.bounds = opts.bounds ?? "parent";
    this.snapX = opts.snapX ?? null;
    this.snapY = opts.snapY ?? null;
    this.snapPoints = opts.snapPoints ?? null;
    this.dragCursor = opts.dragCursor ?? "grabbing";
    this.threshold = opts.threshold ?? 3;
    this.activeZIndex = opts.activeZIndex ?? 9999;
    this.disableSelect = opts.disableSelect ?? true;
    this.mass = opts.mass ?? 1;
    this.damping = opts.damping ?? 0.92;
    this.stiffness = opts.stiffness ?? 0.15;
    for (const el of this.elements) this._wire(el);
  }
  // ── Public API ────────────────────────────────────────────────────────
  onStart(cb) {
    this.#startCallbacks.push(cb);
    return this;
  }
  onMove(cb) {
    this.#moveCallbacks.push(cb);
    return this;
  }
  onEnd(cb) {
    this.#endCallbacks.push(cb);
    return this;
  }
  onSnap(cb) {
    this.#snapCallbacks.push(cb);
    return this;
  }
  /** Programmatically set the position (no animation). */
  setPosition(x, y) {
    for (const el of this.elements) _applyTransform(el, x, y);
    return this;
  }
  /**
   * Hook for the upcoming physics engine. Currently a no-op so the API
   * is stable from v1.1.0; when the engine arrives, this method will
   * integrate velocity, apply spring-back to last snap point, etc.
   */
  _physicsTick(_dt) {
  }
  // ── Modifier2D template ───────────────────────────────────────────────
  _applyTo(_el) {
  }
  // ── Internal wiring ───────────────────────────────────────────────────
  _wire(target) {
    const handleEl = this.handle ? target.querySelector(this.handle) ?? target : target;
    if (!handleEl.style.touchAction) handleEl.style.touchAction = "none";
    if (!handleEl.style.cursor) handleEl.style.cursor = "grab";
    const onDown = (e) => this._onDown(target, handleEl, e);
    handleEl.addEventListener("pointerdown", onDown);
    this.cleanups.push(() => {
      handleEl.removeEventListener("pointerdown", onDown);
      const s = this.#states.get(target);
      if (s) {
        handleEl.removeEventListener("pointermove", s.onMove);
        handleEl.removeEventListener("pointerup", s.onUp);
        handleEl.removeEventListener("pointercancel", s.onUp);
        this.#states.delete(target);
      }
    });
  }
  _onDown(target, handleEl, ev) {
    if (!this.enabled) return;
    if (ev.button !== 0) return;
    const origin = _parseTransform(target);
    const onMove = (e) => this._onMove(target, e);
    const onUp = (e) => this._onUp(target, handleEl, e);
    this.#states.set(target, {
      pointerId: ev.pointerId,
      startX: ev.clientX,
      startY: ev.clientY,
      originX: origin.x,
      originY: origin.y,
      currentX: origin.x,
      currentY: origin.y,
      velocityX: 0,
      velocityY: 0,
      lastTime: performance.now(),
      started: false,
      prevZIndex: target.style.zIndex,
      prevSelect: document.body.style.userSelect,
      handleEl,
      onMove,
      onUp
    });
    try {
      handleEl.setPointerCapture(ev.pointerId);
    } catch {
    }
    handleEl.addEventListener("pointermove", onMove);
    handleEl.addEventListener("pointerup", onUp);
    handleEl.addEventListener("pointercancel", onUp);
  }
  _onMove(target, ev) {
    const s = this.#states.get(target);
    if (!s || s.pointerId !== ev.pointerId) return;
    const dx = ev.clientX - s.startX;
    const dy = ev.clientY - s.startY;
    if (!s.started) {
      if (Math.hypot(dx, dy) < this.threshold) return;
      s.started = true;
      if (this.activeZIndex !== null) target.style.zIndex = String(this.activeZIndex);
      if (this.disableSelect) document.body.style.userSelect = "none";
      target.style.cursor = this.dragCursor;
      this.#startCallbacks.forEach((cb) => cb(target, s.originX, s.originY, ev));
    }
    let nx = s.originX + dx;
    let ny = s.originY + dy;
    if (this.axis === "x") ny = s.originY;
    if (this.axis === "y") nx = s.originX;
    const bounds = _resolveBounds(target, this.bounds);
    ({ x: nx, y: ny } = _clampToBounds(nx, ny, s.originX, s.originY, bounds));
    const snap = _applySnap(nx, ny, this.snapX, this.snapY, this.snapPoints);
    if (snap.snapped) this.#snapCallbacks.forEach((cb) => cb(target, snap.x, snap.y));
    nx = snap.x;
    ny = snap.y;
    const now = performance.now();
    const dt = Math.max(now - s.lastTime, 1);
    s.velocityX = (nx - s.currentX) / dt * 1e3;
    s.velocityY = (ny - s.currentY) / dt * 1e3;
    s.lastTime = now;
    s.currentX = nx;
    s.currentY = ny;
    _applyTransform(target, nx, ny);
    this.#moveCallbacks.forEach((cb) => cb(target, nx, ny, ev));
  }
  _onUp(target, handleEl, ev) {
    const s = this.#states.get(target);
    if (!s || s.pointerId !== ev.pointerId) return;
    handleEl.removeEventListener("pointermove", s.onMove);
    handleEl.removeEventListener("pointerup", s.onUp);
    handleEl.removeEventListener("pointercancel", s.onUp);
    try {
      handleEl.releasePointerCapture(ev.pointerId);
    } catch {
    }
    if (s.started) {
      target.style.zIndex = s.prevZIndex;
      if (this.disableSelect) document.body.style.userSelect = s.prevSelect;
      target.style.cursor = "";
      this.#endCallbacks.forEach((cb) => cb(target, s.currentX, s.currentY, ev));
    }
    this.#states.delete(target);
  }
};

// components/modifiers/2D/index.ts
var Modifiers2D = { Resizer, Rotator, Skewer, Rounder, Reflector, Mover };
var D_default = Modifiers2D;

// components/modifiers/3D/Base.ts
function _v3(x, y, z) {
  return { x, y, z };
}
function _vAdd(a, b) {
  return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z };
}
function _vSub(a, b) {
  return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}
function _vScale(v, s) {
  return { x: v.x * s, y: v.y * s, z: v.z * s };
}
function _vLen(v) {
  return Math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2);
}
function _vNorm(v) {
  const l = _vLen(v) || 1;
  return _vScale(v, 1 / l);
}
function _vCross(a, b) {
  return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x };
}
function _vLerp(a, b, t) {
  return _vAdd(a, _vScale(_vSub(b, a), t));
}
function _cloneGeom(g) {
  return {
    vertices: g.vertices.map((v) => ({ ...v })),
    normals: g.normals.map((v) => ({ ...v })),
    indices: [...g.indices],
    uvs: g.uvs ? g.uvs.map((uv) => [...uv]) : void 0,
    clone() {
      return _cloneGeom(this);
    }
  };
}
function _recomputeNormals(g) {
  const normals = Array.from({ length: g.vertices.length }, () => _v3(0, 0, 0));
  for (let i = 0; i < g.indices.length; i += 3) {
    const [ia, ib, ic] = g.indices.slice(i, i + 3);
    const n = _vNorm(_vCross(_vSub(g.vertices[ib], g.vertices[ia]), _vSub(g.vertices[ic], g.vertices[ia])));
    [ia, ib, ic].forEach((idx) => {
      normals[idx] = _vAdd(normals[idx], n);
    });
  }
  g.normals = normals.map(_vNorm);
}
var Modifier3D = class {
  mesh;
  enabled = true;
  cleanups = [];
  constructor(mesh) {
    this.mesh = mesh;
  }
  enable() {
    this.enabled = true;
    return this;
  }
  disable() {
    this.enabled = false;
    return this;
  }
  destroy() {
    this.cleanups.forEach((fn) => fn());
    this.cleanups = [];
  }
};

// components/modifiers/3D/SubdivisionModifier.ts
var SubdivisionModifier = class extends Modifier3D {
  #iterations;
  constructor(mesh, iterations = 1) {
    super(mesh);
    this.#iterations = iterations;
  }
  apply() {
    if (!this.enabled) return this;
    let g = _cloneGeom(this.mesh.geometry);
    for (let i = 0; i < this.#iterations; i++) g = this.#subdivide(g);
    this.mesh.geometry = g;
    return this;
  }
  #subdivide(g) {
    const out = {
      vertices: [...g.vertices.map((v) => ({ ...v }))],
      normals: [],
      indices: [],
      clone() {
        return _cloneGeom(this);
      }
    };
    const midCache = /* @__PURE__ */ new Map();
    const midpoint = (ia, ib) => {
      const key = `${Math.min(ia, ib)}_${Math.max(ia, ib)}`;
      if (midCache.has(key)) return midCache.get(key);
      const m = {
        x: (g.vertices[ia].x + g.vertices[ib].x) / 2,
        y: (g.vertices[ia].y + g.vertices[ib].y) / 2,
        z: (g.vertices[ia].z + g.vertices[ib].z) / 2
      };
      const idx = out.vertices.length;
      out.vertices.push(m);
      midCache.set(key, idx);
      return idx;
    };
    for (let i = 0; i < g.indices.length; i += 3) {
      const [a, b, c] = g.indices.slice(i, i + 3);
      const ab = midpoint(a, b), bc = midpoint(b, c), ca = midpoint(c, a);
      out.indices.push(a, ab, ca, ab, b, bc, ca, bc, c, ab, bc, ca);
    }
    _recomputeNormals(out);
    return out;
  }
};

// components/modifiers/3D/DecimateModifier.ts
var DecimateModifier = class extends Modifier3D {
  #ratio;
  constructor(mesh, ratio = 0.5) {
    super(mesh);
    this.#ratio = Math.max(0.01, Math.min(1, ratio));
  }
  apply() {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    const step = Math.max(1, Math.floor(g.indices.length / 3 / Math.max(1, Math.floor(g.indices.length / 3 * this.#ratio))));
    const newIdx = [];
    for (let i = 0; i < g.indices.length; i += 3 * step) newIdx.push(...g.indices.slice(i, i + 3));
    g.indices = newIdx;
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/BevelModifier.ts
var BevelModifier = class extends Modifier3D {
  #amount;
  #segments;
  constructor(mesh, amount = 0.05, segments = 2) {
    super(mesh);
    this.#amount = amount;
    this.#segments = segments;
  }
  apply() {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    const bevelVerts = [];
    for (let i = 0; i < g.indices.length; i += 3) {
      const [ia, ib, ic] = g.indices.slice(i, i + 3);
      const a = g.vertices[ia], b = g.vertices[ib], c = g.vertices[ic];
      const n = _vNorm(_vCross(_vSub(b, a), _vSub(c, a)));
      for (let s = 1; s <= this.#segments; s++) {
        const t = s / (this.#segments + 1) * this.#amount;
        bevelVerts.push(_vAdd(a, _vScale(n, t)), _vAdd(b, _vScale(n, t)), _vAdd(c, _vScale(n, t)));
      }
    }
    g.vertices.push(...bevelVerts);
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/MirrorModifier.ts
var MirrorModifier = class extends Modifier3D {
  #axis;
  #merge;
  #threshold;
  constructor(mesh, axis = "x", merge = true, threshold = 1e-3) {
    super(mesh);
    this.#axis = axis;
    this.#merge = merge;
    this.#threshold = threshold;
  }
  apply() {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    const base = g.vertices.length;
    const mirror = (v) => ({
      x: this.#axis === "x" ? -v.x : v.x,
      y: this.#axis === "y" ? -v.y : v.y,
      z: this.#axis === "z" ? -v.z : v.z
    });
    g.vertices.push(...g.vertices.map(mirror));
    const mirrorIndices = g.indices.map((i) => base + i);
    for (let i = 0; i < mirrorIndices.length; i += 3) {
      const [a, b, c] = mirrorIndices.slice(i, i + 3);
      g.indices.push(a, c, b);
    }
    if (this.#merge) {
      const t = this.#threshold;
      const onPlane = g.vertices.reduce((acc, v, i) => {
        const onP = this.#axis === "x" && Math.abs(v.x) < t || this.#axis === "y" && Math.abs(v.y) < t || this.#axis === "z" && Math.abs(v.z) < t;
        if (onP) acc.push(i);
        return acc;
      }, []);
      for (const i of onPlane)
        for (const j of onPlane)
          if (i !== j && _vLen(_vSub(g.vertices[i], g.vertices[j])) < t * 2)
            g.indices = g.indices.map((idx) => idx === j ? i : idx);
    }
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/ArrayModifier.ts
var ArrayModifier = class extends Modifier3D {
  #opts;
  #copies = [];
  constructor(mesh, opts) {
    super(mesh);
    this.#opts = {
      type: "linear",
      offset: _v3(1, 0, 0),
      radius: 2,
      axis: "y",
      scene: { children: [], add() {
      }, remove() {
      } },
      meshFactory: () => mesh,
      ...opts
    };
  }
  apply() {
    if (!this.enabled) return this;
    this.#copies.forEach((c) => this.#opts.scene.remove(c));
    this.#copies = [];
    const { count, type, offset, radius, axis } = this.#opts;
    for (let i = 1; i < count; i++) {
      const copy = this.#opts.meshFactory();
      if (type === "linear") {
        copy.position.x = this.mesh.position.x + offset.x * i;
        copy.position.y = this.mesh.position.y + offset.y * i;
        copy.position.z = this.mesh.position.z + offset.z * i;
      } else {
        const angle = 2 * Math.PI * i / count;
        if (axis === "y") {
          copy.position.x = this.mesh.position.x + Math.cos(angle) * radius;
          copy.position.z = this.mesh.position.z + Math.sin(angle) * radius;
          copy.position.y = this.mesh.position.y;
        } else if (axis === "x") {
          copy.position.y = this.mesh.position.y + Math.cos(angle) * radius;
          copy.position.z = this.mesh.position.z + Math.sin(angle) * radius;
          copy.position.x = this.mesh.position.x;
        } else {
          copy.position.x = this.mesh.position.x + Math.cos(angle) * radius;
          copy.position.y = this.mesh.position.y + Math.sin(angle) * radius;
          copy.position.z = this.mesh.position.z;
        }
      }
      this.#opts.scene.add(copy);
      this.#copies.push(copy);
    }
    return this;
  }
  destroy() {
    this.#copies.forEach((c) => this.#opts.scene.remove(c));
    this.#copies = [];
    super.destroy();
  }
};

// components/modifiers/3D/BendModifier.ts
var BendModifier = class extends Modifier3D {
  #angle;
  #axis;
  constructor(mesh, angle, axis = "y") {
    super(mesh);
    this.#angle = angle;
    this.#axis = axis;
  }
  apply() {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    const vals = g.vertices.map((v) => this.#axis === "y" ? v.y : this.#axis === "x" ? v.x : v.z);
    const vmin = Math.min(...vals), range = Math.max(...vals) - vmin || 1;
    g.vertices = g.vertices.map((v) => {
      const t = ((this.#axis === "y" ? v.y : this.#axis === "x" ? v.x : v.z) - vmin) / range;
      const \u03B8 = t * this.#angle, c = Math.cos(\u03B8), s = Math.sin(\u03B8);
      if (this.#axis === "y") return { x: c * v.x - s * v.z, y: v.y, z: s * v.x + c * v.z };
      if (this.#axis === "x") return { x: v.x, y: c * v.y - s * v.z, z: s * v.y + c * v.z };
      return { x: c * v.x - s * v.y, y: s * v.x + c * v.y, z: v.z };
    });
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/TwistModifier.ts
var TwistModifier = class extends Modifier3D {
  #angle;
  #axis;
  constructor(mesh, angle, axis = "y") {
    super(mesh);
    this.#angle = angle;
    this.#axis = axis;
  }
  apply() {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    const vals = g.vertices.map((v) => this.#axis === "y" ? v.y : this.#axis === "x" ? v.x : v.z);
    const vmin = Math.min(...vals), range = Math.max(...vals) - vmin || 1;
    g.vertices = g.vertices.map((v) => {
      const t = ((this.#axis === "y" ? v.y : this.#axis === "x" ? v.x : v.z) - vmin) / range;
      const \u03B8 = t * this.#angle, c = Math.cos(\u03B8), s = Math.sin(\u03B8);
      if (this.#axis === "y") return { x: c * v.x - s * v.z, y: v.y, z: s * v.x + c * v.z };
      if (this.#axis === "x") return { x: v.x, y: c * v.y - s * v.z, z: s * v.y + c * v.z };
      return { x: c * v.x - s * v.y, y: s * v.x + c * v.y, z: v.z };
    });
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/WaveModifier.ts
var WaveModifier = class extends Modifier3D {
  #opts;
  constructor(mesh, opts = {}) {
    super(mesh);
    this.#opts = { amplitude: 0.2, frequency: 2, axis: "y", direction: "x", time: 0, ...opts };
  }
  apply(time) {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    const { amplitude, frequency, axis, direction } = this.#opts;
    const t = time ?? this.#opts.time;
    g.vertices = g.vertices.map((v) => {
      const disp = amplitude * Math.sin(frequency * (direction === "x" ? v.x : v.z) + t);
      const out = { ...v };
      if (axis === "y") out.y += disp;
      else if (axis === "x") out.x += disp;
      else out.z += disp;
      return out;
    });
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/InflateModifier.ts
var InflateModifier = class extends Modifier3D {
  #amount;
  constructor(mesh, amount = 0.1) {
    super(mesh);
    this.#amount = amount;
  }
  apply() {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    _recomputeNormals(g);
    g.vertices = g.vertices.map((v, i) => _vAdd(v, _vScale(g.normals[i] ?? _v3(0, 1, 0), this.#amount)));
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/SmoothModifier.ts
var SmoothModifier = class extends Modifier3D {
  #iterations;
  #factor;
  constructor(mesh, iterations = 3, factor = 0.5) {
    super(mesh);
    this.#iterations = iterations;
    this.#factor = factor;
  }
  apply() {
    if (!this.enabled) return this;
    const g = _cloneGeom(this.mesh.geometry);
    const adj = g.vertices.map(() => /* @__PURE__ */ new Set());
    for (let i = 0; i < g.indices.length; i += 3) {
      const [a, b, c] = g.indices.slice(i, i + 3);
      adj[a].add(b);
      adj[a].add(c);
      adj[b].add(a);
      adj[b].add(c);
      adj[c].add(a);
      adj[c].add(b);
    }
    for (let iter = 0; iter < this.#iterations; iter++) {
      g.vertices = g.vertices.map((v, i) => {
        const ns = Array.from(adj[i]);
        if (!ns.length) return v;
        const avg = _vScale(ns.reduce((s, ni) => _vAdd(s, g.vertices[ni]), { x: 0, y: 0, z: 0 }), 1 / ns.length);
        return _vLerp(v, avg, this.#factor);
      });
    }
    _recomputeNormals(g);
    this.mesh.geometry = g;
    return this;
  }
};

// components/modifiers/3D/DragModifier.ts
var DragModifier = class extends Modifier3D {
  #canvas;
  #plane;
  #callbacks = [];
  constructor(mesh, canvas, _camera, plane = "xz") {
    super(mesh);
    this.#canvas = canvas;
    this.#plane = plane;
    this.#setup();
  }
  apply() {
    return this;
  }
  #setup() {
    let dragging = false, startMX = 0, startMY = 0;
    let startPos = { ...this.mesh.position };
    const scale = 0.01;
    const onDown = (e) => {
      if (!this.enabled) return;
      dragging = true;
      startMX = e.clientX;
      startMY = e.clientY;
      startPos = { ...this.mesh.position };
    };
    const onMove = (e) => {
      if (!dragging || !this.enabled) return;
      const dx = (e.clientX - startMX) * scale, dy = (e.clientY - startMY) * scale;
      if (this.#plane === "xz") {
        this.mesh.position.x = startPos.x + dx;
        this.mesh.position.z = startPos.z + dy;
      } else if (this.#plane === "xy") {
        this.mesh.position.x = startPos.x + dx;
        this.mesh.position.y = startPos.y - dy;
      } else {
        this.mesh.position.y = startPos.y - dy;
        this.mesh.position.z = startPos.z + dx;
      }
      this.#callbacks.forEach((cb) => cb(this.mesh, { ...this.mesh.position }));
    };
    const onUp = () => {
      dragging = false;
    };
    this.#canvas.addEventListener("mousedown", onDown);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    this.cleanups.push(() => {
      this.#canvas.removeEventListener("mousedown", onDown);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    });
  }
  onDrag(cb) {
    this.#callbacks.push(cb);
    return this;
  }
};

// components/modifiers/3D/SnapModifier.ts
var SnapModifier = class extends Modifier3D {
  #posGrid;
  #rotGrid;
  // radians
  constructor(mesh, posGrid = 0.5, rotGridDeg = 15) {
    super(mesh);
    this.#posGrid = posGrid;
    this.#rotGrid = rotGridDeg * Math.PI / 180;
  }
  apply() {
    if (!this.enabled) return this;
    const s = this.#posGrid, r = this.#rotGrid;
    this.mesh.position.x = Math.round(this.mesh.position.x / s) * s;
    this.mesh.position.y = Math.round(this.mesh.position.y / s) * s;
    this.mesh.position.z = Math.round(this.mesh.position.z / s) * s;
    this.mesh.rotation.x = Math.round(this.mesh.rotation.x / r) * r;
    this.mesh.rotation.y = Math.round(this.mesh.rotation.y / r) * r;
    this.mesh.rotation.z = Math.round(this.mesh.rotation.z / r) * r;
    return this;
  }
};

// components/modifiers/3D/LODModifier.ts
var LODModifier = class extends Modifier3D {
  #levels;
  #current = -1;
  constructor(mesh, levels) {
    super(mesh);
    this.#levels = levels.sort((a, b) => a.distance - b.distance);
  }
  apply() {
    return this;
  }
  update(camera) {
    if (!this.enabled) return this;
    const d = _vLen(_vSub(this.mesh.position, camera.position));
    let best = this.#levels.length - 1;
    for (let i = 0; i < this.#levels.length; i++) {
      if (d <= this.#levels[i].distance) {
        best = i;
        break;
      }
    }
    if (best !== this.#current) {
      this.#current = best;
      this.mesh.geometry = this.#levels[best].geometry;
    }
    return this;
  }
};

// components/modifiers/3D/FadeModifier.ts
var FadeModifier = class extends Modifier3D {
  #near;
  #far;
  #onFade = null;
  constructor(mesh, near = 10, far = 50) {
    super(mesh);
    this.#near = near;
    this.#far = far;
  }
  apply() {
    return this;
  }
  update(camera) {
    if (!this.enabled) return this;
    const d = _vLen(_vSub(this.mesh.position, camera.position));
    const opacity = 1 - Math.max(0, Math.min(1, (d - this.#near) / (this.#far - this.#near)));
    this.mesh.visible = opacity > 0.01;
    this.#onFade?.(this.mesh, opacity);
    return this;
  }
  onFade(cb) {
    this.#onFade = cb;
    return this;
  }
};

// components/modifiers/3D/BillboardModifier.ts
var BillboardModifier = class extends Modifier3D {
  #lockX;
  #lockY;
  #lockZ;
  constructor(mesh, opts = {}) {
    super(mesh);
    this.#lockX = opts.lockX ?? false;
    this.#lockY = opts.lockY ?? false;
    this.#lockZ = opts.lockZ ?? false;
  }
  apply() {
    return this;
  }
  update(camera) {
    if (!this.enabled) return this;
    const dir = _vNorm(_vSub(camera.position, this.mesh.position));
    if (!this.#lockY) this.mesh.rotation.y = Math.atan2(dir.x, dir.z);
    if (!this.#lockX) this.mesh.rotation.x = -Math.asin(dir.y);
    return this;
  }
};

// components/modifiers/3D/index.ts
var Modifiers3D = {
  SubdivisionModifier,
  DecimateModifier,
  BevelModifier,
  MirrorModifier,
  ArrayModifier,
  BendModifier,
  TwistModifier,
  WaveModifier,
  InflateModifier,
  SmoothModifier,
  DragModifier,
  SnapModifier,
  LODModifier,
  FadeModifier,
  BillboardModifier
};
var D_default2 = Modifiers3D;

// components/navigation/Breadcrumb.ts
var Breadcrumb = class extends Control {
  _items = [];
  constructor(container = null, opts = {}) {
    super(container, "nav", opts);
    this.el.className = `ar-breadcrumb${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("aria-label", "Breadcrumb");
  }
  set items(v) {
    this._items = v;
    this._set("items", v);
  }
  _build() {
    this.el.innerHTML = "";
    const ol = this._el("ol", "ar-breadcrumb__list", this.el);
    const sep = this._get("separator", "/");
    this._items.forEach((item, i) => {
      const li = this._el("li", "ar-breadcrumb__item", ol);
      const isLast = i === this._items.length - 1;
      if (item.icon) {
        const ic = this._el("span", "ar-breadcrumb__icon", li);
        ic.textContent = item.icon;
      }
      if (isLast) {
        const s = this._el("span", "ar-breadcrumb__current", li);
        s.textContent = item.label;
        s.setAttribute("aria-current", "page");
      } else {
        const a = document.createElement("a");
        a.className = "ar-breadcrumb__link";
        a.textContent = item.label;
        if (item.href) a.href = item.href;
        a.addEventListener("click", (e) => {
          e.preventDefault();
          this._emit("click", { item }, e);
        });
        li.appendChild(a);
        const s2 = this._el("span", "ar-breadcrumb__sep", li);
        s2.textContent = sep;
        s2.setAttribute("aria-hidden", "true");
      }
    });
  }
};

// components/navigation/Header.ts
var Header = class extends Control {
  _title = "";
  _logo = "";
  _actions = "";
  constructor(container = null, opts = {}) {
    super(container, "header", opts);
    this.el.className = `ar-header${opts.sticky ? " ar-header--sticky" : ""}${opts.class ? " " + opts.class : ""}`;
  }
  set title(v) {
    this._title = v;
    this._build();
  }
  set logo(v) {
    this._logo = v;
    this._build();
  }
  set actions(v) {
    this._actions = v;
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    const inner = this._el("div", "ar-header__inner", this.el);
    if (this._logo) {
      const l = this._el("div", "ar-header__logo", inner);
      if (typeof this._logo === "string") l.innerHTML = this._logo;
      else l.appendChild(this._logo);
    }
    if (this._title) {
      const t = this._el("span", "ar-header__title", inner);
      t.textContent = this._title;
    }
    this._el("div", "ar-header__spacer", inner);
    if (this._actions) {
      const a = this._el("div", "ar-header__actions", inner);
      if (typeof this._actions === "string") a.innerHTML = this._actions;
      else a.appendChild(this._actions);
    }
  }
};

// components/navigation/Menu.ts
var Menu = class extends Control {
  _items = [];
  constructor() {
    super(null, "div");
    document.body.appendChild(this.el);
    this.el.className = "ar-menu";
    this.el.style.display = "none";
    this._on(document, "click", () => this.close());
    this._on(document, "keydown", (e) => {
      if (e.key === "Escape") this.close();
    });
  }
  set items(v) {
    this._items = v;
    this._set("items", v);
  }
  openAt(x, y) {
    this._build();
    this.el.style.display = "";
    const w = this.el.offsetWidth || 180;
    const h = this.el.offsetHeight || 200;
    this.el.style.left = (x + w > window.innerWidth ? window.innerWidth - w - 8 : x) + "px";
    this.el.style.top = (y + h > window.innerHeight ? window.innerHeight - h - 8 : y) + "px";
    this._emit("open", {});
  }
  openBelow(anchor) {
    const r = anchor.getBoundingClientRect();
    this.openAt(r.left, r.bottom + 4);
  }
  close() {
    this.el.style.display = "none";
    this._emit("close", {});
  }
  _build() {
    this.el.innerHTML = "";
    this._items.forEach((item) => {
      if (item.separator) {
        this._el("div", "ar-menu__sep", this.el);
        return;
      }
      const row = this._el("button", `ar-menu__item${item.disabled ? " ar-menu__item--disabled" : ""}${item.danger ? " ar-menu__item--danger" : ""}`, this.el);
      row.disabled = !!item.disabled;
      if (item.icon) {
        const ic = this._el("span", "ar-menu__icon", row);
        ic.textContent = item.icon;
      }
      const lbl = this._el("span", "ar-menu__label", row);
      lbl.textContent = item.label;
      if (item.shortcut) {
        const sc = this._el("span", "ar-menu__shortcut", row);
        sc.textContent = item.shortcut;
      }
      row.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!item.disabled) {
          this._emit("select", { id: item.id, item });
          this.close();
        }
      });
    });
  }
};

// components/navigation/NavRail.ts
var NavRail = class extends Control {
  _items = [];
  _active = "";
  constructor(container = null, opts = {}) {
    super(container, "nav", opts);
    this.el.className = `ar-navrail${opts.collapsed ? " ar-navrail--collapsed" : ""}${opts.class ? " " + opts.class : ""}`;
  }
  set items(v) {
    this._items = v;
    this._set("items", v);
  }
  set active(id) {
    this._active = id;
    this._build();
  }
  get active() {
    return this._active;
  }
  toggle() {
    const c = !this._get("collapsed", false);
    this._set("collapsed", c);
    this.el.classList.toggle("ar-navrail--collapsed", c);
  }
  _build() {
    this.el.innerHTML = "";
    const btn = this._el("button", "ar-navrail__toggle", this.el);
    btn.textContent = this._get("collapsed", false) ? "\u25B8" : "\u25C2";
    btn.addEventListener("click", () => this.toggle());
    this._items.forEach((item) => {
      const el = this._el("button", `ar-navrail__item${item.id === this._active ? " ar-navrail__item--active" : ""}`, this.el);
      const ic = this._el("span", "ar-navrail__icon", el);
      ic.textContent = item.icon;
      const lbl = this._el("span", "ar-navrail__label", el);
      lbl.textContent = item.label;
      if (item.badge !== void 0) {
        const b = this._el("span", "ar-navrail__badge", el);
        b.textContent = String(item.badge);
      }
      el.addEventListener("click", () => {
        this._active = item.id;
        this._build();
        this._emit("select", { id: item.id, item });
      });
    });
  }
};

// components/navigation/Pagination.ts
var Pagination = class extends Control {
  _page = 1;
  constructor(container = null, opts = {}) {
    super(container, "nav", { total: 0, pageSize: 10, page: 1, siblings: 1, ...opts });
    this._page = opts.page ?? 1;
    this.el.className = `ar-pagination${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("aria-label", "Pagination");
  }
  set total(v) {
    this._set("total", v);
  }
  set pageSize(v) {
    this._set("pageSize", v);
  }
  set page(v) {
    this._page = v;
    this._build();
  }
  get page() {
    return this._page;
  }
  get totalPages() {
    return Math.ceil(this._get("total", 0) / this._get("pageSize", 10));
  }
  _go(p) {
    const tp = this.totalPages;
    if (p < 1 || p > tp) return;
    this._page = p;
    this._build();
    this._emit("change", { page: p, totalPages: tp });
  }
  _btn(label, page, disabled, active = false) {
    const b = this._el("button", `ar-pagination__btn${active ? " ar-pagination__btn--active" : ""}`, this.el);
    b.textContent = label;
    b.disabled = disabled;
    b.addEventListener("click", () => this._go(page));
    return b;
  }
  _build() {
    this.el.innerHTML = "";
    const tp = this.totalPages;
    if (tp <= 1) return;
    const sib = this._get("siblings", 1);
    this._btn("\u2039", this._page - 1, this._page <= 1);
    const start = Math.max(1, this._page - sib);
    const end = Math.min(tp, this._page + sib);
    if (start > 1) {
      this._btn("1", 1, false);
      if (start > 2) {
        const d = this._el("span", "ar-pagination__dots", this.el);
        d.textContent = "\u2026";
      }
    }
    for (let p = start; p <= end; p++) this._btn(String(p), p, false, p === this._page);
    if (end < tp) {
      if (end < tp - 1) {
        const d = this._el("span", "ar-pagination__dots", this.el);
        d.textContent = "\u2026";
      }
      this._btn(String(tp), tp, false);
    }
    this._btn("\u203A", this._page + 1, this._page >= tp);
  }
};

// core/Observable.ts
function uuid() {
  const b = [];
  for (let i = 0; i < 9; i++)
    b.push(Math.floor(1 + Math.random() * 65536).toString(16).slice(1));
  return `${b[1]}${b[2]}-${b[3]}-${b[4]}-${b[5]}-${b[6]}${b[7]}${b[8]}`;
}
var _activeEffect = null;
var _batchDepth = 0;
var _pendingEffects = [];
function _notify(subs) {
  if (_batchDepth > 0) {
    subs.forEach((e) => {
      if (!_pendingEffects.includes(e)) _pendingEffects.push(e);
    });
    return;
  }
  [...subs].forEach((e) => e.run());
}
function signal(value) {
  const subs = /* @__PURE__ */ new Set();
  return {
    get() {
      if (_activeEffect) subs.add(_activeEffect);
      return value;
    },
    set(v) {
      if (Object.is(v, value)) return;
      value = v;
      _notify(subs);
    },
    peek() {
      return value;
    },
    readonly() {
      return { get: () => {
        if (_activeEffect) subs.add(_activeEffect);
        return value;
      }, peek: () => value };
    }
  };
}
function signalMono(value) {
  const s = {
    _sub: null,
    get() {
      return value;
    },
    set(v) {
      if (!Object.is(v, value)) {
        value = v;
        s._sub?.();
      }
    },
    peek() {
      return value;
    }
  };
  return s;
}
function sinkText(s, node) {
  node.nodeValue = s.peek();
  s._sub = () => {
    node.nodeValue = s.peek();
  };
}
function sinkClass(el, cls, getter) {
  const update = () => {
    if (getter()) el.classList.add(cls);
    else el.classList.remove(cls);
  };
  update();
  return update;
}
function effect(fn) {
  const runner = {
    deps: /* @__PURE__ */ new Set(),
    run() {
      runner.deps.forEach((d) => d.delete(runner));
      runner.deps.clear();
      const prev = _activeEffect;
      _activeEffect = runner;
      try {
        fn();
      } finally {
        _activeEffect = prev;
      }
    }
  };
  runner.run();
  return () => {
    runner.deps.forEach((d) => d.delete(runner));
    runner.deps.clear();
  };
}
function computed(fn) {
  const s = signal(void 0);
  effect(() => s.set(fn()));
  return s.readonly();
}
function batch(fn) {
  _batchDepth++;
  try {
    fn();
  } finally {
    if (--_batchDepth === 0) {
      const p = _pendingEffects.splice(0);
      p.forEach((e) => e.run());
    }
  }
}
function untrack(fn) {
  const prev = _activeEffect;
  _activeEffect = null;
  try {
    return fn();
  } finally {
    _activeEffect = prev;
  }
}
var AriannATemplate = class {
  #tpl;
  constructor(html) {
    this.#tpl = document.createElement("template");
    this.#tpl.innerHTML = html;
  }
  /**
   * Clona il primo elemento del template — O(1) in C++.
   * Zero HTML parsing. Zero allocazione JS oltre il nodo clonato.
   */
  clone() {
    return this.#tpl.content.firstElementChild.cloneNode(true);
  }
  /**
   * Clona l'intero content come DocumentFragment.
   * Per template con più elementi root.
   */
  cloneAll() {
    return this.#tpl.content.cloneNode(true);
  }
  /**
   * Accesso O(1) a un nodo interno tramite path di indici childNodes.
   * Evita querySelector — accesso diretto via childNodes[i] chain.
   *
   * @example
   *   const tr    = tpl.clone();
   *   const idTxt = tpl.walk(tr, [0, 0]) as Text;
   *   // tr.childNodes[0].childNodes[0]
   */
  walk(root, path) {
    let n = root;
    for (const i of path) n = n.childNodes[i];
    return n;
  }
  /**
   * Accesso O(1) a più nodi interni in una singola chiamata.
   * Restituisce array di nodi nell'ordine dei path forniti.
   *
   * @example
   *   const [idTxt, labelTxt] = tpl.walkAll(tr, [0,0], [1,0,0]);
   */
  walkAll(root, ...paths) {
    return paths.map((p) => this.walk(root, p));
  }
  /** Il DocumentFragment interno — read-only. */
  get content() {
    return this.#tpl.content;
  }
};
function _safeEventCtor(name, resolver) {
  try {
    const ctor = resolver();
    if (ctor) return ctor;
  } catch {
  }
  return { [name]: class extends Event {
  } }[name];
}
var _TouchEvent = _safeEventCtor("TouchEvent", () => typeof TouchEvent !== "undefined" ? TouchEvent : void 0);
var DOM_TYPES = Object.freeze(
  {
    click: { Name: "click", Interface: MouseEvent },
    dblclick: { Name: "dblclick", Interface: MouseEvent },
    mouseenter: { Name: "mouseenter", Interface: MouseEvent },
    mouseleave: { Name: "mouseleave", Interface: MouseEvent },
    mousemove: { Name: "mousemove", Interface: MouseEvent },
    mouseout: { Name: "mouseout", Interface: MouseEvent },
    mouseover: { Name: "mouseover", Interface: MouseEvent },
    mouseup: { Name: "mouseup", Interface: MouseEvent },
    mousedown: { Name: "mousedown", Interface: MouseEvent },
    contextmenu: { Name: "contextmenu", Interface: MouseEvent },
    drag: { Name: "drag", Interface: DragEvent },
    dragend: { Name: "dragend", Interface: DragEvent },
    dragenter: { Name: "dragenter", Interface: DragEvent },
    dragleave: { Name: "dragleave", Interface: DragEvent },
    dragover: { Name: "dragover", Interface: DragEvent },
    dragstart: { Name: "dragstart", Interface: DragEvent },
    drop: { Name: "drop", Interface: DragEvent },
    wheel: { Name: "wheel", Interface: WheelEvent },
    keypress: { Name: "keypress", Interface: KeyboardEvent },
    keydown: { Name: "keydown", Interface: KeyboardEvent },
    keyup: { Name: "keyup", Interface: KeyboardEvent },
    animationstart: { Name: "animationstart", Interface: AnimationEvent },
    animationend: { Name: "animationend", Interface: AnimationEvent },
    animationiteration: { Name: "animationiteration", Interface: AnimationEvent },
    abort: { Name: "abort", Interface: UIEvent },
    load: { Name: "load", Interface: UIEvent },
    resize: { Name: "resize", Interface: UIEvent },
    scroll: { Name: "scroll", Interface: UIEvent },
    select: { Name: "select", Interface: UIEvent },
    unload: { Name: "unload", Interface: UIEvent },
    focusin: { Name: "focusin", Interface: FocusEvent },
    focusout: { Name: "focusout", Interface: FocusEvent },
    focus: { Name: "focus", Interface: FocusEvent },
    blur: { Name: "blur", Interface: FocusEvent },
    cut: { Name: "cut", Interface: ClipboardEvent },
    copy: { Name: "copy", Interface: ClipboardEvent },
    paste: { Name: "paste", Interface: ClipboardEvent },
    compositionstart: { Name: "compositionstart", Interface: CompositionEvent },
    compositionend: { Name: "compositionend", Interface: CompositionEvent },
    change: { Name: "change", Interface: Event },
    input: { Name: "input", Interface: Event },
    submit: { Name: "submit", Interface: Event },
    reset: { Name: "reset", Interface: Event },
    DOMContentLoaded: { Name: "DOMContentLoaded", Interface: Event },
    message: { Name: "message", Interface: Event },
    online: { Name: "online", Interface: Event },
    offline: { Name: "offline", Interface: Event },
    popstate: { Name: "popstate", Interface: Event },
    hashchange: { Name: "hashchange", Interface: Event },
    beforeunload: { Name: "beforeunload", Interface: Event },
    touchstart: { Name: "touchstart", Interface: _TouchEvent },
    touchend: { Name: "touchend", Interface: _TouchEvent },
    touchmove: { Name: "touchmove", Interface: _TouchEvent },
    touchcancel: { Name: "touchcancel", Interface: _TouchEvent },
    pointerdown: { Name: "pointerdown", Interface: PointerEvent },
    pointerup: { Name: "pointerup", Interface: PointerEvent },
    pointermove: { Name: "pointermove", Interface: PointerEvent },
    pointercancel: { Name: "pointercancel", Interface: PointerEvent },
    pointerenter: { Name: "pointerenter", Interface: PointerEvent },
    pointerleave: { Name: "pointerleave", Interface: PointerEvent },
    transitionstart: { Name: "transitionstart", Interface: TransitionEvent },
    transitionend: { Name: "transitionend", Interface: TransitionEvent },
    transitioncancel: { Name: "transitioncancel", Interface: TransitionEvent }
  }
);
var DOM_INTERFACES = {};
for (const [name, desc] of Object.entries(DOM_TYPES)) {
  const iname = desc.Interface.name;
  if (!DOM_INTERFACES[iname]) DOM_INTERFACES[iname] = { Name: iname, Types: {} };
  DOM_INTERFACES[iname].Types[name] = desc;
}
var _globalListeners = /* @__PURE__ */ new Map();
function _toTargets(target) {
  if (typeof target === "string") return typeof document !== "undefined" ? Array.from(document.querySelectorAll(target)) : [];
  return Array.isArray(target) ? target : [target];
}
function _toTypes(types) {
  return types.split(/[\s,|]+/).filter(Boolean);
}
var _MUTATING_ARRAY = /* @__PURE__ */ new Set([
  "push",
  "pop",
  "shift",
  "unshift",
  "splice",
  "sort",
  "reverse",
  "fill",
  "copyWithin"
]);
var _MUTATING_MAP = /* @__PURE__ */ new Set(["set", "delete", "clear"]);
var _MUTATING_SET = /* @__PURE__ */ new Set(["add", "delete", "clear"]);
var _RAW = /* @__PURE__ */ Symbol("arianna.observable.raw");
function _isReactiveTarget(v) {
  if (v === null || typeof v !== "object") return false;
  if (Object.isFrozen(v) || Object.isSealed(v)) return false;
  return true;
}
function _makeReactive(root, emit) {
  const cache = /* @__PURE__ */ new WeakMap();
  function wrap(value, path) {
    if (!_isReactiveTarget(value)) return value;
    const cached = cache.get(value);
    if (cached) return cached;
    if (value instanceof Map || value instanceof WeakMap || value instanceof Set || value instanceof WeakSet) {
      const proxy = _wrapCollection(value, path, emit, wrap);
      cache.set(value, proxy);
      return proxy;
    }
    if (Array.isArray(value)) {
      const proxy = _wrapArray(value, path, emit, wrap);
      cache.set(value, proxy);
      return proxy;
    }
    _installObjectTraps(value, path, emit, wrap);
    cache.set(value, value);
    return value;
  }
  return wrap(root, []);
}
function _wrapArray(arr, path, emit, wrap) {
  for (let i = 0; i < arr.length; i++) {
    const w = wrap(arr[i], [...path, String(i)]);
    if (w !== arr[i]) arr[i] = w;
  }
  return new Proxy(arr, {
    get(target, key) {
      if (key === _RAW) return target;
      const v = target[key];
      if (typeof key === "string" && _MUTATING_ARRAY.has(key) && typeof v === "function") {
        return function(...args) {
          const before = target.slice();
          const result = v.apply(target, args);
          emit([...path], target, key, before, target.slice(), "mutate");
          for (let i = 0; i < target.length; i++) {
            const w = wrap(target[i], [...path, String(i)]);
            if (w !== target[i]) target[i] = w;
          }
          return result;
        };
      }
      return v;
    },
    set(target, key, value) {
      if (key === "length") {
        const old2 = target.length;
        if (Object.is(old2, value)) return true;
        if (!emit([...path], target, key, old2, value, "set")) return false;
        target.length = value;
        return true;
      }
      const old = target[key];
      if (Object.is(old, value)) return true;
      if (!emit([...path], target, key, old, value, "set")) return false;
      const wrapped = wrap(value, [...path, key]);
      target[key] = wrapped;
      return true;
    },
    deleteProperty(target, key) {
      if (!(key in target)) return true;
      const old = target[key];
      if (!emit([...path], target, key, old, void 0, "delete")) return false;
      delete target[key];
      return true;
    }
  });
}
function _wrapCollection(coll, path, emit, wrap) {
  const isMap = coll instanceof Map || coll instanceof WeakMap;
  const mutating = isMap ? _MUTATING_MAP : _MUTATING_SET;
  return new Proxy(coll, {
    get(target, key) {
      if (key === _RAW) return target;
      const v = Reflect.get(target, key);
      if (typeof v !== "function") return v;
      if (typeof key === "string" && mutating.has(key)) {
        return function(...args) {
          const before = isMap ? new Map(target instanceof Map ? target.entries() : []) : new Set(target instanceof Set ? target.values() : []);
          if (isMap && key === "set" && args.length === 2) {
            args[1] = wrap(args[1], [...path, "<map-value>"]);
          } else if (!isMap && key === "add" && args.length === 1) {
            args[0] = wrap(args[0], [...path, "<set-value>"]);
          }
          const result = v.apply(target, args);
          emit([...path], target, key, before, void 0, "mutate");
          return result;
        };
      }
      return v.bind(target);
    }
  });
}
function _installObjectTraps(obj, path, emit, wrap) {
  for (const key of Object.keys(obj)) {
    const desc = Object.getOwnPropertyDescriptor(obj, key);
    if (!desc || !desc.configurable) continue;
    if (desc.get || desc.set) continue;
    let value = wrap(obj[key], [...path, key]);
    Object.defineProperty(obj, key, {
      enumerable: true,
      configurable: true,
      get() {
        return value;
      },
      set(next) {
        if (Object.is(value, next)) return;
        const old = value;
        if (!emit([...path], obj, key, old, next, "set")) return;
        value = wrap(next, [...path, key]);
      }
    });
  }
}
var Observable = class _Observable {
  #events = /* @__PURE__ */ new Map();
  #target;
  #effects = [];
  #opts;
  #history = [];
  #reactive;
  /**
   * Wraps `value` (or `this`) into a reactive observer.
   *
   * - Pass an object/array/Map/Set: it becomes deep-reactive. Read it via
   *   `obs.value`. All assignments emit 'change-before' (cancelable) and
   *   'change-after' on the instance, plus '<key>-change-before' /
   *   '<key>-change-after' scoped events.
   * - Pass nothing: behaves as the legacy event bus on `this`.
   */
  constructor(value, options = {}) {
    this.#opts = options;
    if (value !== void 0 && value !== null && typeof value === "object") {
      this.#target = value;
      this.#reactive = _makeReactive(value, (path, target, key, old, nw, kind) => this.#emit(path, target, key, old, nw, kind));
    } else {
      this.#target = this;
      this.#reactive = void 0;
    }
  }
  /**
   * The reactive view of the wrapped value. Mutations through this
   * proxy fire 'change-before' / 'change-after' on this Observable.
   */
  get value() {
    return this.#reactive ?? this.#target;
  }
  /**
   * Reverts the most recent change recorded in the history stack.
   * No-op if history is disabled or empty. Does not fire change events
   * on undo (silent).
   */
  undo() {
    const entry = this.#history.pop();
    if (!entry) return false;
    const t = entry.target;
    if (entry.kind === "set" || entry.kind === "mutate") t[entry.key] = entry.old;
    else if (entry.kind === "delete") t[entry.key] = entry.old;
    return true;
  }
  /** Number of recorded entries in the history stack. */
  get historyLength() {
    return this.#history.length;
  }
  /**
   * Internal: fired by the reactive Proxy/setter layer. Emits the
   * 4-event pattern (change-before, <key>-change-before, change-after,
   * <key>-change-after) and records to history if enabled.
   * Returns false if any 'change-before' listener cancels the event.
   */
  #emit(path, target, key, old, nw, kind) {
    const keyStr = typeof key === "symbol" ? key.description ?? "" : String(key);
    const evBefore = {
      Type: "change-before",
      Target: target,
      Key: key,
      Path: [...path, key],
      Old: old,
      New: nw,
      Kind: kind
    };
    let cancelled = false;
    for (const l of this.#events.get("change-before") ?? []) {
      const before = evBefore.New;
      l.Handler.call(l.Target, evBefore);
      if (evBefore.Cancelled) cancelled = true;
      if (evBefore.New !== before) {
      }
    }
    if (keyStr) for (const l of this.#events.get(`${keyStr}-change-before`) ?? []) {
      const ev = { ...evBefore, Type: `${keyStr}-change-before` };
      l.Handler.call(l.Target, ev);
      if (ev.Cancelled) cancelled = true;
    }
    if (cancelled) return false;
    if (this.#opts.history) {
      this.#history.push({ path, target, key, old, nw: evBefore.New, kind });
      const limit = this.#opts.historyLimit ?? 100;
      if (this.#history.length > limit) this.#history.shift();
    }
    const evAfter = {
      Type: "change-after",
      Target: target,
      Key: key,
      Path: [...path, key],
      Old: old,
      New: evBefore.New,
      Kind: kind
    };
    for (const l of this.#events.get("change-after") ?? [])
      l.Handler.call(l.Target, evAfter);
    if (keyStr) for (const l of this.#events.get(`${keyStr}-change-after`) ?? [])
      l.Handler.call(l.Target, { ...evAfter, Type: `${keyStr}-change-after` });
    return true;
  }
  // ── Instance Signal API ───────────────────────────────────────────────────
  signal(value) {
    return signal(value);
  }
  signalMono(value) {
    return signalMono(value);
  }
  effect(fn) {
    this.#effects.push(effect(fn));
    return this;
  }
  computed(fn) {
    const s = signal(void 0);
    this.#effects.push(effect(() => s.set(fn())));
    return s.readonly();
  }
  // ── Instance pub/sub ──────────────────────────────────────────────────────
  on(types, cb) {
    const ls = { Id: uuid(), Handler: cb, Target: this.#target };
    types.split(/(?!-)\W/g).filter(Boolean).forEach((t) => {
      const b = this.#events.get(t) ?? /* @__PURE__ */ new Set();
      b.add(ls);
      this.#events.set(t, b);
    });
    return this;
  }
  off(type, cb) {
    this.#events.get(type)?.forEach((l) => l.Handler === cb && this.#events.get(type).delete(l));
    return this;
  }
  fire(event) {
    if (!event?.Type) return this;
    this.#events.get(event.Type)?.forEach((l) => l.Handler.call(l.Target, event));
    return this;
  }
  once(event, cb) {
    const w = (e) => {
      cb(e);
      this.off(event.Type, w);
    };
    return this.on(event.Type, w);
  }
  all(event) {
    return this.fire(event);
  }
  destroy() {
    this.#effects.forEach((s) => s());
    this.#effects.length = 0;
    this.#events.clear();
    return this;
  }
  // ── Static DOM bus ────────────────────────────────────────────────────────
  static On(target, types, handler, opts) {
    const ids = [];
    const addOpts = { passive: opts?.Passive, capture: opts?.Capture ?? opts?.Phase === "capture", once: opts?.Once, signal: opts?.Signal };
    for (const t of _toTargets(target)) for (const type of _toTypes(types)) {
      const id = uuid();
      t.addEventListener(type, handler, addOpts);
      _globalListeners.set(id, { UUID: id, Type: type, Target: t, Function: handler, Propagation: addOpts.capture ? "capture" : "bubble", XML: "" });
      ids.push(id);
    }
    return ids;
  }
  static Off(target, types, handler, opts) {
    for (const t of _toTargets(target)) for (const type of _toTypes(types)) t.removeEventListener(type, handler, { capture: opts?.Capture ?? opts?.Phase === "capture" });
  }
  static Fire(target, type, init, detail) {
    const ev = detail !== void 0 ? new CustomEvent(type, { ...init, ...detail }) : new Event(type, init);
    _toTargets(target).forEach((t) => t.dispatchEvent(ev));
  }
  static Once(target, types, handler, opts) {
    return _Observable.On(target, types, handler, { ...opts, Once: true });
  }
  static Trigger(target, type) {
    _Observable.Fire(target, type);
  }
  static All = _Observable.On;
  static get Listeners() {
    return _globalListeners;
  }
  static GetListener(id) {
    return _globalListeners.get(id);
  }
  static GetListeners(target, type) {
    return [..._globalListeners.values()].filter((r) => r.Target === target && (type === void 0 || r.Type === type));
  }
  static Dom = { Types: DOM_TYPES, Interfaces: DOM_INTERFACES };
  static GetInterface(eventType) {
    return DOM_TYPES[eventType]?.Interface?.name;
  }
  static GetTypes(interfaceName) {
    return Object.keys(DOM_INTERFACES[interfaceName]?.Types ?? {});
  }
  // ── Static Signal + Template shorthands ───────────────────────────────────
  static signal = signal;
  static signalMono = signalMono;
  static sinkText = sinkText;
  static sinkClass = sinkClass;
  static effect = effect;
  static computed = computed;
  static batch = batch;
  static untrack = untrack;
  /**
   * Crea un AriannATemplate — parse HTML una volta, clone O(1) N volte.
   * @example
   *   const tpl = Observable.template('<tr><td></td></tr>');
   *   const tr  = tpl.clone();
   */
  static template(html) {
    return new AriannATemplate(html);
  }
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Observable")) {
  try {
    Object.defineProperty(window, "Observable", { enumerable: true, configurable: false, writable: false, value: Observable });
  } catch {
  }
}
var Observable_default = Observable;

// components/navigation/Sidebar.ts
var DEFAULTS = {
  orientation: "left",
  width: 260,
  minWidth: 160,
  maxWidth: 480,
  resizable: true,
  collapsible: true,
  collapsed: false,
  collapsedWidth: 48,
  searchable: true,
  showToggle: true,
  persist: true,
  storageKey: "arianna-wip-sidebar-w"
};
var Sidebar = class {
  /** Root element — attach to your layout. */
  el;
  _obs;
  _opts;
  _raw;
  _sections = [];
  _active = "";
  _collapsed;
  _width;
  _query = "";
  _openSecs = /* @__PURE__ */ new Set();
  // DOM refs
  _list;
  _handle;
  _search;
  _toggleBtn;
  _listeners = [];
  constructor(container = null, opts = {}) {
    this._raw = opts;
    this._opts = { ...DEFAULTS, ...opts };
    this._collapsed = this._opts.collapsed;
    this._width = this._opts.width;
    if (this._opts.persist) {
      const saved = localStorage.getItem(this._opts.storageKey);
      if (saved) {
        const w = parseInt(saved, 10);
        if (w >= this._opts.minWidth && w <= this._opts.maxWidth) this._width = w;
      }
    }
    this.el = document.createElement("nav");
    this._obs = new Observable_default(this.el);
    const orient = this._opts.orientation;
    this.el.setAttribute("role", "navigation");
    this.el.setAttribute("aria-label", opts.ariaLabel ?? "Site navigation");
    const cls = ["ar-sidebar", `ar-sidebar--${orient}`, this._collapsed ? "ar-sidebar--collapsed" : "", opts.class ?? ""];
    this.el.className = cls.filter(Boolean).join(" ");
    this._applyWidth();
    this._build();
    if (container) {
      const parent = typeof container === "string" ? document.querySelector(container) : container;
      if (parent) parent.appendChild(this.el);
    }
  }
  // ── Data setters ──────────────────────────────────────────────────────────
  set sections(v) {
    this._sections = v;
    this._openSecs = new Set(v.filter((s) => s.open !== false).map((s) => s.id));
    this._renderList();
  }
  get sections() {
    return this._sections;
  }
  set active(id) {
    this._active = id;
    this._refreshActive();
  }
  get active() {
    return this._active;
  }
  // ── Collapse API ──────────────────────────────────────────────────────────
  collapse() {
    this._collapsed = true;
    this.el.classList.add("ar-sidebar--collapsed");
    this._applyWidth();
    if (this._toggleBtn) this._toggleBtn.textContent = this._toggleIcon();
    this._emit("collapse", { collapsed: true });
    return this;
  }
  expand() {
    this._collapsed = false;
    this.el.classList.remove("ar-sidebar--collapsed");
    this._applyWidth();
    if (this._toggleBtn) this._toggleBtn.textContent = this._toggleIcon();
    this._emit("collapse", { collapsed: false });
    return this;
  }
  toggle() {
    return this._collapsed ? this.expand() : this.collapse();
  }
  // ── Width API ─────────────────────────────────────────────────────────────
  setWidth(w) {
    this._width = Math.max(this._opts.minWidth, Math.min(this._opts.maxWidth, w));
    if (!this._collapsed) this.el.style.width = this._width + "px";
    this._persist();
    this._emit("resize", { width: this._width });
    return this;
  }
  // ── Section API ───────────────────────────────────────────────────────────
  openSection(id) {
    this._openSecs.add(id);
    this._renderList();
    return this;
  }
  closeSection(id) {
    this._openSecs.delete(id);
    this._renderList();
    return this;
  }
  toggleSection(id) {
    this._openSecs.has(id) ? this.closeSection(id) : this.openSection(id);
    return this;
  }
  // ── Search ────────────────────────────────────────────────────────────────
  search(q) {
    this._query = q.toLowerCase().trim();
    if (this._search) this._search.value = q;
    this._renderList();
    return this;
  }
  // ── Event API ─────────────────────────────────────────────────────────────
  on(type, cb) {
    this._obs.on(type, cb);
    return this;
  }
  off(type, cb) {
    this._obs.off(type, cb);
    return this;
  }
  // ── Destroy ───────────────────────────────────────────────────────────────
  destroy() {
    this._listeners.forEach(({ el, type, fn, opts }) => el.removeEventListener(type, fn, opts));
    this._listeners = [];
    if (this.el.parentNode) this.el.parentNode.removeChild(this.el);
  }
  // ── Private: build ────────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = "";
    const o = this._opts;
    const orient = o.orientation;
    if (this._raw.header) {
      const hdr = this._mk("div", "ar-sidebar__header");
      if (typeof this._raw.header === "string") hdr.innerHTML = this._raw.header;
      else hdr.appendChild(this._raw.header);
      this.el.appendChild(hdr);
    }
    if (o.showToggle && o.collapsible) {
      this._toggleBtn = this._mk("button", "ar-sidebar__toggle");
      this._toggleBtn.setAttribute("aria-label", "Toggle sidebar");
      this._toggleBtn.textContent = this._toggleIcon();
      this._bind(this._toggleBtn, "click", () => this.toggle());
      this.el.appendChild(this._toggleBtn);
    }
    if (o.searchable) {
      const wrap = this._mk("div", "ar-sidebar__search-wrap");
      this._search = document.createElement("input");
      this._search.type = "text";
      this._search.className = "ar-sidebar__search";
      this._search.placeholder = "Search\u2026";
      this._search.setAttribute("aria-label", "Filter navigation");
      this._bind(this._search, "input", () => {
        this._query = this._search.value.toLowerCase().trim();
        this._renderList();
      });
      wrap.appendChild(this._search);
      this.el.appendChild(wrap);
    }
    this._list = this._mk("div", "ar-sidebar__list");
    this.el.setAttribute("role", "navigation");
    this.el.appendChild(this._list);
    this._renderList();
    if (this._raw.footer) {
      const ftr = this._mk("div", "ar-sidebar__footer");
      if (typeof this._raw.footer === "string") ftr.innerHTML = this._raw.footer;
      else ftr.appendChild(this._raw.footer);
      this.el.appendChild(ftr);
    }
    if (o.resizable) {
      const handleCls = orient === "right" ? "ar-sidebar__handle ar-sidebar__handle--right" : "ar-sidebar__handle ar-sidebar__handle--left";
      this._handle = this._mk("div", handleCls);
      this._handle.setAttribute("role", "separator");
      this._handle.setAttribute("aria-label", "Drag to resize sidebar");
      this.el.appendChild(this._handle);
      this._setupResize();
    }
    this._bind(this.el, "keydown", (e) => {
      if (e.key === "Escape" && o.collapsible) this.collapse();
    });
  }
  // ── Private: render sections ──────────────────────────────────────────────
  _renderList() {
    if (!this._list) return;
    this._list.innerHTML = "";
    const q = this._query;
    const collapsed = this._collapsed;
    for (const sec of this._sections) {
      const matchedItems = q ? sec.items.filter((i) => i.label.toLowerCase().includes(q) || String(i.badge ?? "").toLowerCase().includes(q)) : sec.items;
      if (q && matchedItems.length === 0) continue;
      const isOpen = this._openSecs.has(sec.id) || !!q;
      const secEl = this._mk("div", "ar-sidebar__section");
      const hd = this._mk("button", `ar-sidebar__section-hd${isOpen ? " ar-sidebar__section-hd--open" : ""}`);
      hd.setAttribute("aria-expanded", String(isOpen));
      hd.setAttribute("aria-controls", `sec-items-${sec.id}`);
      if (!collapsed) {
        if (sec.icon) {
          const ic = this._mk("span", "ar-sidebar__sec-icon");
          ic.textContent = sec.icon;
          hd.appendChild(ic);
        }
        const lbl = this._mk("span", "ar-sidebar__sec-label");
        lbl.textContent = sec.label;
        hd.appendChild(lbl);
        const arr = this._mk("span", "ar-sidebar__sec-arrow");
        arr.setAttribute("aria-hidden", "true");
        arr.textContent = isOpen ? "\u25BE" : "\u25B8";
        hd.appendChild(arr);
      }
      hd.addEventListener("click", () => this.toggleSection(sec.id));
      secEl.appendChild(hd);
      const itemsEl = this._mk("div", "ar-sidebar__items");
      itemsEl.id = `sec-items-${sec.id}`;
      if (!isOpen && !q) itemsEl.style.display = "none";
      for (const item of matchedItems) {
        const isActive = this._active === item.id;
        const btn = this._mk("button", [
          "ar-sidebar__item",
          isActive ? "ar-sidebar__item--active" : "",
          item.disabled ? "ar-sidebar__item--disabled" : "",
          item.class ?? ""
        ].filter(Boolean).join(" "));
        btn.disabled = !!item.disabled;
        btn.setAttribute("aria-current", isActive ? "page" : "false");
        btn.dataset["id"] = item.id;
        if (collapsed && item.label) btn.title = item.label;
        if (item.icon) {
          const ic = this._mk("span", "ar-sidebar__item-icon");
          ic.setAttribute("aria-hidden", "true");
          ic.textContent = item.icon;
          btn.appendChild(ic);
        }
        if (!collapsed) {
          const lbl = this._mk("span", "ar-sidebar__item-label");
          lbl.textContent = item.label;
          btn.appendChild(lbl);
          if (item.badge !== void 0) {
            const b = this._mk("span", "ar-sidebar__item-badge");
            b.textContent = String(item.badge);
            btn.appendChild(b);
          }
        }
        btn.addEventListener("click", () => {
          if (item.disabled) return;
          this._active = item.id;
          this._refreshActive();
          this._emit("select", { item, section: sec });
        });
        itemsEl.appendChild(btn);
      }
      secEl.appendChild(itemsEl);
      this._list.appendChild(secEl);
    }
  }
  _refreshActive() {
    this._list?.querySelectorAll(".ar-sidebar__item").forEach((btn) => {
      const active = btn.dataset["id"] === this._active;
      btn.classList.toggle("ar-sidebar__item--active", active);
      btn.setAttribute("aria-current", active ? "page" : "false");
    });
  }
  // ── Private: resize ───────────────────────────────────────────────────────
  _setupResize() {
    const o = this._opts;
    let dragging = false, startX = 0, startW = 0;
    const move = (clientX) => {
      if (!dragging || this._collapsed) return;
      const delta = o.orientation === "left" ? clientX - startX : startX - clientX;
      this._width = Math.max(o.minWidth, Math.min(o.maxWidth, startW + delta));
      this.el.style.width = this._width + "px";
      this._emit("resize", { width: this._width });
    };
    const end = () => {
      if (!dragging) return;
      dragging = false;
      this._handle.classList.remove("ar-sidebar__handle--dragging");
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      this._persist();
    };
    this._bind(this._handle, "mousedown", (e) => {
      if (this._collapsed) return;
      dragging = true;
      startX = e.clientX;
      startW = this._width;
      this._handle.classList.add("ar-sidebar__handle--dragging");
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
      e.preventDefault();
    });
    this._bind(document, "mousemove", (e) => move(e.clientX));
    this._bind(document, "mouseup", () => end());
    this._bind(this._handle, "touchstart", (e) => {
      if (this._collapsed) return;
      dragging = true;
      startX = e.touches[0].clientX;
      startW = this._width;
      e.preventDefault();
    }, { passive: false });
    this._bind(document, "touchmove", (e) => move(e.touches[0].clientX));
    this._bind(document, "touchend", () => end());
  }
  // ── Private: helpers ──────────────────────────────────────────────────────
  _applyWidth() {
    const w = this._collapsed ? this._opts.collapsedWidth : this._width;
    this.el.style.width = w + "px";
  }
  _persist() {
    if (this._opts.persist)
      localStorage.setItem(this._opts.storageKey, String(this._width));
  }
  _toggleIcon() {
    const o = this._opts.orientation;
    if (o === "left") return this._collapsed ? "\u25B8" : "\u25C2";
    if (o === "right") return this._collapsed ? "\u25C2" : "\u25B8";
    return "\u2261";
  }
  _emit(type, detail) {
    this._obs.fire({ Type: type, ...detail });
  }
  _mk(tag, cls) {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    return el;
  }
  _bind(target, type, fn, opts) {
    target.addEventListener(type, fn, opts);
    this._listeners.push({ el: target, type, fn, opts });
  }
};

// components/navigation/Stepper.ts
var Stepper = class extends Control {
  _steps = [];
  _current = 0;
  _completed = /* @__PURE__ */ new Set();
  constructor(container = null, opts = {}) {
    super(container, "div", opts);
    this.el.className = `ar-stepper ar-stepper--${opts.variant ?? "horizontal"}${opts.class ? " " + opts.class : ""}`;
  }
  set steps(v) {
    this._steps = v;
    this._set("steps", v);
  }
  set current(n) {
    this._current = n;
    this._build();
  }
  get current() {
    return this._current;
  }
  next() {
    if (this._current < this._steps.length - 1) {
      this._completed.add(this._current);
      this._current++;
      this._build();
      this._emit("change", { step: this._current });
    }
  }
  prev() {
    if (this._current > 0) {
      this._current--;
      this._build();
      this._emit("change", { step: this._current });
    }
  }
  complete(n = this._current) {
    this._completed.add(n);
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    this._steps.forEach((label, i) => {
      const isDone = this._completed.has(i);
      const isActive = i === this._current;
      const isPending = i > this._current && !isDone;
      const step = this._el("div", `ar-stepper__step${isActive ? " ar-stepper__step--active" : ""}${isDone ? " ar-stepper__step--done" : ""}${isPending ? " ar-stepper__step--pending" : ""}`, this.el);
      const dot = this._el("div", "ar-stepper__dot", step);
      dot.textContent = isDone ? "\u2713" : String(i + 1);
      const lbl = this._el("div", "ar-stepper__label", step);
      lbl.textContent = label;
      if (i < this._steps.length - 1) this._el("div", "ar-stepper__line", this.el);
    });
  }
};

// components/payments/ApplePay.ts
var ApplePay = class _ApplePay extends Control {
  _elBtn;
  _elFallback;
  constructor(container, opts) {
    super(container, "div", {
      label: "Total",
      supportedNetworks: ["visa", "masterCard", "amex"],
      merchantCapabilities: ["supports3DS"],
      forceShow: false,
      buttonStyle: "black",
      buttonType: "plain",
      ...opts
    });
    this.el.className = `ar-applepay${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Programmatically trigger the Apple Pay sheet. */
  pay() {
    return this._pay();
  }
  /**
   * Detect whether Apple Pay can be invoked on this device. Resolves to
   * `true` if a PaymentRequest could be constructed (does NOT confirm the
   * user has cards on file — that requires `canMakePayment()`).
   */
  static async isAvailable() {
    if (typeof window === "undefined") return false;
    const w = window;
    if (w.ApplePaySession?.canMakePayments) return w.ApplePaySession.canMakePayments();
    if (typeof window.PaymentRequest !== "undefined") return true;
    return false;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    const buttonStyle = this._get("buttonStyle", "black");
    const buttonType = this._get("buttonType", "plain");
    this.el.innerHTML = `
<button class="ar-applepay__btn ar-applepay__btn--${buttonStyle} ar-applepay__btn--${buttonType}" data-r="btn" type="button">
  <span class="ar-applepay__logo">${APPLE_LOGO_SVG}</span>
  <span class="ar-applepay__label">${this._buttonLabel()}</span>
</button>
<div class="ar-applepay__fallback" data-r="fallback" style="display:none">
  Apple Pay is not available on this device.
</div>`;
    this._elBtn = this.el.querySelector('[data-r="btn"]');
    this._elFallback = this.el.querySelector('[data-r="fallback"]');
    this._elBtn.addEventListener("click", () => {
      void this._pay();
    });
    _ApplePay.isAvailable().then((ok) => {
      if (!ok && !this._get("forceShow", false)) {
        this._elBtn.style.display = "none";
        this._elFallback.style.display = "";
      }
      this._emit("ready", { available: ok });
    });
  }
  _buttonLabel() {
    const t = this._get("buttonType", "plain");
    switch (t) {
      case "buy":
        return "Buy with";
      case "donate":
        return "Donate with";
      case "check-out":
        return "Check out with";
      case "subscribe":
        return "Subscribe with";
      case "reload":
        return "Reload with";
      default:
        return "";
    }
  }
  async _pay() {
    const PR = window.PaymentRequest;
    if (!PR) {
      this._emit("error", { message: "PaymentRequest API not supported" });
      return;
    }
    const networks = this._get("supportedNetworks", ["visa", "masterCard", "amex"]);
    const caps = this._get("merchantCapabilities", ["supports3DS"]);
    const amount = this._get("amount", 0).toFixed(2);
    const currency = this._get("currency", "EUR");
    const country = this._get("countryCode", "IT");
    const methodData = [{
      supportedMethods: "https://apple.com/apple-pay",
      data: {
        version: 3,
        merchantIdentifier: this._get("merchantId", ""),
        merchantCapabilities: caps,
        supportedNetworks: networks,
        countryCode: country
      }
    }];
    const details = {
      total: { label: this._get("label", "Total"), amount: { currency, value: amount } }
    };
    try {
      const Ctor = PR;
      const req = new Ctor(methodData, details);
      const can = await req.canMakePayment();
      if (!can) {
        this._emit("error", { message: "No Apple Pay cards available" });
        return;
      }
      const response = await req.show();
      const r = response;
      this._emit("success", { token: r.details });
      await r.complete?.("success");
    } catch (e) {
      const msg = e.message || "Apple Pay failed";
      if (/cancel|abort/i.test(msg)) this._emit("cancel", {});
      else this._emit("error", { message: msg });
    }
  }
  _injectStyles() {
    if (document.getElementById("ar-applepay-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-applepay-styles";
    s.textContent = `
.ar-applepay { display:inline-block; }
.ar-applepay__btn { display:inline-flex; align-items:center; justify-content:center; gap:6px; min-width:160px; padding:11px 20px; border:0; border-radius:6px; font:600 16px -apple-system,system-ui,sans-serif; cursor:pointer; transition:transform .08s; -webkit-appearance:none; }
.ar-applepay__btn:active { transform:scale(0.98); }
.ar-applepay__btn--black         { background:#000; color:#fff; }
.ar-applepay__btn--white         { background:#fff; color:#000; border:1px solid #000; }
.ar-applepay__btn--white-outline { background:#fff; color:#000; border:1px solid #000; }
.ar-applepay__btn:hover { opacity:0.92; }
.ar-applepay__logo svg { display:block; height:18px; width:auto; }
.ar-applepay__btn--white .ar-applepay__logo svg path,
.ar-applepay__btn--white-outline .ar-applepay__logo svg path { fill:#000; }
.ar-applepay__label:empty { display:none; }
.ar-applepay__fallback { color:#888; font:12px sans-serif; padding:6px 10px; }
`;
    document.head.appendChild(s);
  }
};
var APPLE_LOGO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 22" aria-hidden="true">
<path fill="#fff" d="M14.94 11.5c0-2.06 1.69-3.05 1.76-3.1a3.78 3.78 0 0 0-2.98-1.61c-1.26-.13-2.45.74-3.09.74-.65 0-1.62-.72-2.67-.7A3.95 3.95 0 0 0 4.6 8.86c-1.43 2.48-.36 6.13 1.02 8.13.69.97 1.51 2.07 2.58 2.03 1.04-.04 1.43-.67 2.69-.67 1.25 0 1.6.67 2.69.65 1.11-.02 1.81-1 2.49-1.97a8.78 8.78 0 0 0 1.13-2.31 3.79 3.79 0 0 1-2.26-3.22zM12.92 5.5a3.75 3.75 0 0 0 .85-2.69 3.79 3.79 0 0 0-2.46 1.27 3.55 3.55 0 0 0-.87 2.6c.93.07 1.86-.47 2.48-1.18z"/>
</svg>`;

// components/payments/GooglePay.ts
var GooglePay = class extends Control {
  _elBtnHost;
  _elFallback;
  _client = null;
  constructor(container, opts) {
    super(container, "div", {
      allowedCardNetworks: ["VISA", "MASTERCARD", "AMEX"],
      allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
      test: true,
      buttonColor: "black",
      buttonType: "buy",
      ...opts
    });
    this.el.className = `ar-gpay${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Trigger the Google Pay sheet programmatically. */
  pay() {
    return this._pay();
  }
  /** Whether Google Pay JS API is loaded and a client is ready. */
  isReady() {
    return this._client !== null;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = `
<div class="ar-gpay__btn-host" data-r="btn"></div>
<div class="ar-gpay__fallback" data-r="fallback" style="display:none">
  Google Pay is not available.
</div>`;
    this._elBtnHost = this.el.querySelector('[data-r="btn"]');
    this._elFallback = this.el.querySelector('[data-r="fallback"]');
    void this._loadAndInit();
  }
  async _loadAndInit() {
    try {
      await loadGooglePayScript();
    } catch (e) {
      this._showFallback();
      this._emit("error", { message: "Failed to load Google Pay script: " + e.message });
      return;
    }
    const w = window;
    if (!w.google?.payments?.api?.PaymentsClient) {
      this._showFallback();
      this._emit("error", { message: "Google Pay API not present after load" });
      return;
    }
    const test = this._get("test", true);
    const Client = w.google.payments.api.PaymentsClient;
    this._client = new Client({ environment: test ? "TEST" : "PRODUCTION" });
    const isReady = this._client.isReadyToPay(this._isReadyRequest());
    try {
      const res = await isReady;
      if (!res.result) {
        this._showFallback();
        this._emit("ready", { available: false });
        return;
      }
      this._renderButton();
      this._emit("ready", { available: true });
    } catch (e) {
      this._showFallback();
      this._emit("error", { message: "isReadyToPay failed: " + e.message });
    }
  }
  _renderButton() {
    const c = this._client;
    const btn = c.createButton({
      buttonColor: this._get("buttonColor", "black"),
      buttonType: this._get("buttonType", "buy"),
      buttonSizeMode: "fill",
      onClick: () => {
        void this._pay();
      }
    });
    this._elBtnHost.innerHTML = "";
    this._elBtnHost.appendChild(btn);
  }
  async _pay() {
    if (!this._client) {
      this._emit("error", { message: "Google Pay client not ready" });
      return;
    }
    const c = this._client;
    try {
      const data = await c.loadPaymentData(this._paymentDataRequest());
      this._emit("success", { token: data.paymentMethodData });
    } catch (e) {
      const err = e;
      if (err.statusCode === "CANCELED") this._emit("cancel", {});
      else this._emit("error", { message: err.message || "Google Pay failed" });
    }
  }
  _baseCardPaymentMethod() {
    return {
      type: "CARD",
      parameters: {
        allowedAuthMethods: this._get("allowedAuthMethods", ["PAN_ONLY", "CRYPTOGRAM_3DS"]),
        allowedCardNetworks: this._get("allowedCardNetworks", ["VISA", "MASTERCARD", "AMEX"])
      }
    };
  }
  _isReadyRequest() {
    return {
      apiVersion: 2,
      apiVersionMinor: 0,
      allowedPaymentMethods: [this._baseCardPaymentMethod()]
    };
  }
  _paymentDataRequest() {
    const card = this._baseCardPaymentMethod();
    card.tokenizationSpecification = {
      type: "PAYMENT_GATEWAY",
      parameters: {
        gateway: this._get("gateway", ""),
        gatewayMerchantId: this._get("gatewayMerchantId", "")
      }
    };
    return {
      apiVersion: 2,
      apiVersionMinor: 0,
      allowedPaymentMethods: [card],
      transactionInfo: {
        totalPriceStatus: "FINAL",
        totalPrice: this._get("amount", 0).toFixed(2),
        currencyCode: this._get("currency", "EUR"),
        countryCode: this._get("countryCode", "IT")
      },
      merchantInfo: {
        merchantId: this._get("merchantId", ""),
        merchantName: this._get("merchantName", "")
      }
    };
  }
  _showFallback() {
    this._elBtnHost.style.display = "none";
    this._elFallback.style.display = "";
  }
  _injectStyles() {
    if (document.getElementById("ar-gpay-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-gpay-styles";
    s.textContent = `
.ar-gpay { display:inline-block; min-width:200px; }
.ar-gpay__btn-host { display:inline-block; }
.ar-gpay__fallback { color:#888; font:12px sans-serif; padding:6px 10px; }
`;
    document.head.appendChild(s);
  }
};
var _gpayPromise = null;
function loadGooglePayScript() {
  if (_gpayPromise) return _gpayPromise;
  _gpayPromise = new Promise((resolve, reject) => {
    if (typeof document === "undefined") {
      reject(new Error("no document"));
      return;
    }
    const w = window;
    if (w.google?.payments) {
      resolve();
      return;
    }
    const s = document.createElement("script");
    s.src = "https://pay.google.com/gp/p/js/pay.js";
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("script load failed"));
    document.head.appendChild(s);
  });
  return _gpayPromise;
}

// components/payments/CreditCard.ts
var CreditCard = class extends Control {
  _brand = "unknown";
  _save = false;
  // DOM
  _elPreview;
  _elBrandLogo;
  _elPreviewNumber;
  _elPreviewName;
  _elPreviewExp;
  _elNumber;
  _elName;
  _elExp;
  _elCvv;
  _elCountry;
  _elZip;
  _elSave;
  _elBtn;
  _elError;
  constructor(container, opts) {
    super(container, "div", {
      currency: "EUR",
      showAddress: true,
      saveOption: false,
      allowedBrands: ["visa", "mastercard", "amex", "maestro"],
      locale: "en",
      ...opts
    });
    this.el.className = `ar-cc${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
    this._refreshPreview();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /**
   * Get the current card data. Returns a deep clone — the caller may
   * inspect or mutate without affecting the form.
   */
  getCard() {
    return {
      number: this._elNumber.value.replace(/\s+/g, ""),
      cardholder: this._elName.value.trim(),
      expMonth: this._expParts().mm,
      expYear: this._expParts().yyyy,
      cvv: this._elCvv.value,
      country: this._elCountry?.value.trim().toUpperCase() || void 0,
      zip: this._elZip?.value.trim() || void 0,
      brand: this._brand,
      save: this._save
    };
  }
  /** Programmatically set field values. */
  setCard(data) {
    if (data.number !== void 0) {
      this._elNumber.value = formatCardNumber(data.number, data.brand ?? detectBrand(data.number));
      this._brand = data.brand ?? detectBrand(data.number);
    }
    if (data.cardholder !== void 0) this._elName.value = data.cardholder;
    if (data.expMonth !== void 0 && data.expYear !== void 0) {
      const yy = data.expYear.length === 4 ? data.expYear.slice(2) : data.expYear;
      this._elExp.value = `${data.expMonth.padStart(2, "0")}/${yy.padStart(2, "0")}`;
    }
    if (data.cvv !== void 0) this._elCvv.value = data.cvv;
    if (data.country !== void 0 && this._elCountry) this._elCountry.value = data.country;
    if (data.zip !== void 0 && this._elZip) this._elZip.value = data.zip;
    this._refreshPreview();
    return this;
  }
  /**
   * Trigger validation + submission programmatically. Equivalent to clicking
   * the "Pay" button.
   */
  pay() {
    this._submit();
    return this;
  }
  /** Validate the current input. Returns null if valid, error message if not. */
  validate() {
    const c = this.getCard();
    if (!validateLuhn(c.number)) return "Invalid card number";
    if (this._brand === "unknown") return "Unknown card brand";
    const allowed = this._get("allowedBrands", []);
    if (allowed.length && !allowed.includes(this._brand))
      return `${this._brand} cards are not accepted`;
    if (!c.cardholder) return "Cardholder name required";
    if (!c.expMonth || !c.expYear) return "Expiry date required";
    const m = parseInt(c.expMonth, 10), y = parseInt(c.expYear, 10);
    if (!(m >= 1 && m <= 12)) return "Invalid expiry month";
    const now = /* @__PURE__ */ new Date();
    const expEnd = new Date(y, m, 0, 23, 59, 59);
    if (expEnd < now) return "Card has expired";
    const cvvLen = this._brand === "amex" ? 4 : 3;
    if (c.cvv.length !== cvvLen) return `CVV must be ${cvvLen} digits`;
    return null;
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _build() {
    const showAddress = this._get("showAddress", true);
    const saveOption = this._get("saveOption", false);
    const cardholder = this._get("cardholder", "");
    this.el.innerHTML = `
<div class="ar-cc__preview" data-r="preview">
  <div class="ar-cc__preview-top">
    <span class="ar-cc__chip">\u25A3</span>
    <span class="ar-cc__brand-logo" data-r="brand-logo">CARD</span>
  </div>
  <div class="ar-cc__preview-number" data-r="preview-number">\u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022</div>
  <div class="ar-cc__preview-bottom">
    <div>
      <div class="ar-cc__lbl">CARDHOLDER</div>
      <div class="ar-cc__preview-name" data-r="preview-name">YOUR NAME</div>
    </div>
    <div>
      <div class="ar-cc__lbl">EXPIRES</div>
      <div class="ar-cc__preview-exp" data-r="preview-exp">MM/YY</div>
    </div>
  </div>
</div>

<div class="ar-cc__form">
  <label class="ar-cc__field ar-cc__field--full">
    <span>Card number</span>
    <input data-r="number" type="text" inputmode="numeric" maxlength="23" placeholder="1234 5678 9012 3456" autocomplete="cc-number">
  </label>
  <label class="ar-cc__field ar-cc__field--full">
    <span>Cardholder</span>
    <input data-r="name" type="text" placeholder="Name on card" autocomplete="cc-name" value="${escapeHtml7(cardholder)}">
  </label>
  <label class="ar-cc__field">
    <span>MM/YY</span>
    <input data-r="exp" type="text" inputmode="numeric" maxlength="5" placeholder="12/28" autocomplete="cc-exp">
  </label>
  <label class="ar-cc__field">
    <span>CVV</span>
    <input data-r="cvv" type="text" inputmode="numeric" maxlength="4" placeholder="123" autocomplete="cc-csc">
  </label>
  ${showAddress ? `
  <label class="ar-cc__field">
    <span>Country</span>
    <input data-r="country" type="text" maxlength="2" placeholder="IT" autocomplete="country">
  </label>
  <label class="ar-cc__field">
    <span>ZIP</span>
    <input data-r="zip" type="text" maxlength="10" placeholder="00100" autocomplete="postal-code">
  </label>` : ""}
  ${saveOption ? `
  <label class="ar-cc__save ar-cc__field--full">
    <input data-r="save" type="checkbox">
    <span>Save card for future purchases</span>
  </label>` : ""}
  <div class="ar-cc__error" data-r="error" style="display:none"></div>
  <button class="ar-cc__btn" data-r="btn">${this._buttonLabel()}</button>
</div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elPreview = r("preview");
    this._elBrandLogo = r("brand-logo");
    this._elPreviewNumber = r("preview-number");
    this._elPreviewName = r("preview-name");
    this._elPreviewExp = r("preview-exp");
    this._elNumber = r("number");
    this._elName = r("name");
    this._elExp = r("exp");
    this._elCvv = r("cvv");
    if (showAddress) {
      this._elCountry = r("country");
      this._elZip = r("zip");
    }
    if (saveOption) this._elSave = r("save");
    this._elBtn = r("btn");
    this._elError = r("error");
    this._wireEvents();
  }
  _wireEvents() {
    this._elNumber.addEventListener("input", () => {
      const raw = this._elNumber.value.replace(/\D/g, "");
      this._brand = detectBrand(raw);
      this._elNumber.value = formatCardNumber(raw, this._brand);
      this._elCvv.maxLength = this._brand === "amex" ? 4 : 3;
      this._refreshPreview();
    });
    this._elName.addEventListener("input", () => this._refreshPreview());
    this._elExp.addEventListener("input", () => {
      const raw = this._elExp.value.replace(/\D/g, "").slice(0, 4);
      this._elExp.value = raw.length >= 3 ? `${raw.slice(0, 2)}/${raw.slice(2)}` : raw;
      this._refreshPreview();
    });
    this._elCvv.addEventListener("input", () => {
      this._elCvv.value = this._elCvv.value.replace(/\D/g, "");
    });
    if (this._elSave) this._elSave.addEventListener("change", () => {
      this._save = this._elSave.checked;
    });
    this._elBtn.addEventListener("click", () => this._submit());
  }
  _submit() {
    const err = this.validate();
    if (err) {
      this._showError(err);
      this._emit("error", { message: err });
      return;
    }
    this._showError(null);
    this._emit("submit", { card: this.getCard() });
  }
  _showError(msg) {
    if (!msg) {
      this._elError.style.display = "none";
      this._elError.textContent = "";
      return;
    }
    this._elError.style.display = "";
    this._elError.textContent = msg;
  }
  _refreshPreview() {
    this._elBrandLogo.textContent = brandLogoText(this._brand);
    this._elBrandLogo.className = "ar-cc__brand-logo ar-cc__brand-logo--" + this._brand;
    this._elPreview.className = "ar-cc__preview ar-cc__preview--" + this._brand;
    const raw = this._elNumber.value.replace(/\s+/g, "");
    if (raw.length === 0) {
      this._elPreviewNumber.textContent = this._brand === "amex" ? "\u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022\u2022" : "\u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022";
    } else {
      this._elPreviewNumber.textContent = formatCardPreview(raw, this._brand);
    }
    this._elPreviewName.textContent = (this._elName.value || "YOUR NAME").toUpperCase().slice(0, 26);
    this._elPreviewExp.textContent = this._elExp.value || "MM/YY";
  }
  _expParts() {
    const v = this._elExp.value.trim();
    const m = /^(\d{1,2})\s*\/\s*(\d{1,4})$/.exec(v);
    if (!m) return { mm: "", yyyy: "" };
    const mm = m[1].padStart(2, "0");
    let yy = m[2];
    if (yy.length === 2) yy = "20" + yy;
    return { mm, yyyy: yy };
  }
  _buttonLabel() {
    const amount = this._get("amount", 0);
    const cur = this._get("currency", "EUR");
    const loc = this._get("locale", "en");
    try {
      const fmt2 = new Intl.NumberFormat(loc, { style: "currency", currency: cur });
      return `Pay ${fmt2.format(amount)}`;
    } catch {
      return `Pay ${cur} ${amount.toFixed(2)}`;
    }
  }
  _injectStyles() {
    if (document.getElementById("ar-cc-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-cc-styles";
    s.textContent = `
.ar-cc { display:flex; flex-direction:column; gap:18px; padding:20px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:13px -apple-system,system-ui,sans-serif; max-width:420px; }
.ar-cc__preview { background:linear-gradient(135deg, #1f2937 0%, #111827 100%); border-radius:10px; padding:18px 20px; color:#fff; aspect-ratio:1.586; display:flex; flex-direction:column; justify-content:space-between; box-shadow:0 4px 12px rgba(0,0,0,0.4); transition:background .25s; }
.ar-cc__preview--visa       { background:linear-gradient(135deg, #1a3d8f 0%, #0d1f4d 100%); }
.ar-cc__preview--mastercard { background:linear-gradient(135deg, #b91c1c 0%, #7f1d1d 100%); }
.ar-cc__preview--amex       { background:linear-gradient(135deg, #006fcf 0%, #003e6b 100%); }
.ar-cc__preview--maestro    { background:linear-gradient(135deg, #0099df 0%, #ed1c2e 100%); }
.ar-cc__preview-top { display:flex; justify-content:space-between; align-items:center; }
.ar-cc__chip { font-size:24px; color:#facc15; }
.ar-cc__brand-logo { font:700 14px sans-serif; letter-spacing:.1em; padding:3px 10px; border-radius:3px; background:rgba(255,255,255,0.15); }
.ar-cc__brand-logo--unknown { opacity:0.4; }
.ar-cc__preview-number { font:600 19px ui-monospace,monospace; letter-spacing:.12em; }
.ar-cc__preview-bottom { display:flex; justify-content:space-between; }
.ar-cc__lbl { font:9px sans-serif; opacity:0.7; letter-spacing:.08em; }
.ar-cc__preview-name, .ar-cc__preview-exp { font:600 12px sans-serif; letter-spacing:.05em; }

.ar-cc__form { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.ar-cc__field { display:flex; flex-direction:column; gap:4px; }
.ar-cc__field--full { grid-column:1 / -1; }
.ar-cc__field span { font:10px sans-serif; color:#888; letter-spacing:.06em; text-transform:uppercase; }
.ar-cc__field input { background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:8px 10px; font:13px ui-monospace,monospace; border-radius:3px; }
.ar-cc__field input:focus { outline:none; border-color:#e40c88; }
.ar-cc__save { display:flex; align-items:center; gap:8px; font:12px sans-serif; color:#888; cursor:pointer; }
.ar-cc__error { grid-column:1 / -1; padding:8px 12px; background:rgba(220,38,38,0.15); border:1px solid #dc2626; border-radius:3px; color:#fca5a5; font-size:12px; }
.ar-cc__btn { grid-column:1 / -1; background:#e40c88; color:#fff; border:0; padding:12px; font:600 14px sans-serif; border-radius:4px; cursor:pointer; transition:background .12s; }
.ar-cc__btn:hover { background:#c30b75; }
.ar-cc__btn:disabled { background:#555; cursor:not-allowed; }
`;
    document.head.appendChild(s);
  }
};
function detectBrand(pan) {
  const n = pan.replace(/\D/g, "");
  if (!n) return "unknown";
  if (/^4/.test(n)) return "visa";
  if (/^3[47]/.test(n)) return "amex";
  if (/^5[1-5]/.test(n)) return "mastercard";
  if (/^2[2-7]/.test(n)) {
    const four = parseInt(n.slice(0, 4), 10);
    if (n.length >= 4 && four >= 2221 && four <= 2720) return "mastercard";
    if (n.length < 4) return "mastercard";
  }
  if (/^(50|5[6-8]|6)/.test(n)) return "maestro";
  return "unknown";
}
function validateLuhn(pan) {
  const n = pan.replace(/\D/g, "");
  if (n.length < 12) return false;
  let sum = 0, alt = false;
  for (let i = n.length - 1; i >= 0; i--) {
    let d = n.charCodeAt(i) - 48;
    if (alt) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    alt = !alt;
  }
  return sum % 10 === 0;
}
function formatCardNumber(pan, brand) {
  const n = pan.replace(/\D/g, "").slice(0, brand === "amex" ? 15 : 19);
  if (brand === "amex") {
    const a = n.slice(0, 4), b = n.slice(4, 10), c = n.slice(10, 15);
    return [a, b, c].filter(Boolean).join(" ");
  }
  return n.match(/.{1,4}/g)?.join(" ") ?? n;
}
function formatCardPreview(pan, brand) {
  const last4 = pan.slice(-4).padStart(4, "\u2022");
  if (brand === "amex") return `\u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022\u2022\u2022 \u2022${last4}`;
  return `\u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 ${last4}`;
}
function brandLogoText(brand) {
  switch (brand) {
    case "visa":
      return "VISA";
    case "mastercard":
      return "MC";
    case "amex":
      return "AMEX";
    case "maestro":
      return "MAESTRO";
    default:
      return "CARD";
  }
}
function escapeHtml7(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/payments/PayPal.ts
var PayPal = class extends Control {
  _elHost;
  _elFallback;
  constructor(container, opts) {
    super(container, "div", {
      description: "",
      intent: "capture",
      buttonStyle: { layout: "vertical", color: "gold", shape: "rect", label: "paypal" },
      disableFunding: [],
      ...opts
    });
    this.el.className = `ar-paypal${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = `
<div class="ar-paypal__host" data-r="host"></div>
<div class="ar-paypal__fallback" data-r="fallback" style="display:none">
  PayPal is not available right now.
</div>`;
    this._elHost = this.el.querySelector('[data-r="host"]');
    this._elFallback = this.el.querySelector('[data-r="fallback"]');
    void this._loadAndRender();
  }
  async _loadAndRender() {
    const clientId = this._get("clientId", "");
    const currency = this._get("currency", "EUR");
    const intent = this._get("intent", "capture");
    const locale = this._get("locale", "");
    const disable = this._get("disableFunding", []);
    try {
      await loadPayPalScript({ clientId, currency, intent, locale, disableFunding: disable });
    } catch (e) {
      this._showFallback();
      this._emit("error", { message: "Failed to load PayPal SDK: " + e.message });
      return;
    }
    const paypal = window.paypal;
    if (!paypal?.Buttons) {
      this._showFallback();
      this._emit("error", { message: "PayPal Buttons not available" });
      return;
    }
    const style = this._get("buttonStyle", {});
    const buttons = paypal.Buttons({
      style,
      createOrder: (_d, actions) => {
        return actions.order.create({
          intent: intent.toUpperCase(),
          purchase_units: [{
            description: this._get("description", ""),
            amount: { currency_code: currency, value: this._get("amount", 0).toFixed(2) }
          }]
        });
      },
      onApprove: async (_d, actions) => {
        try {
          const result = intent === "capture" ? await actions.order.capture?.() : await actions.order.authorize?.();
          this._emit("success", { orderId: _d.orderID, result });
        } catch (e) {
          this._emit("error", { message: e.message });
        }
      },
      onCancel: (_d) => this._emit("cancel", {}),
      onError: (e) => this._emit("error", { message: e.message || "PayPal error" })
    });
    if (buttons.isEligible && !buttons.isEligible()) {
      this._showFallback();
      this._emit("ready", { available: false });
      return;
    }
    try {
      await buttons.render(this._elHost);
      this._emit("ready", { available: true });
    } catch (e) {
      this._showFallback();
      this._emit("error", { message: "Render failed: " + e.message });
    }
  }
  _showFallback() {
    this._elHost.style.display = "none";
    this._elFallback.style.display = "";
  }
  _injectStyles() {
    if (document.getElementById("ar-paypal-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-paypal-styles";
    s.textContent = `
.ar-paypal { display:inline-block; min-width:200px; }
.ar-paypal__host { display:inline-block; min-width:200px; }
.ar-paypal__fallback { color:#888; font:12px sans-serif; padding:6px 10px; }
`;
    document.head.appendChild(s);
  }
};
var _ppPromise = null;
var _ppCacheKey = "";
function loadPayPalScript(opts) {
  const key = `${opts.clientId}|${opts.currency}|${opts.intent}|${opts.locale ?? ""}|${(opts.disableFunding ?? []).join(",")}`;
  if (_ppPromise && _ppCacheKey === key) return _ppPromise;
  _ppCacheKey = key;
  _ppPromise = new Promise((resolve, reject) => {
    if (typeof document === "undefined") {
      reject(new Error("no document"));
      return;
    }
    const params = new URLSearchParams({
      "client-id": opts.clientId,
      currency: opts.currency,
      intent: opts.intent
    });
    if (opts.locale) params.set("locale", opts.locale);
    if (opts.disableFunding && opts.disableFunding.length)
      params.set("disable-funding", opts.disableFunding.join(","));
    const s = document.createElement("script");
    s.src = `https://www.paypal.com/sdk/js?${params.toString()}`;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("script load failed"));
    document.head.appendChild(s);
  });
  return _ppPromise;
}

// components/payments/Stripe.ts
var Stripe = class extends Control {
  _stripe = null;
  _elements = null;
  _paymentEl = null;
  _elMount;
  _elBtn;
  _elError;
  constructor(container, opts) {
    super(container, "div", {
      locale: "auto",
      buttonLabel: "Pay",
      ...opts
    });
    this.el.className = `ar-stripe${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Confirm the PaymentIntent. Equivalent to clicking the Pay button. */
  pay() {
    return this._confirm();
  }
  /** True once Stripe.js has loaded and the payment element has mounted. */
  isReady() {
    return this._paymentEl !== null;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = `
<div class="ar-stripe__mount" data-r="mount"></div>
<div class="ar-stripe__error" data-r="error" style="display:none"></div>
<button class="ar-stripe__btn" data-r="btn" disabled>${escapeHtml8(this._get("buttonLabel", "Pay"))}</button>`;
    this._elMount = this.el.querySelector('[data-r="mount"]');
    this._elError = this.el.querySelector('[data-r="error"]');
    this._elBtn = this.el.querySelector('[data-r="btn"]');
    this._elBtn.addEventListener("click", () => {
      void this._confirm();
    });
    void this._loadAndMount();
  }
  async _loadAndMount() {
    try {
      await loadStripeScript();
    } catch (e) {
      this._showError("Failed to load Stripe: " + e.message);
      return;
    }
    const Stripe2 = window.Stripe;
    if (!Stripe2) {
      this._showError("Stripe.js not available");
      return;
    }
    const apiVersion = this._get("apiVersion", "");
    this._stripe = Stripe2(
      this._get("publishableKey", ""),
      apiVersion ? { apiVersion } : {}
    );
    const elementsCfg = {
      clientSecret: this._get("clientSecret", ""),
      locale: this._get("locale", "auto")
    };
    const appearance = this._get("appearance", {});
    if (Object.keys(appearance).length) elementsCfg.appearance = appearance;
    const stripe = this._stripe;
    this._elements = stripe.elements(elementsCfg);
    const elements = this._elements;
    this._paymentEl = elements.create("payment");
    const paymentEl = this._paymentEl;
    paymentEl.mount(this._elMount);
    this._elBtn.disabled = false;
    this._emit("ready", {});
  }
  async _confirm() {
    if (!this._stripe || !this._elements) {
      this._showError("Not ready yet");
      return;
    }
    this._showError(null);
    this._elBtn.disabled = true;
    const stripe = this._stripe;
    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements: this._elements,
        confirmParams: { return_url: this._get("returnUrl", "") },
        redirect: "if_required"
      });
      this._elBtn.disabled = false;
      if (error) {
        this._showError(error.message || "Payment failed");
        this._emit("error", { message: error.message });
        return;
      }
      if (paymentIntent && (paymentIntent.status === "succeeded" || paymentIntent.status === "requires_capture")) {
        this._emit("success", { intent: paymentIntent });
      } else {
        this._emit("pending", { intent: paymentIntent });
      }
    } catch (e) {
      this._elBtn.disabled = false;
      this._showError(e.message || "Unexpected error");
      this._emit("error", { message: e.message });
    }
  }
  _showError(msg) {
    if (!msg) {
      this._elError.style.display = "none";
      this._elError.textContent = "";
      return;
    }
    this._elError.style.display = "";
    this._elError.textContent = msg;
  }
  _injectStyles() {
    if (document.getElementById("ar-stripe-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-stripe-styles";
    s.textContent = `
.ar-stripe { display:flex; flex-direction:column; gap:12px; padding:16px; background:#1e1e1e; border:1px solid #333; border-radius:8px; max-width:420px; }
.ar-stripe__mount { background:#fff; padding:14px; border-radius:6px; min-height:80px; }
.ar-stripe__error { padding:8px 12px; background:rgba(220,38,38,0.15); border:1px solid #dc2626; border-radius:3px; color:#fca5a5; font:12px sans-serif; }
.ar-stripe__btn { background:#635bff; color:#fff; border:0; padding:12px; font:600 14px sans-serif; border-radius:4px; cursor:pointer; transition:background .12s; }
.ar-stripe__btn:hover:not(:disabled) { background:#4f46e5; }
.ar-stripe__btn:disabled { background:#555; cursor:not-allowed; }
`;
    document.head.appendChild(s);
  }
};
var _stripePromise = null;
function loadStripeScript() {
  if (_stripePromise) return _stripePromise;
  _stripePromise = new Promise((resolve, reject) => {
    if (typeof document === "undefined") {
      reject(new Error("no document"));
      return;
    }
    if (window.Stripe) {
      resolve();
      return;
    }
    const s = document.createElement("script");
    s.src = "https://js.stripe.com/v3/";
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("script load failed"));
    document.head.appendChild(s);
  });
  return _stripePromise;
}
function escapeHtml8(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/payments/Satispay.ts
var Satispay = class extends Control {
  constructor(container, opts) {
    super(container, "div", {
      currency: "EUR",
      mode: "button",
      locale: detectItOrEn(),
      ...opts
    });
    this.el.className = `ar-satispay${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  pay() {
    const url = this._get("redirectUrl", "");
    if (!url) {
      this._emit("error", { message: "redirectUrl not configured" });
      return this;
    }
    this._emit("click", {});
    window.location.href = url;
    return this;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    const mode = this._get("mode", "button");
    const locale = this._get("locale", "it");
    const label = this._get("buttonLabel", "") || (locale === "it" ? "Paga con Satispay" : "Pay with Satispay");
    const qr = this._get("qrCode", "");
    let html = "";
    if (mode === "button" || mode === "both") {
      html += `
<button class="ar-satispay__btn" data-r="btn" type="button">
  <span class="ar-satispay__logo">${SATISPAY_LOGO}</span>
  <span>${escapeHtml9(label)}</span>
</button>`;
    }
    if ((mode === "qr" || mode === "both") && qr) {
      html += `
<div class="ar-satispay__qr-wrap">
  <img class="ar-satispay__qr" src="${qr}" alt="Satispay QR">
  <div class="ar-satispay__qr-label">${escapeHtml9(locale === "it" ? "Scansiona con Satispay" : "Scan with Satispay")}</div>
</div>`;
    }
    this.el.innerHTML = html;
    this.el.querySelector('[data-r="btn"]')?.addEventListener("click", () => this.pay());
    this._emit("ready", { mode });
  }
  _injectStyles() {
    if (document.getElementById("ar-satispay-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-satispay-styles";
    s.textContent = `
.ar-satispay { display:inline-flex; gap:14px; align-items:center; }
.ar-satispay__btn { display:inline-flex; align-items:center; gap:8px; min-width:200px; padding:11px 20px; background:#ff4081; color:#fff; border:0; border-radius:6px; font:600 15px -apple-system,system-ui,sans-serif; cursor:pointer; transition:background .12s; }
.ar-satispay__btn:hover { background:#e91e63; }
.ar-satispay__logo svg { display:block; height:18px; width:auto; }
.ar-satispay__qr-wrap { display:inline-flex; flex-direction:column; align-items:center; gap:8px; padding:14px; background:#fff; border:2px solid #ff4081; border-radius:8px; }
.ar-satispay__qr { width:180px; height:180px; display:block; }
.ar-satispay__qr-label { font:13px sans-serif; color:#ff4081; }
`;
    document.head.appendChild(s);
  }
};
var SATISPAY_LOGO = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true">
<rect width="32" height="32" rx="8" fill="#fff"/>
<path d="M16 8a8 8 0 1 0 0 16 8 8 0 0 0 0-16zm0 13a5 5 0 1 1 0-10 5 5 0 0 1 0 10z" fill="#ff4081"/>
</svg>`;
function detectItOrEn() {
  if (typeof navigator !== "undefined" && navigator.language?.startsWith("it")) return "it";
  return "en";
}
function escapeHtml9(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/payments/Nexi.ts
var Nexi = class extends Control {
  constructor(container, opts) {
    super(container, "div", {
      currency: "EUR",
      openInNewTab: false,
      locale: detectItOrEn2(),
      ...opts
    });
    this.el.className = `ar-nexi${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  pay() {
    const url = this._get("redirectUrl", "");
    if (!url) {
      this._emit("error", { message: "redirectUrl not configured" });
      return this;
    }
    this._emit("click", { transactionCode: this._get("transactionCode", "") });
    if (this._get("openInNewTab", false)) window.open(url, "_blank", "noopener");
    else window.location.href = url;
    return this;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    const locale = this._get("locale", "it");
    const label = this._get("buttonLabel", "") || (locale === "it" ? "Paga con Nexi" : "Pay with Nexi");
    const tx = this._get("transactionCode", "");
    this.el.innerHTML = `
<button class="ar-nexi__btn" data-r="btn" type="button">
  <span class="ar-nexi__logo">${NEXI_LOGO}</span>
  <span>${escapeHtml10(label)}</span>
</button>
${tx ? `<div class="ar-nexi__txn">${escapeHtml10(locale === "it" ? "Codice: " : "Code: ")}${escapeHtml10(tx)}</div>` : ""}`;
    this.el.querySelector('[data-r="btn"]')?.addEventListener("click", () => this.pay());
    this._emit("ready", {});
  }
  _injectStyles() {
    if (document.getElementById("ar-nexi-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-nexi-styles";
    s.textContent = `
.ar-nexi { display:inline-flex; flex-direction:column; gap:6px; align-items:flex-start; }
.ar-nexi__btn { display:inline-flex; align-items:center; gap:8px; min-width:200px; padding:11px 20px; background:#002756; color:#fff; border:0; border-radius:6px; font:600 15px -apple-system,system-ui,sans-serif; cursor:pointer; transition:background .12s; }
.ar-nexi__btn:hover { background:#001a3d; }
.ar-nexi__logo svg { display:block; height:18px; width:auto; }
.ar-nexi__txn { font:11px ui-monospace,monospace; color:#666; }
`;
    document.head.appendChild(s);
  }
};
var NEXI_LOGO = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 24" aria-hidden="true">
<text x="0" y="18" font-family="-apple-system,system-ui,sans-serif" font-size="18" font-weight="700" fill="#ffd200">nexi</text>
</svg>`;
function detectItOrEn2() {
  if (typeof navigator !== "undefined" && navigator.language?.startsWith("it")) return "it";
  return "en";
}
function escapeHtml10(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/payments/AliPay.ts
var AliPay = class extends Control {
  constructor(container, opts) {
    super(container, "div", {
      currency: "CNY",
      openInNewTab: false,
      locale: "en",
      ...opts
    });
    this.el.className = `ar-alipay${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Programmatically invoke the redirect (for mode='redirect' only). */
  pay() {
    const url = this._get("redirectUrl", "");
    if (!url) {
      this._emit("error", { message: "redirectUrl not configured" });
      return this;
    }
    this._emit("click", {});
    if (this._get("openInNewTab", false))
      window.open(url, "_blank", "noopener");
    else
      window.location.href = url;
    return this;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    const mode = this._get("mode", "redirect");
    const locale = this._get("locale", "en");
    const label = this._get("buttonLabel", "") || (locale === "zh" ? "\u4F7F\u7528\u652F\u4ED8\u5B9D\u4ED8\u6B3E" : "Pay with Alipay");
    if (mode === "qr") {
      const qr = this._get("qrCode", "");
      this.el.innerHTML = `
<div class="ar-alipay__qr-wrap">
  ${qr ? `<img class="ar-alipay__qr" src="${qr}" alt="Alipay QR">` : `<div class="ar-alipay__qr ar-alipay__qr--missing">QR code missing</div>`}
  <div class="ar-alipay__qr-label">
    <span class="ar-alipay__brand">${ALIPAY_LOGO}</span>
    <span>${escapeHtml11(locale === "zh" ? "\u8BF7\u4F7F\u7528\u652F\u4ED8\u5B9D\u626B\u63CF\u4E8C\u7EF4\u7801" : "Scan with Alipay")}</span>
  </div>
</div>`;
    } else {
      this.el.innerHTML = `
<button class="ar-alipay__btn" data-r="btn" type="button">
  <span class="ar-alipay__brand">${ALIPAY_LOGO}</span>
  <span>${escapeHtml11(label)}</span>
</button>`;
      this.el.querySelector('[data-r="btn"]')?.addEventListener("click", () => this.pay());
    }
    this._emit("ready", { mode });
  }
  _injectStyles() {
    if (document.getElementById("ar-alipay-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-alipay-styles";
    s.textContent = `
.ar-alipay { display:inline-block; }
.ar-alipay__btn { display:inline-flex; align-items:center; gap:8px; min-width:200px; padding:11px 20px; background:#1677ff; color:#fff; border:0; border-radius:6px; font:600 15px -apple-system,system-ui,sans-serif; cursor:pointer; transition:background .12s; }
.ar-alipay__btn:hover { background:#0958d9; }
.ar-alipay__brand { font:700 16px sans-serif; letter-spacing:.02em; }
.ar-alipay__brand svg { display:block; height:18px; }
.ar-alipay__qr-wrap { display:inline-flex; flex-direction:column; align-items:center; gap:10px; padding:16px; background:#fff; border:2px solid #1677ff; border-radius:8px; }
.ar-alipay__qr { width:200px; height:200px; display:block; background:#f3f4f6; }
.ar-alipay__qr--missing { display:flex; align-items:center; justify-content:center; color:#888; font:13px sans-serif; }
.ar-alipay__qr-label { display:flex; align-items:center; gap:8px; font:13px sans-serif; color:#1677ff; }
`;
    document.head.appendChild(s);
  }
};
var ALIPAY_LOGO = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true">
<rect width="32" height="32" rx="6" fill="#1677ff"/>
<text x="16" y="22" text-anchor="middle" font-family="-apple-system,system-ui,sans-serif" font-size="14" font-weight="700" fill="#fff">\u652F</text>
</svg>`;
function escapeHtml11(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/payments/PaymentGateway.ts
var METHOD_META = [
  { id: "applePay", label: "Apple Pay", icon: "" },
  { id: "googlePay", label: "Google Pay", icon: "G" },
  { id: "card", label: "Credit / Debit Card", icon: "\u25A3" },
  { id: "paypal", label: "PayPal", icon: "P" },
  { id: "stripe", label: "Stripe", icon: "S" },
  { id: "satispay", label: "Satispay", icon: "\u25C9" },
  { id: "nexi", label: "Nexi", icon: "n" },
  { id: "alipay", label: "Alipay", icon: "\u652F" }
];
var PaymentGateway = class extends Control {
  _selected = null;
  /** Lazily-instantiated child widgets, keyed by method id. */
  _children = {};
  _elList;
  _elPanel;
  constructor(container, opts) {
    super(container, "div", {
      title: detectIt() ? "Scegli come pagare" : "Choose how to pay",
      locale: detectIt() ? "it" : "en",
      ...opts
    });
    this.el.className = `ar-pg${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
    const initial = opts.initial ?? this._availableMethods()[0];
    if (initial) this.select(initial);
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Methods the merchant has actually configured (in display order). */
  getAvailableMethods() {
    return this._availableMethods();
  }
  /** Currently-selected method id, or null. */
  getSelected() {
    return this._selected;
  }
  /** Select a payment method (rebuilds the panel). */
  select(id) {
    if (!this._availableMethods().includes(id)) {
      this._emit("error", { method: id, message: "method not configured" });
      return this;
    }
    this._selected = id;
    this._refreshList();
    this._buildPanel();
    this._emit("select", { method: id });
    return this;
  }
  /** Trigger pay() on the currently-selected child widget, if it has one. */
  pay() {
    const id = this._selected;
    if (!id) {
      this._emit("error", { method: null, message: "no method selected" });
      return this;
    }
    const child = this._children[id];
    if (child && typeof child.pay === "function") {
      void child.pay();
    }
    return this;
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = `
<div class="ar-pg__head">
  <span class="ar-pg__title">${escapeHtml12(this._get("title", "Choose how to pay"))}</span>
  <span class="ar-pg__total">${this._formatTotal()}</span>
</div>
<div class="ar-pg__body">
  <div class="ar-pg__list" data-r="list"></div>
  <div class="ar-pg__panel" data-r="panel"></div>
</div>`;
    this._elList = this.el.querySelector('[data-r="list"]');
    this._elPanel = this.el.querySelector('[data-r="panel"]');
    this._refreshList();
  }
  _refreshList() {
    this._elList.innerHTML = "";
    for (const id of this._availableMethods()) {
      const meta = METHOD_META.find((m) => m.id === id);
      const row = document.createElement("button");
      row.type = "button";
      row.className = "ar-pg__row" + (id === this._selected ? " ar-pg__row--selected" : "");
      row.dataset.id = id;
      row.innerHTML = `
<span class="ar-pg__radio">${id === this._selected ? "\u25C9" : "\u25CB"}</span>
<span class="ar-pg__icon">${escapeHtml12(meta.icon)}</span>
<span class="ar-pg__label">${escapeHtml12(meta.label)}</span>`;
      row.addEventListener("click", () => this.select(id));
      this._elList.appendChild(row);
    }
  }
  _buildPanel() {
    this._elPanel.innerHTML = "";
    if (!this._selected) return;
    const mount = document.createElement("div");
    mount.className = "ar-pg__mount";
    mount.dataset.method = this._selected;
    this._elPanel.appendChild(mount);
    if (this._children[this._selected]) {
      const cached = this._children[this._selected];
      mount.appendChild(cached.el);
      return;
    }
    const amount = this._get("amount", 0);
    const currency = this._get("currency", "EUR");
    const cfg = this._get("methods", {});
    let child = null;
    const stripTotals = (o) => o ? { ...o, amount: void 0, currency: void 0 } : {};
    switch (this._selected) {
      case "applePay":
        child = new ApplePay(mount, { amount, currency, ...stripTotals(cfg.applePay) });
        break;
      case "googlePay":
        child = new GooglePay(mount, { amount, currency, ...stripTotals(cfg.googlePay) });
        break;
      case "card":
        child = new CreditCard(mount, { amount, currency, ...stripTotals(cfg.card) });
        break;
      case "paypal":
        child = new PayPal(mount, { amount, currency, ...stripTotals(cfg.paypal) });
        break;
      case "stripe":
        child = new Stripe(mount, { ...cfg.stripe });
        break;
      case "satispay":
        child = new Satispay(mount, { amount, currency, ...stripTotals(cfg.satispay) });
        break;
      case "nexi":
        child = new Nexi(mount, { amount, currency, ...stripTotals(cfg.nexi) });
        break;
      case "alipay":
        child = new AliPay(mount, { amount, currency, ...stripTotals(cfg.alipay) });
        break;
    }
    if (child) {
      this._children[this._selected] = child;
      for (const evt of ["ready", "submit", "success", "error", "cancel", "click", "pending"]) {
        child.on(evt, (data) => this._emit(evt, { method: this._selected, ...data }));
      }
    }
  }
  _availableMethods() {
    const cfg = this._get("methods", {});
    const order = this._get("order", METHOD_META.map((m) => m.id));
    return order.filter((id) => cfg[id] !== void 0);
  }
  _formatTotal() {
    const amount = this._get("amount", 0);
    const currency = this._get("currency", "EUR");
    const locale = this._get("locale", "en");
    try {
      const fmt2 = new Intl.NumberFormat(locale === "it" ? "it-IT" : "en-US", {
        style: "currency",
        currency
      });
      return fmt2.format(amount);
    } catch {
      return `${currency} ${amount.toFixed(2)}`;
    }
  }
  _injectStyles() {
    if (document.getElementById("ar-pg-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-pg-styles";
    s.textContent = `
.ar-pg { display:flex; flex-direction:column; max-width:720px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:13px -apple-system,system-ui,sans-serif; }
.ar-pg__head { display:flex; align-items:baseline; justify-content:space-between; padding:14px 18px; border-bottom:1px solid #333; }
.ar-pg__title { font:600 14px sans-serif; }
.ar-pg__total { font:600 16px ui-monospace,monospace; color:#e40c88; }
.ar-pg__body { display:flex; min-height:240px; }
.ar-pg__list  { width:240px; flex-shrink:0; border-right:1px solid #333; padding:8px; display:flex; flex-direction:column; gap:2px; }
.ar-pg__row   { display:flex; align-items:center; gap:10px; padding:10px 12px; background:transparent; border:0; color:#d4d4d4; cursor:pointer; border-radius:4px; text-align:left; font:13px sans-serif; }
.ar-pg__row:hover { background:#2a2a2a; }
.ar-pg__row--selected { background:rgba(228,12,136,0.15); border-left:3px solid #e40c88; padding-left:9px; }
.ar-pg__radio { font-size:14px; color:#888; width:14px; }
.ar-pg__row--selected .ar-pg__radio { color:#e40c88; }
.ar-pg__icon  { width:22px; text-align:center; font:600 14px sans-serif; }
.ar-pg__label { flex:1; }
.ar-pg__panel { flex:1; padding:18px; min-height:200px; display:flex; align-items:flex-start; }
.ar-pg__mount { width:100%; }
`;
    document.head.appendChild(s);
  }
};
function detectIt() {
  if (typeof navigator !== "undefined" && navigator.language?.startsWith("it")) return true;
  return false;
}
function escapeHtml12(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/shipments/Tracker.ts
var Tracker = class extends Control {
  _events = [];
  _elList;
  _elHeader;
  _elFooter;
  constructor(container, opts) {
    super(container, "div", {
      showPortalLink: true,
      openInNewTab: true,
      ...opts
    });
    this.el.className = `ar-trk ar-trk--${this._carrier().id}${opts.class ? " " + opts.class : ""}`;
    this._events = (opts.events ?? []).slice();
    this._injectSharedStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Replace the events list. Most-recent-first ordering is enforced. */
  setEvents(events) {
    this._events = events.slice().sort((a, b) => b.at - a.at);
    this._renderTimeline();
    this._emit("events", { events: this._events.slice() });
    return this;
  }
  /** Append a single event (maintains sort order). */
  addEvent(e) {
    return this.setEvents([...this._events, e]);
  }
  /** Current events (deep cloned). */
  getEvents() {
    return this._events.map((e) => ({ ...e }));
  }
  /** The latest event, or null. */
  getLatest() {
    return this._events[0] ?? null;
  }
  /** The carrier-specific public URL for the current tracking number. */
  getPortalUrl() {
    const n = encodeURIComponent(this._get("trackingNumber", ""));
    return this._carrier().publicUrl.replace("{n}", n);
  }
  /** Open the carrier portal. */
  openPortal() {
    const url = this.getPortalUrl();
    this._emit("open-portal", { url });
    if (this._get("openInNewTab", true)) window.open(url, "_blank", "noopener");
    else window.location.href = url;
    return this;
  }
  /**
   * Validate the configured tracking number against the carrier's pattern.
   * Returns null if valid, or an error message.
   */
  validate() {
    const n = (this._get("trackingNumber", "") || "").trim();
    if (!n) return "tracking number missing";
    const p = this._carrier().pattern;
    if (p && !p.test(n)) return `does not look like a ${this._carrier().name} tracking number`;
    return null;
  }
  // ── Internal build / render ────────────────────────────────────────────
  _build() {
    const c = this._carrier();
    this.el.innerHTML = `
<div class="ar-trk__header" data-r="header"></div>
<div class="ar-trk__list"   data-r="list"></div>
<div class="ar-trk__footer" data-r="footer"></div>`;
    this._elHeader = this.el.querySelector('[data-r="header"]');
    this._elList = this.el.querySelector('[data-r="list"]');
    this._elFooter = this.el.querySelector('[data-r="footer"]');
    this._elHeader.style.borderLeft = `4px solid ${c.color}`;
    this._elHeader.innerHTML = `
<span class="ar-trk__logo">${c.logo}</span>
<span class="ar-trk__carrier">${escapeHtml13(c.name)}</span>
<span class="ar-trk__number">${escapeHtml13(this._get("trackingNumber", ""))}</span>`;
    this._renderTimeline();
    if (this._get("showPortalLink", true)) {
      this._elFooter.innerHTML = `<button class="ar-trk__portal" data-r="portal" type="button">Track on ${escapeHtml13(c.name)} \u2192</button>`;
      this._elFooter.querySelector('[data-r="portal"]')?.addEventListener("click", () => this.openPortal());
    }
  }
  _renderTimeline() {
    if (!this._events.length) {
      this._elList.innerHTML = `<div class="ar-trk__empty">No tracking updates yet.</div>`;
      return;
    }
    const locale = this._get("locale", "") || void 0;
    const html = this._events.map((e, i) => {
      const top = i === 0;
      return `
<div class="ar-trk__row${top ? " ar-trk__row--top" : ""} ar-trk__row--${e.kind}">
  <div class="ar-trk__dot"></div>
  <div class="ar-trk__body">
    <div class="ar-trk__kind">${escapeHtml13(EVENT_LABEL[e.kind] ?? e.kind)}</div>
    ${e.raw ? `<div class="ar-trk__raw">${escapeHtml13(e.raw)}</div>` : ""}
    <div class="ar-trk__meta">
      ${e.location ? `<span class="ar-trk__loc">${escapeHtml13(e.location)}</span>` : ""}
      <span class="ar-trk__time">${formatTime4(e.at, locale)}</span>
    </div>
  </div>
</div>`;
    }).join("");
    this._elList.innerHTML = html;
  }
  _injectSharedStyles() {
    if (document.getElementById("ar-trk-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-trk-styles";
    s.textContent = `
.ar-trk { display:flex; flex-direction:column; max-width:520px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:13px -apple-system,system-ui,sans-serif; overflow:hidden; }
.ar-trk__header { display:flex; align-items:center; gap:10px; padding:12px 16px; background:#252525; border-bottom:1px solid #333; }
.ar-trk__logo svg { display:block; height:20px; width:auto; }
.ar-trk__carrier { font:600 14px sans-serif; flex:1; }
.ar-trk__number  { font:12px ui-monospace,monospace; color:#888; }
.ar-trk__list { padding:12px 16px; max-height:340px; overflow-y:auto; }
.ar-trk__empty { padding:30px 0; text-align:center; color:#666; font-size:12px; }
.ar-trk__row { display:flex; gap:12px; padding-bottom:12px; position:relative; }
.ar-trk__row:not(:last-child)::before { content:''; position:absolute; left:5px; top:14px; bottom:0; width:2px; background:#333; }
.ar-trk__dot { width:12px; height:12px; border-radius:50%; background:#333; flex-shrink:0; margin-top:2px; z-index:1; border:2px solid #1e1e1e; }
.ar-trk__row--top .ar-trk__dot { background:#22c55e; box-shadow:0 0 6px rgba(34,197,94,0.6); }
.ar-trk__row--exception .ar-trk__dot, .ar-trk__row--failed .ar-trk__dot { background:#dc2626; }
.ar-trk__row--customs .ar-trk__dot, .ar-trk__row--returned .ar-trk__dot { background:#eab308; }
.ar-trk__body { flex:1; min-width:0; }
.ar-trk__kind { font:600 13px sans-serif; }
.ar-trk__raw { font:12px sans-serif; color:#888; margin:1px 0; }
.ar-trk__meta { display:flex; gap:8px; font:11px sans-serif; color:#888; margin-top:2px; }
.ar-trk__loc::after  { content:'\xB7'; margin-left:8px; }
.ar-trk__footer { padding:10px 16px; background:#181818; border-top:1px solid #333; }
.ar-trk__portal { width:100%; background:transparent; border:1px solid #444; color:#d4d4d4; padding:8px 14px; font:600 12px sans-serif; border-radius:4px; cursor:pointer; transition:all .12s; }
.ar-trk__portal:hover { background:#2a2a2a; border-color:#666; }
`;
    document.head.appendChild(s);
  }
};
var EVENT_LABEL = {
  "created": "Label created",
  "picked-up": "Picked up",
  "in-transit": "In transit",
  "arrived": "Arrived at hub",
  "customs": "Customs clearance",
  "out-delivery": "Out for delivery",
  "delivered": "Delivered",
  "failed": "Delivery attempt failed",
  "returned": "Returned to sender",
  "exception": "Exception",
  "unknown": "Update"
};
function formatTime4(at, locale) {
  const d = new Date(at);
  const date = d.toLocaleDateString(locale, { day: "2-digit", month: "short" });
  const time = d.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" });
  return `${date}, ${time}`;
}
function escapeHtml13(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/shipments/DHLTracker.ts
var DHL = {
  id: "dhl",
  name: "DHL",
  color: "#d40511",
  publicUrl: "https://www.dhl.com/it-it/home/tracciamento.html?tracking-id={n}",
  pattern: /^(\d{10,11}|[A-Z]{3}\d{7})$/i,
  logo: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 22" aria-hidden="true">
<rect width="64" height="22" fill="#ffcc00"/>
<text x="32" y="16" text-anchor="middle" font-family="Arial,sans-serif" font-size="13" font-weight="900" fill="#d40511" letter-spacing="1">DHL</text>
</svg>`
};
var DHLTracker = class extends Tracker {
  constructor(container, opts) {
    super(container, opts);
  }
  _carrier() {
    return DHL;
  }
};

// components/shipments/UPSTracker.ts
var UPS = {
  id: "ups",
  name: "UPS",
  color: "#644117",
  publicUrl: "https://www.ups.com/track?tracknum={n}",
  pattern: /^1Z[0-9A-Z]{16}$/i,
  logo: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 22" aria-hidden="true">
<rect width="64" height="22" rx="3" fill="#644117"/>
<text x="32" y="16" text-anchor="middle" font-family="Arial,sans-serif" font-size="13" font-weight="900" fill="#ffcc00" letter-spacing="1">UPS</text>
</svg>`
};
var UPSTracker = class extends Tracker {
  constructor(container, opts) {
    super(container, opts);
  }
  _carrier() {
    return UPS;
  }
};

// components/shipments/FedExTracker.ts
var FEDEX = {
  id: "fedex",
  name: "FedEx",
  color: "#4d148c",
  publicUrl: "https://www.fedex.com/fedextrack/?trknbr={n}",
  pattern: /^(\d{12}|\d{15}|\d{20})$/,
  logo: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 22" aria-hidden="true">
<text x="0"  y="17" font-family="Arial Black,Arial,sans-serif" font-size="17" font-weight="900" fill="#4d148c">Fed</text>
<text x="36" y="17" font-family="Arial Black,Arial,sans-serif" font-size="17" font-weight="900" fill="#ff6600">Ex</text>
</svg>`
};
var FedExTracker = class extends Tracker {
  constructor(container, opts) {
    super(container, opts);
  }
  _carrier() {
    return FEDEX;
  }
};

// components/shipments/BRTTracker.ts
var BRT = {
  id: "brt",
  name: "BRT",
  color: "#e3000b",
  publicUrl: "https://vas.brt.it/vas/sped_det_show.hsm?referer=sped_numspe_par.htm&Nspediz={n}",
  pattern: /^\d{10,12}$/,
  logo: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 22" aria-hidden="true">
<rect width="64" height="22" rx="3" fill="#e3000b"/>
<text x="32" y="16" text-anchor="middle" font-family="Arial,sans-serif" font-size="13" font-weight="900" fill="#fff" letter-spacing="1">BRT</text>
</svg>`
};
var BRTTracker = class extends Tracker {
  constructor(container, opts) {
    super(container, opts);
  }
  _carrier() {
    return BRT;
  }
};

// components/shipments/TrackingMulti.ts
var CARRIERS = [
  { id: "ups", name: "UPS", pattern: /^1Z[0-9A-Z]{16}$/i, factory: (m, o) => new UPSTracker(m, o) },
  { id: "fedex", name: "FedEx", pattern: /^(\d{12}|\d{15}|\d{20})$/, factory: (m, o) => new FedExTracker(m, o) },
  { id: "dhl", name: "DHL", pattern: /^(\d{10,11}|[A-Z]{3}\d{7})$/i, factory: (m, o) => new DHLTracker(m, o) },
  { id: "brt", name: "BRT", pattern: /^\d{10,12}$/, factory: (m, o) => new BRTTracker(m, o) }
];
var TrackingMulti = class extends Control {
  _number = "";
  _carrier = null;
  _events = [];
  _active = null;
  _elInput;
  _elBtn;
  _elPicker;
  _elMount;
  constructor(container, opts = {}) {
    super(container, "div", { showInput: true, ...opts });
    this.el.className = `ar-trk-multi${opts.class ? " " + opts.class : ""}`;
    this._number = opts.trackingNumber ?? "";
    this._carrier = opts.carrier ?? null;
    this._events = opts.events ?? [];
    this._injectStyles();
    this._build();
    if (this._number) {
      if (this._carrier) this._mount(this._carrier);
      else this._autoDetect();
    }
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Currently-detected (or forced) carrier id, or null. */
  getCarrier() {
    return this._carrier;
  }
  /** Current tracking number. */
  getNumber() {
    return this._number;
  }
  /** Active sub-Tracker instance, or null. */
  getActive() {
    return this._active;
  }
  /**
   * Set / change the tracking number. Triggers auto-detection unless
   * `carrier` was forced via the constructor or `setCarrier`.
   */
  setNumber(n) {
    this._number = n.trim();
    if (this._elInput) this._elInput.value = this._number;
    if (!this._number) {
      this._unmount();
      return this;
    }
    if (this._carrier) this._mount(this._carrier);
    else this._autoDetect();
    return this;
  }
  /** Force a specific carrier (skips auto-detection). */
  setCarrier(id) {
    this._carrier = id;
    if (this._number) this._mount(id);
    return this;
  }
  /**
   * Forward events to the active subcomponent. If no carrier is mounted
   * yet, the events are buffered and applied when one becomes active.
   */
  setEvents(events) {
    this._events = events.slice();
    if (this._active) this._active.setEvents(this._events);
    return this;
  }
  /** Carriers whose pattern matches the current tracking number. */
  getCandidates() {
    if (!this._number) return [];
    return CARRIERS.filter((c) => c.pattern.test(this._number)).map((c) => c.id);
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    const showInput = this._get("showInput", true);
    this.el.innerHTML = `
${showInput ? `
<div class="ar-trk-multi__head">
  <input class="ar-trk-multi__inp" data-r="inp" type="text" placeholder="Tracking number">
  <button class="ar-trk-multi__btn" data-r="btn" type="button">Track</button>
</div>` : ""}
<div class="ar-trk-multi__picker" data-r="picker" style="display:none"></div>
<div class="ar-trk-multi__mount"  data-r="mount"></div>`;
    if (showInput) {
      this._elInput = this.el.querySelector('[data-r="inp"]');
      this._elBtn = this.el.querySelector('[data-r="btn"]');
      this._elInput.value = this._number;
      this._elInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") this.setNumber(this._elInput.value);
      });
      this._elBtn.addEventListener("click", () => this.setNumber(this._elInput.value));
    }
    this._elPicker = this.el.querySelector('[data-r="picker"]');
    this._elMount = this.el.querySelector('[data-r="mount"]');
  }
  _autoDetect() {
    const candidates = this.getCandidates();
    if (candidates.length === 0) {
      this._showPicker(`No known carrier matches this format.`, [], null);
      this._unmount();
      this._emit("not-recognised", { number: this._number });
      return;
    }
    if (candidates.length === 1) {
      this._hidePicker();
      this._mount(candidates[0]);
      this._emit("detected", { carrier: candidates[0], number: this._number });
      return;
    }
    this._showPicker(`This number could be from multiple carriers \u2014 pick one:`, candidates, candidates[0]);
    this._mount(candidates[0]);
    this._emit("ambiguous", { carriers: candidates, number: this._number });
  }
  _showPicker(label, candidates, selected) {
    this._elPicker.style.display = "";
    this._elPicker.innerHTML = `
<div class="ar-trk-multi__picker-label">${escapeHtml14(label)}</div>
${candidates.length ? `<div class="ar-trk-multi__picker-row">
  ${candidates.map((id) => {
      const c = CARRIERS.find((x) => x.id === id);
      const sel = id === selected;
      return `<label class="ar-trk-multi__picker-opt${sel ? " ar-trk-multi__picker-opt--sel" : ""}">
        <input type="radio" name="ar-trk-pick" data-pick="${id}"${sel ? " checked" : ""}>
        <span>${escapeHtml14(c.name)}</span>
      </label>`;
    }).join("")}
</div>` : ""}`;
    this._elPicker.querySelectorAll("[data-pick]").forEach((r) => {
      r.addEventListener("change", () => {
        if (!r.checked) return;
        const id = r.dataset.pick;
        this._mount(id);
        this._elPicker.querySelectorAll(".ar-trk-multi__picker-opt").forEach((el) => el.classList.toggle("ar-trk-multi__picker-opt--sel", el.contains(r)));
        this._emit("select", { carrier: id, number: this._number });
      });
    });
  }
  _hidePicker() {
    this._elPicker.style.display = "none";
    this._elPicker.innerHTML = "";
  }
  _mount(id) {
    if (this._active && this._carrier === id) return;
    this._unmount();
    const entry = CARRIERS.find((c) => c.id === id);
    if (!entry) return;
    this._carrier = id;
    const inner = document.createElement("div");
    this._elMount.appendChild(inner);
    this._active = entry.factory(inner, {
      trackingNumber: this._number,
      events: this._events,
      locale: this._get("locale", "") || void 0
    });
    for (const evt of ["events", "open-portal"]) {
      this._active.on(evt, (data) => this._emit(evt, { carrier: id, ...data }));
    }
  }
  _unmount() {
    this._elMount.innerHTML = "";
    this._active = null;
  }
  _injectStyles() {
    if (document.getElementById("ar-trk-multi-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-trk-multi-styles";
    s.textContent = `
.ar-trk-multi { display:flex; flex-direction:column; gap:10px; max-width:520px; font:13px -apple-system,system-ui,sans-serif; }
.ar-trk-multi__head { display:flex; gap:6px; }
.ar-trk-multi__inp  { flex:1; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:9px 12px; font:13px ui-monospace,monospace; border-radius:4px; }
.ar-trk-multi__inp:focus { outline:none; border-color:#e40c88; }
.ar-trk-multi__btn  { background:#e40c88; color:#fff; border:0; padding:9px 18px; font:600 13px sans-serif; border-radius:4px; cursor:pointer; }
.ar-trk-multi__btn:hover { background:#c30b75; }
.ar-trk-multi__picker { padding:10px 12px; background:#252525; border:1px solid #444; border-radius:4px; }
.ar-trk-multi__picker-label { font:12px sans-serif; color:#eab308; margin-bottom:6px; }
.ar-trk-multi__picker-row { display:flex; flex-wrap:wrap; gap:8px; }
.ar-trk-multi__picker-opt { display:inline-flex; gap:6px; align-items:center; padding:4px 10px; background:#1e1e1e; border:1px solid #444; border-radius:14px; cursor:pointer; font:12px sans-serif; }
.ar-trk-multi__picker-opt:hover { border-color:#666; }
.ar-trk-multi__picker-opt--sel { border-color:#e40c88; background:rgba(228,12,136,0.15); }
.ar-trk-multi__picker-opt input { margin:0; }
`;
    document.head.appendChild(s);
  }
};
function escapeHtml14(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// components/video/VideoPlayer.ts
function resolveTwitchParents(override) {
  if (override !== void 0) {
    const list = Array.isArray(override) ? override : [override];
    const cleaned = list.map((s) => s.trim()).filter(Boolean);
    if (cleaned.length > 0) return cleaned;
  }
  const host = typeof location !== "undefined" && location.hostname || "";
  return host ? [host] : ["localhost"];
}
function detectVideoProvider(url, twitchParent) {
  if (!url) return null;
  let m = url.match(/^https?:\/\/(?:www\.)?youtu\.be\/([\w-]{6,})/i);
  if (m) return ytEmbed(m[1]);
  m = url.match(/^https?:\/\/(?:www\.|m\.)?youtube\.com\/watch\?(?:[^#]*&)?v=([\w-]{6,})/i);
  if (m) return ytEmbed(m[1]);
  m = url.match(/^https?:\/\/(?:www\.|m\.)?youtube\.com\/(?:shorts|embed|v)\/([\w-]{6,})/i);
  if (m) return ytEmbed(m[1]);
  m = url.match(/^https?:\/\/(?:www\.)?vimeo\.com\/(?:video\/)?(\d{6,})/i);
  if (m) return vimeoEmbed(m[1]);
  m = url.match(/^https?:\/\/player\.vimeo\.com\/video\/(\d{6,})/i);
  if (m) return vimeoEmbed(m[1]);
  const parents = resolveTwitchParents(twitchParent);
  m = url.match(/^https?:\/\/(?:www\.)?twitch\.tv\/videos\/(\d+)/i);
  if (m) return twitchEmbed("video", m[1], parents);
  m = url.match(/^https?:\/\/clips\.twitch\.tv\/([\w-]+)/i);
  if (m) return twitchEmbed("clip", m[1], parents);
  m = url.match(/^https?:\/\/(?:www\.)?twitch\.tv\/([\w-]+)\/clip\/([\w-]+)/i);
  if (m) return twitchEmbed("clip", m[2], parents);
  m = url.match(/^https?:\/\/(?:www\.)?twitch\.tv\/([a-zA-Z0-9_]{3,})$/i);
  if (m) return twitchEmbed("channel", m[1], parents);
  return null;
}
function ytEmbed(id) {
  return {
    provider: "youtube",
    id,
    embed: `https://www.youtube.com/embed/${id}?enablejsapi=1&playsinline=1&rel=0`
  };
}
function vimeoEmbed(id) {
  return {
    provider: "vimeo",
    id,
    embed: `https://player.vimeo.com/video/${id}?api=1`
  };
}
function twitchEmbed(kind, id, parents) {
  const base = kind === "clip" ? "https://clips.twitch.tv/embed" : "https://player.twitch.tv";
  const param = kind === "clip" ? "clip=" : kind === "channel" ? "channel=" : "video=";
  const parentParams = parents.map((p) => `&parent=${encodeURIComponent(p)}`).join("");
  return {
    provider: "twitch",
    id,
    embed: `${base}/?${param}${encodeURIComponent(id)}${parentParams}`
  };
}
var VideoPlayer = class extends AudioComponent {
  // Native-mode internals (only assigned when provider === 'native')
  _video;
  _mediaSrc;
  _gain;
  // Embed-mode internals (only assigned when provider !== 'native')
  _iframe;
  // Current provider state
  _provider = "native";
  _sourceUrl = "";
  // Cached state (kept up to date by event listeners; used in embed mode where
  // the provider iframe doesn't expose synchronous getters).
  _isPlaying = false;
  _curTime = 0;
  _duration = 0;
  _volume = 1;
  // Polling handle for embed-mode time updates
  _pollHandle = null;
  // Shell DOM refs (controls)
  _elPlay;
  _elTime;
  _elBar;
  _elVolume;
  _elDur;
  _elFs;
  _elStage;
  // postMessage handler bound once for cleanup
  _onMessageBound = (e) => this._onProviderMessage(e);
  constructor(container, opts = {}) {
    super(container, "div", {
      loop: false,
      volume: 1,
      autoplay: false,
      showControls: true,
      aspectRatio: "16/9",
      ...opts
    });
    this.el.className = `ar-videoplayer${opts.class ? " " + opts.class : ""}`;
    this._volume = this._get("volume", 1);
    this._injectStyles();
    this._buildShell();
    const initial = opts.Source ?? opts.src;
    if (initial) this.load(initial, opts.poster);
    window.addEventListener("message", this._onMessageBound);
  }
  // ── Public API ──────────────────────────────────────────────────────────
  /**
   * Current source URL. Setting this re-detects the provider, swaps
   * between native <video> and the appropriate <iframe> embed, and resumes
   * playback if `autoplay` is set.
   */
  get Source() {
    return this._sourceUrl;
  }
  set Source(url) {
    this.load(url);
  }
  /** Currently active provider (native | youtube | twitch | vimeo). */
  get provider() {
    return this._provider;
  }
  /**
   * Load a new source. Detects the provider, swaps the underlying element
   * (`<video>` ↔ `<iframe>`), and re-applies user options (volume, loop,
   * poster). Returns this for chaining.
   *
   * Note on first-load: the constructor leaves `_provider` set to `'native'`
   * but does NOT actually create a `<video>` element until a Source arrives.
   * That's why we trigger `_setupNative()` / `_setupEmbed()` either when the
   * provider changes OR when the corresponding underlying element is still
   * missing — without the latter, calling `load('movie.mp4')` on a freshly
   * constructed player would dereference `this._video` before it exists.
   */
  load(url, poster) {
    const info = detectVideoProvider(url, this._get("twitchParent", void 0));
    const next = info ? info.provider : "native";
    this._sourceUrl = url;
    const needsSetup = next !== this._provider || next === "native" && !this._video || next !== "native" && !this._iframe;
    if (needsSetup) {
      this._teardownMedia();
      this._provider = next;
      if (next === "native") this._setupNative();
      else this._setupEmbed();
    }
    if (next === "native") {
      this._video.src = url;
      if (poster) this._video.poster = poster;
      this._video.load();
    } else {
      this._iframe.src = info.embed;
    }
    this._refreshTime();
    return this;
  }
  play() {
    if (this._provider === "native") {
      AudioComponent.resume();
      return this._video.play();
    }
    this._postProvider({ event: "play" });
    return Promise.resolve();
  }
  pause() {
    if (this._provider === "native") this._video.pause();
    else this._postProvider({ event: "pause" });
    return this;
  }
  stop() {
    if (this._provider === "native") {
      this._video.pause();
      this._video.currentTime = 0;
    } else {
      this._postProvider({ event: "pause" });
      this._postProvider({ event: "seek", value: 0 });
    }
    return this;
  }
  seek(time) {
    if (this._provider === "native") {
      this._video.currentTime = Math.max(0, Math.min(time, this._video.duration || 0));
    } else {
      this._postProvider({ event: "seek", value: Math.max(0, time) });
    }
    return this;
  }
  setVolume(v) {
    const c = Math.max(0, Math.min(1, v));
    this._volume = c;
    if (this._provider === "native") {
      this._video.volume = c;
      if (this._gain) this._gain.gain.value = c;
    } else {
      this._postProvider({ event: "volume", value: c });
    }
    if (this._elVolume) this._elVolume.value = String(c);
    return this;
  }
  setLoop(loop) {
    if (this._provider === "native") this._video.loop = loop;
    return this;
  }
  fullscreen() {
    const el = this._video ?? this._iframe;
    if (el && el.requestFullscreen) el.requestFullscreen();
    return this;
  }
  getCurrentTime() {
    return this._provider === "native" ? this._video?.currentTime ?? 0 : this._curTime;
  }
  getDuration() {
    return this._provider === "native" ? this._video?.duration ?? 0 : this._duration;
  }
  isPlaying() {
    return this._provider === "native" ? !(this._video?.paused ?? true) : this._isPlaying;
  }
  /** Returns the underlying <video> when in native mode, the <iframe> for embeds. */
  getElement() {
    return this._video ?? this._iframe;
  }
  /** Web Audio output node — only available in native mode. */
  getOutput() {
    if (this._provider !== "native") {
      console.warn("[VideoPlayer] Web Audio routing not available for provider:", this._provider);
      return void 0;
    }
    return this._gain;
  }
  /** Clean up listeners, postMessage handler, and audio graph. */
  destroy() {
    window.removeEventListener("message", this._onMessageBound);
    this._stopEmbedPolling();
    this._teardownMedia();
  }
  // ── Internal: native video setup ───────────────────────────────────────
  /** Required by AudioComponent abstract — actual graph is built lazily. */
  _buildAudioGraph() {
  }
  _build() {
  }
  _setupNative() {
    const v = document.createElement("video");
    v.crossOrigin = "anonymous";
    v.loop = this._get("loop", false);
    v.volume = this._volume;
    v.autoplay = this._get("autoplay", false);
    v.playsInline = true;
    this._video = v;
    this._mediaSrc = this._audioCtx.createMediaElementSource(v);
    this._gain = this._audioCtx.createGain();
    this._gain.gain.value = this._volume;
    this._mediaSrc.connect(this._gain);
    this._gain.connect(this._audioCtx.destination);
    this._output = this._gain;
    this._elStage.innerHTML = "";
    this._elStage.appendChild(v);
    v.addEventListener("play", () => {
      this._isPlaying = true;
      this._emit("play", { provider: "native" });
    });
    v.addEventListener("pause", () => {
      this._isPlaying = false;
      this._emit("pause", { provider: "native" });
    });
    v.addEventListener("ended", () => {
      this._isPlaying = false;
      this._emit("ended", { provider: "native" });
    });
    v.addEventListener("timeupdate", () => {
      this._refreshTime();
      this._emit("timeupdate", { time: v.currentTime, duration: v.duration, provider: "native" });
    });
    v.addEventListener("loadedmetadata", () => {
      this._refreshTime();
      this._emit("loaded", {
        duration: v.duration,
        width: v.videoWidth,
        height: v.videoHeight,
        provider: "native"
      });
    });
  }
  // ── Internal: embed iframe setup ───────────────────────────────────────
  _setupEmbed() {
    const f = document.createElement("iframe");
    f.setAttribute("frameborder", "0");
    f.setAttribute("allow", "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share");
    f.setAttribute("allowfullscreen", "true");
    f.style.width = "100%";
    f.style.height = "100%";
    f.style.border = "0";
    this._iframe = f;
    this._elStage.innerHTML = "";
    this._elStage.appendChild(f);
    f.addEventListener("load", () => this._embedBootstrap());
    this._startEmbedPolling();
  }
  /** After the iframe loads, hand-shake with provider's JS API. */
  _embedBootstrap() {
    switch (this._provider) {
      case "youtube":
        this._postProvider({ event: "listening", id: "arianna-yt" });
        this._postProvider({ event: "command", func: "addEventListener", args: ["onStateChange"] });
        this._postProvider({ event: "command", func: "addEventListener", args: ["onReady"] });
        if (this._get("autoplay", false)) this._postProvider({ event: "command", func: "playVideo" });
        break;
      case "vimeo":
        this._postProvider({ method: "addEventListener", value: "play" });
        this._postProvider({ method: "addEventListener", value: "pause" });
        this._postProvider({ method: "addEventListener", value: "ended" });
        this._postProvider({ method: "addEventListener", value: "timeupdate" });
        this._postProvider({ method: "addEventListener", value: "loaded" });
        if (this._get("autoplay", false)) this._postProvider({ method: "play" });
        break;
      case "twitch":
        setTimeout(() => this._emit("loaded", { provider: "twitch" }), 200);
        break;
    }
    this.setVolume(this._volume);
  }
  /** Send a JSON-encoded postMessage to the embed iframe (provider-specific shape). */
  _postProvider(payload) {
    if (!this._iframe?.contentWindow) return;
    const targetOrigin = this._provider === "youtube" ? "https://www.youtube.com" : this._provider === "vimeo" ? "https://player.vimeo.com" : "*";
    this._iframe.contentWindow.postMessage(JSON.stringify(payload), targetOrigin);
  }
  /** Receive postMessage events from provider iframes and translate to AriannA events. */
  _onProviderMessage(ev) {
    if (!this._iframe || ev.source !== this._iframe.contentWindow) return;
    let data;
    try {
      data = typeof ev.data === "string" ? JSON.parse(ev.data) : ev.data;
    } catch {
      return;
    }
    if (this._provider === "youtube") this._handleYouTubeMessage(data);
    else if (this._provider === "vimeo") this._handleVimeoMessage(data);
  }
  _handleYouTubeMessage(data) {
    const m = data;
    if (!m || typeof m !== "object") return;
    if (m.event === "onStateChange" && typeof m.info === "number") {
      switch (m.info) {
        case 1:
          this._isPlaying = true;
          this._emit("play", { provider: "youtube" });
          break;
        case 2:
          this._isPlaying = false;
          this._emit("pause", { provider: "youtube" });
          break;
        case 0:
          this._isPlaying = false;
          this._emit("ended", { provider: "youtube" });
          break;
      }
    } else if (m.event === "infoDelivery" && m.info && typeof m.info === "object") {
      const info = m.info;
      if (typeof info.currentTime === "number") this._curTime = info.currentTime;
      if (typeof info.duration === "number") this._duration = info.duration;
    } else if (m.event === "onReady") {
      this._emit("loaded", { provider: "youtube", duration: this._duration });
    }
  }
  _handleVimeoMessage(data) {
    const m = data;
    if (!m || typeof m !== "object") return;
    switch (m.event) {
      case "play":
        this._isPlaying = true;
        this._emit("play", { provider: "vimeo" });
        break;
      case "pause":
        this._isPlaying = false;
        this._emit("pause", { provider: "vimeo" });
        break;
      case "ended":
        this._isPlaying = false;
        this._emit("ended", { provider: "vimeo" });
        break;
      case "timeupdate":
        if (m.data?.seconds !== void 0) this._curTime = m.data.seconds;
        if (m.data?.duration !== void 0) this._duration = m.data.duration;
        this._emit("timeupdate", { time: this._curTime, duration: this._duration, provider: "vimeo" });
        break;
      case "loaded":
        if (m.data?.duration !== void 0) this._duration = m.data.duration;
        this._emit("loaded", { duration: this._duration, provider: "vimeo" });
        break;
    }
  }
  /** YouTube doesn't always push timeupdate. Poll via postMessage. */
  _startEmbedPolling() {
    this._stopEmbedPolling();
    this._pollHandle = window.setInterval(() => {
      if (this._provider === "youtube") {
        this._postProvider({ event: "listening", id: "arianna-yt" });
        this._postProvider({ event: "command", func: "getCurrentTime" });
        this._postProvider({ event: "command", func: "getDuration" });
      }
      this._refreshTime();
      this._emit("timeupdate", {
        time: this._curTime,
        duration: this._duration,
        provider: this._provider
      });
    }, 500);
  }
  _stopEmbedPolling() {
    if (this._pollHandle != null) {
      clearInterval(this._pollHandle);
      this._pollHandle = null;
    }
  }
  /** Cleanup current media element + audio graph (called on provider switch). */
  _teardownMedia() {
    this._stopEmbedPolling();
    if (this._video) {
      try {
        this._video.pause();
      } catch {
      }
      try {
        this._mediaSrc?.disconnect();
      } catch {
      }
      try {
        this._gain?.disconnect();
      } catch {
      }
      this._video.remove();
      this._video = void 0;
      this._mediaSrc = void 0;
      this._gain = void 0;
      this._output = void 0;
    }
    if (this._iframe) {
      this._iframe.src = "about:blank";
      this._iframe.remove();
      this._iframe = void 0;
    }
  }
  // ── Shell + UI ─────────────────────────────────────────────────────────
  _buildShell() {
    const ar = this._get("aspectRatio", "16/9");
    this.el.innerHTML = `
<div class="ar-videoplayer__stage" data-r="stage" style="aspect-ratio:${ar}"></div>
${this._get("showControls", true) ? `
<div class="ar-videoplayer__row">
  <button class="ar-videoplayer__btn play" data-r="play" title="Play / Pause">\u25B6</button>
  <button class="ar-videoplayer__btn"      data-r="stop" title="Stop">\u25A0</button>
  <span class="ar-videoplayer__time" data-r="time">0:00</span>
  <input  class="ar-videoplayer__bar"  data-r="bar"  type="range" min="0" max="1000" value="0">
  <span class="ar-videoplayer__time" data-r="duration">0:00</span>
  <span class="ar-videoplayer__lbl">Vol</span>
  <input  class="ar-videoplayer__vol" data-r="volume" type="range" min="0" max="1" step="0.01">
  <span class="ar-videoplayer__provider" data-r="provider"></span>
  <button class="ar-videoplayer__btn" data-r="fs" title="Fullscreen">\u26F6</button>
</div>` : ""}`;
    this._elStage = this.el.querySelector('[data-r="stage"]');
    if (!this._get("showControls", true)) return;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elPlay = r("play");
    this._elTime = r("time");
    this._elDur = r("duration");
    this._elBar = r("bar");
    this._elVolume = r("volume");
    this._elFs = r("fs");
    this._elVolume.value = String(this._volume);
    this._elPlay.addEventListener("click", () => {
      if (this.isPlaying()) this.pause();
      else this.play();
    });
    r("stop").addEventListener("click", () => this.stop());
    this._elBar.addEventListener("input", () => {
      const frac = parseInt(this._elBar.value, 10) / 1e3;
      this.seek(frac * this.getDuration());
    });
    this._elVolume.addEventListener("input", () => this.setVolume(parseFloat(this._elVolume.value)));
    this._elFs.addEventListener("click", () => this.fullscreen());
    this.on("play", () => {
      if (this._elPlay) this._elPlay.textContent = "\u2016";
    });
    this.on("pause", () => {
      if (this._elPlay) this._elPlay.textContent = "\u25B6";
    });
    this.on("ended", () => {
      if (this._elPlay) this._elPlay.textContent = "\u25B6";
    });
  }
  _refreshTime() {
    if (!this._elTime || !this._elDur) return;
    const cur = this.getCurrentTime();
    const dur = this.getDuration();
    this._elTime.textContent = formatTime5(cur);
    this._elDur.textContent = formatTime5(dur);
    if (dur > 0 && this._elBar) {
      this._elBar.value = String(Math.round(cur / dur * 1e3));
    }
    const provLbl = this.el.querySelector('[data-r="provider"]');
    if (provLbl) provLbl.textContent = this._provider === "native" ? "" : this._provider.toUpperCase();
  }
  _injectStyles() {
    if (document.getElementById("ar-videoplayer-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-videoplayer-styles";
    s.textContent = `
.ar-videoplayer { font:13px -apple-system,system-ui,sans-serif; background:#1e1e1e; color:#d4d4d4; border-radius:6px; overflow:hidden; }
.ar-videoplayer__stage { width:100%; background:#000; position:relative; }
.ar-videoplayer__stage video, .ar-videoplayer__stage iframe { width:100%; height:100%; display:block; border:0; }
.ar-videoplayer__row { display:flex; align-items:center; gap:10px; padding:8px 12px; }
.ar-videoplayer__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:14px sans-serif; border-radius:3px; cursor:pointer; min-width:32px; }
.ar-videoplayer__btn:hover { background:#2a2a2a; }
.ar-videoplayer__btn.play { background:#16a34a; border-color:#16a34a; color:#fff; }
.ar-videoplayer__btn.play:hover { background:#15803d; }
.ar-videoplayer__time { font:11px ui-monospace,monospace; color:#888; min-width:40px; text-align:center; }
.ar-videoplayer__bar { flex:1; -webkit-appearance:none; height:4px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-videoplayer__bar::-webkit-slider-thumb { -webkit-appearance:none; width:12px; height:12px; border-radius:50%; background:#e40c88; cursor:pointer; }
.ar-videoplayer__bar::-moz-range-thumb     { width:12px; height:12px; border-radius:50%; background:#e40c88; cursor:pointer; border:0; }
.ar-videoplayer__lbl { font:10px sans-serif; color:#888; }
.ar-videoplayer__vol { width:80px; -webkit-appearance:none; height:3px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-videoplayer__vol::-webkit-slider-thumb { -webkit-appearance:none; width:10px; height:10px; border-radius:50%; background:#d4d4d4; cursor:pointer; }
.ar-videoplayer__vol::-moz-range-thumb     { width:10px; height:10px; border-radius:50%; background:#d4d4d4; cursor:pointer; border:0; }
.ar-videoplayer__provider { font:10px sans-serif; color:#e40c88; letter-spacing:.05em; min-width:50px; text-align:right; }
`;
    document.head.appendChild(s);
  }
};
function formatTime5(s) {
  if (!isFinite(s) || s < 0) return "0:00";
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

// components/video/VideoTrackEditor.ts
var VideoTrackEditor = class extends AudioComponent {
  _tracks = [];
  _clips = [];
  _sources = /* @__PURE__ */ new Map();
  _nextId = 1;
  _zoom;
  _pxPerSec;
  _selected = /* @__PURE__ */ new Set();
  _selectedTracks = /* @__PURE__ */ new Set();
  _clipboard = [];
  _playhead = 0;
  // Loop state — Task B (Loop selection)
  // The host (or the user dragging on the ruler) can define a time range
  // that the playhead will wrap around when reaching `end`. The TrackEditor
  // does NOT own the playback engine — when `enabled` and `setPlayhead()` is
  // called past `end`, we wrap to `start` and emit a `loop-wrap` event so
  // the engine can adjust.
  _loop = { start: 0, end: 0, enabled: false };
  _elLoopRange;
  // overlay rectangle on ruler
  _elLoopHandleLeft;
  // left resize handle
  _elLoopHandleRight;
  // right resize handle
  // DOM
  _elTrackHeads;
  _elTrackBodies;
  _elRuler;
  _elPlayhead;
  constructor(container, opts = {}) {
    super(container, "div", {
      tracks: 3,
      pxPerSec: 50,
      zoom: 1,
      ...opts
    });
    this.el.className = `ar-videotrack${opts.class ? " " + opts.class : ""}`;
    this._zoom = this._get("zoom", 1);
    this._pxPerSec = this._get("pxPerSec", 50);
    this._injectStyles();
    this._buildAudioGraph();
    this._buildShell();
    const n = this._get("tracks", 3);
    for (let i = 0; i < n; i++) {
      this.addTrack({
        id: `v${i + 1}`,
        name: i === n - 1 ? "Audio" : `V${i + 1}`,
        color: i === n - 1 ? "#a855f7" : "#3b82f6",
        type: i === n - 1 ? "audio" : "video"
      });
    }
    this._on(document, "keydown", (e) => {
      if (!this.el.contains(document.activeElement) && document.activeElement !== document.body) return;
      const tg = e.target;
      if (tg.tagName === "INPUT" || tg.tagName === "TEXTAREA") return;
      if ((e.metaKey || e.ctrlKey) && (e.key === "c" || e.key === "C")) {
        this.copy();
        e.preventDefault();
      }
      if ((e.metaKey || e.ctrlKey) && (e.key === "v" || e.key === "V")) {
        this.paste(this._playhead);
        e.preventDefault();
      }
      if ((e.metaKey || e.ctrlKey) && (e.key === "x" || e.key === "X")) {
        this.cut();
        e.preventDefault();
      }
      if (e.key === "Delete" || e.key === "Backspace") {
        this.deleteSelection();
        e.preventDefault();
      }
    });
  }
  // ── Public API ──────────────────────────────────────────────────────────
  addTrack(t) {
    const tk = { color: "#3b82f6", type: "video", muted: false, soloed: false, ...t };
    this._tracks.push(tk);
    this._renderTracks();
    this._emit("change", { kind: "add-track", track: tk });
    return tk;
  }
  removeTrack(id) {
    this._tracks = this._tracks.filter((t) => t.id !== id);
    this._clips = this._clips.filter((c) => c.trackId !== id);
    this._renderTracks();
    this._renderClips();
    this._emit("change", { kind: "remove-track", id });
  }
  /** Load a video source from URL or File. Generates thumbnails. */
  async loadSource(srcOrFile, thumbCount = 8) {
    const url = typeof srcOrFile === "string" ? srcOrFile : URL.createObjectURL(srcOrFile);
    const video = document.createElement("video");
    video.crossOrigin = "anonymous";
    video.preload = "metadata";
    video.src = url;
    await new Promise((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = () => reject(new Error("video load failed"));
    });
    const duration = video.duration;
    const thumbnails = [];
    const canvas = document.createElement("canvas");
    canvas.width = 80;
    canvas.height = 45;
    const ctx = canvas.getContext("2d");
    for (let i = 0; i < thumbCount; i++) {
      const t = duration / thumbCount * i;
      video.currentTime = t;
      await new Promise((r) => {
        video.onseeked = () => r();
      });
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        thumbnails.push(canvas.toDataURL("image/jpeg", 0.6));
      }
    }
    const source = {
      id: `s${this._nextId++}`,
      url,
      duration,
      width: video.videoWidth,
      height: video.videoHeight,
      thumbnails
    };
    this._sources.set(source.id, source);
    return source;
  }
  addClip(trackId, opts) {
    const clip = {
      id: `c${this._nextId++}`,
      trackId,
      sourceId: opts.source.id,
      start: opts.start,
      sourceIn: opts.sourceIn ?? 0,
      duration: opts.duration ?? opts.source.duration,
      name: opts.name
    };
    this._clips.push(clip);
    this._renderClips();
    this._emit("change", { kind: "add-clip", clip });
    return clip;
  }
  removeClip(id) {
    this._clips = this._clips.filter((c) => c.id !== id);
    this._selected.delete(id);
    this._renderClips();
    this._emit("change", { kind: "remove-clip", id });
  }
  splitClip(id, atTime) {
    const c = this._clips.find((x) => x.id === id);
    if (!c) return null;
    const local = atTime - c.start;
    if (local <= 0 || local >= c.duration) return null;
    const left = { ...c, duration: local };
    const right = { ...c, id: `c${this._nextId++}`, start: c.start + local, sourceIn: c.sourceIn + local, duration: c.duration - local };
    this._clips = this._clips.filter((x) => x.id !== id);
    this._clips.push(left, right);
    this._renderClips();
    this._emit("change", { kind: "split", original: id, parts: [left, right] });
    return [left, right];
  }
  copy() {
    this._clipboard = [...this._selected].map((id) => {
      const c = this._clips.find((x) => x.id === id);
      return c ? { ...c } : null;
    }).filter(Boolean);
  }
  cut() {
    this.copy();
    this.deleteSelection();
  }
  paste(atTime) {
    if (this._clipboard.length === 0) return;
    const baseTime = Math.min(...this._clipboard.map((c) => c.start));
    const offset = atTime - baseTime;
    for (const c of this._clipboard) {
      this._clips.push({ ...c, id: `c${this._nextId++}`, start: c.start + offset });
    }
    this._renderClips();
    this._emit("change", { kind: "paste" });
  }
  deleteSelection() {
    const trackIds = this._selectedTracks;
    this._clips = this._clips.filter((c) => !this._selected.has(c.id) && !trackIds.has(c.trackId));
    this._selected.clear();
    if (trackIds.size > 0) {
      this._tracks = this._tracks.filter((t) => !trackIds.has(t.id));
      this._selectedTracks.clear();
      this._renderTracks();
    } else {
      this._renderClips();
    }
    this._emit("change", { kind: "delete-selection" });
  }
  setZoom(z) {
    this._zoom = Math.max(0.1, Math.min(8, z));
    this._renderRuler();
    this._renderClips();
    this._emit("change", { kind: "zoom", value: this._zoom });
    return this;
  }
  setPlayhead(t) {
    let pos = Math.max(0, t);
    if (this._loop.enabled && this._loop.end > this._loop.start && pos >= this._loop.end) {
      pos = this._loop.start;
      this._emit("loop-wrap", { start: this._loop.start, end: this._loop.end });
    }
    this._playhead = pos;
    this._renderPlayhead();
    return this;
  }
  // ── Loop API (Task B) ──────────────────────────────────────────────────
  /**
   * Get the current loop range. Always defined; if no loop is active,
   * `enabled` is false and start/end may be 0.
   */
  getLoop() {
    return { ...this._loop };
  }
  /**
   * Define and (optionally) enable the loop range. Both `start` and `end`
   * are in seconds; `start` < `end` is enforced. Setting `enabled: false`
   * keeps the range stored but disables wrap-around.
   */
  setLoop(loop) {
    this._loop.start = Math.max(0, loop.start);
    if (loop.end !== void 0) this._loop.end = Math.max(this._loop.start + 0.05, loop.end);
    if (loop.enabled !== void 0) this._loop.enabled = loop.enabled;
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  /** Disable the loop. The stored range is preserved, only the flag flips. */
  enableLoop(enabled) {
    this._loop.enabled = enabled;
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  /** Clear the loop range entirely (start = end = 0, disabled). */
  clearLoop() {
    this._loop = { start: 0, end: 0, enabled: false };
    this._renderLoopOverlay();
    this._emit("change", { kind: "loop", loop: { ...this._loop } });
    return this;
  }
  /** Serialize the whole project. */
  export() {
    return {
      tracks: this._tracks.map((t) => ({ ...t })),
      clips: this._clips.map((c) => ({ ...c })),
      sources: [...this._sources.values()].map((s) => ({
        id: s.id,
        url: s.url,
        duration: s.duration,
        width: s.width,
        height: s.height
      }))
    };
  }
  // ── Internal ────────────────────────────────────────────────────────────
  _buildAudioGraph() {
  }
  _build() {
  }
  _buildShell() {
    this.el.innerHTML = `
<div class="ar-videotrack__toolbar">
  <button class="ar-videotrack__btn" data-r="add-track">+ Track</button>
  <label class="ar-videotrack__btn" style="cursor:pointer">+ Source
    <input type="file" accept="video/*" data-r="upload" style="display:none">
  </label>
  <span class="ar-videotrack__lbl">Zoom</span>
  <input type="range" class="ar-videotrack__zoom" data-r="zoom" min="0.1" max="4" step="0.1" value="1">
  <span class="ar-videotrack__lbl" data-r="info"></span>
</div>
<div class="ar-videotrack__main">
  <div class="ar-videotrack__heads" data-r="heads"></div>
  <div class="ar-videotrack__rest">
    <div class="ar-videotrack__ruler" data-r="ruler"></div>
    <div class="ar-videotrack__bodies" data-r="bodies">
      <div class="ar-videotrack__playhead" data-r="playhead"></div>
    </div>
  </div>
</div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elTrackHeads = r("heads");
    this._elTrackBodies = r("bodies");
    this._elRuler = r("ruler");
    this._elPlayhead = r("playhead");
    r("add-track").addEventListener("click", () => {
      const i = this._tracks.length + 1;
      this.addTrack({ id: `v${this._nextId++}`, name: `V${i}` });
    });
    const upload = r("upload");
    upload.addEventListener("change", async () => {
      const f = upload.files?.[0];
      if (!f) return;
      const info = r("info");
      info.textContent = "\u23F3 Loading...";
      const src = await this.loadSource(f);
      info.textContent = `Loaded: ${f.name} (${src.duration.toFixed(1)}s)`;
      const firstVideo = this._tracks.find((t) => t.type === "video");
      if (firstVideo) {
        this.addClip(firstVideo.id, { source: src, start: 0, name: f.name });
      }
    });
    const zoom = r("zoom");
    zoom.addEventListener("input", () => this.setZoom(parseFloat(zoom.value)));
    this._elTrackBodies.addEventListener("click", (e) => {
      if (e.target.closest(".ar-videotrack__clip")) return;
      const rect = this._elTrackBodies.getBoundingClientRect();
      const x = e.clientX - rect.left + this._elTrackBodies.scrollLeft;
      const px = this._pxPerSec * this._zoom;
      this.setPlayhead(x / px);
    });
    this._elRuler.addEventListener("pointerdown", (e) => this._onRulerDown(e));
    this._renderRuler();
  }
  _renderTracks() {
    this._elTrackHeads.innerHTML = "";
    for (const t of this._tracks) {
      const head = document.createElement("div");
      head.className = "ar-videotrack__head";
      if (this._selectedTracks.has(t.id)) head.classList.add("selected");
      head.dataset.trackId = t.id;
      head.style.borderLeft = `4px solid ${t.color}`;
      head.innerHTML = `
<div class="ar-videotrack__head-row">
  <span class="ar-videotrack__head-name">${t.name}</span>
  <button class="ar-videotrack__head-x" data-act="remove" aria-label="Remove track">\xD7</button>
</div>
<div class="ar-videotrack__head-row">
  <button class="ar-videotrack__btn-sm mute ${t.muted ? "active" : ""}" data-act="mute">M</button>
  <button class="ar-videotrack__btn-sm solo ${t.soloed ? "active" : ""}" data-act="solo">S</button>
</div>`;
      head.addEventListener("pointerdown", (e) => {
        const tgt = e.target;
        if (tgt.closest("button, input, label")) return;
        if (!e.shiftKey) this._selectedTracks.clear();
        if (this._selectedTracks.has(t.id)) this._selectedTracks.delete(t.id);
        else this._selectedTracks.add(t.id);
        this._renderTracks();
        this._emit("change", { kind: "select-tracks", ids: [...this._selectedTracks] });
      });
      head.querySelector('[data-act="remove"]').addEventListener("click", (e) => {
        e.stopPropagation();
        this.removeTrack(t.id);
      });
      head.querySelector('[data-act="mute"]').addEventListener("click", (e) => {
        e.stopPropagation();
        t.muted = !t.muted;
        this._renderTracks();
      });
      head.querySelector('[data-act="solo"]').addEventListener("click", (e) => {
        e.stopPropagation();
        t.soloed = !t.soloed;
        this._renderTracks();
      });
      this._elTrackHeads.appendChild(head);
    }
    for (const t of this._tracks) {
      let body = this._elTrackBodies.querySelector(`[data-track-row="${t.id}"]`);
      if (!body) {
        body = document.createElement("div");
        body.className = "ar-videotrack__body";
        body.dataset.trackRow = t.id;
        this._elTrackBodies.insertBefore(body, this._elPlayhead);
      }
    }
    this._elTrackBodies.querySelectorAll("[data-track-row]").forEach((el) => {
      if (!this._tracks.find((t) => t.id === el.dataset.trackRow)) el.remove();
    });
    this._renderClips();
  }
  _renderRuler() {
    this._elRuler.innerHTML = "";
    const total = 120;
    const px = this._pxPerSec * this._zoom;
    this._elRuler.style.width = total * px + "px";
    this._elTrackBodies.style.width = total * px + "px";
    for (let s = 0; s <= total; s++) {
      if (s % 5 === 0) {
        const t = document.createElement("div");
        t.className = "ar-videotrack__ruler-tick";
        t.style.left = s * px + "px";
        this._elRuler.appendChild(t);
        const lbl = document.createElement("div");
        lbl.className = "ar-videotrack__ruler-lbl";
        lbl.style.left = s * px + 2 + "px";
        lbl.textContent = formatTime6(s);
        this._elRuler.appendChild(lbl);
      }
    }
    this._renderLoopOverlay();
  }
  /**
   * Render the loop-range overlay and its two resize handles on the ruler.
   * Visible only when `_loop.enabled` and `start < end`. The overlay is a
   * semi-transparent rectangle that visually marks the looped region; the
   * handles let the user drag-resize either side. Drag-creating a loop range
   * is done by shift-clicking on the ruler (see _onRulerDown).
   */
  _renderLoopOverlay() {
    if (this._elLoopRange) this._elLoopRange.remove();
    if (this._elLoopHandleLeft) this._elLoopHandleLeft.remove();
    if (this._elLoopHandleRight) this._elLoopHandleRight.remove();
    this._elLoopRange = this._elLoopHandleLeft = this._elLoopHandleRight = void 0;
    if (!this._loop.enabled || this._loop.end <= this._loop.start) return;
    const px = this._pxPerSec * this._zoom;
    const left = this._loop.start * px;
    const width = (this._loop.end - this._loop.start) * px;
    const range = document.createElement("div");
    range.className = "ar-videotrack__loop-range";
    range.style.left = left + "px";
    range.style.width = width + "px";
    this._elRuler.appendChild(range);
    const hL = document.createElement("div");
    hL.className = "ar-videotrack__loop-handle ar-videotrack__loop-handle--left";
    hL.style.left = left + "px";
    this._elRuler.appendChild(hL);
    const hR = document.createElement("div");
    hR.className = "ar-videotrack__loop-handle ar-videotrack__loop-handle--right";
    hR.style.left = left + width + "px";
    this._elRuler.appendChild(hR);
    this._elLoopRange = range;
    this._elLoopHandleLeft = hL;
    this._elLoopHandleRight = hR;
    hL.addEventListener("pointerdown", (e) => this._onLoopHandleDown(e, "left"));
    hR.addEventListener("pointerdown", (e) => this._onLoopHandleDown(e, "right"));
    range.addEventListener("pointerdown", (e) => this._onLoopRangeDown(e));
  }
  /**
   * Pointer-down handler on a loop handle; resize the loop range while
   * dragging. The opposite handle's time stays anchored.
   */
  _onLoopHandleDown(e, which) {
    e.preventDefault();
    e.stopPropagation();
    const px = this._pxPerSec * this._zoom;
    const startX = e.clientX;
    const startLoop = { ...this._loop };
    e.currentTarget.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const dt = (ev.clientX - startX) / px;
      if (which === "left") {
        this._loop.start = Math.max(0, Math.min(startLoop.start + dt, this._loop.end - 0.05));
      } else {
        this._loop.end = Math.max(this._loop.start + 0.05, startLoop.end + dt);
      }
      this._renderLoopOverlay();
    };
    const onUp = () => {
      e.currentTarget.removeEventListener("pointermove", onMove);
      e.currentTarget.removeEventListener("pointerup", onUp);
      this._emit("change", { kind: "loop", loop: { ...this._loop } });
    };
    e.currentTarget.addEventListener("pointermove", onMove);
    e.currentTarget.addEventListener("pointerup", onUp);
  }
  /** Drag the whole loop range (translate without resize). */
  _onLoopRangeDown(e) {
    e.preventDefault();
    e.stopPropagation();
    const px = this._pxPerSec * this._zoom;
    const startX = e.clientX;
    const startLoop = { ...this._loop };
    const range = e.currentTarget;
    range.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
      const dt = (ev.clientX - startX) / px;
      const len = startLoop.end - startLoop.start;
      this._loop.start = Math.max(0, startLoop.start + dt);
      this._loop.end = this._loop.start + len;
      this._renderLoopOverlay();
    };
    const onUp = () => {
      range.removeEventListener("pointermove", onMove);
      range.removeEventListener("pointerup", onUp);
      this._emit("change", { kind: "loop", loop: { ...this._loop } });
    };
    range.addEventListener("pointermove", onMove);
    range.addEventListener("pointerup", onUp);
  }
  /**
   * Pointer-down handler on the timeline ruler.
   *
   * Two interactions are supported:
   *   • Shift+drag — define a fresh loop range (replaces any existing one).
   *     The drag direction doesn't matter — start/end are sorted at the end.
   *   • Plain click / drag — moves the playhead. (Useful as a quick scrub.)
   *
   * Clicks on the loop overlay or its handles are intercepted earlier and
   * never reach this handler.
   */
  _onRulerDown(e) {
    const target = e.target;
    if (target.classList.contains("ar-videotrack__loop-range") || target.classList.contains("ar-videotrack__loop-handle")) return;
    const px = this._pxPerSec * this._zoom;
    const rect = this._elRuler.getBoundingClientRect();
    const x0 = e.clientX - rect.left + this._elRuler.scrollLeft;
    const t0 = x0 / px;
    if (e.shiftKey) {
      e.preventDefault();
      e.stopPropagation();
      this._loop.start = t0;
      this._loop.end = t0 + 1e-3;
      this._loop.enabled = true;
      this._renderLoopOverlay();
      this._elRuler.setPointerCapture(e.pointerId);
      const onMove = (ev) => {
        const x = ev.clientX - rect.left + this._elRuler.scrollLeft;
        const t = x / px;
        if (t >= t0) {
          this._loop.start = t0;
          this._loop.end = t;
        } else {
          this._loop.start = t;
          this._loop.end = t0;
        }
        this._renderLoopOverlay();
      };
      const onUp = () => {
        this._elRuler.removeEventListener("pointermove", onMove);
        this._elRuler.removeEventListener("pointerup", onUp);
        if (this._loop.end - this._loop.start < 0.05) {
          this._loop = { start: 0, end: 0, enabled: false };
          this._renderLoopOverlay();
        }
        this._emit("change", { kind: "loop", loop: { ...this._loop } });
      };
      this._elRuler.addEventListener("pointermove", onMove);
      this._elRuler.addEventListener("pointerup", onUp);
      return;
    }
    this.setPlayhead(t0);
  }
  _renderClips() {
    this._elTrackBodies.querySelectorAll(".ar-videotrack__clip").forEach((n) => n.remove());
    const px = this._pxPerSec * this._zoom;
    for (const c of this._clips) {
      const row = this._elTrackBodies.querySelector(`[data-track-row="${c.trackId}"]`);
      if (!row) continue;
      const t = this._tracks.find((x) => x.id === c.trackId);
      const src = this._sources.get(c.sourceId);
      const el = document.createElement("div");
      el.className = "ar-videotrack__clip";
      el.style.left = c.start * px + "px";
      el.style.width = Math.max(20, c.duration * px) + "px";
      el.style.background = (t?.color || "#3b82f6") + "33";
      el.style.borderColor = t?.color || "#3b82f6";
      if (this._selected.has(c.id)) el.classList.add("selected");
      if (src && src.thumbnails.length > 0) {
        const thumbsContainer = document.createElement("div");
        thumbsContainer.className = "ar-videotrack__thumbs";
        const w = Math.max(20, c.duration * px) | 0;
        const thumbW = 80;
        const count = Math.max(1, Math.ceil(w / thumbW));
        for (let i = 0; i < count; i++) {
          const sourceTime = c.sourceIn + i / count * c.duration;
          const idx = Math.min(
            src.thumbnails.length - 1,
            Math.floor(sourceTime / src.duration * src.thumbnails.length)
          );
          const img = document.createElement("img");
          img.src = src.thumbnails[idx];
          img.className = "ar-videotrack__thumb";
          thumbsContainer.appendChild(img);
        }
        el.appendChild(thumbsContainer);
      }
      const lbl = document.createElement("div");
      lbl.className = "ar-videotrack__clip-lbl";
      lbl.textContent = c.name || c.id;
      el.appendChild(lbl);
      const lh = document.createElement("div");
      lh.className = "ar-videotrack__clip-h left";
      el.appendChild(lh);
      const rh = document.createElement("div");
      rh.className = "ar-videotrack__clip-h right";
      el.appendChild(rh);
      el.addEventListener("pointerdown", (e) => this._onClipDown(e, c, el, lh, rh));
      row.appendChild(el);
    }
  }
  _onClipDown(e, c, el, lh, rh) {
    e.preventDefault();
    e.stopPropagation();
    const px = this._pxPerSec * this._zoom;
    if (!this._selected.has(c.id)) {
      if (!e.shiftKey) {
        this._selected.clear();
        this.el.querySelectorAll(".ar-videotrack__clip.selected").forEach((n) => n.classList.remove("selected"));
      }
      this._selected.add(c.id);
      el.classList.add("selected");
    }
    const mode = e.target === lh ? "resize-left" : e.target === rh ? "resize-right" : "move";
    const startX = e.clientX;
    const startY = e.clientY;
    const startStart = c.start, startDur = c.duration, startSrcIn = c.sourceIn;
    const startTrackId = c.trackId;
    let rowRects = [];
    const captureRowRects = () => {
      rowRects = [];
      this._elTrackBodies.querySelectorAll("[data-track-row]").forEach((row) => {
        const rect = row.getBoundingClientRect();
        rowRects.push({ id: row.dataset.trackRow, top: rect.top, bottom: rect.bottom });
      });
    };
    captureRowRects();
    let autoCreatedThisDrag = false;
    const autoCreateTrackBelow = () => {
      const id = `v${this._tracks.length + 1}`;
      const idx = this._tracks.length + 1;
      const name = `V${idx}`;
      let unique = id;
      let bump = idx;
      while (this._tracks.find((t) => t.id === unique)) {
        bump += 1;
        unique = `v${bump}`;
      }
      const parent = el.parentElement;
      if (parent) parent.removeChild(el);
      const newTrack = this.addTrack({
        id: unique,
        name,
        color: "#3b82f6",
        type: "video"
      });
      const newRow = this._elTrackBodies.querySelector(`[data-track-row="${newTrack.id}"]`);
      if (newRow) newRow.appendChild(el);
      captureRowRects();
      autoCreatedThisDrag = true;
      return newTrack.id;
    };
    const rowAt = (clientY) => {
      for (const r of rowRects) if (clientY >= r.top && clientY < r.bottom) return r.id;
      if (rowRects.length === 0) return null;
      if (clientY < rowRects[0].top) return rowRects[0].id;
      return null;
    };
    let highlightedRow = null;
    const setHighlight = (rowId) => {
      if (highlightedRow) highlightedRow.classList.remove("ar-videotrack__body--dropping");
      highlightedRow = rowId ? this._elTrackBodies.querySelector(`[data-track-row="${rowId}"]`) : null;
      if (highlightedRow) highlightedRow.classList.add("ar-videotrack__body--dropping");
    };
    try {
      el.setPointerCapture(e.pointerId);
    } catch {
    }
    const onMove = (ev) => {
      if (ev.pointerId !== e.pointerId) return;
      const dx = (ev.clientX - startX) / px;
      if (mode === "move") {
        c.start = Math.max(0, startStart + dx);
      } else if (mode === "resize-right") {
        c.duration = Math.max(0.05, startDur + dx);
      } else if (mode === "resize-left") {
        const newStart = Math.max(0, startStart + dx);
        const delta = newStart - startStart;
        c.start = newStart;
        c.sourceIn = startSrcIn + delta;
        c.duration = Math.max(0.05, startDur - delta);
      }
      el.style.left = c.start * px + "px";
      el.style.width = Math.max(20, c.duration * px) + "px";
      if (mode === "move") {
        let targetTrackId = rowAt(ev.clientY);
        const lastBottom = rowRects.length ? rowRects[rowRects.length - 1].bottom : 0;
        if (!targetTrackId && !autoCreatedThisDrag && ev.clientY >= lastBottom) {
          targetTrackId = autoCreateTrackBelow();
        }
        if (targetTrackId && rowRects.length > 0 && ev.clientY < lastBottom - 4) {
          autoCreatedThisDrag = false;
        }
        if (targetTrackId && targetTrackId !== c.trackId) {
          c.trackId = targetTrackId;
          const newRow = this._elTrackBodies.querySelector(`[data-track-row="${targetTrackId}"]`);
          if (newRow && el.parentElement !== newRow) newRow.appendChild(el);
          const t = this._tracks.find((x) => x.id === targetTrackId);
          if (t) {
            el.style.background = (t.color || "#3b82f6") + "33";
            el.style.borderColor = t.color || "#3b82f6";
          }
          setHighlight(targetTrackId);
        } else if (!targetTrackId) {
          setHighlight(null);
        } else {
          setHighlight(targetTrackId);
        }
      }
      void (ev.clientY - startY);
    };
    const cleanup = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      try {
        el.releasePointerCapture(e.pointerId);
      } catch {
      }
    };
    const onUp = (ev) => {
      if (ev.pointerId !== e.pointerId) return;
      cleanup();
      setHighlight(null);
      this._renderClips();
      if (mode === "move" && c.trackId !== startTrackId) {
        this._emit("change", { kind: "move-clip-track", clip: c, fromTrack: startTrackId, toTrack: c.trackId });
      }
      this._emit("change", { kind: mode + "-clip", clip: c });
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
  }
  _renderPlayhead() {
    const px = this._pxPerSec * this._zoom;
    this._elPlayhead.style.left = this._playhead * px + "px";
  }
  _injectStyles() {
    if (document.getElementById("ar-videotrack-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-videotrack-styles";
    s.textContent = `
.ar-videotrack { font:12px -apple-system,system-ui,sans-serif; background:#1e1e1e; color:#d4d4d4; border-radius:4px; display:flex; flex-direction:column; height:100%; min-height:300px; user-select:none; }
.ar-videotrack__toolbar { background:#252525; padding:6px 10px; display:flex; gap:8px; align-items:center; border-bottom:1px solid #333; flex-shrink:0; }
.ar-videotrack__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:12px sans-serif; border-radius:3px; cursor:pointer; }
.ar-videotrack__btn:hover { background:#2a2a2a; }
.ar-videotrack__lbl { font:11px sans-serif; color:#888; }
.ar-videotrack__zoom { width:120px; -webkit-appearance:none; height:3px; background:#444; border-radius:2px; outline:none; cursor:pointer; }
.ar-videotrack__zoom::-webkit-slider-thumb { -webkit-appearance:none; width:10px; height:10px; border-radius:50%; background:#3b82f6; cursor:pointer; }
.ar-videotrack__main { flex:1; display:flex; min-height:0; overflow:hidden; }
.ar-videotrack__heads { width:120px; background:#252525; border-right:1px solid #333; overflow-y:auto; flex-shrink:0; }
.ar-videotrack__head { height:60px; padding:6px 8px; border-bottom:1px solid #333; box-sizing:border-box; cursor:pointer; touch-action:manipulation; }
.ar-videotrack__head.selected { background:rgba(59,130,246,0.18); box-shadow:inset 0 0 0 2px #3b82f6; }
.ar-videotrack__head-row { display:flex; align-items:center; gap:4px; margin:2px 0; }
.ar-videotrack__head-name { flex:1; font-weight:600; font-size:11px; }
.ar-videotrack__head-x { background:transparent; border:0; color:#666; font-size:18px; line-height:1; cursor:pointer; padding:6px 10px; min-width:32px; min-height:28px; border-radius:3px; touch-action:manipulation; }
.ar-videotrack__head-x:hover { color:#dc2626; background:rgba(220,38,38,0.1); }
.ar-videotrack__btn-sm { background:transparent; border:1px solid #444; color:#d4d4d4; padding:4px 10px; font:10px sans-serif; font-weight:600; border-radius:2px; cursor:pointer; touch-action:manipulation; min-height:24px; }
.ar-videotrack__btn-sm.mute.active { background:#dc2626; border-color:#dc2626; color:#fff; }
.ar-videotrack__btn-sm.solo.active { background:#eab308; border-color:#eab308; color:#1f1f1f; }
.ar-videotrack__rest { flex:1; overflow:auto; }
.ar-videotrack__ruler { background:#252525; border-bottom:1px solid #333; height:22px; position:relative; touch-action:none; }
.ar-videotrack__ruler-tick { position:absolute; top:0; bottom:0; width:1px; background:#555; }
.ar-videotrack__ruler-lbl  { position:absolute; top:4px; font:10px ui-monospace,monospace; color:#999; }
.ar-videotrack__bodies { position:relative; min-height:200px; cursor:crosshair; }
.ar-videotrack__body { height:60px; border-bottom:1px solid #333; position:relative; }
.ar-videotrack__clip { position:absolute; top:4px; bottom:4px; border:1.5px solid #3b82f6; border-radius:3px; cursor:move; overflow:hidden; touch-action:none; }
.ar-videotrack__clip.selected { box-shadow:0 0 0 2px #fff inset; }
.ar-videotrack__clip-lbl { position:absolute; top:2px; left:6px; font:10px sans-serif; color:#fff; pointer-events:none; text-shadow:0 1px 2px rgba(0,0,0,.5); z-index:2; }
.ar-videotrack__clip-h { position:absolute; top:0; bottom:0; width:10px; cursor:ew-resize; z-index:3; touch-action:none; }
.ar-videotrack__clip-h.left  { left:0; }
.ar-videotrack__clip-h.right { right:0; }
.ar-videotrack__thumbs { position:absolute; inset:0; display:flex; }
.ar-videotrack__thumb { width:80px; height:100%; object-fit:cover; flex-shrink:0; opacity:.85; }
.ar-videotrack__playhead { position:absolute; top:0; bottom:0; width:2px; background:#16a34a; pointer-events:none; box-shadow:0 0 4px rgba(22,163,74,.5); z-index:10; }

/* Cross-track drag \u2014 highlight on the destination track row */
.ar-videotrack__body--dropping { background:rgba(228,12,136,0.10); outline:1px dashed #e40c88; outline-offset:-1px; }

/* Loop selection \u2014 overlay on the ruler (Task B) */
.ar-videotrack__loop-range  { position:absolute; top:0; bottom:0; background:rgba(228,12,136,0.18); border-top:2px solid #e40c88; border-bottom:2px solid #e40c88; cursor:grab; z-index:5; }
.ar-videotrack__loop-range:active { cursor:grabbing; }
.ar-videotrack__loop-handle { position:absolute; top:0; bottom:0; width:6px; margin-left:-3px; background:#e40c88; cursor:ew-resize; z-index:6; }
.ar-videotrack__loop-handle::after { content:''; position:absolute; top:50%; left:50%; width:2px; height:8px; margin:-4px 0 0 -1px; background:rgba(255,255,255,0.7); border-radius:1px; }
`;
    document.head.appendChild(s);
  }
};
function formatTime6(s) {
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

// components/core/Theme.ts
var DARK = {
  "--ar-bg": "#0d0d0d",
  "--ar-bg2": "#161616",
  "--ar-bg3": "#1e1e1e",
  "--ar-bg4": "#252525",
  "--ar-border": "#2a2a2a",
  "--ar-border2": "#333",
  "--ar-text": "#e0e0e0",
  "--ar-muted": "#888",
  "--ar-dim": "#444",
  "--ar-primary": "#7eb8f7",
  "--ar-primary-text": "#000",
  "--ar-success": "#4caf50",
  "--ar-warning": "#ff9800",
  "--ar-danger": "#f44336",
  "--ar-info": "#4dd0e1",
  "--ar-radius": "5px",
  "--ar-radius-sm": "3px",
  "--ar-radius-lg": "10px",
  "--ar-shadow": "0 2px 8px rgba(0,0,0,.4)",
  "--ar-shadow-lg": "0 8px 32px rgba(0,0,0,.6)",
  "--ar-font": 'ui-monospace,"Cascadia Code",monospace',
  "--ar-font-mono": 'ui-monospace,"Cascadia Code",monospace',
  "--ar-font-size": "13px",
  "--ar-transition": ".14s ease"
};
var LIGHT = {
  "--ar-bg": "#ffffff",
  "--ar-bg2": "#f5f5f5",
  "--ar-bg3": "#eeeeee",
  "--ar-bg4": "#e0e0e0",
  "--ar-border": "#d0d0d0",
  "--ar-border2": "#bdbdbd",
  "--ar-text": "#1a1a1a",
  "--ar-muted": "#666",
  "--ar-dim": "#999",
  "--ar-primary": "#1565c0",
  "--ar-primary-text": "#ffffff",
  "--ar-success": "#2e7d32",
  "--ar-warning": "#e65100",
  "--ar-danger": "#c62828",
  "--ar-info": "#00838f",
  "--ar-radius": "5px",
  "--ar-radius-sm": "3px",
  "--ar-radius-lg": "10px",
  "--ar-shadow": "0 2px 8px rgba(0,0,0,.12)",
  "--ar-shadow-lg": "0 8px 32px rgba(0,0,0,.18)",
  "--ar-font": "system-ui,sans-serif",
  "--ar-font-mono": "ui-monospace,monospace",
  "--ar-font-size": "13px",
  "--ar-transition": ".14s ease"
};
var Theme = {
  dark: DARK,
  light: LIGHT,
  /**
   * Apply theme tokens to an element (default: document.documentElement).
   *
   * @example
   *   Theme.apply('dark');
   *   Theme.apply('light', document.querySelector('#panel'));
   */
  apply(mode, target = document.documentElement) {
    const tokens = mode === "light" ? LIGHT : mode === "auto" ? window.matchMedia("(prefers-color-scheme: light)").matches ? LIGHT : DARK : DARK;
    Object.entries(tokens).forEach(([k, v]) => target.style.setProperty(k, v ?? null));
    target.dataset.arTheme = mode;
  },
  /**
   * Extend / override specific tokens on a target element.
   *
   * @example
   *   Theme.extend({ '--ar-primary': '#ff6b6b', '--ar-radius': '8px' });
   */
  extend(tokens, target = document.documentElement) {
    Object.entries(tokens).forEach(([k, v]) => target.style.setProperty(k, v ?? null));
  },
  /**
   * Inject the shared base CSS required by all controls.
   * Call once at app startup.
   */
  inject() {
    if (document.getElementById("arianna-wip-base-css")) return;
    const s = document.createElement("style");
    s.id = "arianna-wip-base-css";
    s.textContent = `
*, *::before, *::after { box-sizing: border-box; }
.ar-ctrl { font-family: var(--ar-font); font-size: var(--ar-font-size); color: var(--ar-text); }
.ar-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  background: var(--ar-bg3); border: 1px solid var(--ar-border); border-radius: var(--ar-radius);
  color: var(--ar-text); cursor: pointer; font: inherit; font-size: .82rem;
  padding: 5px 14px; transition: background var(--ar-transition), border-color var(--ar-transition);
  user-select: none; white-space: nowrap;
}
.ar-btn:hover:not(:disabled) { background: var(--ar-bg4); border-color: var(--ar-border2); }
.ar-btn--primary { background: var(--ar-primary); border-color: var(--ar-primary); color: var(--ar-primary-text); }
.ar-btn--primary:hover:not(:disabled) { filter: brightness(1.1); }
.ar-btn:disabled { opacity: .4; cursor: not-allowed; }
.ar-input {
  background: var(--ar-bg3); border: 1px solid var(--ar-border); border-radius: var(--ar-radius);
  color: var(--ar-text); font: inherit; font-size: .82rem; outline: none;
  padding: 5px 10px; transition: border-color var(--ar-transition); width: 100%;
}
.ar-input:focus { border-color: var(--ar-primary); }
.ar-input:disabled { opacity: .5; cursor: not-allowed; }
`;
    document.head.appendChild(s);
  }
};

// components/core/Animation.ts
var easing = {
  linear: (t) => t,
  easeInQuad: (t) => t * t,
  easeOutQuad: (t) => t * (2 - t),
  easeInOutQuad: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  easeInCubic: (t) => t * t * t,
  easeOutCubic: (t) => --t * t * t + 1,
  easeInOutCubic: (t) => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
  easeInQuart: (t) => t * t * t * t,
  easeOutQuart: (t) => 1 - --t * t * t * t,
  easeInElastic: (t) => t === 0 ? 0 : t === 1 ? 1 : -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * (2 * Math.PI) / 3),
  easeOutElastic: (t) => t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1,
  easeOutBounce: (t) => {
    const n1 = 7.5625, d1 = 2.75;
    if (t < 1 / d1) return n1 * t * t;
    if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
    if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
    return n1 * (t -= 2.625 / d1) * t + 0.984375;
  },
  easeInOutSine: (t) => -(Math.cos(Math.PI * t) - 1) / 2
};
function animate(opts) {
  const { from, to, duration, onUpdate, onComplete, signal: signal2 } = opts;
  const ease = opts.easing ?? easing.easeOutCubic;
  let start = 0;
  let raf = 0;
  let done = false;
  const step = (ts) => {
    if (done) return;
    if (signal2?.aborted) {
      done = true;
      return;
    }
    if (!start) start = ts;
    const elapsed = ts - start;
    const t = Math.min(elapsed / duration, 1);
    onUpdate(from + (to - from) * ease(t));
    if (t < 1) {
      raf = requestAnimationFrame(step);
    } else {
      done = true;
      onComplete?.();
    }
  };
  raf = requestAnimationFrame(step);
  return () => {
    done = true;
    cancelAnimationFrame(raf);
  };
}
function fadeIn(el, duration = 200) {
  el.style.opacity = "0";
  el.style.display = "";
  return new Promise((res) => animate({ from: 0, to: 1, duration, easing: easing.easeOutQuad, onUpdate: (v) => el.style.opacity = String(v), onComplete: res }));
}
function fadeOut(el, duration = 200) {
  return new Promise((res) => animate({ from: 1, to: 0, duration, easing: easing.easeInQuad, onUpdate: (v) => el.style.opacity = String(v), onComplete: () => {
    el.style.display = "none";
    res();
  } }));
}
function slideDown(el, duration = 250) {
  const targetH = el.scrollHeight;
  el.style.overflow = "hidden";
  el.style.height = "0";
  el.style.display = "";
  return new Promise((res) => animate({ from: 0, to: targetH, duration, easing: easing.easeOutCubic, onUpdate: (v) => el.style.height = v + "px", onComplete: () => {
    el.style.height = "";
    el.style.overflow = "";
    res();
  } }));
}
function slideUp(el, duration = 250) {
  const startH = el.offsetHeight;
  el.style.overflow = "hidden";
  return new Promise((res) => animate({ from: startH, to: 0, duration, easing: easing.easeInCubic, onUpdate: (v) => el.style.height = v + "px", onComplete: () => {
    el.style.display = "none";
    el.style.height = "";
    el.style.overflow = "";
    res();
  } }));
}
function stagger(els, fn, delay = 40) {
  Array.from(els).forEach(
    (el, i) => setTimeout(() => fn(el, i), i * delay)
  );
}

// components/charts/BarChart.ts
var BarChart = class extends Control {
  _data = [];
  constructor(container = null, opts = {}) {
    super(container, "div", { height: 220, color: "var(--ar-primary)", showValues: true, ...opts });
    this.el.className = `ar-chart ar-barchart${opts.class ? " " + opts.class : ""}`;
  }
  set data(v) {
    this._data = v;
    this._set("data", v);
  }
  get data() {
    return this._data;
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-chart__title", this.el).textContent = lbl;
    if (!this._data.length) {
      this._el("div", "ar-chart__empty", this.el).textContent = "No data";
      return;
    }
    const h = this._get("height", 220);
    const color = this._get("color", "var(--ar-primary)");
    const sv = this._get("showValues", true);
    const max = Math.max(...this._data.map((d) => d.value));
    const W = this._data.length * 60;
    const padB = 24;
    const padT = 20;
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${h}`);
    svg.style.width = "100%";
    svg.style.height = h + "px";
    svg.style.overflow = "visible";
    this._data.forEach((d, i) => {
      const barH = max ? d.value / max * (h - padT - padB) : 0;
      const x = i * 60 + 8;
      const bW = 44;
      const y = h - padB - barH;
      const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      rect.setAttribute("x", String(x));
      rect.setAttribute("y", String(y));
      rect.setAttribute("width", String(bW));
      rect.setAttribute("height", String(barH));
      rect.setAttribute("fill", d.color ?? color);
      rect.setAttribute("rx", "3");
      rect.style.cursor = "pointer";
      rect.addEventListener("click", () => this._emit("click", { bar: d }));
      svg.appendChild(rect);
      const tLbl = document.createElementNS("http://www.w3.org/2000/svg", "text");
      tLbl.setAttribute("x", String(x + bW / 2));
      tLbl.setAttribute("y", String(h - 6));
      tLbl.setAttribute("text-anchor", "middle");
      tLbl.setAttribute("fill", "var(--ar-muted)");
      tLbl.setAttribute("font-size", "10");
      tLbl.textContent = d.label;
      svg.appendChild(tLbl);
      if (sv && barH > 12) {
        const tVal = document.createElementNS("http://www.w3.org/2000/svg", "text");
        tVal.setAttribute("x", String(x + bW / 2));
        tVal.setAttribute("y", String(y - 4));
        tVal.setAttribute("text-anchor", "middle");
        tVal.setAttribute("fill", "var(--ar-text)");
        tVal.setAttribute("font-size", "10");
        tVal.textContent = String(d.value);
        svg.appendChild(tVal);
      }
    });
    this.el.appendChild(svg);
  }
};

// components/charts/PieChart.ts
var PIE_COLORS = ["#7eb8f7", "#4caf50", "#ff9800", "#f44336", "#4dd0e1", "#b39ddb", "#ff7043", "#a5d6a7"];
var PieChart = class extends Control {
  _data = [];
  constructor(container = null, opts = {}) {
    super(container, "div", { size: 180, donut: true, legend: true, ...opts });
    this.el.className = `ar-chart ar-piechart${opts.class ? " " + opts.class : ""}`;
  }
  set data(v) {
    this._data = v;
    this._set("data", v);
  }
  get data() {
    return this._data;
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-chart__title", this.el).textContent = lbl;
    if (!this._data.length) {
      this._el("div", "ar-chart__empty", this.el).textContent = "No data";
      return;
    }
    const size = this._get("size", 180);
    const R = size / 2;
    const r = this._get("donut", true) ? R * 0.55 : 0;
    const total = this._data.reduce((s, d) => s + d.value, 0);
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
    svg.style.width = size + "px";
    svg.style.height = size + "px";
    let angle = -Math.PI / 2;
    this._data.forEach((d, i) => {
      const slice = d.value / total * Math.PI * 2;
      const x1 = R + R * Math.cos(angle);
      const y1 = R + R * Math.sin(angle);
      const x2 = R + R * Math.cos(angle + slice);
      const y2 = R + R * Math.sin(angle + slice);
      const ix1 = R + r * Math.cos(angle);
      const iy1 = R + r * Math.sin(angle);
      const ix2 = R + r * Math.cos(angle + slice);
      const iy2 = R + r * Math.sin(angle + slice);
      const large = slice > Math.PI ? 1 : 0;
      const color = d.color ?? PIE_COLORS[i % PIE_COLORS.length];
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", r > 0 ? `M ${ix1} ${iy1} L ${x1} ${y1} A ${R} ${R} 0 ${large} 1 ${x2} ${y2} L ${ix2} ${iy2} A ${r} ${r} 0 ${large} 0 ${ix1} ${iy1} Z` : `M ${R} ${R} L ${x1} ${y1} A ${R} ${R} 0 ${large} 1 ${x2} ${y2} Z`);
      path.setAttribute("fill", color);
      path.style.cursor = "pointer";
      path.style.transition = "opacity .15s";
      path.addEventListener("mouseenter", () => path.style.opacity = "0.8");
      path.addEventListener("mouseleave", () => path.style.opacity = "1");
      path.addEventListener("click", () => this._emit("click", { slice: d }));
      svg.appendChild(path);
      angle += slice;
    });
    const wrap = this._el("div", "ar-piechart__wrap", this.el);
    wrap.appendChild(svg);
    if (this._get("legend", true)) {
      const leg = this._el("div", "ar-piechart__legend", this.el);
      this._data.forEach((d, i) => {
        const row = this._el("div", "ar-piechart__legend-row", leg);
        const dot = this._el("span", "ar-piechart__legend-dot", row);
        dot.style.background = d.color ?? PIE_COLORS[i % PIE_COLORS.length];
        this._el("span", "ar-piechart__legend-label", row).textContent = d.label;
        this._el("span", "ar-piechart__legend-value", row).textContent = Math.round(d.value / total * 100) + "%";
      });
    }
  }
};

// components/charts/LineChart.ts
var LineChart = class extends Control {
  _data = [];
  constructor(container = null, opts = {}) {
    super(container, "div", { height: 180, color: "var(--ar-primary)", area: true, showDots: true, smooth: true, ...opts });
    this.el.className = `ar-chart ar-linechart${opts.class ? " " + opts.class : ""}`;
  }
  set data(v) {
    this._data = v;
    this._set("data", v);
  }
  get data() {
    return this._data;
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-chart__title", this.el).textContent = lbl;
    if (this._data.length < 2) {
      this._el("div", "ar-chart__empty", this.el).textContent = "No data";
      return;
    }
    const h = this._get("height", 180);
    const W = 400;
    const pad = 22;
    const max = Math.max(...this._data.map((d2) => d2.value)) || 1;
    const pts = this._data.map((_, i) => ({
      x: pad + i * (W - 2 * pad) / (this._data.length - 1),
      y: pad + (1 - this._data[i].value / max) * (h - 2 * pad)
    }));
    const color = this._get("color", "var(--ar-primary)");
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${h}`);
    svg.style.width = "100%";
    svg.style.height = h + "px";
    const smooth = this._get("smooth", true);
    const d = smooth ? "M " + pts.map((p, i) => {
      if (!i) return `${p.x},${p.y}`;
      const prev = pts[i - 1];
      const cx = (prev.x + p.x) / 2;
      return `C ${cx},${prev.y} ${cx},${p.y} ${p.x},${p.y}`;
    }).join(" ") : "M " + pts.map((p) => `${p.x},${p.y}`).join(" L ");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", d);
    path.setAttribute("fill", "none");
    path.setAttribute("stroke", color);
    path.setAttribute("stroke-width", "2");
    path.setAttribute("stroke-linejoin", "round");
    svg.appendChild(path);
    if (this._get("area", true)) {
      const area = document.createElementNS("http://www.w3.org/2000/svg", "path");
      area.setAttribute("d", d + ` L ${pts[pts.length - 1].x},${h - pad} L ${pts[0].x},${h - pad} Z`);
      area.setAttribute("fill", color);
      area.setAttribute("fill-opacity", "0.1");
      svg.appendChild(area);
    }
    if (this._get("showDots", true)) pts.forEach((p) => {
      const c = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      c.setAttribute("cx", String(p.x));
      c.setAttribute("cy", String(p.y));
      c.setAttribute("r", "3");
      c.setAttribute("fill", color);
      svg.appendChild(c);
    });
    const step = Math.max(1, Math.ceil(this._data.length / 6));
    this._data.forEach((dp, i) => {
      if (i % step !== 0 && i !== this._data.length - 1) return;
      const t = document.createElementNS("http://www.w3.org/2000/svg", "text");
      t.setAttribute("x", String(pts[i].x));
      t.setAttribute("y", String(h - 4));
      t.setAttribute("text-anchor", "middle");
      t.setAttribute("font-size", "9");
      t.setAttribute("fill", "var(--ar-muted)");
      t.textContent = dp.label;
      svg.appendChild(t);
    });
    this.el.appendChild(svg);
  }
};

// components/finance/helpers.ts
function _svg(tag, attrs, inner = "") {
  const a = Object.entries(attrs).map(([k, v]) => `${k}="${v}"`).join(" ");
  return inner ? `<${tag} ${a}>${inner}</${tag}>` : `<${tag} ${a}/>`;
}
function _fmt(n, dec = 2) {
  return n.toFixed(dec);
}
function _fmtK(n) {
  return n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}K` : String(n);
}

// components/finance/CandlestickChart.ts
var CandlestickChart = class {
  #opts;
  #el;
  constructor(container, opts = {}) {
    this.#opts = {
      width: 800,
      height: 500,
      bullColor: "#26a69a",
      bearColor: "#ef5350",
      background: "#131722",
      gridColor: "#2a2e39",
      textColor: "#787b86",
      showVolume: true,
      maxBars: 100,
      ...opts
    };
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
  }
  render(bars) {
    const { width, height, bullColor, bearColor, background, gridColor, textColor, showVolume, maxBars } = this.#opts;
    const data = bars.slice(-maxBars);
    const chartH = showVolume ? height * 0.75 : height;
    const volH = height - chartH;
    const pad = { l: 60, r: 20, t: 20, b: showVolume ? 0 : 30 };
    const W = width - pad.l - pad.r;
    const H = chartH - pad.t - (showVolume ? 0 : pad.b);
    const bw = Math.max(1, W / data.length - 1);
    const prices = data.flatMap((b) => [b.high, b.low]);
    const minP = Math.min(...prices), maxP = Math.max(...prices);
    const rng = maxP - minP || 1;
    const pY = (p) => pad.t + (maxP - p) / rng * H;
    const bX = (i) => pad.l + i * (W / data.length) + bw / 4;
    let gridLines = "";
    for (let i = 0; i <= 5; i++) {
      const p = minP + i / 5 * rng, y = pY(p);
      gridLines += _svg("line", { x1: pad.l, y1: y, x2: pad.l + W, y2: y, stroke: gridColor, "stroke-width": 1 });
      gridLines += _svg("text", { x: pad.l - 5, y: y + 4, fill: textColor, "font-size": 11, "text-anchor": "end" }, _fmt(p));
    }
    let candles = "";
    for (let i = 0; i < data.length; i++) {
      const b = data[i];
      const color = b.close >= b.open ? bullColor : bearColor;
      const x = bX(i), cy1 = pY(b.high), cy2 = pY(b.low);
      const by1 = pY(Math.max(b.open, b.close)), by2 = pY(Math.min(b.open, b.close));
      candles += _svg("line", { x1: x + bw / 2, y1: cy1, x2: x + bw / 2, y2: cy2, stroke: color, "stroke-width": 1 });
      candles += _svg("rect", { x, y: by1, width: Math.max(1, bw), height: Math.max(1, by2 - by1), fill: color });
    }
    let volBars = "";
    if (showVolume && volH > 0) {
      const maxVol = Math.max(...data.map((b) => b.volume));
      for (let i = 0; i < data.length; i++) {
        const b = data[i], color = b.close >= b.open ? bullColor : bearColor;
        const vh = b.volume / maxVol * (volH - 10);
        volBars += _svg("rect", { x: bX(i), y: chartH + (volH - 10 - vh), width: Math.max(1, bw), height: Math.max(1, vh), fill: color, opacity: 0.6 });
      }
    }
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" style="background:${background};border-radius:4px">
${gridLines}${candles}${volBars}
</svg>`;
    return this;
  }
};

// components/finance/LineChart.ts
var LineChart2 = class {
  #el;
  #w;
  #h;
  #bg;
  #grid;
  #text;
  constructor(container, opts = {}) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
    this.#w = opts.width ?? 600;
    this.#h = opts.height ?? 300;
    this.#bg = opts.background ?? "#131722";
    this.#grid = opts.gridColor ?? "#2a2e39";
    this.#text = opts.textColor ?? "#787b86";
  }
  render(series) {
    const COLORS = ["#e40c88", "#26a69a", "#ef5350", "#f4c842", "#7b9ef9", "#ff9800"];
    const pad = { l: 55, r: 20, t: 20, b: 30 };
    const W = this.#w - pad.l - pad.r, H = this.#h - pad.t - pad.b;
    const allData = series.flatMap((s) => s.data);
    const minV = Math.min(...allData), maxV = Math.max(...allData);
    const rng = maxV - minV || 1;
    const maxLen = Math.max(...series.map((s) => s.data.length));
    const xS = (i) => pad.l + i / (maxLen - 1) * W;
    const yS = (v) => pad.t + (maxV - v) / rng * H;
    let grid = "", lines = "", legend = "";
    for (let i = 0; i <= 4; i++) {
      const v = minV + i / 4 * rng, y = yS(v);
      grid += _svg("line", { x1: pad.l, y1: y, x2: pad.l + W, y2: y, stroke: this.#grid, "stroke-width": 1 });
      grid += _svg("text", { x: pad.l - 5, y: y + 4, fill: this.#text, "font-size": 11, "text-anchor": "end" }, _fmt(v));
    }
    series.forEach((s, si) => {
      const color = s.color ?? COLORS[si % COLORS.length];
      const pts = s.data.map((v, i) => `${xS(i)},${yS(v)}`).join(" ");
      lines += _svg("polyline", { points: pts, fill: "none", stroke: color, "stroke-width": 2 });
      legend += `<text x="${pad.l + si * 120}" y="${this.#h - 5}" fill="${color}" font-size="12">${s.name}</text>`;
    });
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${this.#w}" height="${this.#h}" style="background:${this.#bg};border-radius:4px">${grid}${lines}${legend}</svg>`;
    return this;
  }
};

// components/finance/DepthChart.ts
var DepthChart = class {
  #el;
  #w;
  #h;
  constructor(container, opts = {}) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
    this.#w = opts.width ?? 600;
    this.#h = opts.height ?? 300;
  }
  render(bids, asks) {
    const pad = { l: 60, r: 20, t: 20, b: 30 };
    const W = this.#w - pad.l - pad.r, H = this.#h - pad.t - pad.b;
    const cumulate = (levels) => levels.reduce((acc, [p, q]) => {
      const prev = acc[acc.length - 1] ?? [p, 0];
      acc.push([p, prev[1] + q]);
      return acc;
    }, []);
    const cumBids = cumulate(bids);
    const cumAsks = cumulate(asks);
    const allPrices = [...bids.map((b) => b[0]), ...asks.map((a) => a[0])];
    const allSizes = [...cumBids.map((b) => b[1]), ...cumAsks.map((a) => a[1])];
    const minP = Math.min(...allPrices), maxP = Math.max(...allPrices);
    const maxS = Math.max(...allSizes) || 1;
    const xS = (p) => pad.l + (p - minP) / (maxP - minP) * W;
    const yS = (s) => pad.t + (1 - s / maxS) * H;
    const bidPts = cumBids.map(([p, s]) => `${xS(p)},${yS(s)}`).join(" ");
    const askPts = cumAsks.map(([p, s]) => `${xS(p)},${yS(s)}`).join(" ");
    const floor = pad.t + H;
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${this.#w}" height="${this.#h}" style="background:#131722;border-radius:4px">
<polyline points="${bidPts} ${xS(bids[0][0])},${floor}" fill="#26a69a33" stroke="#26a69a" stroke-width="2"/>
<polyline points="${askPts} ${xS(asks[asks.length - 1][0])},${floor}" fill="#ef535033" stroke="#ef5350" stroke-width="2"/>
</svg>`;
    return this;
  }
};

// components/finance/HeatmapChart.ts
var HeatmapChart = class {
  #el;
  #w;
  #h;
  constructor(container, opts = {}) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
    this.#w = opts.width ?? 600;
    this.#h = opts.height ?? 400;
  }
  render(labels, matrix) {
    const n = labels.length;
    const pad = 60, cellW = (this.#w - pad) / n, cellH = (this.#h - pad) / n;
    let cells = "", axes = "";
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        const v = matrix[i][j];
        const t = (v + 1) / 2;
        const r = Math.round(t < 0.5 ? 0 : (t - 0.5) * 2 * 239);
        const g = Math.round(t < 0.5 ? (0.5 - t) * 2 * 82 : (t - 0.5) * 2 * 68);
        const b = Math.round(t < 0.5 ? (0.5 - t) * 2 * 129 : 0);
        const x = pad + j * cellW, y = pad + i * cellH;
        cells += _svg("rect", { x, y, width: cellW, height: cellH, fill: `rgb(${r},${g},${b})` });
        cells += _svg("text", { x: x + cellW / 2, y: y + cellH / 2 + 5, fill: "#fff", "font-size": 10, "text-anchor": "middle" }, _fmt(v));
      }
      axes += _svg("text", { x: pad + i * cellW + cellW / 2, y: pad - 5, fill: "#787b86", "font-size": 11, "text-anchor": "middle" }, labels[i]);
      axes += _svg("text", { x: pad - 5, y: pad + i * cellH + cellH / 2 + 4, fill: "#787b86", "font-size": 11, "text-anchor": "end" }, labels[i]);
    }
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${this.#w}" height="${this.#h}" style="background:#131722;border-radius:4px">${axes}${cells}</svg>`;
    return this;
  }
};

// components/finance/PortfolioDonut.ts
var PortfolioDonut = class {
  #el;
  #size;
  constructor(container, opts = {}) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
    this.#size = opts.size ?? 300;
  }
  render(segments) {
    const COLORS = ["#e40c88", "#26a69a", "#7b9ef9", "#f4c842", "#ef5350", "#ff9800", "#ce93d8", "#80cbc4"];
    const total = segments.reduce((a, s) => a + s.value, 0);
    const cx = this.#size / 2, cy = this.#size / 2, R = cx * 0.7, r = cx * 0.4;
    let angle = -Math.PI / 2, arcs = "", legend = "";
    segments.forEach((seg, i) => {
      const slice = seg.value / total * 2 * Math.PI;
      const x1 = cx + R * Math.cos(angle), y1 = cy + R * Math.sin(angle);
      const x2 = cx + R * Math.cos(angle + slice), y2 = cy + R * Math.sin(angle + slice);
      const ix1 = cx + r * Math.cos(angle), iy1 = cy + r * Math.sin(angle);
      const ix2 = cx + r * Math.cos(angle + slice), iy2 = cy + r * Math.sin(angle + slice);
      const large = slice > Math.PI ? 1 : 0;
      const color = seg.color ?? COLORS[i % COLORS.length];
      arcs += `<path d="M${ix1},${iy1} L${x1},${y1} A${R},${R} 0 ${large},1 ${x2},${y2} L${ix2},${iy2} A${r},${r} 0 ${large},0 ${ix1},${iy1}" fill="${color}"/>`;
      const midA = angle + slice / 2;
      const lx = cx + R * 1.1 * Math.cos(midA), ly = cy + R * 1.1 * Math.sin(midA);
      legend += `<text x="${lx}" y="${ly}" fill="#fff" font-size="11" text-anchor="middle">${_fmt(seg.value / total * 100)}%</text>`;
      legend += `<text x="${lx}" y="${ly + 14}" fill="#787b86" font-size="10" text-anchor="middle">${seg.label}</text>`;
      angle += slice;
    });
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${this.#size}" height="${this.#size}" style="background:#131722;border-radius:4px">${arcs}${legend}</svg>`;
    return this;
  }
};

// components/finance/PnLChart.ts
var PnLChart = class {
  #el;
  #w;
  #h;
  constructor(container, opts = {}) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
    this.#w = opts.width ?? 500;
    this.#h = opts.height ?? 250;
  }
  render(data) {
    const pad = { l: 70, r: 20, t: 20, b: 40 };
    const W = this.#w - pad.l - pad.r, H = this.#h - pad.t - pad.b;
    const maxAbs = Math.max(...data.map((d) => Math.abs(d.pnl))) || 1;
    const bw = W / data.length - 2;
    const yZ = pad.t + H / 2;
    const yS = (v) => v >= 0 ? yZ - v / maxAbs * (H / 2) : yZ;
    const bH = (v) => Math.abs(v) / maxAbs * (H / 2);
    let bars = "", labels = "";
    data.forEach((d, i) => {
      const x = pad.l + i * (W / data.length);
      const color = d.pnl >= 0 ? "#26a69a" : "#ef5350";
      bars += _svg("rect", { x, y: yS(d.pnl), width: Math.max(1, bw), height: Math.max(1, bH(d.pnl)), fill: color });
      labels += _svg("text", { x: x + bw / 2, y: pad.t + H + 15, fill: "#787b86", "font-size": 10, "text-anchor": "middle" }, d.label);
    });
    let axes = _svg("line", { x1: pad.l, y1: yZ, x2: pad.l + W, y2: yZ, stroke: "#2a2e39", "stroke-width": 1 });
    for (let i = -2; i <= 2; i++) {
      const v = i / 2 * maxAbs, y = yZ - i / 2 * H / 2;
      axes += _svg("text", { x: pad.l - 5, y: y + 4, fill: "#787b86", "font-size": 10, "text-anchor": "end" }, _fmtK(v));
    }
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${this.#w}" height="${this.#h}" style="background:#131722;border-radius:4px">${axes}${bars}${labels}</svg>`;
    return this;
  }
};

// components/finance/RiskGauge.ts
var RiskGauge = class {
  #el;
  #size;
  constructor(container, opts = {}) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
    this.#size = opts.size ?? 200;
  }
  render(value, min = 0, max = 100, label = "Risk") {
    const s = this.#size, cx = s / 2, cy = s * 0.6, R = s * 0.4;
    const t = (value - min) / (max - min);
    const endA = Math.PI + t * Math.PI;
    const color = t < 0.33 ? "#26a69a" : t < 0.66 ? "#f4c842" : "#ef5350";
    const aX = (a) => cx + R * Math.cos(a);
    const aY = (a) => cy + R * Math.sin(a);
    const bgPath = `M${aX(Math.PI)},${aY(Math.PI)} A${R},${R} 0 0,1 ${aX(0)},${aY(0)}`;
    const fgPath = `M${aX(Math.PI)},${aY(Math.PI)} A${R},${R} 0 ${t > 0.5 ? 1 : 0},1 ${aX(endA)},${aY(endA)}`;
    const sw = R * 0.3;
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s * 0.7}" style="background:#131722;border-radius:4px">
<path d="${bgPath}" fill="none" stroke="#2a2e39" stroke-width="${sw}"/>
<path d="${fgPath}" fill="none" stroke="${color}" stroke-width="${sw}"/>
<line x1="${cx}" y1="${cy}" x2="${aX(endA) * 0.85 + cx * 0.15}" y2="${aY(endA) * 0.85 + cy * 0.15}" stroke="#fff" stroke-width="2"/>
<circle cx="${cx}" cy="${cy}" r="4" fill="#fff"/>
<text x="${cx}" y="${cy - 10}" fill="${color}" font-size="16" font-weight="bold" text-anchor="middle">${_fmt(value)}</text>
<text x="${cx}" y="${cy + 5}" fill="#787b86" font-size="11" text-anchor="middle">${label}</text>
</svg>`;
    return this;
  }
};

// components/finance/OrderBook.ts
var OrderBook = class {
  #el;
  constructor(container) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
  }
  render(bids, asks, depth = 10) {
    const row = (price, size, side) => `<tr><td style="color:${side === "bid" ? "#26a69a" : "#ef5350"};padding:2px 8px">${_fmt(price)}</td><td style="color:#fff;padding:2px 8px;text-align:right">${_fmtK(size)}</td></tr>`;
    const askRows = asks.slice(0, depth).reverse().map(([p, s]) => row(p, s, "ask")).join("");
    const bidRows = bids.slice(0, depth).map(([p, s]) => row(p, s, "bid")).join("");
    const midPrice = ((asks[0]?.[0] ?? 0) + (bids[0]?.[0] ?? 0)) / 2;
    const spread = (asks[0]?.[0] ?? 0) - (bids[0]?.[0] ?? 0);
    this.#el.innerHTML = `<div style="background:#131722;border-radius:4px;padding:8px;font-family:monospace;font-size:12px">
<table style="width:100%;border-collapse:collapse">
<thead><tr><th style="color:#787b86;text-align:left;padding:2px 8px">Price</th><th style="color:#787b86;text-align:right;padding:2px 8px">Size</th></tr></thead>
<tbody>${askRows}</tbody>
</table>
<div style="color:#f4c842;padding:4px 8px;border-top:1px solid #2a2e39;border-bottom:1px solid #2a2e39">Mid: ${_fmt(midPrice)} | Spread: ${_fmt(spread)}</div>
<table style="width:100%;border-collapse:collapse">
<tbody>${bidRows}</tbody>
</table></div>`;
    return this;
  }
};

// components/finance/Screener.ts
var Screener = class {
  #el;
  constructor(container) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
  }
  render(rows, columns) {
    const cols = columns ?? ["symbol", "price", "change", "volume"];
    const header = cols.map(
      (c) => `<th style="padding:6px 12px;border-bottom:1px solid #2a2e39;color:#787b86;font-weight:500">${String(c).toUpperCase()}</th>`
    ).join("");
    const body = rows.map((row) => {
      const cells = cols.map((c) => {
        let val = row[c];
        let style = "padding:6px 12px;";
        if (c === "change") {
          const n = Number(val);
          style += `color:${n >= 0 ? "#26a69a" : "#ef5350"}`;
          val = `${n >= 0 ? "+" : ""}${_fmt(n)}%`;
        } else if (c === "symbol") {
          style += "color:#fff;font-weight:600";
        } else if (typeof val === "number") {
          val = _fmtK(val);
        }
        return `<td style="${style}">${String(val)}</td>`;
      }).join("");
      return `<tr style="border-bottom:1px solid #1e222d">${cells}</tr>`;
    }).join("");
    this.#el.innerHTML = `<div style="background:#131722;border-radius:4px;overflow:auto;font-family:sans-serif;font-size:13px">
<table style="width:100%;border-collapse:collapse">
<thead><tr>${header}</tr></thead>
<tbody>${body}</tbody>
</table></div>`;
    return this;
  }
};

// components/finance/Sparkline.ts
var Sparkline = class {
  #el;
  constructor(container) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
  }
  render(data, opts = {}) {
    const w = opts.width ?? 100, h = opts.height ?? 30;
    const color = opts.color ?? (data[data.length - 1] >= data[0] ? "#26a69a" : "#ef5350");
    const mn = Math.min(...data), mx = Math.max(...data), rng = mx - mn || 1;
    const pts = data.map((v, i) => `${w * i / (data.length - 1)},${h - (v - mn) / rng * h}`).join(" ");
    this.#el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="1.5"/></svg>`;
    return this;
  }
};

// components/finance/AlertBadge.ts
var AlertBadge = class {
  #el;
  constructor(container) {
    this.#el = typeof container === "string" ? document.querySelector(container) ?? document.body : container;
  }
  render(text, level = "neutral", sublabel) {
    const colors = {
      neutral: ["#2a2e39", "#787b86"],
      info: ["#1e3a5f", "#7b9ef9"],
      warning: ["#3d2e00", "#f4c842"],
      danger: ["#3d0000", "#ef5350"]
    };
    const [bg, fg] = colors[level];
    this.#el.innerHTML = `<div style="display:inline-flex;align-items:center;gap:6px;background:${bg};border-radius:4px;padding:4px 10px;font-family:sans-serif">
<span style="color:${fg};font-size:13px;font-weight:600">${text}</span>
${sublabel ? `<span style="color:#787b86;font-size:11px">${sublabel}</span>` : ""}
</div>`;
    return this;
  }
};

// components/finance/index.ts
var FinanceComponents = {
  CandlestickChart,
  LineChart: LineChart2,
  DepthChart,
  HeatmapChart,
  PortfolioDonut,
  PnLChart,
  RiskGauge,
  OrderBook,
  Screener,
  Sparkline,
  AlertBadge
};

// components/data/Table.ts
var LRUCache = class {
  _map = /* @__PURE__ */ new Map();
  _cap;
  constructor(capacity) {
    this._cap = capacity;
  }
  get(key) {
    if (!this._map.has(key)) return void 0;
    const v = this._map.get(key);
    this._map.delete(key);
    this._map.set(key, v);
    return v;
  }
  set(key, value) {
    if (this._map.has(key)) this._map.delete(key);
    else if (this._map.size >= this._cap) this._map.delete(this._map.keys().next().value);
    this._map.set(key, value);
  }
  clear() {
    this._map.clear();
  }
};
var WORKER_SRC = `
self.onmessage = function(e) {
  const { rows, sort, filter, columnFilters, columns } = e.data;
  let result = rows.slice();

  // Global filter
  if (filter) {
    const q = filter.toLowerCase();
    result = result.filter(row =>
      Object.values(row).some(v => String(v ?? '').toLowerCase().includes(q))
    );
  }

  // Column filters
  if (columnFilters) {
    Object.entries(columnFilters).forEach(([key, val]) => {
      if (!val) return;
      const q = val.toLowerCase();
      result = result.filter(row => String(row[key] ?? '').toLowerCase().includes(q));
    });
  }

  // Sort
  if (sort && sort.key) {
    const dir = sort.dir === 'asc' ? 1 : -1;
    result.sort((a: R, b: R) => {
      const av = a[sort.key] ?? '';
      const bv = b[sort.key] ?? '';
      if (av < bv) return -dir;
      if (av > bv) return  dir;
      return 0;
    });
  }

  self.postMessage({ rows: result, total: result.length });
};
`;
var Table = class extends Control {
  _expandedRows = /* @__PURE__ */ new Set();
  _renderRows() {
    this._renderBody();
  }
  _build() {
    this._renderBody();
  }
  /** Full client-side dataset. */
  _data = [];
  /** Currently visible rows (after sort+filter). */
  _rows = [];
  /** Total row count (for server-side). */
  _total = 0;
  /** Current page (1-indexed). */
  _page = 1;
  /** Current page size. */
  _pageSize;
  /** Current sort state. */
  _sort;
  /** Current global filter. */
  _filter = "";
  /** Current column filters. */
  _colFilters = {};
  /** Selected row indices (by row reference). */
  _selected = /* @__PURE__ */ new Set();
  /** Loading state. */
  _loading = false;
  /** Web Worker instance. */
  _worker;
  /** Pending worker resolve. */
  _workerResolve;
  /** LRU page cache. */
  _cache;
  /** Column resize state. */
  _resizeCol;
  /** DOM refs. */
  _dom = {};
  // ── Constructor ─────────────────────────────────────────────────────────────
  constructor(container = null, options) {
    super(container, "div", {
      paging: { pageSize: 25, sizes: [10, 25, 50, 100] },
      selectable: "none",
      checkboxes: false,
      worker: false,
      cache: false,
      cacheSize: 20,
      searchable: true,
      columnFilters: false,
      columnToggle: false,
      resizable: false,
      stickyHeader: true,
      info: true,
      exportCsv: false,
      emptyText: "No data",
      loadingText: "Loading\u2026",
      ...options
    });
    this.el.className = `arianna-table-wrap${options.class ? " " + options.class : ""}`;
    const paging = this.get("paging");
    this._pageSize = paging ? paging.pageSize ?? 25 : Infinity;
    this._page = paging ? paging.page ?? 1 : 1;
    if (this.get("worker") && !this.get("fetch")) {
      const blob = new Blob([WORKER_SRC], { type: "text/javascript" });
      const url = URL.createObjectURL(blob);
      this._worker = new Worker(url);
      this._worker.onmessage = (e) => {
        if (this._workerResolve) {
          this._workerResolve(e.data.rows);
          this._total = e.data.total;
          this._workerResolve = void 0;
        }
      };
      this._onDestroy(() => {
        this._worker?.terminate();
        URL.revokeObjectURL(url);
      });
    }
    if (this.get("cache") && this.get("fetch")) {
      this._cache = new LRUCache(this.get("cacheSize") ?? 20);
    }
  }
  // ── Data ────────────────────────────────────────────────────────────────────
  /**
   * Load client-side data.
   * Triggers a re-render if mounted.
   *
   * @example
   *   table.load(myRows);
   */
  load(data) {
    this._data = data;
    this._total = data.length;
    this._page = 1;
    if (this._mounted) this._process().then(() => this._renderBody());
    return this;
  }
  /**
   * Append rows to client-side data.
   */
  append(rows) {
    this._data.push(...rows);
    this._total = this._data.length;
    if (this._mounted) this._process().then(() => this._renderBody());
    return this;
  }
  /**
   * Clear all data.
   */
  clear() {
    this._data = [];
    this._rows = [];
    this._total = 0;
    this._page = 1;
    if (this._mounted) this._renderBody();
    return this;
  }
  /**
   * Reload data — re-triggers fetch (server-side) or re-processes (client-side).
   */
  reload() {
    this._page = 1;
    if (this._mounted) this._load();
    return this;
  }
  /**
   * Invalidate the cache and reload.
   */
  invalidateCache() {
    this._cache?.clear();
    return this.reload();
  }
  // ── Selection ────────────────────────────────────────────────────────────────
  /**
   * Get all selected rows.
   */
  getSelected() {
    return [...this._selected];
  }
  /**
   * Clear selection.
   */
  clearSelection() {
    this._selected.clear();
    this._dom.tbody?.querySelectorAll("tr.selected").forEach((r) => r.classList.remove("selected"));
    return this;
  }
  // ── Export ───────────────────────────────────────────────────────────────────
  /**
   * Export current view to CSV and trigger download.
   */
  exportToCsv(filename = "export.csv") {
    const cols = this.get("columns") ?? [].filter((c) => c.visible !== false);
    const header = cols.map((c) => JSON.stringify(c.label)).join(",");
    const rowLines = this._rows.map(
      (row) => cols.map((c) => {
        const v = c.value ? c.value(row) : row[c.key];
        return JSON.stringify(String(v ?? ""));
      }).join(",")
    );
    const csv = [header, ...rowLines].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  // ── Render ───────────────────────────────────────────────────────────────────
  _render() {
    this.el.innerHTML = "";
    const opts = this._state.State;
    this._dom.toolbar = this._el("div", "arianna-wip-table__toolbar", this.el);
    this._buildToolbar();
    const tableWrap = this._el("div", "arianna-wip-table__scroll", this.el);
    this._dom.table = document.createElement("table");
    this._dom.table.className = "arianna-wip-table";
    this._dom.table.setAttribute("role", "grid");
    tableWrap.appendChild(this._dom.table);
    this._dom.thead = this._dom.table.createTHead();
    this._dom.tbody = this._dom.table.createTBody();
    this._buildHeader();
    this._dom.empty = this._el("div", "arianna-wip-table__empty", this.el);
    this._dom.empty.textContent = opts.emptyText ?? "No data";
    this._dom.empty.style.display = "none";
    this._dom.spinner = this._el("div", "arianna-wip-table__spinner", this.el);
    this._dom.spinner.textContent = opts.loadingText ?? "Loading\u2026";
    this._dom.spinner.style.display = "none";
    this._dom.footer = this._el("div", "arianna-wip-table__footer", this.el);
    this._dom.info = this._el("span", "arianna-wip-table__info", this._dom.footer);
    this._dom.pager = this._el("div", "arianna-wip-table__pager", this._dom.footer);
    this._load();
  }
  _buildToolbar() {
    const opts = this._state.State;
    const tb = this._dom.toolbar;
    if (opts.searchable) {
      const input = document.createElement("input");
      input.type = "text";
      input.placeholder = "Search\u2026";
      input.className = "arianna-wip-table__search";
      input.value = this._filter;
      this._listen(input, "input", () => {
        this._filter = input.value;
        this._page = 1;
        this._load();
      });
      tb.appendChild(input);
    }
    if (opts.exportCsv) {
      const btn = document.createElement("button");
      btn.className = "arianna-wip-table__btn";
      btn.textContent = "\u2193 CSV";
      btn.addEventListener("click", () => this.exportToCsv());
      tb.appendChild(btn);
    }
    if (opts.columnToggle) {
      const btn = document.createElement("button");
      btn.className = "arianna-wip-table__btn";
      btn.textContent = "\u229E Columns";
      btn.addEventListener("click", () => this._showColumnToggle(btn));
      tb.appendChild(btn);
    }
  }
  _buildHeader() {
    const opts = this._state.State;
    const tr = this._dom.thead.insertRow();
    tr.setAttribute("role", "row");
    if (opts.checkboxes && opts.selectable === "multi") {
      const th = document.createElement("th");
      th.className = "arianna-wip-table__th arianna-wip-table__th--check";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.addEventListener("change", () => {
        if (cb.checked) this._rows.forEach((r) => this._selected.add(r));
        else this._selected.clear();
        this._renderBody();
      });
      th.appendChild(cb);
      tr.appendChild(th);
    }
    (opts.columns ?? []).filter((c) => c.visible !== false).forEach((col) => {
      const th = document.createElement("th");
      th.className = `arianna-table__th ${col.headerClass ?? ""}`;
      th.setAttribute("role", "columnheader");
      th.setAttribute("aria-sort", "none");
      th.style.width = col.width ? typeof col.width === "number" ? col.width + "px" : col.width : "";
      if (col.align) th.style.textAlign = col.align;
      const inner = this._el("div", "arianna-wip-table__th-inner", th);
      if (col.renderHeader) {
        const h = col.renderHeader(col);
        if (typeof h === "string") inner.innerHTML = h;
        else inner.appendChild(h);
      } else {
        inner.textContent = col.label;
      }
      if (col.sortable) {
        th.classList.add("arianna-wip-table__th--sortable");
        const arrow = this._el("span", "arianna-wip-table__sort-arrow", inner);
        arrow.textContent = this._sort?.key === col.key ? this._sort.dir === "asc" ? "\u2191" : "\u2193" : "\u2195";
        th.addEventListener("click", () => this._toggleSort(col));
      }
      if (opts.resizable && col.resizable !== false) {
        const handle = this._el("div", "arianna-wip-table__resize-handle", th);
        this._listen(handle, "mousedown", (e) => {
          this._resizeCol = {
            col,
            startX: e.clientX,
            startW: th.offsetWidth
          };
        });
      }
      if (opts.columnFilters && col.filterable) {
        const fi = document.createElement("input");
        fi.type = "text";
        fi.placeholder = "\u2026";
        fi.className = "arianna-wip-table__col-filter";
        fi.value = this._colFilters[col.key] ?? "";
        fi.addEventListener("input", () => {
          this._colFilters[col.key] = fi.value;
          this._page = 1;
          this._load();
        });
        fi.addEventListener("click", (e) => e.stopPropagation());
        th.appendChild(fi);
      }
      tr.appendChild(th);
    });
    this._listen(document, "mousemove", (e) => {
      if (!this._resizeCol) return;
      const dx = e.clientX - this._resizeCol.startX;
      const min = this._resizeCol.col.minWidth ?? 60;
      const w = Math.max(min, this._resizeCol.startW + dx);
      const idx = (opts.columns ?? []).findIndex((c) => c.key === this._resizeCol.col.key);
      const th = this._dom.thead.rows[0]?.cells[idx];
      if (th) th.style.width = w + "px";
      this._resizeCol.col.width = w;
    });
    this._listen(document, "mouseup", () => {
      this._resizeCol = void 0;
    });
  }
  _renderBody() {
    const opts = this._state.State;
    const tbody = this._dom.tbody;
    tbody.innerHTML = "";
    if (this._loading) {
      this._dom.spinner.style.display = "";
      this._dom.empty.style.display = "none";
      this._renderFooter();
      return;
    }
    this._dom.spinner.style.display = "none";
    if (!this._rows.length) {
      this._dom.empty.style.display = "";
      this._renderFooter();
      return;
    }
    this._dom.empty.style.display = "none";
    this._rows.forEach((row, ri) => {
      const tr = tbody.insertRow();
      tr.setAttribute("role", "row");
      if (this._selected.has(row)) tr.classList.add("selected");
      if (opts.expandable) {
        const td = tr.insertCell();
        td.className = "ar-table__td ar-table__td--exp";
        const btn = document.createElement("button");
        btn.className = "ar-table__exp-btn";
        const idx2 = ri;
        btn.innerHTML = this._expandedRows.has(idx2) ? "\u25BE" : "\u25B8";
        btn.addEventListener("click", async (e) => {
          e.stopPropagation();
          if (this._expandedRows.has(idx2)) {
            this._expandedRows.delete(idx2);
            this._emit("collapse", { row, index: idx2 });
          } else {
            if (opts.expandSingle) this._expandedRows.clear();
            this._expandedRows.add(idx2);
            this._emit("expand", { row, index: idx2 });
          }
          this._renderRows();
          if (this._expandedRows.has(idx2) && opts.rowContent) {
            const detailRow = tbody.querySelector(`[data-exp-detail="${idx2}"]`);
            if (detailRow) {
              const cell = detailRow.querySelector("td");
              if (cell) {
                cell.innerHTML = '<span style="color:var(--ar-muted);font-size:.8rem">Loading\u2026</span>';
                const content = await opts.rowContent(row);
                if (typeof content === "string") cell.innerHTML = content;
                else {
                  cell.innerHTML = "";
                  cell.appendChild(content);
                }
              }
            }
          }
        });
        td.appendChild(btn);
      }
      tr.addEventListener("click", (e) => {
        const mode = opts.selectable;
        if (mode === "none") {
          opts.onRowClick?.(row, e);
          return;
        }
        if (mode === "single") {
          this._selected.clear();
        }
        if (this._selected.has(row)) this._selected.delete(row);
        else this._selected.add(row);
        this._renderBody();
        this._fire("select", { rows: this.getSelected(), row });
        opts.onRowClick?.(row, e);
      });
      if (opts.checkboxes && opts.selectable === "multi") {
        const td = tr.insertCell();
        td.className = "arianna-wip-table__td arianna-wip-table__td--check";
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = this._selected.has(row);
        cb.addEventListener("change", (e) => {
          e.stopPropagation();
          if (cb.checked) this._selected.add(row);
          else this._selected.delete(row);
          if (cb.checked) tr.classList.add("selected");
          else tr.classList.remove("selected");
          this._fire("select", { rows: this.getSelected(), row });
        });
        td.appendChild(cb);
      }
      (opts.columns ?? []).filter((c) => c.visible !== false).forEach((col) => {
        const td = tr.insertCell();
        td.className = `arianna-table__td ${col.class ?? ""}`;
        td.setAttribute("role", "gridcell");
        if (col.align) td.style.textAlign = col.align;
        const v = col.value ? col.value(row) : row[col.key];
        if (col.render) {
          const r = col.render(v, row, col);
          if (typeof r === "string") td.innerHTML = r;
          else td.appendChild(r);
        } else {
          td.textContent = String(v ?? "");
        }
      });
    });
    this._renderFooter();
  }
  _renderFooter() {
    const opts = this._state.State;
    const paging = opts.paging;
    const info = this._dom.info;
    const pager = this._dom.pager;
    pager.innerHTML = "";
    if (opts.info) {
      if (paging) {
        const start2 = (this._page - 1) * this._pageSize + 1;
        const end2 = Math.min(this._page * this._pageSize, this._total);
        info.textContent = `${start2}\u2013${end2} of ${this._total}`;
      } else {
        info.textContent = `${this._total} rows`;
      }
    }
    if (!paging || this._total <= this._pageSize) return;
    const totalPages = Math.ceil(this._total / this._pageSize);
    if (paging.sizes && paging.sizes.length > 1) {
      const sel = document.createElement("select");
      sel.className = "arianna-wip-table__page-size";
      paging.sizes.forEach((s) => {
        const o = document.createElement("option");
        o.value = String(s);
        o.textContent = `${s} / page`;
        if (s === this._pageSize) o.selected = true;
        sel.appendChild(o);
      });
      sel.addEventListener("change", () => {
        this._pageSize = Number(sel.value);
        this._page = 1;
        this._load();
      });
      pager.appendChild(sel);
    }
    this._pageBtn(pager, "\u2039", this._page > 1, () => {
      this._page--;
      this._load();
    });
    const half = 2;
    const start = Math.max(1, Math.min(this._page - half, totalPages - 4));
    const end = Math.min(totalPages, start + 4);
    for (let p = start; p <= end; p++) {
      this._pageBtn(
        pager,
        String(p),
        true,
        () => {
          this._page = p;
          this._load();
        },
        p === this._page
      );
    }
    this._pageBtn(pager, "\u203A", this._page < totalPages, () => {
      this._page++;
      this._load();
    });
    this._fire("page", { page: this._page, pageSize: this._pageSize, total: this._total });
  }
  _pageBtn(parent, label, enabled, onClick, active = false) {
    const btn = document.createElement("button");
    btn.className = `arianna-table__page-btn${active ? " active" : ""}`;
    btn.textContent = label;
    btn.disabled = !enabled;
    btn.addEventListener("click", onClick);
    parent.appendChild(btn);
  }
  // ── Data processing ──────────────────────────────────────────────────────────
  async _load() {
    const fetchFn = this.get("fetch");
    if (fetchFn) {
      await this._fetchRemote(fetchFn);
    } else {
      await this._processLocal();
    }
    this._renderBody();
  }
  async _fetchRemote(fetchFn) {
    const cacheKey = JSON.stringify({
      page: this._page,
      pageSize: this._pageSize,
      sort: this._sort,
      filter: this._filter,
      colFilters: this._colFilters
    });
    if (this._cache) {
      const cached = this._cache.get(cacheKey);
      if (cached) {
        this._rows = cached.rows;
        this._total = cached.total;
        return;
      }
    }
    this._loading = true;
    this._renderBody();
    try {
      const result = await fetchFn({
        page: this._page,
        pageSize: this._pageSize,
        sort: this._sort,
        filter: this._filter,
        filters: this._colFilters
      });
      this._rows = result.rows;
      this._total = result.total;
      this._cache?.set(cacheKey, result);
      this._fire("load", { rows: this._rows, total: this._total });
    } catch (err) {
      this._fire("error", { error: err });
    } finally {
      this._loading = false;
    }
  }
  async _processLocal() {
    const paging = this.get("paging");
    const opts = this._state.State;
    if (this._worker && this._worker) {
      await this._processWithWorker();
    } else {
      this._processSync();
    }
    if (paging) {
      const start = (this._page - 1) * this._pageSize;
      this._rows = this._rows.slice(start, start + this._pageSize);
    }
    this._fire("load", { rows: this._rows, total: this._total });
  }
  _processSync() {
    const opts = this._state.State;
    let rows = this._data.slice();
    if (this._filter) {
      const q = this._filter.toLowerCase();
      rows = rows.filter(
        (row) => Object.values(row).some((v) => String(v ?? "").toLowerCase().includes(q))
      );
    }
    Object.entries(this._colFilters).forEach(([key, val]) => {
      if (!val) return;
      const q = val.toLowerCase();
      rows = rows.filter((row) => String(row[key] ?? "").toLowerCase().includes(q));
    });
    if (this._sort) {
      const { key, dir } = this._sort;
      const col = (opts.columns ?? []).find((c) => c.key === key);
      const d = dir === "asc" ? 1 : -1;
      rows.sort((a, b) => {
        if (col?.sort) return col.sort(a, b, dir);
        const av = col?.value ? col.value(a) : a[key] ?? "";
        const bv = col?.value ? col.value(b) : b[key] ?? "";
        return av < bv ? -d : av > bv ? d : 0;
      });
    }
    this._total = rows.length;
    this._rows = rows;
  }
  _processWithWorker() {
    return new Promise((resolve) => {
      this._workerResolve = (rows) => {
        this._rows = rows;
        resolve();
      };
      this._worker.postMessage({
        rows: this._data,
        sort: this._sort,
        filter: this._filter,
        columnFilters: this._colFilters,
        columns: this.get("columns") ?? [].map((c) => ({ key: c.key }))
      });
    });
  }
  // ── Sort ─────────────────────────────────────────────────────────────────────
  _toggleSort(col) {
    if (!this._sort || this._sort.key !== col.key) {
      this._sort = { key: col.key, dir: "asc" };
    } else if (this._sort.dir === "asc") {
      this._sort = { key: col.key, dir: "desc" };
    } else {
      this._sort = void 0;
    }
    this._page = 1;
    this._rebuildHeader();
    this._load();
    this._fire("sort", { column: col, sort: this._sort });
  }
  _rebuildHeader() {
    this._dom.thead.innerHTML = "";
    this._buildHeader();
  }
  // ── Column toggle ────────────────────────────────────────────────────────────
  _showColumnToggle(anchor) {
    const existing = document.querySelector(".arianna-wip-table__col-menu");
    if (existing) {
      existing.remove();
      return;
    }
    const menu = document.createElement("div");
    menu.className = "arianna-wip-table__col-menu";
    const rect = anchor.getBoundingClientRect();
    menu.style.position = "fixed";
    menu.style.top = rect.bottom + 4 + "px";
    menu.style.left = rect.left + "px";
    this.get("columns") ?? [].forEach((col) => {
      const row = document.createElement("label");
      row.className = "arianna-wip-table__col-menu-row";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = col.visible !== false;
      cb.addEventListener("change", () => {
        col.visible = cb.checked;
        this._rebuildHeader();
        this._renderBody();
      });
      row.appendChild(cb);
      row.appendChild(document.createTextNode(" " + col.label));
      menu.appendChild(row);
    });
    document.body.appendChild(menu);
    const close = (e) => {
      if (!menu.contains(e.target) && e.target !== anchor) {
        menu.remove();
        document.removeEventListener("click", close);
      }
    };
    setTimeout(() => document.addEventListener("click", close), 10);
  }
  // ── Process ──────────────────────────────────────────────────────────────────
  async _process() {
    return this._processLocal();
  }
};

// components/data/TreeView.ts
var TreeView = class extends Control {
  _roots = [];
  _map = /* @__PURE__ */ new Map();
  _focus = null;
  _q = "";
  _list;
  constructor(container = null, opts = {}) {
    super(container, "div", {
      selectable: "single",
      icons: true,
      badges: true,
      indent: 20,
      rowHeight: 32,
      keyboard: true,
      search: true,
      draggable: false,
      checkboxes: false,
      expandOnSelect: false,
      ...opts
    });
    this.el.className = `ar-tree${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("role", "tree");
    this.el.tabIndex = 0;
  }
  set nodes(v) {
    this._roots = [];
    this._map.clear();
    this._roots = v.map((n) => this._ns(n, null, 0));
    this._build();
  }
  get nodes() {
    return this._roots.map((s) => s.node);
  }
  expand(id) {
    const s = this._map.get(id);
    if (s && !s.expanded) this._expand(s);
  }
  collapse(id) {
    const s = this._map.get(id);
    if (s && s.expanded) this._collapse(s);
  }
  expandAll() {
    this._map.forEach((s) => {
      if (!s.expanded) this._expand(s);
    });
  }
  collapseAll() {
    this._map.forEach((s) => {
      if (s.expanded) this._collapse(s);
    });
  }
  select(id) {
    const s = this._map.get(id);
    if (!s || s.node.selectable === false) return;
    if (this._get("selectable", "single") === "single") this._clearSel();
    this._setSel(s, true);
  }
  deselect(id) {
    const s = this._map.get(id);
    if (s) this._setSel(s, false);
  }
  getSelected() {
    return [...this._map.values()].filter((s) => s.selected).map((s) => s.node);
  }
  check(id, v = true) {
    const s = this._map.get(id);
    if (s) this._setChecked(s, v);
  }
  getChecked() {
    return [...this._map.values()].filter((s) => s.checked).map((s) => s.node);
  }
  search(q) {
    this._q = q.toLowerCase().trim();
    this._applyFilter();
  }
  _build() {
    this.el.innerHTML = "";
    const opts = this._state.State;
    if (opts.search) {
      const inp = document.createElement("input");
      inp.type = "text";
      inp.className = "ar-tree__search";
      inp.placeholder = "Search\u2026";
      inp.value = this._q;
      inp.addEventListener("input", () => {
        this._q = inp.value.toLowerCase().trim();
        this._applyFilter();
      });
      this.el.appendChild(inp);
    }
    this._list = this._el("ul", "ar-tree__list", this.el);
    this._list.setAttribute("role", "group");
    this._roots.forEach((s) => this._renderNode(s, this._list));
    if (opts.keyboard) this._on(this.el, "keydown", (e) => this._onKey(e));
  }
  _renderNode(s, parent) {
    const opts = this._state.State;
    const hasChildren = (s.node.children?.length ?? 0) > 0 || s.node.lazy;
    const li = this._el("li", "ar-tree__node", parent);
    li.setAttribute("role", "treeitem");
    li.setAttribute("aria-expanded", String(s.expanded));
    li.setAttribute("aria-selected", String(s.selected));
    li.dataset.id = s.node.id;
    if (s.node.class) li.classList.add(...s.node.class.split(" "));
    s.el = li;
    const row = this._el("div", `ar-tree__row${s.selected ? " ar-tree__row--on" : ""}`, li);
    row.style.paddingLeft = s.depth * (opts.indent ?? 20) + 8 + "px";
    row.style.height = (opts.rowHeight ?? 32) + "px";
    const arrow = this._el("span", "ar-tree__arrow", row);
    if (hasChildren) {
      arrow.textContent = s.loading ? "\u27F3" : s.expanded ? "\u25BE" : "\u25B8";
      arrow.addEventListener("click", (e) => {
        e.stopPropagation();
        s.expanded ? this._collapse(s) : this._expand(s);
      });
    }
    if (opts.checkboxes) {
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.className = "ar-tree__cb";
      cb.checked = s.checked;
      cb.addEventListener("change", () => this._setChecked(s, cb.checked));
      row.appendChild(cb);
    }
    if (opts.icons && s.node.icon) this._el("span", "ar-tree__icon", row).textContent = s.node.icon;
    this._el("span", "ar-tree__label", row).textContent = s.node.label;
    if (opts.badges && s.node.badge !== void 0) this._el("span", "ar-tree__badge", row).textContent = String(s.node.badge);
    if (s.node.selectable !== false) {
      row.addEventListener("click", (e) => {
        const mode = this._get("selectable", "single");
        if (mode === "none") return;
        if (mode === "single") this._clearSel();
        this._setSel(s, !s.selected);
        if (opts.expandOnSelect && hasChildren) s.expanded ? this._collapse(s) : this._expand(s);
        this._focus = s;
        this._emit("select", { node: s.node, selected: s.selected }, e);
      });
    }
    if (opts.draggable) this._drag(s, li, row);
    if (hasChildren) {
      const ul = this._el("ul", "ar-tree__children", li);
      ul.setAttribute("role", "group");
      ul.style.display = s.expanded ? "" : "none";
      if (s.expanded && s.loaded) s.children.forEach((c) => this._renderNode(c, ul));
    }
  }
  _expand(s) {
    if (s.node.lazy && !s.loaded) {
      s.loading = true;
      this._updateRow(s);
      let resolved = false;
      this._emit("load", { node: s.node, resolve: (children) => {
        if (resolved) return;
        resolved = true;
        s.children = children.map((c) => this._ns(c, s, s.depth + 1));
        s.node.children = children;
        s.loaded = true;
        s.loading = false;
        s.expanded = true;
        this._updateRow(s);
        this._emit("expand", { node: s.node });
      } });
      return;
    }
    s.expanded = true;
    this._updateRow(s);
    this._emit("expand", { node: s.node });
  }
  _collapse(s) {
    s.expanded = false;
    this._updateRow(s);
    this._emit("collapse", { node: s.node });
  }
  _updateRow(s) {
    if (!s.el) return;
    const li = s.el;
    const opts = this._state.State;
    const hasChildren = (s.node.children?.length ?? 0) > 0 || s.node.lazy;
    li.setAttribute("aria-expanded", String(s.expanded));
    const oldRow = li.querySelector(".ar-tree__row");
    if (oldRow) oldRow.remove();
    const row = this._el("div", `ar-tree__row${s.selected ? " ar-tree__row--on" : ""}`, li);
    row.style.paddingLeft = s.depth * (opts.indent ?? 20) + 8 + "px";
    row.style.height = (opts.rowHeight ?? 32) + "px";
    if (li.firstChild && li.firstChild !== row) li.insertBefore(row, li.firstChild);
    const arrow = this._el("span", "ar-tree__arrow", row);
    if (hasChildren) {
      arrow.textContent = s.loading ? "\u27F3" : s.expanded ? "\u25BE" : "\u25B8";
      arrow.addEventListener("click", (e) => {
        e.stopPropagation();
        s.expanded ? this._collapse(s) : this._expand(s);
      });
    }
    if (opts.icons && s.node.icon) this._el("span", "ar-tree__icon", row).textContent = s.node.icon;
    this._el("span", "ar-tree__label", row).textContent = s.node.label;
    if (opts.badges && s.node.badge !== void 0) this._el("span", "ar-tree__badge", row).textContent = String(s.node.badge);
    row.addEventListener("click", (e) => {
      if (s.node.selectable === false) return;
      const mode = this._get("selectable", "single");
      if (mode === "none") return;
      if (mode === "single") this._clearSel();
      this._setSel(s, !s.selected);
      this._emit("select", { node: s.node, selected: s.selected }, e);
    });
    let ul = li.querySelector(".ar-tree__children");
    if (!ul && hasChildren) {
      ul = this._el("ul", "ar-tree__children");
      ul.setAttribute("role", "group");
      li.appendChild(ul);
    }
    if (ul) {
      if (s.expanded) {
        ul.style.display = "";
        if (s.loaded && !ul.children.length) s.children.forEach((c) => this._renderNode(c, ul));
      } else ul.style.display = "none";
    }
  }
  _clearSel() {
    this._map.forEach((s) => {
      if (s.selected) this._setSel(s, false);
    });
  }
  _setSel(s, v) {
    s.selected = v;
    if (!s.el) return;
    const row = s.el.querySelector(".ar-tree__row");
    if (row) {
      if (v) row.classList.add("ar-tree__row--on");
      else row.classList.remove("ar-tree__row--on");
    }
    s.el.setAttribute("aria-selected", String(v));
  }
  _setChecked(s, v) {
    s.checked = s.node.checked = v;
    const cb = s.el?.querySelector(".ar-tree__cb");
    if (cb) cb.checked = v;
    this._emit("check", { node: s.node, checked: v });
  }
  _applyFilter() {
    const q = this._q;
    this._map.forEach((s) => {
      if (s.el) s.el.style.display = q ? s.node.label.toLowerCase().includes(q) ? "" : "none" : "";
    });
    if (q) this._map.forEach((s) => {
      if (s.node.label.toLowerCase().includes(q)) {
        let p = s.parent;
        while (p) {
          if (p.el) p.el.style.display = "";
          p = p.parent;
        }
      }
    });
  }
  _visible() {
    const out = [];
    const walk = (nodes) => {
      for (const s of nodes) {
        if (s.el?.style.display === "none") continue;
        out.push(s);
        if (s.expanded && s.children.length) walk(s.children);
      }
    };
    walk(this._roots);
    return out;
  }
  _onKey(e) {
    const vis = this._visible();
    const idx = this._focus ? vis.indexOf(this._focus) : -1;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      const n = vis[idx + 1];
      if (n) {
        this._focus = n;
        n.el?.focus();
      }
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      const n = vis[idx - 1];
      if (n) {
        this._focus = n;
        n.el?.focus();
      }
    }
    if (e.key === "ArrowRight") {
      e.preventDefault();
      if (this._focus && !this._focus.expanded) this._expand(this._focus);
    }
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      if (this._focus?.expanded) this._collapse(this._focus);
      else if (this._focus?.parent) {
        this._focus = this._focus.parent;
        this._focus.el?.focus();
      }
    }
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      if (this._focus) {
        const mode = this._get("selectable", "single");
        if (mode !== "none") {
          if (mode === "single") this._clearSel();
          this._setSel(this._focus, !this._focus.selected);
          this._emit("select", { node: this._focus.node, selected: this._focus.selected });
        }
      }
    }
  }
  _drag(s, li, row) {
    li.draggable = true;
    li.addEventListener("dragstart", (e) => {
      e.dataTransfer?.setData("text/plain", s.node.id);
      li.classList.add("ar-tree__node--drag");
    });
    li.addEventListener("dragend", () => li.classList.remove("ar-tree__node--drag"));
    row.addEventListener("dragover", (e) => {
      e.preventDefault();
      row.classList.add("ar-tree__row--drop");
    });
    row.addEventListener("dragleave", () => row.classList.remove("ar-tree__row--drop"));
    row.addEventListener("drop", (e) => {
      e.preventDefault();
      row.classList.remove("ar-tree__row--drop");
      const src = e.dataTransfer?.getData("text/plain");
      if (src && src !== s.node.id) this._emit("drop", { sourceId: src, targetId: s.node.id });
    });
  }
  _ns(node, parent, depth) {
    const s = { node, expanded: node.expanded ?? false, selected: node.selected ?? false, checked: node.checked ?? false, loading: false, loaded: !node.lazy, depth, parent, children: [] };
    this._map.set(node.id, s);
    if (node.children) s.children = node.children.map((c) => this._ns(c, s, depth + 1));
    return s;
  }
};

// components/display/Avatar.ts
var Avatar = class extends Control {
  _src = "";
  _name = "";
  _icon = "";
  constructor(container = null, opts = {}) {
    super(container, "div", { size: 36, shape: "circle", ...opts });
    const s = opts.size ?? 36;
    this.el.className = `ar-avatar ar-avatar--${opts.shape ?? "circle"}${opts.class ? " " + opts.class : ""}`;
    this.el.style.cssText += `;width:${s}px;height:${s}px;font-size:${Math.round(s * 0.38)}px`;
  }
  set src(v) {
    this._src = v;
    this._build();
  }
  set name(v) {
    this._name = v;
    this._build();
  }
  set icon(v) {
    this._icon = v;
    this._build();
  }
  set status(v) {
    this._set("status", v);
    this._build();
  }
  _initials(name) {
    return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  }
  _build() {
    this.el.innerHTML = "";
    if (this._src) {
      const img = document.createElement("img");
      img.src = this._src;
      img.alt = this._name;
      img.className = "ar-avatar__img";
      this.el.appendChild(img);
    } else if (this._name) this._el("span", "ar-avatar__initials", this.el).textContent = this._initials(this._name);
    else if (this._icon) this._el("span", "ar-avatar__icon", this.el).textContent = this._icon;
    const s = this._get("status", "");
    if (s) this._el("span", `ar-avatar__status ar-avatar__status--${s}`, this.el);
  }
};

// components/display/Badge.ts
var Badge = class extends Control {
  _label = "";
  constructor(container = null, opts = {}) {
    super(container, "span", opts);
    this.el.className = `ar-badge ar-badge--${opts.variant ?? "default"}${opts.dot ? " ar-badge--dot" : ""}${opts.class ? " " + opts.class : ""}`;
  }
  set label(v) {
    this._label = v;
    this._build();
  }
  get label() {
    return this._label;
  }
  _build() {
    if (!this._get("dot", false)) this.el.textContent = this._label;
  }
};

// components/display/Banner.ts
var Banner = class extends Control {
  _message = "";
  _action = "";
  constructor(container = null, opts = {}) {
    super(container, "div", { variant: "default", dismissible: true, ...opts });
    this.el.className = `ar-banner ar-banner--${opts.variant ?? "default"}${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("role", "alert");
  }
  set message(v) {
    this._message = v;
    this._build();
  }
  set action(v) {
    this._action = v;
    this._build();
  }
  dismiss() {
    this.el.style.display = "none";
    this._emit("dismiss", {});
  }
  _build() {
    this.el.innerHTML = "";
    const icon = this._get("icon", "");
    if (icon) this._el("span", "ar-banner__icon", this.el).textContent = icon;
    this._el("span", "ar-banner__msg", this.el).textContent = this._message;
    if (this._action) {
      const btn = this._el("button", "ar-banner__action", this.el);
      btn.textContent = this._action;
      btn.addEventListener("click", () => this._emit("action", {}));
    }
    if (this._get("dismissible", true)) {
      const x = this._el("button", "ar-banner__close", this.el);
      x.textContent = "\u2715";
      x.addEventListener("click", () => this.dismiss());
    }
  }
};

// components/display/Chip.ts
var Chip = class extends Control {
  _label = "";
  _icon = "";
  _avatar = "";
  constructor(container = null, opts = {}) {
    super(container, "div", { variant: "default", size: "md", deletable: false, ...opts });
    this.el.className = `ar-dchip ar-dchip--${opts.variant ?? "default"} ar-dchip--${opts.size ?? "md"}${opts.class ? " " + opts.class : ""}`;
  }
  set label(v) {
    this._label = v;
    this._build();
  }
  set icon(v) {
    this._icon = v;
    this._build();
  }
  set avatar(v) {
    this._avatar = v;
    this._build();
  }
  get label() {
    return this._label;
  }
  _build() {
    this.el.innerHTML = "";
    if (this._avatar) {
      const av = this._el("span", "ar-dchip__avatar", this.el);
      av.textContent = this._avatar.slice(0, 2).toUpperCase();
    } else if (this._icon) {
      this._el("span", "ar-dchip__icon", this.el).textContent = this._icon;
    }
    this._el("span", "ar-dchip__label", this.el).textContent = this._label;
    if (this._get("deletable", false)) {
      const x = this._el("button", "ar-dchip__delete", this.el);
      x.textContent = "\u2715";
      x.setAttribute("aria-label", "Remove");
      x.addEventListener("click", (e) => {
        e.stopPropagation();
        this._emit("delete", { label: this._label }, e);
      });
    }
  }
};

// components/display/Divider.ts
var Divider = class extends Control {
  constructor(container = null, opts = {}) {
    super(container, "div", { orientation: "horizontal", variant: "solid", ...opts });
    this.el.className = `ar-divider ar-divider--${opts.orientation ?? "horizontal"} ar-divider--${opts.variant ?? "solid"}${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("role", "separator");
  }
  set label(v) {
    this._set("label", v);
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    this._el("span", "ar-divider__line", this.el);
    if (lbl) this._el("span", "ar-divider__label", this.el).textContent = lbl;
    if (lbl) this._el("span", "ar-divider__line", this.el);
  }
};

// components/display/Icon.ts
var Icon = class extends Control {
  _src = "";
  constructor(container = null, opts = {}) {
    super(container, "span", opts);
    this.el.className = `ar-icon${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("aria-hidden", "true");
    if (opts.size) {
      this.el.style.fontSize = opts.size + "px";
      this.el.style.width = opts.size + "px";
      this.el.style.height = opts.size + "px";
    }
    if (opts.color) this.el.style.color = opts.color;
  }
  set src(v) {
    this._src = v;
    this._build();
  }
  get src() {
    return this._src;
  }
  _build() {
    if (this._src.trimStart().startsWith("<")) this.el.innerHTML = this._src;
    else this.el.textContent = this._src;
  }
};

// components/display/List.ts
var List = class extends Control {
  _items = [];
  _selected = /* @__PURE__ */ new Set();
  constructor(container = null, opts = {}) {
    super(container, "ul", opts);
    this.el.className = `ar-list${opts.dense ? " ar-list--dense" : ""}${opts.divided ? " ar-list--divided" : ""}${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("role", opts.selectable ? "listbox" : "list");
  }
  set items(v) {
    this._items = v;
    this._set("items", v);
  }
  get selected() {
    return this._selected;
  }
  clearSelection() {
    this._selected.clear();
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    this._items.forEach((item) => {
      const isOn = this._selected.has(item.id);
      const li = this._el("li", `ar-list__item${isOn ? " ar-list__item--selected" : ""}${item.disabled ? " ar-list__item--disabled" : ""}`, this.el);
      li.setAttribute("role", this._get("selectable", false) ? "option" : "listitem");
      if (item.icon) this._el("span", "ar-list__icon", li).textContent = item.icon;
      const body = this._el("div", "ar-list__body", li);
      this._el("div", "ar-list__label", body).textContent = item.label;
      if (item.subtitle) this._el("div", "ar-list__subtitle", body).textContent = item.subtitle;
      if (item.badge !== void 0) this._el("span", "ar-list__badge", li).textContent = String(item.badge);
      if (item.meta) this._el("span", "ar-list__meta", li).textContent = item.meta;
      if (this._get("selectable", false) && !item.disabled) {
        li.style.cursor = "pointer";
        li.addEventListener("click", () => {
          if (!this._get("multiselect", false)) this._selected.clear();
          if (isOn) this._selected.delete(item.id);
          else this._selected.add(item.id);
          this._build();
          this._emit("select", { item, selected: [...this._selected] });
        });
      }
    });
  }
};

// components/display/ProgressBar.ts
var ProgressBar = class extends Control {
  _value = 0;
  _indeterminate = false;
  _bar;
  constructor(container = null, opts = {}) {
    super(container, "div", { variant: "default", height: 6, showValue: false, ...opts });
    this.el.className = `ar-progress${opts.class ? " " + opts.class : ""}`;
  }
  set value(v) {
    this._value = Math.max(0, Math.min(100, v));
    this._indeterminate = false;
    if (this._bar) {
      this._bar.style.width = this._value + "%";
      this._bar.classList.remove("ar-progress__bar--indeterminate");
    }
    const lv = this.el.querySelector(".ar-progress__value");
    if (lv) lv.textContent = this._value + "%";
  }
  get value() {
    return this._value;
  }
  set indeterminate(v) {
    this._indeterminate = v;
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    const sv = this._get("showValue", false);
    if (lbl || sv) {
      const row = this._el("div", "ar-progress__header", this.el);
      if (lbl) this._el("span", "ar-progress__label", row).textContent = lbl;
      if (sv) this._el("span", "ar-progress__value", row).textContent = this._value + "%";
    }
    const track = this._el("div", "ar-progress__track", this.el);
    track.style.height = this._get("height", 6) + "px";
    this._bar = this._el("div", `ar-progress__bar ar-progress__bar--${this._get("variant", "default")}${this._indeterminate ? " ar-progress__bar--indeterminate" : ""}`, track);
    this._bar.style.width = this._indeterminate ? "40%" : this._value + "%";
    this._bar.setAttribute("role", "progressbar");
    this._bar.setAttribute("aria-valuenow", String(this._value));
  }
};

// components/display/ProgressCircular.ts
var ProgressCircular = class extends Control {
  _value = 0;
  _indeterminate = false;
  constructor(container = null, opts = {}) {
    super(container, "div", { size: 48, strokeWidth: 4, showValue: false, variant: "default", ...opts });
    this.el.className = `ar-progress-circ${opts.class ? " " + opts.class : ""}`;
  }
  set value(v) {
    this._value = Math.max(0, Math.min(100, v));
    this._indeterminate = false;
    this._build();
  }
  get value() {
    return this._value;
  }
  set indeterminate(v) {
    this._indeterminate = v;
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    const size = this._get("size", 48);
    const sw = this._get("strokeWidth", 4);
    const r = (size - sw) / 2;
    const circ = 2 * Math.PI * r;
    const dash = this._indeterminate ? circ * 0.75 : circ * this._value / 100;
    const variantColors = { default: "var(--ar-primary)", success: "var(--ar-success)", warning: "var(--ar-warning)", danger: "var(--ar-danger)" };
    const color = variantColors[this._get("variant", "default")] ?? "var(--ar-primary)";
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
    svg.style.width = size + "px";
    svg.style.height = size + "px";
    if (this._indeterminate) svg.classList.add("ar-progress-circ__spin");
    const bg = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    bg.setAttribute("cx", String(size / 2));
    bg.setAttribute("cy", String(size / 2));
    bg.setAttribute("r", String(r));
    bg.setAttribute("fill", "none");
    bg.setAttribute("stroke", "var(--ar-bg4)");
    bg.setAttribute("stroke-width", String(sw));
    svg.appendChild(bg);
    const arc = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    arc.setAttribute("cx", String(size / 2));
    arc.setAttribute("cy", String(size / 2));
    arc.setAttribute("r", String(r));
    arc.setAttribute("fill", "none");
    arc.setAttribute("stroke", color);
    arc.setAttribute("stroke-width", String(sw));
    arc.setAttribute("stroke-linecap", "round");
    arc.setAttribute("stroke-dasharray", `${dash} ${circ - dash}`);
    arc.setAttribute("stroke-dashoffset", String(circ * 0.25));
    arc.style.transition = "stroke-dasharray .3s ease";
    svg.appendChild(arc);
    this.el.appendChild(svg);
    if (this._get("showValue", false) && !this._indeterminate) {
      const lbl = this._el("div", "ar-progress-circ__label", this.el);
      lbl.textContent = this._value + "%";
      lbl.style.fontSize = Math.round(size * 0.22) + "px";
    }
  }
};

// components/display/Skeleton.ts
var Skeleton = class extends Control {
  constructor(container = null, opts = {}) {
    super(container, "div", { variant: "text", lines: 3, ...opts });
    this.el.className = `ar-skeleton${opts.class ? " " + opts.class : ""}`;
  }
  _build() {
    this.el.innerHTML = "";
    const v = this._get("variant", "text");
    const w = this._get("width", "");
    const h = this._get("height", "");
    if (v === "circle") {
      const c = this._el("div", "ar-skeleton__circle", this.el);
      if (w) {
        c.style.width = w;
        c.style.height = h || w;
      }
      return;
    }
    if (v === "rect") {
      const r = this._el("div", "ar-skeleton__rect", this.el);
      if (w) r.style.width = w;
      if (h) r.style.height = h;
      return;
    }
    if (v === "card") {
      this._el("div", "ar-skeleton__rect", this.el).style.height = "160px";
      for (let i = 0; i < 3; i++) this._el("div", "ar-skeleton__line", this.el);
      return;
    }
    if (this._get("avatar", false)) {
      const row = this._el("div", "ar-skeleton__row", this.el);
      this._el("div", "ar-skeleton__circle", row);
      const lines = this._el("div", "ar-skeleton__lines", row);
      for (let i = 0; i < 2; i++) {
        const l = this._el("div", "ar-skeleton__line", lines);
        if (i === 1) l.style.width = "60%";
      }
      return;
    }
    const n = this._get("lines", 3);
    for (let i = 0; i < n; i++) {
      const l = this._el("div", "ar-skeleton__line", this.el);
      if (i === n - 1) l.style.width = "60%";
    }
  }
};

// components/display/Snackbar.ts
function getContainer(pos) {
  const id = "ar-snack-" + pos;
  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement("div");
    el.id = id;
    el.className = "ar-snackbar-container ar-snackbar-container--" + pos;
    document.body.appendChild(el);
  }
  return el;
}
var Snackbar = class _Snackbar extends Control {
  _timer = 0;
  constructor(opts = {}) {
    super(getContainer(opts.position ?? "bottom-center"), "div", { duration: 4e3, variant: "default", position: "bottom-center", ...opts });
    this.el.className = `ar-snackbar ar-snackbar--${opts.variant ?? "default"}${opts.class ? " " + opts.class : ""}`;
    this.el.style.display = "none";
  }
  set message(v) {
    this._set("message", v);
  }
  show() {
    this.el.style.display = "";
    setTimeout(() => this.el.classList.add("ar-snackbar--on"), 10);
    const dur = this._get("duration", 4e3);
    if (dur > 0) this._timer = window.setTimeout(() => this.hide(), dur);
    this._emit("show", {});
  }
  hide() {
    clearTimeout(this._timer);
    this.el.classList.remove("ar-snackbar--on");
    setTimeout(() => {
      this.el.style.display = "none";
      this._emit("hide", {});
    }, 280);
  }
  _build() {
    this.el.innerHTML = "";
    const msg = this._el("span", "ar-snackbar__msg", this.el);
    msg.textContent = this._get("message", "");
    const action = this._get("action", "");
    if (action) {
      const btn = this._el("button", "ar-snackbar__action", this.el);
      btn.textContent = action;
      btn.addEventListener("click", () => {
        this._emit("action", {});
        this.hide();
      });
    }
    const x = this._el("button", "ar-snackbar__close", this.el);
    x.textContent = "\u2715";
    x.addEventListener("click", () => this.hide());
  }
  static show(message, opts = {}) {
    const sb = new _Snackbar({ message, ...opts });
    sb.show();
    return sb;
  }
};

// components/display/Tag.ts
var Tag = class extends Control {
  _items = [];
  constructor(container = null, opts = {}) {
    super(container, "div", { removable: false, ...opts });
    this.el.className = `ar-tag-group${opts.class ? " " + opts.class : ""}`;
  }
  set items(v) {
    this._items = v;
    this._set("items", v);
  }
  get items() {
    return this._items;
  }
  add(item) {
    this._items.push(item);
    this._build();
  }
  remove(item) {
    this._items = this._items.filter((i) => i !== item);
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    this._items.forEach((item) => {
      const tag = this._el("span", "ar-tag", this.el);
      tag.textContent = item;
      if (this._get("removable", false)) {
        const x = this._el("button", "ar-tag__remove", tag);
        x.textContent = "\u2715";
        x.setAttribute("aria-label", "Remove");
        x.addEventListener("click", () => {
          this.remove(item);
          this._emit("remove", { item });
        });
      }
    });
  }
};

// components/display/Tooltip.ts
var Tooltip = class _Tooltip extends Control {
  _tip;
  _timer = 0;
  constructor(container = null, opts = {}) {
    super(container, "div", { position: "top", delay: 180, ...opts });
    this.el.className = `ar-tooltip-host${opts.class ? " " + opts.class : ""}`;
    this._tip = this._el("div", `ar-tooltip ar-tooltip--${opts.position ?? "top"}`, document.body);
    if (opts.text) this._tip.textContent = opts.text;
    this._on(this.el, "mouseenter", () => {
      clearTimeout(this._timer);
      this._timer = window.setTimeout(() => {
        this._place();
        this._tip.classList.add("ar-tooltip--on");
      }, this._get("delay", 180));
    });
    this._on(this.el, "mouseleave", () => {
      clearTimeout(this._timer);
      this._tip.classList.remove("ar-tooltip--on");
    });
    this._gc(() => this._tip.remove());
  }
  set text(v) {
    this._tip.textContent = v;
  }
  get text() {
    return this._tip.textContent ?? "";
  }
  _place() {
    const r = this.el.getBoundingClientRect();
    const pos = this._get("position", "top");
    const tw = this._tip.offsetWidth || 120;
    const th = this._tip.offsetHeight || 28;
    this._tip.style.left = r.left + r.width / 2 - tw / 2 + "px";
    this._tip.style.top = pos === "bottom" ? r.bottom + 6 + "px" : r.top - th - 6 + "px";
    if (pos === "left") {
      this._tip.style.left = r.left - tw - 6 + "px";
      this._tip.style.top = r.top + r.height / 2 - th / 2 + "px";
    }
    if (pos === "right") {
      this._tip.style.left = r.right + 6 + "px";
      this._tip.style.top = r.top + r.height / 2 - th / 2 + "px";
    }
  }
  _build() {
    if (this._tip) this._tip.textContent = this._get("text", "");
  }
  static attach(el, text, opts = {}) {
    const host = document.createElement("div");
    host.style.display = "contents";
    el.parentElement?.insertBefore(host, el);
    host.appendChild(el);
    return new _Tooltip(host, { text, ...opts });
  }
};

// components/inputs/Button.ts
var Button = class extends Control {
  _label = "";
  _loading = false;
  constructor(container = null, opts = {}) {
    super(container, "button", { variant: "default", size: "md", ...opts });
    this.el.type = "button";
    this.el.className = `ar-btn ar-btn--${opts.variant ?? "default"} ar-btn--${opts.size ?? "md"}${opts.class ? " " + opts.class : ""}`;
    this.el.addEventListener("click", (e) => {
      if (!this.el.disabled && !this._loading) this._emit("click", {}, e);
    });
  }
  set label(v) {
    this._label = v;
    this._build();
  }
  get label() {
    return this._label;
  }
  set loading(v) {
    this._loading = v;
    this.el.disabled = v;
    this._build();
  }
  set disabled(v) {
    this.el.disabled = v;
  }
  get disabled() {
    return this.el.disabled;
  }
  _build() {
    this.el.innerHTML = "";
    if (this._loading) {
      this._el("span", "ar-btn__spinner", this.el).textContent = "\u27F3";
    } else {
      const icon = this._get("icon", "");
      if (icon) this._el("span", "ar-btn__icon", this.el).textContent = icon;
    }
    if (this._label) this._el("span", "", this.el).textContent = this._label;
    if (!this._loading) {
      const ir = this._get("iconRight", "");
      if (ir) this._el("span", "ar-btn__icon", this.el).textContent = ir;
    }
  }
};

// components/inputs/Calendar.ts
var MS_PER_DAY = 864e5;
var PALETTE = ["#e40c88", "#3b82f6", "#16a34a", "#eab308", "#a855f7", "#06b6d4"];
var isSameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
var startOfDay = (d) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
var addDays = (d, n) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};
var startOfWeek = (d, weekStart) => {
  const x = startOfDay(d);
  const diff = (x.getDay() - weekStart + 7) % 7;
  return addDays(x, -diff);
};
var escapeHtml15 = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var Calendar = class extends Control {
  _view;
  _focused;
  _weekStart;
  _locale;
  _events = [];
  _elGrid;
  _elTitle;
  constructor(container, opts = {}) {
    super(container, "div", {
      view: "month",
      weekStart: 1,
      locale: typeof navigator !== "undefined" && navigator.language || "en-US",
      hideToolbar: false,
      ...opts
    });
    const self = this;
    self.el.className = `ar-cal${opts.class ? " " + opts.class : ""}`;
    this._view = self._get("view", "month");
    this._weekStart = self._get("weekStart", 1);
    this._locale = self._get("locale", "en-US");
    this._focused = opts.date ? startOfDay(opts.date) : startOfDay(/* @__PURE__ */ new Date());
    for (const e of opts.events ?? []) this._events.push({ ...e });
    this._injectStyles();
    this._build();
    this._render();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  setView(v) {
    this._view = v;
    this._render();
    this._emit("view-change", { view: v });
    return this;
  }
  getView() {
    return this._view;
  }
  goToToday() {
    this._focused = startOfDay(/* @__PURE__ */ new Date());
    this._render();
    this._emit("navigate", { date: this._focused });
    return this;
  }
  goTo(d) {
    this._focused = startOfDay(d);
    this._render();
    this._emit("navigate", { date: this._focused });
    return this;
  }
  prev() {
    this._step(-1);
    return this;
  }
  next() {
    this._step(1);
    return this;
  }
  addEvent(ev) {
    this._events.push({ ...ev });
    this._render();
    return this;
  }
  removeEvent(id) {
    this._events = this._events.filter((e) => e.id !== id);
    this._render();
    return this;
  }
  updateEvent(id, p) {
    const i = this._events.findIndex((e) => e.id === id);
    if (i >= 0) {
      this._events[i] = { ...this._events[i], ...p };
      this._render();
    }
    return this;
  }
  clearEvents() {
    this._events = [];
    this._render();
    return this;
  }
  getEvents() {
    return this._events.map((e) => ({ ...e }));
  }
  // ── Build + render ─────────────────────────────────────────────────────
  _step(dir) {
    const f = this._focused;
    if (this._view === "month") f.setMonth(f.getMonth() + dir);
    else if (this._view === "week") f.setDate(f.getDate() + 7 * dir);
    else f.setDate(f.getDate() + dir);
    this._focused = new Date(f);
    this._render();
    this._emit("navigate", { date: this._focused });
  }
  _build() {
    const self = this;
    const hideToolbar = self._get("hideToolbar", false);
    self.el.innerHTML = `
${hideToolbar ? "" : `
<header class="ar-cal__toolbar">
  <div class="ar-cal__nav">
    <button class="ar-cal__btn"  data-act="prev"  title="Previous">\u2039</button>
    <button class="ar-cal__btn"  data-act="today" title="Today">Today</button>
    <button class="ar-cal__btn"  data-act="next"  title="Next">\u203A</button>
  </div>
  <div class="ar-cal__title" data-r="title"></div>
  <div class="ar-cal__views">
    <button class="ar-cal__btn" data-view="month">Month</button>
    <button class="ar-cal__btn" data-view="week">Week</button>
    <button class="ar-cal__btn" data-view="day">Day</button>
  </div>
</header>`}
<div class="ar-cal__grid" data-r="grid"></div>`;
    this._elGrid = self.el.querySelector('[data-r="grid"]');
    this._elTitle = self.el.querySelector('[data-r="title"]');
    if (!hideToolbar) {
      self.el.querySelector('[data-act="prev"]')?.addEventListener("click", () => this.prev());
      self.el.querySelector('[data-act="next"]')?.addEventListener("click", () => this.next());
      self.el.querySelector('[data-act="today"]')?.addEventListener("click", () => this.goToToday());
      self.el.querySelectorAll("[data-view]").forEach((b) => {
        b.addEventListener("click", () => this.setView(b.dataset.view));
      });
    }
    if (this._events.length || this._focused) this._render();
  }
  _render() {
    if (!this._elGrid) return;
    const self = this;
    if (this._elTitle) {
      const f = this._focused;
      if (this._view === "month") {
        this._elTitle.textContent = f.toLocaleString(this._locale, { month: "long", year: "numeric" });
      } else if (this._view === "week") {
        const s = startOfWeek(f, this._weekStart);
        const e = addDays(s, 6);
        this._elTitle.textContent = `${s.toLocaleDateString(this._locale, { day: "numeric", month: "short" })} \u2013 ${e.toLocaleDateString(this._locale, { day: "numeric", month: "short", year: "numeric" })}`;
      } else {
        this._elTitle.textContent = f.toLocaleDateString(this._locale, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
      }
    }
    self.el.querySelectorAll("[data-view]").forEach((b) => {
      b.classList.toggle("ar-cal__btn--active", b.dataset.view === this._view);
    });
    this._elGrid.innerHTML = "";
    if (this._view === "month") this._renderMonth();
    else if (this._view === "week") this._renderWeek();
    else this._renderDay();
  }
  _weekdayHeader() {
    const h = document.createElement("div");
    h.className = "ar-cal__weekdays";
    const ws = this._weekStart;
    const fmt2 = new Intl.DateTimeFormat(this._locale, { weekday: "short" });
    for (let i = 0; i < 7; i++) {
      const d = new Date(2024, 0, 7 + (ws + i) % 7);
      const cell = document.createElement("div");
      cell.className = "ar-cal__weekday";
      cell.textContent = fmt2.format(d);
      h.appendChild(cell);
    }
    return h;
  }
  _renderMonth() {
    const f = this._focused;
    const firstOfMonth = new Date(f.getFullYear(), f.getMonth(), 1);
    const gridStart = startOfWeek(firstOfMonth, this._weekStart);
    const today = startOfDay(/* @__PURE__ */ new Date());
    this._elGrid.appendChild(this._weekdayHeader());
    const grid = document.createElement("div");
    grid.className = "ar-cal__month";
    for (let i = 0; i < 42; i++) {
      const day = addDays(gridStart, i);
      const cell = document.createElement("div");
      const outside = day.getMonth() !== f.getMonth();
      cell.className = "ar-cal__cell" + (outside ? " ar-cal__cell--outside" : "") + (isSameDay(day, today) ? " ar-cal__cell--today" : "");
      cell.innerHTML = `<div class="ar-cal__num">${day.getDate()}</div><div class="ar-cal__events" data-r="cell-events"></div>`;
      cell.addEventListener("click", (e) => {
        if (e.target.closest(".ar-cal__event")) return;
        this._emit("day-click", { date: new Date(day) });
      });
      const dayEvs = this._eventsForDay(day);
      const evWrap = cell.querySelector('[data-r="cell-events"]');
      for (let j = 0; j < dayEvs.length && j < 3; j++) {
        evWrap.appendChild(this._renderEvent(dayEvs[j]));
      }
      if (dayEvs.length > 3) {
        const more = document.createElement("div");
        more.className = "ar-cal__more";
        more.textContent = `+${dayEvs.length - 3} more`;
        evWrap.appendChild(more);
      }
      grid.appendChild(cell);
    }
    this._elGrid.appendChild(grid);
  }
  _renderWeek() {
    const ws = startOfWeek(this._focused, this._weekStart);
    const today = startOfDay(/* @__PURE__ */ new Date());
    this._elGrid.appendChild(this._weekdayHeader());
    const grid = document.createElement("div");
    grid.className = "ar-cal__week";
    for (let i = 0; i < 7; i++) {
      const day = addDays(ws, i);
      const cell = document.createElement("div");
      cell.className = "ar-cal__cell ar-cal__cell--week" + (isSameDay(day, today) ? " ar-cal__cell--today" : "");
      cell.innerHTML = `<div class="ar-cal__num">${day.toLocaleDateString(this._locale, { day: "numeric" })}</div><div class="ar-cal__events" data-r="cell-events"></div>`;
      cell.addEventListener("click", (e) => {
        if (e.target.closest(".ar-cal__event")) return;
        this._emit("day-click", { date: new Date(day) });
      });
      const evWrap = cell.querySelector('[data-r="cell-events"]');
      for (const ev of this._eventsForDay(day)) evWrap.appendChild(this._renderEvent(ev));
      grid.appendChild(cell);
    }
    this._elGrid.appendChild(grid);
  }
  _renderDay() {
    const day = startOfDay(this._focused);
    const today = startOfDay(/* @__PURE__ */ new Date());
    const wrap = document.createElement("div");
    wrap.className = "ar-cal__day" + (isSameDay(day, today) ? " ar-cal__day--today" : "");
    const head = document.createElement("div");
    head.className = "ar-cal__day-head";
    head.textContent = day.toLocaleDateString(this._locale, { weekday: "long", day: "numeric", month: "long" });
    wrap.appendChild(head);
    const evs = this._eventsForDay(day);
    const list = document.createElement("div");
    list.className = "ar-cal__day-events";
    if (evs.length === 0) {
      const empty = document.createElement("div");
      empty.className = "ar-cal__empty";
      empty.textContent = "No events";
      list.appendChild(empty);
    } else {
      for (const ev of evs) list.appendChild(this._renderEvent(ev, true));
    }
    wrap.appendChild(list);
    this._elGrid.appendChild(wrap);
  }
  _renderEvent(ev, detailed = false) {
    const el = document.createElement("div");
    el.className = "ar-cal__event";
    const color = ev.color || PALETTE[(ev.id.charCodeAt(0) + ev.id.length) % PALETTE.length];
    el.style.background = color + (detailed ? "cc" : "33");
    el.style.borderLeft = `3px solid ${color}`;
    if (detailed) {
      const t = ev.allDay ? "All day" : `${ev.start.toLocaleTimeString(this._locale, { hour: "2-digit", minute: "2-digit" })}${ev.end ? " \u2013 " + ev.end.toLocaleTimeString(this._locale, { hour: "2-digit", minute: "2-digit" }) : ""}`;
      el.innerHTML = `<div class="ar-cal__event-time">${escapeHtml15(t)}</div><div class="ar-cal__event-title">${escapeHtml15(ev.title)}</div>`;
    } else {
      el.textContent = ev.title;
    }
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      this._emit("event-click", { event: { ...ev } });
    });
    return el;
  }
  _eventsForDay(day) {
    const dayMs = day.getTime();
    const nextMs = dayMs + MS_PER_DAY;
    return this._events.filter((ev) => {
      const s = startOfDay(ev.start).getTime();
      const e = ev.end ? ev.end.getTime() : ev.start.getTime() + MS_PER_DAY - 1;
      return s < nextMs && e >= dayMs;
    }).sort((a, b) => a.start.getTime() - b.start.getTime());
  }
  _injectStyles() {
    if (document.getElementById("ar-cal-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-cal-styles";
    s.textContent = `
.ar-cal { display:flex; flex-direction:column; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:13px -apple-system,system-ui,sans-serif; overflow:hidden; }
.ar-cal__toolbar { display:flex; align-items:center; gap:8px; padding:10px 14px; border-bottom:1px solid #333; background:#161616; }
.ar-cal__nav { display:flex; gap:4px; }
.ar-cal__title { flex:1; text-align:center; font:600 14px sans-serif; color:#fff; }
.ar-cal__views { display:flex; gap:2px; }
.ar-cal__btn { background:transparent; border:1px solid #333; color:#d4d4d4; padding:4px 10px; font:12px sans-serif; border-radius:4px; cursor:pointer; transition:background .12s, border-color .12s; }
.ar-cal__btn:hover { background:#2a2a2a; border-color:#444; }
.ar-cal__btn--active { background:#e40c88; border-color:#e40c88; color:#fff; }
.ar-cal__grid { flex:1; min-height:0; overflow:auto; }
.ar-cal__weekdays { display:grid; grid-template-columns:repeat(7, 1fr); background:#161616; border-bottom:1px solid #333; }
.ar-cal__weekday { padding:8px; font:10px sans-serif; text-transform:uppercase; letter-spacing:.08em; color:#888; text-align:center; }
.ar-cal__month { display:grid; grid-template-columns:repeat(7, 1fr); grid-auto-rows:minmax(80px, 1fr); }
.ar-cal__week { display:grid; grid-template-columns:repeat(7, 1fr); min-height:300px; }
.ar-cal__cell { border-right:1px solid #2a2a2a; border-bottom:1px solid #2a2a2a; padding:4px; min-height:80px; cursor:pointer; transition:background .12s; overflow:hidden; display:flex; flex-direction:column; }
.ar-cal__cell:hover { background:#252525; }
.ar-cal__cell--outside { background:#161616; color:#555; }
.ar-cal__cell--today .ar-cal__num { background:#e40c88; color:#fff; }
.ar-cal__cell--week { min-height:200px; }
.ar-cal__num { display:inline-block; min-width:22px; height:22px; line-height:22px; text-align:center; font:600 12px sans-serif; border-radius:50%; padding:0 4px; }
.ar-cal__events { display:flex; flex-direction:column; gap:2px; margin-top:4px; flex:1; min-height:0; }
.ar-cal__event { font:11px sans-serif; padding:2px 6px; border-radius:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; cursor:pointer; }
.ar-cal__event:hover { filter:brightness(1.15); }
.ar-cal__more { font:10px sans-serif; color:#888; padding:1px 6px; }
.ar-cal__day { padding:16px; }
.ar-cal__day-head { font:600 16px sans-serif; color:#fff; margin-bottom:14px; }
.ar-cal__day-events { display:flex; flex-direction:column; gap:6px; }
.ar-cal__day .ar-cal__event { padding:8px 12px; font:13px sans-serif; }
.ar-cal__event-time { font:11px ui-monospace,monospace; color:rgba(255,255,255,.85); }
.ar-cal__event-title { color:#fff; font-weight:500; margin-top:2px; }
.ar-cal__empty { color:#666; font-style:italic; padding:20px; text-align:center; }
@media (max-width: 600px) {
  .ar-cal__toolbar { padding:8px 10px; gap:4px; flex-wrap:wrap; }
  .ar-cal__title { order:-1; flex:1 1 100%; padding-bottom:4px; }
  .ar-cal__btn { padding:3px 8px; font-size:11px; }
  .ar-cal__weekday { padding:4px 2px; font-size:9px; }
  .ar-cal__month { grid-auto-rows:minmax(56px, 1fr); }
  .ar-cal__cell { min-height:56px; padding:2px; }
  .ar-cal__num { min-width:18px; height:18px; line-height:18px; font-size:10px; }
  .ar-cal__event { font-size:9px; padding:1px 3px; }
  .ar-cal__events { gap:1px; }
}
`;
    document.head.appendChild(s);
  }
};

// components/inputs/Checkbox.ts
var Checkbox = class extends Control {
  _checked = false;
  _indeterminate = false;
  _input;
  constructor(container = null, opts = {}) {
    super(container, "label", opts);
    this.el.className = `ar-checkbox${opts.class ? " " + opts.class : ""}`;
  }
  set checked(v) {
    this._checked = v;
    if (this._input) this._input.checked = v;
  }
  get checked() {
    return this._input?.checked ?? this._checked;
  }
  set indeterminate(v) {
    this._indeterminate = v;
    if (this._input) this._input.indeterminate = v;
  }
  set disabled(v) {
    if (this._input) this._input.disabled = v;
  }
  _build() {
    this.el.innerHTML = "";
    this._input = document.createElement("input");
    this._input.type = "checkbox";
    this._input.className = "ar-checkbox__input";
    this._input.checked = this._checked;
    this._input.disabled = this._get("disabled", false);
    this._input.indeterminate = this._indeterminate;
    this._input.addEventListener("change", () => {
      this._checked = this._input.checked;
      this._emit("change", { checked: this._checked });
    });
    this.el.appendChild(this._input);
    this._el("span", "ar-checkbox__box", this.el);
    const lbl = this._get("label", "");
    if (lbl) this._el("span", "ar-checkbox__label", this.el).textContent = lbl;
  }
};

// components/inputs/Chip.ts
var Chip2 = class extends Control {
  _options = [];
  _selected = /* @__PURE__ */ new Set();
  constructor(container = null, opts = {}) {
    super(container, "div", { multiple: true, removable: false, ...opts });
    this.el.className = `ar-chip-group${opts.class ? " " + opts.class : ""}`;
  }
  set options(v) {
    this._options = v;
    this._set("options", v);
  }
  set selected(v) {
    this._selected = new Set(v);
    this._build();
  }
  get selected() {
    return [...this._selected];
  }
  _build() {
    this.el.innerHTML = "";
    this._options.forEach((opt) => {
      const isOn = this._selected.has(opt);
      const chip = this._el("button", `ar-chip${isOn ? " ar-chip--on" : ""}`, this.el);
      chip.textContent = opt;
      chip.addEventListener("click", () => {
        if (isOn) this._selected.delete(opt);
        else {
          if (!this._get("multiple", true)) this._selected.clear();
          this._selected.add(opt);
        }
        this._emit("change", { selected: this.selected });
        this._build();
      });
      if (this._get("removable", false) && isOn) {
        const x = this._el("span", "ar-chip__remove", chip);
        x.textContent = " \u2715";
        x.addEventListener("click", (e) => {
          e.stopPropagation();
          this._selected.delete(opt);
          this._emit("change", { selected: this.selected });
          this._build();
        });
      }
    });
  }
};

// components/inputs/ColorPicker.ts
var ColorPicker = class extends Control {
  _value = "#000000";
  _input;
  constructor(container = null, opts = {}) {
    super(container, "div", opts);
    this.el.className = `ar-colorpicker${opts.class ? " " + opts.class : ""}`;
  }
  set value(v) {
    this._value = v;
    if (this._input) this._input.value = v;
    this._updatePreview();
  }
  get value() {
    return this._input?.value ?? this._value;
  }
  _updatePreview() {
    const sw = this.el.querySelector(".ar-colorpicker__swatch");
    if (sw) sw.style.background = this.value;
    const hex = this.el.querySelector(".ar-colorpicker__hex");
    if (hex) hex.textContent = this.value.toUpperCase();
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-colorpicker__label", this.el).textContent = lbl;
    const row = this._el("div", "ar-colorpicker__row", this.el);
    const swatch = this._el("div", "ar-colorpicker__swatch", row);
    swatch.style.background = this._value;
    this._input = document.createElement("input");
    this._input.type = "color";
    this._input.className = "ar-colorpicker__input";
    this._input.value = this._value;
    this._input.disabled = this._get("disabled", false);
    this._input.addEventListener("input", () => {
      this._value = this._input.value;
      this._updatePreview();
      this._emit("input", { value: this._value });
    });
    this._input.addEventListener("change", () => this._emit("change", { value: this._input.value }));
    swatch.appendChild(this._input);
    this._el("span", "ar-colorpicker__hex", row).textContent = this._value.toUpperCase();
    const presets = this._get("presets", []);
    if (presets.length) {
      const wrap = this._el("div", "ar-colorpicker__presets", this.el);
      presets.forEach((c) => {
        const p = this._el("button", "ar-colorpicker__preset", wrap);
        p.style.background = c;
        p.title = c;
        p.addEventListener("click", () => {
          this._value = c;
          if (this._input) this._input.value = c;
          this._updatePreview();
          this._emit("change", { value: c });
        });
      });
    }
  }
};

// components/inputs/DatePicker.ts
var DatePicker = class extends Control {
  _value = "";
  _open = false;
  _view = /* @__PURE__ */ new Date();
  constructor(container = null, opts = {}) {
    super(container, "div", opts);
    this.el.className = `ar-datepicker${opts.class ? " " + opts.class : ""}`;
    this._on(document, "click", (e) => {
      if (!this.el.contains(e.target)) {
        this._open = false;
        this._build();
      }
    });
  }
  set value(v) {
    this._value = v;
    if (v) this._view = /* @__PURE__ */ new Date(v + "T12:00:00");
    this._build();
  }
  get value() {
    return this._value;
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-datepicker__label", this.el).textContent = lbl;
    const trigger = this._el("div", "ar-datepicker__trigger", this.el);
    const lv = this._el("span", "ar-datepicker__value", trigger);
    lv.textContent = this._value || "Select date\u2026";
    if (!this._value) lv.classList.add("ar-datepicker__placeholder");
    this._el("span", "ar-datepicker__icon", trigger).textContent = "\u{1F4C5}";
    if (!this._get("disabled", false)) trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      this._open = !this._open;
      this._build();
    });
    if (this._open) this._buildCalendar();
  }
  _buildCalendar() {
    const cal = this._el("div", "ar-datepicker__calendar", this.el);
    const y = this._view.getFullYear();
    const m = this._view.getMonth();
    const header = this._el("div", "ar-datepicker__cal-header", cal);
    const prev = this._el("button", "ar-datepicker__nav", header);
    prev.textContent = "\u2039";
    prev.addEventListener("click", (e) => {
      e.stopPropagation();
      this._view = new Date(y, m - 1, 1);
      this._build();
    });
    this._el("span", "ar-datepicker__cal-title", header).textContent = this._view.toLocaleString("default", { month: "long", year: "numeric" });
    const next = this._el("button", "ar-datepicker__nav", header);
    next.textContent = "\u203A";
    next.addEventListener("click", (e) => {
      e.stopPropagation();
      this._view = new Date(y, m + 1, 1);
      this._build();
    });
    const grid = this._el("div", "ar-datepicker__grid", cal);
    ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].forEach((d) => {
      this._el("div", "ar-datepicker__day-name", grid).textContent = d;
    });
    const firstDay = new Date(y, m, 1).getDay();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    for (let i = 0; i < firstDay; i++) this._el("div", "ar-datepicker__day ar-datepicker__day--empty", grid);
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      const btn = this._el("button", `ar-datepicker__day${dateStr === this._value ? " ar-datepicker__day--selected" : ""}${dateStr === today ? " ar-datepicker__day--today" : ""}`, grid);
      btn.textContent = String(d);
      const min = this._get("min", "");
      const max = this._get("max", "");
      if (min && dateStr < min || max && dateStr > max) {
        btn.disabled = true;
        btn.classList.add("ar-datepicker__day--disabled");
      } else btn.addEventListener("click", (e) => {
        e.stopPropagation();
        this._value = dateStr;
        this._open = false;
        this._emit("change", { value: dateStr, date: /* @__PURE__ */ new Date(dateStr + "T12:00:00") });
        this._build();
      });
    }
  }
};

// components/inputs/Dropdown.ts
var Dropdown = class extends Control {
  _options = [];
  _value = "";
  _open = false;
  _filter = "";
  constructor(container = null, opts = {}) {
    super(container, "div", { placeholder: "Select\u2026", searchable: false, clearable: false, ...opts });
    this.el.className = `ar-dropdown${opts.class ? " " + opts.class : ""}`;
    this._on(document, "click", (e) => {
      if (!this.el.contains(e.target)) this._closeList();
    });
  }
  set options(v) {
    this._options = v;
    this._set("options", v);
  }
  set value(v) {
    this._value = v;
    this._build();
  }
  get value() {
    return this._value;
  }
  get selectedOption() {
    return this._options.find((o) => o.value === this._value);
  }
  _closeList() {
    this._open = false;
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    const sel = this.selectedOption;
    const trigger = this._el("div", "ar-dropdown__trigger", this.el);
    if (sel?.icon) this._el("span", "ar-dropdown__icon", trigger).textContent = sel.icon;
    const lbl = this._el("span", "ar-dropdown__value", trigger);
    lbl.textContent = sel?.label ?? this._get("placeholder", "Select\u2026");
    if (!sel) lbl.classList.add("ar-dropdown__placeholder");
    if (this._get("clearable", false) && sel) {
      const x = this._el("button", "ar-dropdown__clear", trigger);
      x.textContent = "\u2715";
      x.addEventListener("click", (e) => {
        e.stopPropagation();
        this._value = "";
        this._emit("change", { value: "", option: null });
        this._build();
      });
    }
    this._el("span", "ar-dropdown__arrow", trigger).textContent = this._open ? "\u25BE" : "\u25B8";
    if (!this._get("disabled", false)) {
      trigger.addEventListener("click", (e) => {
        e.stopPropagation();
        this._open = !this._open;
        this._build();
      });
    }
    if (this._open) {
      const list = this._el("div", "ar-dropdown__list", this.el);
      if (this._get("searchable", false)) {
        const inp = document.createElement("input");
        inp.type = "text";
        inp.className = "ar-dropdown__search";
        inp.placeholder = "Search\u2026";
        inp.value = this._filter;
        inp.addEventListener("input", () => {
          this._filter = inp.value;
          this._renderOptions(list);
        });
        inp.addEventListener("click", (e) => e.stopPropagation());
        list.appendChild(inp);
        setTimeout(() => inp.focus(), 0);
      }
      this._renderOptions(list);
    }
  }
  _renderOptions(list) {
    list.querySelectorAll(".ar-dropdown__option").forEach((e) => e.remove());
    const q = this._filter.toLowerCase();
    const filtered = q ? this._options.filter((o) => o.label.toLowerCase().includes(q)) : this._options;
    filtered.forEach((opt) => {
      const row = this._el("div", `ar-dropdown__option${opt.value === this._value ? " ar-dropdown__option--active" : ""}${opt.disabled ? " ar-dropdown__option--disabled" : ""}`, list);
      if (opt.icon) this._el("span", "", row).textContent = opt.icon;
      this._el("span", "", row).textContent = opt.label;
      if (!opt.disabled) row.addEventListener("click", (e) => {
        e.stopPropagation();
        this._value = opt.value;
        this._filter = "";
        this._open = false;
        this._emit("change", { value: opt.value, option: opt });
        this._build();
      });
    });
  }
};

// components/inputs/FileUpload.ts
var FileUpload = class extends Control {
  _files = [];
  _dragging = false;
  constructor(container = null, opts = {}) {
    super(container, "div", opts);
    this.el.className = `ar-fileupload${opts.class ? " " + opts.class : ""}`;
  }
  get files() {
    return this._files;
  }
  clear() {
    this._files = [];
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    const zone = this._el("div", `ar-fileupload__zone${this._dragging ? " ar-fileupload__zone--over" : ""}`, this.el);
    this._el("div", "ar-fileupload__icon", zone).textContent = "\u{1F4C1}";
    const lbl = this._get("label", "Drop files here or click to browse");
    this._el("div", "ar-fileupload__label", zone).textContent = lbl;
    const hint = this._get("hint", "");
    if (hint) this._el("div", "ar-fileupload__hint", zone).textContent = hint;
    const input = document.createElement("input");
    input.type = "file";
    input.className = "ar-fileupload__input";
    const accept = this._get("accept", "");
    if (accept) input.accept = accept;
    input.multiple = this._get("multiple", false);
    input.disabled = this._get("disabled", false);
    input.addEventListener("change", () => {
      if (input.files) {
        this._files = Array.from(input.files);
        this._emit("change", { files: this._files });
        this._build();
      }
    });
    zone.appendChild(input);
    zone.addEventListener("dragover", (e) => {
      e.preventDefault();
      this._dragging = true;
      zone.classList.add("ar-fileupload__zone--over");
    });
    zone.addEventListener("dragleave", () => {
      this._dragging = false;
      zone.classList.remove("ar-fileupload__zone--over");
    });
    zone.addEventListener("drop", (e) => {
      e.preventDefault();
      this._dragging = false;
      zone.classList.remove("ar-fileupload__zone--over");
      if (e.dataTransfer?.files) {
        this._files = Array.from(e.dataTransfer.files);
        this._emit("change", { files: this._files });
        this._build();
      }
    });
    if (this._files.length) {
      const list = this._el("ul", "ar-fileupload__list", this.el);
      this._files.forEach((f) => {
        const li = this._el("li", "ar-fileupload__file", list);
        li.textContent = `${f.name} (${(f.size / 1024).toFixed(1)} KB)`;
      });
    }
  }
};

// components/inputs/Radio.ts
var Radio = class extends Control {
  _options = [];
  _value = "";
  _name = "ar-radio-" + Math.random().toString(36).slice(2, 7);
  constructor(container = null, opts = {}) {
    super(container, "div", { direction: "column", ...opts });
    this.el.className = `ar-radio-group${opts.class ? " " + opts.class : ""}`;
  }
  set options(v) {
    this._options = v;
    this._set("options", v);
  }
  set value(v) {
    this._value = v;
    this._build();
  }
  get value() {
    return this._value;
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-radio-group__label", this.el).textContent = lbl;
    const wrap = this._el("div", `ar-radio-group__items ar-radio-group__items--${this._get("direction", "column")}`, this.el);
    this._options.forEach((opt) => {
      const label = this._el("label", `ar-radio${opt.disabled ? " ar-radio--disabled" : ""}`, wrap);
      const input = document.createElement("input");
      input.type = "radio";
      input.className = "ar-radio__input";
      input.name = this._name;
      input.value = opt.value;
      input.checked = opt.value === this._value;
      input.disabled = !!opt.disabled;
      input.addEventListener("change", () => {
        if (input.checked) {
          this._value = opt.value;
          this._emit("change", { value: opt.value });
        }
      });
      label.appendChild(input);
      this._el("span", "ar-radio__circle", label);
      this._el("span", "ar-radio__label", label).textContent = opt.label;
    });
  }
};

// components/inputs/RangeSlider.ts
var RangeSlider = class extends Control {
  _value = 0;
  _input;
  constructor(container = null, opts = {}) {
    super(container, "div", { min: 0, max: 100, step: 1, showValue: true, ...opts });
    this.el.className = `ar-slider${opts.class ? " " + opts.class : ""}`;
  }
  set value(v) {
    this._value = v;
    if (this._input) this._input.value = String(v);
  }
  get value() {
    return Number(this._input?.value ?? this._value);
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-slider__label", this.el).textContent = lbl;
    const wrap = this._el("div", "ar-slider__wrap", this.el);
    this._input = document.createElement("input");
    this._input.type = "range";
    this._input.className = "ar-slider__input";
    this._input.min = String(this._get("min", 0));
    this._input.max = String(this._get("max", 100));
    this._input.step = String(this._get("step", 1));
    this._input.value = String(this._value);
    this._input.disabled = this._get("disabled", false);
    const val = this._get("showValue", true) ? this._el("span", "ar-slider__value", wrap) : null;
    if (val) val.textContent = String(this._value);
    this._input.addEventListener("input", () => {
      this._value = Number(this._input.value);
      if (val) val.textContent = String(this._value);
      this._emit("input", { value: this._value });
    });
    this._input.addEventListener("change", () => this._emit("change", { value: this.value }));
    wrap.insertBefore(this._input, val ?? null);
  }
};

// components/inputs/Rating.ts
var Rating = class extends Control {
  _value = 0;
  _hover = 0;
  constructor(container = null, opts = {}) {
    super(container, "div", { max: 5, icon: "\u2605", emptyIcon: "\u2606", ...opts });
    this.el.className = `ar-rating${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("role", "slider");
  }
  set value(v) {
    this._value = v;
    this._build();
  }
  get value() {
    return this._value;
  }
  _build() {
    this.el.innerHTML = "";
    const max = this._get("max", 5);
    const ro = this._get("readonly", false);
    const icon = this._get("icon", "\u2605");
    const empty = this._get("emptyIcon", "\u2606");
    for (let i = 1; i <= max; i++) {
      const filled = i <= (this._hover || this._value);
      const star = this._el("span", `ar-rating__star${filled ? " ar-rating__star--filled" : ""}`, this.el);
      star.textContent = filled ? icon : empty;
      if (!ro) {
        star.addEventListener("click", () => {
          this._value = i;
          this._emit("change", { value: i });
          this._build();
        });
        star.addEventListener("mouseenter", () => {
          this._hover = i;
          this._build();
        });
        star.addEventListener("mouseleave", () => {
          this._hover = 0;
          this._build();
        });
      }
    }
  }
};

// components/inputs/RichTextEditor.ts
var TOOLBAR_DEFS = {
  bold: { label: "B", title: "Bold (Ctrl+B)", style: "font-weight:700;", exec: () => document.execCommand("bold") },
  italic: { label: "I", title: "Italic (Ctrl+I)", style: "font-style:italic;", exec: () => document.execCommand("italic") },
  underline: { label: "U", title: "Underline (Ctrl+U)", style: "text-decoration:underline;", exec: () => document.execCommand("underline") },
  strikethrough: { label: "S\u0336", title: "Strikethrough", style: "text-decoration:line-through;", exec: () => document.execCommand("strikeThrough") },
  h1: { label: "H1", title: "Heading 1", exec: () => document.execCommand("formatBlock", false, "h1") },
  h2: { label: "H2", title: "Heading 2", exec: () => document.execCommand("formatBlock", false, "h2") },
  h3: { label: "H3", title: "Heading 3", exec: () => document.execCommand("formatBlock", false, "h3") },
  p: { label: "P", title: "Paragraph", exec: () => document.execCommand("formatBlock", false, "p") },
  blockquote: { label: "\u275D", title: "Blockquote", exec: () => document.execCommand("formatBlock", false, "blockquote") },
  pre: { label: "\u2039\u203A", title: "Code block", style: "font-family:monospace;", exec: () => document.execCommand("formatBlock", false, "pre") },
  ul: { label: "\u2022 List", title: "Bullet list", exec: () => document.execCommand("insertUnorderedList") },
  ol: { label: "1. List", title: "Numbered list", exec: () => document.execCommand("insertOrderedList") },
  alignLeft: { label: "\u2AE4", title: "Align left", exec: () => document.execCommand("justifyLeft") },
  alignCenter: { label: "\u2261", title: "Align center", exec: () => document.execCommand("justifyCenter") },
  alignRight: { label: "\u2AE5", title: "Align right", exec: () => document.execCommand("justifyRight") },
  alignJustify: { label: "\u2630", title: "Justify", exec: () => document.execCommand("justifyFull") },
  link: { label: "\u{1F517}", title: "Insert link", exec: (ed) => {
    const url = prompt("URL:", "https://");
    if (url) document.execCommand("createLink", false, url);
  } },
  unlink: { label: "\u2702 link", title: "Remove link", exec: () => document.execCommand("unlink") },
  image: { label: "\u{1F5BC}", title: "Insert image", exec: () => {
    const url = prompt("Image URL:", "https://");
    if (url) document.execCommand("insertHTML", false, `<img src="${url}" alt="" style="max-width:100%">`);
  } },
  undo: { label: "\u21A9", title: "Undo (Ctrl+Z)", exec: () => document.execCommand("undo") },
  redo: { label: "\u21AA", title: "Redo (Ctrl+Y)", exec: () => document.execCommand("redo") },
  clear: { label: "\u{1F5D1}", title: "Clear all content", exec: (ed) => ed.clear() }
};
var DEFAULT_TOOLBAR = [
  "bold",
  "italic",
  "underline",
  "strikethrough",
  "|",
  "h1",
  "h2",
  "h3",
  "p",
  "|",
  "ul",
  "ol",
  "|",
  "alignLeft",
  "alignCenter",
  "alignRight",
  "|",
  "link",
  "unlink",
  "image",
  "|",
  "undo",
  "redo",
  "|",
  "clear"
];
function htmlToMarkdown(html) {
  return html.replace(/<h1[^>]*>(.*?)<\/h1>/gi, "# $1\n\n").replace(/<h2[^>]*>(.*?)<\/h2>/gi, "## $1\n\n").replace(/<h3[^>]*>(.*?)<\/h3>/gi, "### $1\n\n").replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<i[^>]*>(.*?)<\/i>/gi, "*$1*").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<li[^>]*>(.*?)<\/li>/gi, "- $1\n").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ").trim();
}
var _rteCounter = 0;
var RichTextEditor = class {
  // ── Private fields ────────────────────────────────────────────────────────────
  #id;
  #obs;
  #opts;
  #root;
  #tb;
  #body;
  // ── Constructor ───────────────────────────────────────────────────────────────
  /**
   * Create a RichTextEditor.
   *
   * @param opts - Editor configuration options.
   *
   * @example
   *   const editor = new RichTextEditor({
   *     placeholder: 'Start typing…',
   *     toolbar    : ['bold', 'italic', '|', 'h1', 'h2', '|', 'ul', 'undo', 'redo'],
   *     minHeight  : 200,
   *   });
   *   editor.append('#composer');
   */
  constructor(opts = {}) {
    this.#id = `arianna-rte-${++_rteCounter}`;
    this.#obs = new Observable();
    this.#opts = {
      placeholder: opts.placeholder ?? "Start typing\u2026",
      toolbar: opts.toolbar ?? DEFAULT_TOOLBAR,
      minHeight: opts.minHeight ?? 150,
      maxHeight: opts.maxHeight ?? Infinity,
      spellcheck: opts.spellcheck ?? true,
      markdown: opts.markdown ?? true,
      value: opts.value ?? ""
    };
    this.#root = document.createElement("div");
    this.#root.id = this.#id;
    this.#root.className = "arianna-wip-rte";
    this.#root.style.cssText = `display:flex;flex-direction:column;border:1px solid var(--border,#e0e0e0);border-radius:6px;overflow:hidden;`;
    this.#tb = document.createElement("div");
    this.#tb.className = "arianna-wip-rte-toolbar";
    this.#tb.style.cssText = `display:flex;flex-wrap:wrap;gap:2px;padding:6px 8px;background:var(--bg3,#f5f5f5);border-bottom:1px solid var(--border,#e0e0e0);`;
    this.#buildToolbar();
    this.#root.appendChild(this.#tb);
    this.#body = document.createElement("div");
    this.#body.className = "arianna-wip-rte-body";
    this.#body.contentEditable = "true";
    this.#body.spellcheck = this.#opts.spellcheck;
    this.#body.style.cssText = [
      `flex:1`,
      `padding:14px 16px`,
      `outline:none`,
      `font-size:.88rem`,
      `line-height:1.75`,
      `background:var(--bg2,#fff)`,
      `color:var(--text,#111)`,
      `min-height:${this.#opts.minHeight}px`,
      this.#opts.maxHeight !== Infinity ? `max-height:${this.#opts.maxHeight}px;overflow-y:auto;` : ""
    ].join(";");
    this.#root.appendChild(this.#body);
    if (this.#opts.value) this.#body.innerHTML = this.#opts.value;
    this.#wirePlaceholder();
    this.#wireEvents();
  }
  // ── Public API ─────────────────────────────────────────────────────────────────
  /**
   * Get or set the editor's inner HTML content.
   *
   * @example
   *   editor.html = '<h1>Title</h1><p>Body text here.</p>';
   *   console.log(editor.html);
   */
  get html() {
    return this.#body.innerHTML;
  }
  set html(value) {
    this.#body.innerHTML = value;
    this.#updatePlaceholder();
  }
  /**
   * Get the editor content as plain text (no HTML tags).
   *
   * @example
   *   console.log(editor.text);  // → "Title\nBody text here."
   */
  get text() {
    return this.#body.innerText;
  }
  /**
   * Get a rough Markdown representation of the editor content.
   *
   * @example
   *   console.log(editor.markdown);  // → "# Title\n\nBody text here."
   */
  get markdown() {
    return htmlToMarkdown(this.#body.innerHTML);
  }
  /**
   * `true` if the editor has no meaningful content.
   *
   * @example
   *   if (editor.isEmpty) alert('Please write something!');
   */
  get isEmpty() {
    return !this.#body.textContent?.trim() && !this.#body.querySelector("img, video, iframe");
  }
  /**
   * Return the root container `HTMLElement`.
   *
   * @example
   *   document.body.appendChild(editor.render());
   */
  render() {
    return this.#root;
  }
  /** Implicit coercion to `HTMLElement`. */
  valueOf() {
    return this.#root;
  }
  /**
   * Mount the editor into a parent element.
   * Fluent — returns `this`.
   *
   * @example
   *   editor.append('#composer');
   *   editor.append(containerReal);
   */
  append(parent) {
    const par = typeof parent === "string" ? document.querySelector(parent) : parent instanceof Element ? parent : parent.render();
    if (par) par.appendChild(this.#root);
    return this;
  }
  /**
   * Execute a toolbar command programmatically.
   * Optionally pass a value (for `insertHTML`, `createLink`, etc.).
   * Fluent — returns `this`.
   *
   * @param cmd - Toolbar command string.
   * @param val - Optional value for commands like `'insertHTML'`.
   *
   * @example
   *   editor.command('bold');
   *   editor.command('insertHTML', '<hr>');
   *   editor.command('h1');
   */
  command(cmd, val) {
    this.#body.focus();
    const def = TOOLBAR_DEFS[cmd];
    if (def) {
      def.exec(this);
    } else if (val !== void 0) {
      document.execCommand(cmd, false, val);
    } else {
      document.execCommand(cmd);
    }
    this.#fireChange();
    this.#fire("RichText-Command", { command: cmd, value: val });
    return this;
  }
  /**
   * Focus the editor body.
   * Fluent — returns `this`.
   *
   * @example
   *   editor.focus();
   */
  focus() {
    this.#body.focus();
    return this;
  }
  /**
   * Remove focus from the editor body.
   * Fluent — returns `this`.
   *
   * @example
   *   editor.blur();
   */
  blur() {
    this.#body.blur();
    return this;
  }
  /**
   * Clear all editor content.
   * Fluent — returns `this`.
   *
   * @example
   *   editor.clear();
   */
  clear() {
    this.#body.innerHTML = "";
    this.#updatePlaceholder();
    this.#fireChange();
    return this;
  }
  /**
   * Register a listener for RichTextEditor events.
   * Fluent — returns `this`.
   *
   * @example
   *   editor.on('RichText-Change',  e => save(e.html));
   *   editor.on('RichText-Blur',    e => validate(e.html));
   *   editor.on('RichText-Command', e => console.log(e.command));
   */
  on(type, cb) {
    this.#obs.on(type, cb);
    return this;
  }
  /**
   * Remove a RichTextEditor event listener.
   * Fluent — returns `this`.
   *
   * @example
   *   editor.off('RichText-Change', handler);
   */
  off(type, cb) {
    this.#obs.off(type, cb);
    return this;
  }
  // ── Private helpers ────────────────────────────────────────────────────────────
  #fire(type, extra = {}) {
    this.#obs.fire({
      Type: type,
      editor: this,
      ...extra
    });
  }
  #fireChange() {
    this.#fire("RichText-Change", { html: this.html, text: this.text });
  }
  #buildToolbar() {
    this.#opts.toolbar.forEach((cmd) => {
      if (cmd === "|") {
        const sep = document.createElement("span");
        sep.style.cssText = `width:1px;background:var(--border,#e0e0e0);height:18px;display:inline-block;margin:0 4px;vertical-align:middle;align-self:center;`;
        this.#tb.appendChild(sep);
        return;
      }
      const def = TOOLBAR_DEFS[cmd];
      if (!def) return;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.title = def.title;
      btn.innerHTML = def.label;
      btn.className = "arianna-wip-rte-btn";
      btn.style.cssText = [
        `background:var(--bg2,#fff)`,
        `border:1px solid var(--border,#e0e0e0)`,
        `border-radius:4px`,
        `cursor:pointer`,
        `font:inherit`,
        `font-size:.75rem`,
        `padding:3px 7px`,
        `color:var(--text,#111)`,
        `line-height:1.4`,
        def.style ?? ""
      ].join(";");
      btn.addEventListener("mousedown", (e) => {
        e.preventDefault();
        this.#body.focus();
        def.exec(this);
        this.#fireChange();
        this.#fire("RichText-Command", { command: cmd });
      });
      this.#tb.appendChild(btn);
    });
  }
  #wirePlaceholder() {
    const ph = this.#opts.placeholder;
    const style = document.createElement("style");
    style.textContent = `
      #${this.#id} .arianna-rte-body:empty::before {
        content   : attr(data-placeholder);
        color     : var(--muted, #aaa);
        pointer-events: none;
        position  : absolute;
      }
      #${this.#id} .arianna-rte-body { position: relative; }
    `;
    this.#root.prepend(style);
    this.#body.dataset.placeholder = ph;
    this.#updatePlaceholder();
  }
  #updatePlaceholder() {
  }
  #wireEvents() {
    this.#body.addEventListener("input", () => {
      if (this.#opts.markdown) this.#processMarkdown();
      this.#fireChange();
    });
    this.#body.addEventListener("focus", () => {
      this.#fire("RichText-Focus");
    });
    this.#body.addEventListener("blur", () => {
      this.#fire("RichText-Blur", { html: this.html, text: this.text });
    });
    this.#body.addEventListener("keydown", (e) => {
      const ke = e;
      if (ke.ctrlKey || ke.metaKey) {
        switch (ke.key.toLowerCase()) {
          case "b":
            ke.preventDefault();
            this.command("bold");
            break;
          case "i":
            ke.preventDefault();
            this.command("italic");
            break;
          case "u":
            ke.preventDefault();
            this.command("underline");
            break;
          case "z":
            if (!ke.shiftKey) {
              ke.preventDefault();
              this.command("undo");
            }
            break;
          case "y":
            ke.preventDefault();
            this.command("redo");
            break;
        }
      }
    });
  }
  /**
   * Process inline Markdown shortcuts on Space or Enter.
   * Called only when `opts.markdown` is `true`.
   * @internal
   */
  #processMarkdown() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const node = sel.anchorNode;
    if (!node || node.nodeType !== Node.TEXT_NODE) return;
    const text = node.textContent ?? "";
    const headMatch = text.match(/^(#{1,3})\s(.+)$/);
    if (headMatch) {
      const level = headMatch[1].length;
      const content = headMatch[2];
      document.execCommand("formatBlock", false, `h${level}`);
      if (node.parentElement) node.parentElement.textContent = content;
      const range = document.createRange();
      const el = sel.anchorNode?.parentElement;
      if (el) {
        range.selectNodeContents(el);
        range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
      }
    }
  }
};
if (typeof window !== "undefined")
  Object.defineProperty(window, "RichTextEditor", {
    enumerable: true,
    configurable: false,
    writable: false,
    value: RichTextEditor
  });

// components/inputs/SearchBar.ts
var SearchBar = class extends Control {
  _value = "";
  _timer = 0;
  _input;
  constructor(container = null, opts = {}) {
    super(container, "div", { placeholder: "Search\u2026", debounce: 300, ...opts });
    this.el.className = `ar-searchbar${opts.class ? " " + opts.class : ""}`;
  }
  set value(v) {
    this._value = v;
    if (this._input) this._input.value = v;
  }
  get value() {
    return this._input?.value ?? this._value;
  }
  focus() {
    this._input?.focus();
  }
  clear() {
    this._value = "";
    if (this._input) this._input.value = "";
    this._emit("search", { value: "" });
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    this._el("span", "ar-searchbar__icon", this.el).textContent = "\u{1F50D}";
    this._input = document.createElement("input");
    this._input.type = "text";
    this._input.className = "ar-searchbar__input";
    this._input.placeholder = this._get("placeholder", "Search\u2026");
    this._input.value = this._value;
    const clear = this._el("button", "ar-searchbar__clear", this.el);
    clear.textContent = "\u2715";
    clear.style.visibility = this._value ? "visible" : "hidden";
    this._input.addEventListener("input", () => {
      const v = this._input.value;
      clear.style.visibility = v ? "visible" : "hidden";
      clearTimeout(this._timer);
      this._timer = window.setTimeout(() => {
        this._value = v;
        this._emit("search", { value: v });
      }, this._get("debounce", 300));
    });
    clear.addEventListener("click", () => {
      this._input.value = "";
      this._value = "";
      clear.style.visibility = "hidden";
      this._emit("search", { value: "" });
      this._input.focus();
    });
    this.el.insertBefore(this._input, clear);
  }
};

// components/inputs/Switch.ts
var Switch = class extends Control {
  _checked = false;
  _input;
  constructor(container = null, opts = {}) {
    super(container, "label", opts);
    this.el.className = `ar-switch${opts.labelPosition === "left" ? " ar-switch--label-left" : ""}${opts.class ? " " + opts.class : ""}`;
  }
  set checked(v) {
    this._checked = v;
    if (this._input) this._input.checked = v;
  }
  get checked() {
    return this._input?.checked ?? this._checked;
  }
  set disabled(v) {
    if (this._input) this._input.disabled = v;
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    const pos = this._get("labelPosition", "right");
    if (lbl && pos === "left") this._el("span", "ar-switch__label", this.el).textContent = lbl;
    this._input = document.createElement("input");
    this._input.type = "checkbox";
    this._input.className = "ar-switch__input";
    this._input.checked = this._checked;
    this._input.disabled = this._get("disabled", false);
    this._input.addEventListener("change", () => {
      this._checked = this._input.checked;
      this._emit("change", { checked: this._checked });
    });
    this.el.appendChild(this._input);
    this._el("span", "ar-switch__track", this.el);
    if (lbl && pos !== "left") this._el("span", "ar-switch__label", this.el).textContent = lbl;
  }
};

// components/inputs/TextField.ts
var TextField = class extends Control {
  _value = "";
  _error = "";
  _input;
  constructor(container = null, opts = {}) {
    super(container, "div", { type: "text", ...opts });
    this.el.className = `ar-textfield${opts.class ? " " + opts.class : ""}`;
  }
  set value(v) {
    this._value = v;
    if (this._input) this._input.value = v;
  }
  get value() {
    return this._input?.value ?? this._value;
  }
  set error(v) {
    this._error = v;
    this.el.classList.toggle("ar-textfield--error", !!v);
    const e = this.el.querySelector(".ar-textfield__error");
    if (e) e.textContent = v;
    else this._build();
  }
  set disabled(v) {
    if (this._input) this._input.disabled = v;
  }
  focus() {
    this._input?.focus();
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("label", "ar-textfield__label", this.el).textContent = lbl;
    const wrap = this._el("div", "ar-textfield__wrap", this.el);
    const pfx = this._get("prefix", "");
    if (pfx) this._el("span", "ar-textfield__prefix", wrap).textContent = pfx;
    this._input = document.createElement("input");
    this._input.className = "ar-textfield__input";
    this._input.type = this._get("type", "text");
    this._input.placeholder = this._get("placeholder", "");
    this._input.value = this._value;
    this._input.readOnly = this._get("readonly", false);
    this._input.disabled = this._get("disabled", false);
    const ml = this._get("maxlength", 0);
    if (ml) this._input.maxLength = ml;
    this._input.addEventListener("input", () => {
      this._value = this._input.value;
      this._emit("input", { value: this._value });
    });
    this._input.addEventListener("change", () => this._emit("change", { value: this._input.value }));
    wrap.appendChild(this._input);
    const sfx = this._get("suffix", "");
    if (sfx) this._el("span", "ar-textfield__suffix", wrap).textContent = sfx;
    const hint = this._get("hint", "");
    if (hint) this._el("div", "ar-textfield__hint", this.el).textContent = hint;
    if (this._error) this._el("div", "ar-textfield__error", this.el).textContent = this._error;
  }
};

// components/inputs/TimePicker.ts
var TimePicker = class extends Control {
  _value = "";
  _input;
  constructor(container = null, opts = {}) {
    super(container, "div", { seconds: false, ...opts });
    this.el.className = `ar-timepicker${opts.class ? " " + opts.class : ""}`;
  }
  set value(v) {
    this._value = v;
    if (this._input) this._input.value = v;
  }
  get value() {
    return this._input?.value ?? this._value;
  }
  _build() {
    this.el.innerHTML = "";
    const lbl = this._get("label", "");
    if (lbl) this._el("div", "ar-timepicker__label", this.el).textContent = lbl;
    const wrap = this._el("div", "ar-timepicker__wrap", this.el);
    this._el("span", "ar-timepicker__icon", wrap).textContent = "\u{1F550}";
    this._input = document.createElement("input");
    this._input.type = "time";
    this._input.className = "ar-timepicker__input";
    this._input.value = this._value;
    this._input.disabled = this._get("disabled", false);
    if (this._get("seconds", false)) this._input.step = "1";
    const min = this._get("min", "");
    if (min) this._input.min = min;
    const max = this._get("max", "");
    if (max) this._input.max = max;
    this._input.addEventListener("change", () => {
      this._value = this._input.value;
      this._emit("change", { value: this._value });
    });
    wrap.appendChild(this._input);
  }
};

// components/layout/Accordion.ts
function renderIcon(style, open) {
  switch (style) {
    case "chevron":
      return `<span class="arianna-acc-icon" style="display:inline-block;transition:transform .25s;transform:rotate(${open ? 90 : 0}deg);color:var(--muted,#888);font-size:.85em;">\u203A</span>`;
    case "plus":
      return `<span class="arianna-acc-icon" style="display:inline-block;font-size:1.1em;font-weight:400;color:var(--muted,#888);">${open ? "\u2212" : "+"}</span>`;
    case "arrow":
      return `<span class="arianna-acc-icon" style="display:inline-block;transition:transform .25s;transform:rotate(${open ? 90 : 0}deg);color:var(--muted,#888);">\u2192</span>`;
    case "none":
    default:
      return "";
  }
}
var _accCounter = 0;
var Accordion = class {
  // ── Private fields ────────────────────────────────────────────────────────────
  #id;
  #obs;
  #opts;
  #items;
  #open;
  #el;
  // ── Constructor ───────────────────────────────────────────────────────────────
  /**
   * Create an Accordion.
   *
   * @param opts - Accordion configuration options.
   *
   * @example
   *   const acc = new Accordion({
   *     items   : [{ id: 'a', title: 'Section A', content: '<p>Content</p>' }],
   *     multiple: false,
   *     icon    : 'chevron',
   *     animated: true,
   *   });
   *   acc.append('#sidebar');
   */
  constructor(opts = {}) {
    this.#id = `arianna-acc-${++_accCounter}`;
    this.#obs = new Observable();
    this.#opts = {
      items: opts.items ?? [],
      multiple: opts.multiple ?? false,
      animated: opts.animated ?? true,
      icon: opts.icon ?? "chevron",
      borderless: opts.borderless ?? false
    };
    this.#items = this.#opts.items.map((i) => ({ open: false, disabled: false, ...i }));
    this.#open = new Set(this.#items.filter((i) => i.open && !i.disabled).map((i) => i.id));
    if (!this.#opts.multiple && this.#open.size > 1) {
      const first = [...this.#open][0];
      this.#open.clear();
      this.#open.add(first);
    }
    this.#el = document.createElement("div");
    this.#el.id = this.#id;
    this.#el.className = "arianna-wip-accordion";
    this.#el.setAttribute("role", "tablist");
    this.#el.style.cssText = "display:flex;flex-direction:column;width:100%;";
    this.#render();
    this.#wireEvents();
  }
  // ── Public API ─────────────────────────────────────────────────────────────────
  /**
   * Return the root accordion `HTMLElement`.
   *
   * @example
   *   document.body.appendChild(acc.render());
   */
  render() {
    return this.#el;
  }
  /** Implicit coercion to `HTMLElement`. */
  valueOf() {
    return this.#el;
  }
  /**
   * Mount the accordion into a parent element.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.append('#sidebar');
   *   acc.append(containerReal);
   */
  append(parent) {
    const par = typeof parent === "string" ? document.querySelector(parent) : parent instanceof Element ? parent : parent.render();
    if (par) par.appendChild(this.#el);
    return this;
  }
  /**
   * Open a panel by id. In single mode, closes all other panels first.
   * Fluent — returns `this`.
   *
   * @param id - Panel identifier.
   *
   * @example
   *   acc.open('intro');
   */
  open(id) {
    const item = this.#find(id);
    if (!item || item.disabled || this.#open.has(id)) return this;
    if (!this.#opts.multiple) this.#open.clear();
    this.#open.add(id);
    this.#update(id);
    this.#fire("Accordion-Open", id, item);
    return this;
  }
  /**
   * Close a panel by id.
   * Fluent — returns `this`.
   *
   * @param id - Panel identifier.
   *
   * @example
   *   acc.close('intro');
   */
  close(id) {
    const item = this.#find(id);
    if (!item || item.disabled || !this.#open.has(id)) return this;
    this.#open.delete(id);
    this.#update(id);
    this.#fire("Accordion-Close", id, item);
    return this;
  }
  /**
   * Toggle a panel open/closed by id.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.toggle('api');
   */
  toggle(id) {
    return this.#open.has(id) ? this.close(id) : this.open(id);
  }
  /**
   * Open all panels (switches to multiple mode temporarily if needed).
   * Fluent — returns `this`.
   *
   * @example
   *   acc.openAll();
   */
  openAll() {
    this.#items.forEach((item) => {
      if (!item.disabled) this.#open.add(item.id);
    });
    this.#render();
    return this;
  }
  /**
   * Close all panels.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.closeAll();
   */
  closeAll() {
    this.#open.clear();
    this.#render();
    return this;
  }
  /**
   * Check whether a panel is currently open.
   *
   * @example
   *   acc.isOpen('intro')  // → true | false
   */
  isOpen(id) {
    return this.#open.has(id);
  }
  /**
   * Return all currently open panel ids.
   *
   * @example
   *   acc.openItems()  // → ['api', 'usage']
   */
  openItems() {
    return [...this.#open];
  }
  /**
   * Add a new panel.
   * Fluent — returns `this`.
   *
   * @param item  - Panel definition.
   * @param index - Insertion index. Default: append at end.
   *
   * @example
   *   acc.addItem({ id: 'new', title: 'New Section', content: '<p>Hi</p>' });
   *   acc.addItem({ id: 'top', title: 'First', content: '<p>Top</p>' }, 0);
   */
  addItem(item, index) {
    const full = { open: false, disabled: false, ...item };
    if (index !== void 0 && index >= 0 && index < this.#items.length)
      this.#items.splice(index, 0, full);
    else
      this.#items.push(full);
    if (full.open && !full.disabled) {
      if (!this.#opts.multiple) this.#open.clear();
      this.#open.add(full.id);
    }
    this.#render();
    this.#fire("Accordion-Add", item.id, full);
    return this;
  }
  /**
   * Remove a panel by id.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.removeItem('notes');
   */
  removeItem(id) {
    const idx = this.#items.findIndex((i) => i.id === id);
    if (idx < 0) return this;
    this.#items.splice(idx, 1);
    this.#open.delete(id);
    this.#render();
    this.#fire("Accordion-Remove", id);
    return this;
  }
  /**
   * Replace the body content of a panel.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.setContent('usage', '<p>Updated content.</p>');
   */
  setContent(id, html) {
    const item = this.#find(id);
    if (item) {
      item.content = html;
      this.#updateBody(id, html);
    }
    return this;
  }
  /**
   * Update the header title of a panel.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.setTitle('api', 'API Reference v2');
   */
  setTitle(id, html) {
    const item = this.#find(id);
    if (item) {
      item.title = html;
      this.#updateTitle(id, html);
    }
    return this;
  }
  /**
   * Enable a disabled panel (allows it to be toggled again).
   * Fluent — returns `this`.
   *
   * @example
   *   acc.enable('notes');
   */
  enable(id) {
    const item = this.#find(id);
    if (item) {
      item.disabled = false;
      this.#renderItem(id);
    }
    return this;
  }
  /**
   * Disable a panel — it can no longer be opened or closed by the user.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.disable('notes');
   */
  disable(id) {
    const item = this.#find(id);
    if (item) {
      item.disabled = true;
      this.#open.delete(id);
      this.#renderItem(id);
    }
    return this;
  }
  /**
   * Register a listener for Accordion events.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.on('Accordion-Open',  e => console.log(e.id, 'opened'));
   *   acc.on('Accordion-Close', e => console.log(e.id, 'closed'));
   */
  on(type, cb) {
    this.#obs.on(type, cb);
    return this;
  }
  /**
   * Remove an Accordion event listener.
   * Fluent — returns `this`.
   *
   * @example
   *   acc.off('Accordion-Open', handler);
   */
  off(type, cb) {
    this.#obs.off(type, cb);
    return this;
  }
  // ── Private helpers ────────────────────────────────────────────────────────────
  #find(id) {
    return this.#items.find((i) => i.id === id);
  }
  #fire(type, id, item) {
    this.#obs.fire({
      Type: type,
      id,
      item,
      open: this.#open.has(id),
      accordion: this
    });
  }
  #render() {
    this.#el.innerHTML = "";
    this.#items.forEach((item) => this.#el.appendChild(this.#buildPanel(item)));
  }
  #renderItem(id) {
    const item = this.#find(id);
    if (!item) return;
    const existing = this.#el.querySelector(`[data-acc-id="${id}"]`);
    if (existing) {
      const fresh = this.#buildPanel(item);
      existing.parentElement?.replaceChild(fresh, existing);
    }
  }
  #buildPanel(item) {
    const isOpen = this.#open.has(item.id);
    const isDisabled = !!item.disabled;
    const border = this.#opts.borderless ? "none" : "1px solid var(--border,#e0e0e0)";
    const animStyle = this.#opts.animated ? `max-height:${isOpen ? "2000px" : "0"};transition:max-height .3s ease;overflow:hidden;` : `display:${isOpen ? "block" : "none"};`;
    const panel = document.createElement("div");
    panel.className = "arianna-wip-acc-panel";
    panel.dataset.accId = item.id;
    panel.style.cssText = `border:${border};border-radius:6px;overflow:hidden;margin-bottom:4px;`;
    panel.innerHTML = `
      <button
        class="arianna-acc-header"
        data-acc-id="${item.id}"
        aria-expanded="${isOpen}"
        aria-disabled="${isDisabled}"
        role="tab"
        ${isDisabled ? "disabled" : ""}
        style="width:100%;background:var(--bg3,#f5f5f5);border:none;cursor:${isDisabled ? "not-allowed" : "pointer"};
               display:flex;align-items:center;justify-content:space-between;padding:12px 16px;
               font:inherit;font-size:.84rem;font-weight:600;color:${isDisabled ? "var(--muted,#aaa)" : "var(--text,#111)"};
               text-align:left;opacity:${isDisabled ? ".5" : "1"};"
      >
        <span class="arianna-acc-title">${item.title}</span>
        ${renderIcon(this.#opts.icon, isOpen)}
      </button>
      <div
        class="arianna-acc-body"
        data-acc-id="${item.id}"
        role="tabpanel"
        style="${animStyle}background:var(--bg2,#fafafa);"
      >
        <div style="padding:14px 16px;">${item.content}</div>
      </div>
    `;
    return panel;
  }
  #update(id) {
    const isOpen = this.#open.has(id);
    const header = this.#el.querySelector(`.arianna-acc-header[data-acc-id="${id}"]`);
    const body = this.#el.querySelector(`.arianna-acc-body[data-acc-id="${id}"]`);
    const icon = header?.querySelector(".arianna-wip-acc-icon");
    if (header) header.setAttribute("aria-expanded", String(isOpen));
    if (body) {
      if (this.#opts.animated) {
        body.style.maxHeight = isOpen ? "2000px" : "0";
      } else {
        body.style.display = isOpen ? "block" : "none";
      }
    }
    if (icon) {
      switch (this.#opts.icon) {
        case "chevron":
        case "arrow":
          icon.style.transform = `rotate(${isOpen ? 90 : 0}deg)`;
          break;
        case "plus":
          icon.textContent = isOpen ? "\u2212" : "+";
          break;
      }
    }
  }
  #updateBody(id, html) {
    const body = this.#el.querySelector(`.arianna-acc-body[data-acc-id="${id}"] > div`);
    if (body) body.innerHTML = html;
  }
  #updateTitle(id, html) {
    const title = this.#el.querySelector(`.arianna-acc-header[data-acc-id="${id}"] .arianna-acc-title`);
    if (title) title.innerHTML = html;
  }
  #wireEvents() {
    this.#el.addEventListener("click", (e) => {
      const btn = e.target.closest(".arianna-wip-acc-header");
      if (!btn) return;
      const id = btn.dataset.accId;
      if (!id) return;
      const item = this.#find(id);
      if (!item || item.disabled) return;
      this.toggle(id);
      this.#fire("Accordion-Toggle", id, item);
    });
    this.#el.addEventListener("keydown", (e) => {
      const ke = e;
      const btn = ke.target.closest(".arianna-wip-acc-header");
      if (!btn) return;
      const headers = Array.from(this.#el.querySelectorAll(".arianna-wip-acc-header:not([disabled])"));
      const idx = headers.indexOf(btn);
      let next = -1;
      if (ke.key === "ArrowDown") next = (idx + 1) % headers.length;
      if (ke.key === "ArrowUp") next = (idx - 1 + headers.length) % headers.length;
      if (ke.key === "Home") next = 0;
      if (ke.key === "End") next = headers.length - 1;
      if (next >= 0) {
        ke.preventDefault();
        headers[next].focus();
      }
    });
  }
};
if (typeof window !== "undefined")
  Object.defineProperty(window, "Accordion", {
    enumerable: true,
    configurable: false,
    writable: false,
    value: Accordion
  });

// components/layout/Card.ts
var Card = class extends Control {
  _title = "";
  _subtitle = "";
  _media = "";
  _content = "";
  _footer = "";
  constructor(container = null, opts = {}) {
    super(container, "div", { elevation: 1, variant: "outlined", ...opts });
    this.el.className = `ar-card ar-card--${opts.variant ?? "outlined"} ar-card--e${opts.elevation ?? 1}${opts.class ? " " + opts.class : ""}`;
  }
  set title(v) {
    this._title = v;
    this._set("title", v);
  }
  set subtitle(v) {
    this._subtitle = v;
    this._set("subtitle", v);
  }
  set media(v) {
    this._media = v;
    this._set("media", v);
  }
  set content(v) {
    this._content = v;
    this._set("content", v);
  }
  set footer(v) {
    this._footer = v;
    this._set("footer", v);
  }
  _build() {
    this.el.innerHTML = "";
    if (this._media) {
      const m = this._el("div", "ar-card__media", this.el);
      if (typeof this._media === "string") m.innerHTML = this._media;
      else m.appendChild(this._media);
    }
    if (this._title || this._subtitle) {
      const h = this._el("div", "ar-card__header", this.el);
      if (this._title) {
        const t = this._el("div", "ar-card__title", h);
        t.textContent = this._title;
      }
      if (this._subtitle) {
        const s = this._el("div", "ar-card__subtitle", h);
        s.textContent = this._subtitle;
      }
    }
    if (this._content) {
      const b = this._el("div", "ar-card__body", this.el);
      if (typeof this._content === "string") b.innerHTML = this._content;
      else b.appendChild(this._content);
    }
    if (this._footer) {
      const f = this._el("div", "ar-card__footer", this.el);
      if (typeof this._footer === "string") f.innerHTML = this._footer;
      else f.appendChild(this._footer);
    }
  }
};

// components/layout/Dock.ts
var Dock = class extends Control {
  _style;
  _items = [];
  _tray = [];
  _elTrack;
  _elStart;
  _elTray;
  constructor(container, opts = {}) {
    super(container, "div", {
      style: "macos",
      magnify: 1.6,
      position: "bottom",
      startLabel: "",
      ...opts
    });
    this._style = this._get("style", "macos");
    for (const it of opts.items ?? []) this._items.push({ ...it });
    for (const it of opts.tray ?? []) this._tray.push({ ...it });
    this._injectStyles();
    this._build();
    this._render();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  setStyle(s) {
    this._style = s;
    this._build();
    this._render();
    return this;
  }
  getStyle() {
    return this._style;
  }
  setItems(items) {
    this._items = items.map((i) => ({ ...i }));
    this._render();
    return this;
  }
  getItems() {
    return this._items.map((i) => ({ ...i }));
  }
  addItem(item) {
    this._items.push({ ...item });
    this._render();
    return this;
  }
  removeItem(id) {
    this._items = this._items.filter((i) => i.id !== id);
    this._render();
    return this;
  }
  updateItem(id, patch) {
    const i = this._items.findIndex((x) => x.id === id);
    if (i >= 0) {
      this._items[i] = { ...this._items[i], ...patch };
      this._render();
    }
    return this;
  }
  clearItems() {
    this._items = [];
    this._render();
    return this;
  }
  setRunning(id, on) {
    return this.updateItem(id, { running: on });
  }
  setBadge(id, n) {
    return this.updateItem(id, { badge: n > 0 ? n : void 0 });
  }
  setActive(id) {
    this._items = this._items.map((i) => ({ ...i, active: i.id === id }));
    this._render();
    return this;
  }
  // ── Build ──────────────────────────────────────────────────────────────
  _build() {
    const self = this;
    const pos = self._get("position", "bottom");
    self.el.className = `ar-dock ar-dock--${this._style} ar-dock--${pos}`;
    if (this._style === "macos") {
      self.el.innerHTML = `<div class="ar-dock__track" data-r="track"></div>`;
      this._elTrack = self.el.querySelector('[data-r="track"]');
      this._elTrack.addEventListener("pointermove", (e) => this._magnify(e));
      this._elTrack.addEventListener("pointerleave", () => this._unmagnify());
    } else {
      const startLabel = self._get("startLabel", "");
      self.el.innerHTML = `
<button class="ar-dock__start" data-r="start" title="Start" aria-label="Start">
  <span class="ar-dock__start-icon" aria-hidden="true">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><rect x="3"  y="3"  width="8" height="8"/><rect x="13" y="3"  width="8" height="8"/><rect x="3"  y="13" width="8" height="8"/><rect x="13" y="13" width="8" height="8"/></svg>
  </span>
  ${startLabel ? `<span class="ar-dock__start-label">${startLabel}</span>` : ""}
</button>
<div class="ar-dock__track" data-r="track"></div>
<div class="ar-dock__tray" data-r="tray"></div>`;
      this._elTrack = self.el.querySelector('[data-r="track"]');
      this._elStart = self.el.querySelector('[data-r="start"]');
      this._elTray = self.el.querySelector('[data-r="tray"]');
      this._elStart.addEventListener("click", () => self._emit("start", {}));
    }
    if (this._items.length) this._render();
  }
  // ── Render ─────────────────────────────────────────────────────────────
  _render() {
    if (!this._elTrack) return;
    const self = this;
    this._elTrack.innerHTML = "";
    for (const it of this._items) {
      if (it.separator) {
        const sep = document.createElement("div");
        sep.className = "ar-dock__sep";
        this._elTrack.appendChild(sep);
      }
      this._elTrack.appendChild(this._renderItem(it));
    }
    if (this._elTray) {
      this._elTray.innerHTML = "";
      for (const t of this._tray) this._elTray.appendChild(this._renderItem(t, true));
      const clock = document.createElement("div");
      clock.className = "ar-dock__clock";
      const tick = () => {
        const d = /* @__PURE__ */ new Date();
        clock.innerHTML = `<div class="ar-dock__time">${d.toLocaleTimeString(void 0, { hour: "2-digit", minute: "2-digit" })}</div><div class="ar-dock__date">${d.toLocaleDateString(void 0, { month: "numeric", day: "numeric", year: "numeric" })}</div>`;
      };
      tick();
      const id = setInterval(tick, 6e4);
      clock._intervalId = id;
      this._elTray.appendChild(clock);
    }
    void self;
  }
  _renderItem(it, tray = false) {
    const self = this;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "ar-dock__item" + (it.active ? " ar-dock__item--active" : "") + (it.running ? " ar-dock__item--running" : "") + (tray ? " ar-dock__item--tray" : "");
    btn.dataset.id = it.id;
    btn.title = it.label;
    btn.setAttribute("aria-label", it.label);
    const icon = this._renderIcon(it.icon);
    const badge = it.badge && it.badge > 0 ? `<span class="ar-dock__badge">${it.badge > 99 ? "99+" : it.badge}</span>` : "";
    btn.innerHTML = `<span class="ar-dock__icon">${icon}</span>${badge}<span class="ar-dock__dot" aria-hidden="true"></span><span class="ar-dock__tooltip">${it.label}</span>`;
    btn.addEventListener("click", () => self._emit(tray ? "tray-click" : "item-click", { id: it.id, item: { ...it } }));
    btn.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      self._emit("item-context", { id: it.id, item: { ...it }, x: e.clientX, y: e.clientY });
    });
    return btn;
  }
  _renderIcon(icon) {
    const trim = icon.trim();
    if (trim.startsWith("<svg")) return trim;
    if (trim.startsWith("http") || trim.startsWith("/") || trim.startsWith("data:")) {
      return `<img src="${trim}" alt="" draggable="false">`;
    }
    return `<span class="ar-dock__emoji">${trim}</span>`;
  }
  // ── macOS magnification ────────────────────────────────────────────────
  _magnify(e) {
    if (this._style !== "macos") return;
    const factor = this._get("magnify", 1.6);
    if (factor <= 1) return;
    const rect = this._elTrack.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const items = this._elTrack.querySelectorAll(".ar-dock__item");
    const radius = 80;
    items.forEach((it) => {
      const ir = it.getBoundingClientRect();
      const center = ir.left - rect.left + ir.width / 2;
      const dist = Math.abs(x - center);
      const t = Math.max(0, 1 - dist / radius);
      const scale = 1 + (factor - 1) * t;
      it.style.transform = `scale(${scale.toFixed(3)})`;
    });
  }
  _unmagnify() {
    if (this._style !== "macos") return;
    this._elTrack.querySelectorAll(".ar-dock__item").forEach((it) => {
      it.style.transform = "";
    });
  }
  // ── Styles ─────────────────────────────────────────────────────────────
  _injectStyles() {
    if (document.getElementById("ar-dock-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-dock-styles";
    s.textContent = `
.ar-dock { position:relative; display:flex; align-items:center; user-select:none; font:13px -apple-system,system-ui,sans-serif; box-sizing:border-box; }
.ar-dock__track { display:flex; align-items:flex-end; gap:6px; padding:6px 10px; }
.ar-dock__item { position:relative; background:none; border:0; padding:0; cursor:pointer; display:flex; flex-direction:column; align-items:center; transform-origin:bottom center; transition:transform .12s ease-out; }
.ar-dock__icon { display:flex; align-items:center; justify-content:center; }
.ar-dock__icon svg, .ar-dock__icon img { width:100%; height:100%; display:block; pointer-events:none; }
.ar-dock__emoji { font-size:32px; line-height:1; }
.ar-dock__tooltip { position:absolute; bottom:calc(100% + 8px); background:#111; color:#fff; padding:3px 8px; font:11px sans-serif; border-radius:4px; white-space:nowrap; pointer-events:none; opacity:0; transition:opacity .12s; }
.ar-dock__item:hover .ar-dock__tooltip { opacity:1; }
.ar-dock__badge { position:absolute; top:-2px; right:-2px; min-width:16px; height:16px; padding:0 4px; background:#ef4444; color:#fff; border-radius:8px; font:600 10px sans-serif; display:flex; align-items:center; justify-content:center; box-shadow:0 0 0 2px #161616; }
.ar-dock__dot { position:absolute; width:4px; height:4px; border-radius:50%; opacity:0; transition:opacity .12s; }
.ar-dock__item--running .ar-dock__dot { opacity:1; }

/* macOS style \u2014 translucent floating dock */
.ar-dock--macos { background:rgba(28, 28, 30, 0.6); backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px); border-radius:18px; border:1px solid rgba(255,255,255,.08); padding:0; height:78px; }
.ar-dock--macos .ar-dock__item { width:56px; height:62px; }
.ar-dock--macos .ar-dock__icon { width:48px; height:48px; border-radius:11px; overflow:hidden; box-shadow:0 4px 10px rgba(0,0,0,.4); background:linear-gradient(135deg, #2a2a2c 0%, #1c1c1e 100%); }
.ar-dock--macos .ar-dock__emoji { font-size:36px; }
.ar-dock--macos .ar-dock__sep { width:1px; height:48px; background:rgba(255,255,255,.18); margin:0 4px; align-self:center; }
.ar-dock--macos .ar-dock__dot { bottom:0; background:#d4d4d4; }

/* Windows style \u2014 flat bottom taskbar */
.ar-dock--windows { background:rgba(32, 32, 36, 0.92); backdrop-filter:blur(40px); -webkit-backdrop-filter:blur(40px); height:48px; padding:0 4px; gap:4px; border-top:1px solid rgba(255,255,255,.04); }
.ar-dock--windows .ar-dock__start { display:flex; align-items:center; gap:6px; background:transparent; border:0; color:#d4d4d4; height:40px; padding:0 12px; border-radius:6px; cursor:pointer; transition:background .12s; }
.ar-dock--windows .ar-dock__start:hover { background:rgba(255,255,255,.08); }
.ar-dock--windows .ar-dock__start-icon { display:flex; align-items:center; justify-content:center; color:#60a5fa; }
.ar-dock--windows .ar-dock__start-label { font:13px sans-serif; }
.ar-dock--windows .ar-dock__track { flex:1; padding:0 4px; gap:2px; align-items:center; height:48px; overflow:hidden; }
.ar-dock--windows .ar-dock__item { width:40px; height:40px; flex-direction:column; justify-content:center; border-radius:6px; transition:background .12s; }
.ar-dock--windows .ar-dock__item:hover { background:rgba(255,255,255,.08); }
.ar-dock--windows .ar-dock__item--active { background:rgba(255,255,255,.12); }
.ar-dock--windows .ar-dock__icon { width:22px; height:22px; }
.ar-dock--windows .ar-dock__emoji { font-size:20px; }
.ar-dock--windows .ar-dock__dot { bottom:2px; height:3px; width:16px; border-radius:2px; background:#60a5fa; }
.ar-dock--windows .ar-dock__item--running.ar-dock__item--active .ar-dock__dot { width:24px; }
.ar-dock--windows .ar-dock__tray { display:flex; align-items:center; gap:4px; padding:0 8px 0 4px; height:48px; border-left:1px solid rgba(255,255,255,.04); }
.ar-dock--windows .ar-dock__item--tray { width:28px; height:28px; }
.ar-dock--windows .ar-dock__item--tray .ar-dock__icon { width:18px; height:18px; }
.ar-dock--windows .ar-dock__item--tray .ar-dock__emoji { font-size:16px; }
.ar-dock--windows .ar-dock__clock { display:flex; flex-direction:column; align-items:flex-end; padding:0 8px; font:11px sans-serif; color:#d4d4d4; line-height:1.2; cursor:default; }
.ar-dock--windows .ar-dock__clock:hover { background:rgba(255,255,255,.08); }
.ar-dock--windows .ar-dock__time { font-weight:500; }
.ar-dock--windows .ar-dock__date { font-size:10px; opacity:.85; }
.ar-dock--windows .ar-dock__sep { display:none; }

@media (max-width: 600px) {
  .ar-dock--macos { height:64px; border-radius:14px; }
  .ar-dock--macos .ar-dock__item { width:44px; height:50px; }
  .ar-dock--macos .ar-dock__icon { width:38px; height:38px; border-radius:9px; }
  .ar-dock--macos .ar-dock__emoji { font-size:28px; }
  .ar-dock--windows { height:42px; }
  .ar-dock--windows .ar-dock__item { width:34px; height:34px; }
  .ar-dock--windows .ar-dock__icon { width:18px; height:18px; }
  .ar-dock--windows .ar-dock__emoji { font-size:16px; }
  .ar-dock--windows .ar-dock__start-label { display:none; }
  .ar-dock--windows .ar-dock__tray .ar-dock__item--tray { width:24px; height:24px; }
  .ar-dock--windows .ar-dock__clock { font-size:10px; padding:0 4px; }
  .ar-dock--windows .ar-dock__date { display:none; }
  .ar-dock__tooltip { display:none; }
}
`;
    document.head.appendChild(s);
  }
};

// components/layout/Drawer.ts
var Drawer = class extends Control {
  _content = "";
  _panel;
  constructor(opts = {}) {
    super(null, "div", { side: "left", width: 280, closeOnBackdrop: true, ...opts });
    document.body.appendChild(this.el);
    this.el.className = `ar-drawer ar-drawer--${opts.side ?? "left"}${opts.class ? " " + opts.class : ""}`;
    this.el.style.display = "none";
    const backdrop = this._el("div", "ar-drawer__backdrop", this.el);
    this._panel = this._el("div", "ar-drawer__panel", this.el);
    const side = opts.side ?? "left";
    if (side === "left" || side === "right") this._panel.style.width = (opts.width ?? 280) + "px";
    else this._panel.style.height = (opts.height ?? 240) + "px";
    backdrop.addEventListener("click", () => {
      if (this._get("closeOnBackdrop", true)) this.close();
    });
  }
  set content(v) {
    this._content = v;
    this._build();
  }
  open() {
    this.el.style.display = "";
    setTimeout(() => this.el.classList.add("ar-drawer--open"), 10);
    this._emit("open", {});
  }
  close() {
    this.el.classList.remove("ar-drawer--open");
    setTimeout(() => {
      this.el.style.display = "none";
      this._emit("close", {});
    }, 250);
  }
  _build() {
    this._panel.innerHTML = "";
    if (typeof this._content === "string") this._panel.innerHTML = this._content;
    else if (this._content) this._panel.appendChild(this._content);
  }
};

// components/layout/Modal.ts
var Modal = class extends Control {
  _title = "";
  _content = "";
  _footer = "";
  _backdrop;
  _dialog;
  constructor(opts = {}) {
    super(null, "div", { size: "md", closeOnBackdrop: true, ...opts });
    document.body.appendChild(this.el);
    this.el.className = `ar-modal${opts.class ? " " + opts.class : ""}`;
    this.el.setAttribute("role", "dialog");
    this.el.setAttribute("aria-modal", "true");
    this.el.style.display = "none";
    this._backdrop = this._el("div", "ar-modal__backdrop", this.el);
    this._dialog = this._el("div", `ar-modal__dialog ar-modal__dialog--${opts.size ?? "md"}`, this.el);
    this._backdrop.addEventListener("click", () => {
      if (this._get("closeOnBackdrop", true)) this.close();
    });
    this._on(document, "keydown", (e) => {
      if (e.key === "Escape" && this.el.style.display !== "none") this.close();
    });
  }
  set title(v) {
    this._title = v;
    this._build();
  }
  set content(v) {
    this._content = v;
    this._build();
  }
  set footer(v) {
    this._footer = v;
    this._build();
  }
  open() {
    this.el.style.display = "";
    document.body.style.overflow = "hidden";
    this._emit("open", {});
  }
  close() {
    this.el.style.display = "none";
    document.body.style.overflow = "";
    this._emit("close", {});
  }
  _build() {
    this._dialog.innerHTML = "";
    const h = this._el("div", "ar-modal__header", this._dialog);
    const t = this._el("div", "ar-modal__title", h);
    t.textContent = this._title;
    const x = this._el("button", "ar-modal__close", h);
    x.textContent = "\u2715";
    x.setAttribute("aria-label", "Close");
    x.addEventListener("click", () => this.close());
    const b = this._el("div", "ar-modal__body", this._dialog);
    if (typeof this._content === "string") b.innerHTML = this._content;
    else if (this._content) b.appendChild(this._content);
    if (this._footer) {
      const f = this._el("div", "ar-modal__footer", this._dialog);
      if (typeof this._footer === "string") f.innerHTML = this._footer;
      else f.appendChild(this._footer);
    }
  }
};

// components/layout/Panel.ts
var Panel = class extends Control {
  _title = "";
  _content = "";
  _toolbar = "";
  _collapsed = false;
  constructor(container = null, opts = {}) {
    super(container, "div", opts);
    this._collapsed = opts.collapsed ?? false;
    this.el.className = `ar-panel${opts.class ? " " + opts.class : ""}`;
  }
  set title(v) {
    this._title = v;
    this._build();
  }
  set content(v) {
    this._content = v;
    this._build();
  }
  set toolbar(v) {
    this._toolbar = v;
    this._build();
  }
  set collapsible(v) {
    this._set("collapsible", v);
  }
  get collapsed() {
    return this._collapsed;
  }
  toggle() {
    this._collapsed = !this._collapsed;
    this._emit("toggle", { collapsed: this._collapsed });
    this._build();
  }
  _build() {
    this.el.innerHTML = "";
    if (this._title || this._toolbar) {
      const h = this._el("div", "ar-panel__header", this.el);
      if (this._title) {
        const t = this._el("span", "ar-panel__title", h);
        t.textContent = this._title;
      }
      if (this._toolbar) {
        const tb = this._el("div", "ar-panel__toolbar", h);
        if (typeof this._toolbar === "string") tb.innerHTML = this._toolbar;
        else tb.appendChild(this._toolbar);
      }
      if (this._get("collapsible", false)) {
        const btn = this._el("button", "ar-panel__toggle", h);
        btn.textContent = this._collapsed ? "\u25B8" : "\u25BE";
        btn.addEventListener("click", () => this.toggle());
      }
    }
    if (!this._collapsed) {
      const b = this._el("div", "ar-panel__body", this.el);
      if (typeof this._content === "string") b.innerHTML = this._content;
      else if (this._content) b.appendChild(this._content);
    }
  }
};

// components/layout/Splitter.ts
var Splitter = class extends Control {
  _paneA = null;
  _paneB = null;
  _ratio = 0.5;
  constructor(container = null, opts = {}) {
    super(container, "div", { direction: "horizontal", ratio: 0.5, minA: 60, minB: 60, ...opts });
    this._ratio = opts.ratio ?? 0.5;
    this.el.className = `ar-splitter ar-splitter--${opts.direction ?? "horizontal"}${opts.class ? " " + opts.class : ""}`;
  }
  set paneA(el) {
    this._paneA = el;
    this._build();
  }
  set paneB(el) {
    this._paneB = el;
    this._build();
  }
  set ratio(v) {
    this._ratio = Math.max(0.05, Math.min(0.95, v));
    this._build();
  }
  get ratio() {
    return this._ratio;
  }
  _build() {
    this.el.innerHTML = "";
    const isH = this._get("direction", "horizontal") === "horizontal";
    const paneA = this._el("div", "ar-splitter__pane ar-splitter__pane-a", this.el);
    const handle = this._el("div", "ar-splitter__handle", this.el);
    const paneB = this._el("div", "ar-splitter__pane ar-splitter__pane-b", this.el);
    if (this._paneA) paneA.appendChild(this._paneA);
    if (this._paneB) paneB.appendChild(this._paneB);
    const apply = () => {
      const r = this._ratio * 100;
      if (isH) {
        paneA.style.width = r + "%";
        paneB.style.width = 100 - r + "%";
      } else {
        paneA.style.height = r + "%";
        paneB.style.height = 100 - r + "%";
      }
    };
    apply();
    this._on(handle, "mousedown", (e) => {
      e.preventDefault();
      const rect = this.el.getBoundingClientRect();
      const minA = this._get("minA", 60);
      const minB = this._get("minB", 60);
      const move = (e2) => {
        const total = isH ? rect.width : rect.height;
        const offset = isH ? e2.clientX - rect.left : e2.clientY - rect.top;
        this._ratio = Math.max(minA / total, Math.min(1 - minB / total, offset / total));
        apply();
        this._emit("resize", { ratio: this._ratio });
      };
      const up = () => {
        document.removeEventListener("mousemove", move);
        document.removeEventListener("mouseup", up);
      };
      document.addEventListener("mousemove", move);
      document.addEventListener("mouseup", up);
    });
  }
};

// components/layout/Table.ts
var LRUCache2 = class {
  _map = /* @__PURE__ */ new Map();
  _cap;
  constructor(capacity) {
    this._cap = capacity;
  }
  get(key) {
    if (!this._map.has(key)) return void 0;
    const v = this._map.get(key);
    this._map.delete(key);
    this._map.set(key, v);
    return v;
  }
  set(key, value) {
    if (this._map.has(key)) this._map.delete(key);
    else if (this._map.size >= this._cap) this._map.delete(this._map.keys().next().value);
    this._map.set(key, value);
  }
  clear() {
    this._map.clear();
  }
};
var WORKER_SRC2 = `
self.onmessage = function(e) {
  const { rows, sort, filter, columnFilters, columns } = e.data;
  let result = rows.slice();

  // Global filter
  if (filter) {
    const q = filter.toLowerCase();
    result = result.filter(row =>
      Object.values(row).some(v => String(v ?? '').toLowerCase().includes(q))
    );
  }

  // Column filters
  if (columnFilters) {
    Object.entries(columnFilters).forEach(([key, val]) => {
      if (!val) return;
      const q = val.toLowerCase();
      result = result.filter(row => String(row[key] ?? '').toLowerCase().includes(q));
    });
  }

  // Sort
  if (sort && sort.key) {
    const dir = sort.dir === 'asc' ? 1 : -1;
    result.sort((a: R, b: R) => {
      const av = a[sort.key] ?? '';
      const bv = b[sort.key] ?? '';
      if (av < bv) return -dir;
      if (av > bv) return  dir;
      return 0;
    });
  }

  self.postMessage({ rows: result, total: result.length });
};
`;
var Table2 = class extends Control {
  _expandedRows = /* @__PURE__ */ new Set();
  _renderRows() {
    this._renderBody();
  }
  _build() {
    this._renderBody();
  }
  /** Full client-side dataset. */
  _data = [];
  /** Currently visible rows (after sort+filter). */
  _rows = [];
  /** Total row count (for server-side). */
  _total = 0;
  /** Current page (1-indexed). */
  _page = 1;
  /** Current page size. */
  _pageSize;
  /** Current sort state. */
  _sort;
  /** Current global filter. */
  _filter = "";
  /** Current column filters. */
  _colFilters = {};
  /** Selected row indices (by row reference). */
  _selected = /* @__PURE__ */ new Set();
  /** Loading state. */
  _loading = false;
  /** Web Worker instance. */
  _worker;
  /** Pending worker resolve. */
  _workerResolve;
  /** LRU page cache. */
  _cache;
  /** Column resize state. */
  _resizeCol;
  /** DOM refs. */
  _dom = {};
  // ── Constructor ─────────────────────────────────────────────────────────────
  constructor(container = null, options) {
    super(container, "div", {
      paging: { pageSize: 25, sizes: [10, 25, 50, 100] },
      selectable: "none",
      checkboxes: false,
      worker: false,
      cache: false,
      cacheSize: 20,
      searchable: true,
      columnFilters: false,
      columnToggle: false,
      resizable: false,
      stickyHeader: true,
      info: true,
      exportCsv: false,
      emptyText: "No data",
      loadingText: "Loading\u2026",
      ...options
    });
    this.el.className = `arianna-table-wrap${options.class ? " " + options.class : ""}`;
    const paging = this.get("paging");
    this._pageSize = paging ? paging.pageSize ?? 25 : Infinity;
    this._page = paging ? paging.page ?? 1 : 1;
    if (this.get("worker") && !this.get("fetch")) {
      const blob = new Blob([WORKER_SRC2], { type: "text/javascript" });
      const url = URL.createObjectURL(blob);
      this._worker = new Worker(url);
      this._worker.onmessage = (e) => {
        if (this._workerResolve) {
          this._workerResolve(e.data.rows);
          this._total = e.data.total;
          this._workerResolve = void 0;
        }
      };
      this._onDestroy(() => {
        this._worker?.terminate();
        URL.revokeObjectURL(url);
      });
    }
    if (this.get("cache") && this.get("fetch")) {
      this._cache = new LRUCache2(this.get("cacheSize") ?? 20);
    }
  }
  // ── Data ────────────────────────────────────────────────────────────────────
  /**
   * Load client-side data.
   * Triggers a re-render if mounted.
   *
   * @example
   *   table.load(myRows);
   */
  load(data) {
    this._data = data;
    this._total = data.length;
    this._page = 1;
    if (this._mounted) this._process().then(() => this._renderBody());
    return this;
  }
  /**
   * Append rows to client-side data.
   */
  append(rows) {
    this._data.push(...rows);
    this._total = this._data.length;
    if (this._mounted) this._process().then(() => this._renderBody());
    return this;
  }
  /**
   * Clear all data.
   */
  clear() {
    this._data = [];
    this._rows = [];
    this._total = 0;
    this._page = 1;
    if (this._mounted) this._renderBody();
    return this;
  }
  /**
   * Reload data — re-triggers fetch (server-side) or re-processes (client-side).
   */
  reload() {
    this._page = 1;
    if (this._mounted) this._load();
    return this;
  }
  /**
   * Invalidate the cache and reload.
   */
  invalidateCache() {
    this._cache?.clear();
    return this.reload();
  }
  // ── Selection ────────────────────────────────────────────────────────────────
  /**
   * Get all selected rows.
   */
  getSelected() {
    return [...this._selected];
  }
  /**
   * Clear selection.
   */
  clearSelection() {
    this._selected.clear();
    this._dom.tbody?.querySelectorAll("tr.selected").forEach((r) => r.classList.remove("selected"));
    return this;
  }
  // ── Export ───────────────────────────────────────────────────────────────────
  /**
   * Export current view to CSV and trigger download.
   */
  exportToCsv(filename = "export.csv") {
    const cols = this.get("columns") ?? [].filter((c) => c.visible !== false);
    const header = cols.map((c) => JSON.stringify(c.label)).join(",");
    const rowLines = this._rows.map(
      (row) => cols.map((c) => {
        const v = c.value ? c.value(row) : row[c.key];
        return JSON.stringify(String(v ?? ""));
      }).join(",")
    );
    const csv = [header, ...rowLines].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  // ── Render ───────────────────────────────────────────────────────────────────
  _render() {
    this.el.innerHTML = "";
    const opts = this._state.State;
    this._dom.toolbar = this._el("div", "arianna-wip-table__toolbar", this.el);
    this._buildToolbar();
    const tableWrap = this._el("div", "arianna-wip-table__scroll", this.el);
    this._dom.table = document.createElement("table");
    this._dom.table.className = "arianna-wip-table";
    this._dom.table.setAttribute("role", "grid");
    tableWrap.appendChild(this._dom.table);
    this._dom.thead = this._dom.table.createTHead();
    this._dom.tbody = this._dom.table.createTBody();
    this._buildHeader();
    this._dom.empty = this._el("div", "arianna-wip-table__empty", this.el);
    this._dom.empty.textContent = opts.emptyText ?? "No data";
    this._dom.empty.style.display = "none";
    this._dom.spinner = this._el("div", "arianna-wip-table__spinner", this.el);
    this._dom.spinner.textContent = opts.loadingText ?? "Loading\u2026";
    this._dom.spinner.style.display = "none";
    this._dom.footer = this._el("div", "arianna-wip-table__footer", this.el);
    this._dom.info = this._el("span", "arianna-wip-table__info", this._dom.footer);
    this._dom.pager = this._el("div", "arianna-wip-table__pager", this._dom.footer);
    this._load();
  }
  _buildToolbar() {
    const opts = this._state.State;
    const tb = this._dom.toolbar;
    if (opts.searchable) {
      const input = document.createElement("input");
      input.type = "text";
      input.placeholder = "Search\u2026";
      input.className = "arianna-wip-table__search";
      input.value = this._filter;
      this._listen(input, "input", () => {
        this._filter = input.value;
        this._page = 1;
        this._load();
      });
      tb.appendChild(input);
    }
    if (opts.exportCsv) {
      const btn = document.createElement("button");
      btn.className = "arianna-wip-table__btn";
      btn.textContent = "\u2193 CSV";
      btn.addEventListener("click", () => this.exportToCsv());
      tb.appendChild(btn);
    }
    if (opts.columnToggle) {
      const btn = document.createElement("button");
      btn.className = "arianna-wip-table__btn";
      btn.textContent = "\u229E Columns";
      btn.addEventListener("click", () => this._showColumnToggle(btn));
      tb.appendChild(btn);
    }
  }
  _buildHeader() {
    const opts = this._state.State;
    const tr = this._dom.thead.insertRow();
    tr.setAttribute("role", "row");
    if (opts.checkboxes && opts.selectable === "multi") {
      const th = document.createElement("th");
      th.className = "arianna-wip-table__th arianna-wip-table__th--check";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.addEventListener("change", () => {
        if (cb.checked) this._rows.forEach((r) => this._selected.add(r));
        else this._selected.clear();
        this._renderBody();
      });
      th.appendChild(cb);
      tr.appendChild(th);
    }
    (opts.columns ?? []).filter((c) => c.visible !== false).forEach((col) => {
      const th = document.createElement("th");
      th.className = `arianna-table__th ${col.headerClass ?? ""}`;
      th.setAttribute("role", "columnheader");
      th.setAttribute("aria-sort", "none");
      th.style.width = col.width ? typeof col.width === "number" ? col.width + "px" : col.width : "";
      if (col.align) th.style.textAlign = col.align;
      const inner = this._el("div", "arianna-wip-table__th-inner", th);
      if (col.renderHeader) {
        const h = col.renderHeader(col);
        if (typeof h === "string") inner.innerHTML = h;
        else inner.appendChild(h);
      } else {
        inner.textContent = col.label;
      }
      if (col.sortable) {
        th.classList.add("arianna-wip-table__th--sortable");
        const arrow = this._el("span", "arianna-wip-table__sort-arrow", inner);
        arrow.textContent = this._sort?.key === col.key ? this._sort.dir === "asc" ? "\u2191" : "\u2193" : "\u2195";
        th.addEventListener("click", () => this._toggleSort(col));
      }
      if (opts.resizable && col.resizable !== false) {
        const handle = this._el("div", "arianna-wip-table__resize-handle", th);
        this._listen(handle, "mousedown", (e) => {
          this._resizeCol = {
            col,
            startX: e.clientX,
            startW: th.offsetWidth
          };
        });
      }
      if (opts.columnFilters && col.filterable) {
        const fi = document.createElement("input");
        fi.type = "text";
        fi.placeholder = "\u2026";
        fi.className = "arianna-wip-table__col-filter";
        fi.value = this._colFilters[col.key] ?? "";
        fi.addEventListener("input", () => {
          this._colFilters[col.key] = fi.value;
          this._page = 1;
          this._load();
        });
        fi.addEventListener("click", (e) => e.stopPropagation());
        th.appendChild(fi);
      }
      tr.appendChild(th);
    });
    this._listen(document, "mousemove", (e) => {
      if (!this._resizeCol) return;
      const dx = e.clientX - this._resizeCol.startX;
      const min = this._resizeCol.col.minWidth ?? 60;
      const w = Math.max(min, this._resizeCol.startW + dx);
      const idx = (opts.columns ?? []).findIndex((c) => c.key === this._resizeCol.col.key);
      const th = this._dom.thead.rows[0]?.cells[idx];
      if (th) th.style.width = w + "px";
      this._resizeCol.col.width = w;
    });
    this._listen(document, "mouseup", () => {
      this._resizeCol = void 0;
    });
  }
  _renderBody() {
    const opts = this._state.State;
    const tbody = this._dom.tbody;
    tbody.innerHTML = "";
    if (this._loading) {
      this._dom.spinner.style.display = "";
      this._dom.empty.style.display = "none";
      this._renderFooter();
      return;
    }
    this._dom.spinner.style.display = "none";
    if (!this._rows.length) {
      this._dom.empty.style.display = "";
      this._renderFooter();
      return;
    }
    this._dom.empty.style.display = "none";
    this._rows.forEach((row, ri) => {
      const tr = tbody.insertRow();
      tr.setAttribute("role", "row");
      if (this._selected.has(row)) tr.classList.add("selected");
      if (opts.expandable) {
        const td = tr.insertCell();
        td.className = "ar-table__td ar-table__td--exp";
        const btn = document.createElement("button");
        btn.className = "ar-table__exp-btn";
        const idx2 = ri;
        btn.innerHTML = this._expandedRows.has(idx2) ? "\u25BE" : "\u25B8";
        btn.addEventListener("click", async (e) => {
          e.stopPropagation();
          if (this._expandedRows.has(idx2)) {
            this._expandedRows.delete(idx2);
            this._emit("collapse", { row, index: idx2 });
          } else {
            if (opts.expandSingle) this._expandedRows.clear();
            this._expandedRows.add(idx2);
            this._emit("expand", { row, index: idx2 });
          }
          this._renderRows();
          if (this._expandedRows.has(idx2) && opts.rowContent) {
            const detailRow = tbody.querySelector(`[data-exp-detail="${idx2}"]`);
            if (detailRow) {
              const cell = detailRow.querySelector("td");
              if (cell) {
                cell.innerHTML = '<span style="color:var(--ar-muted);font-size:.8rem">Loading\u2026</span>';
                const content = await opts.rowContent(row);
                if (typeof content === "string") cell.innerHTML = content;
                else {
                  cell.innerHTML = "";
                  cell.appendChild(content);
                }
              }
            }
          }
        });
        td.appendChild(btn);
      }
      tr.addEventListener("click", (e) => {
        const mode = opts.selectable;
        if (mode === "none") {
          opts.onRowClick?.(row, e);
          return;
        }
        if (mode === "single") {
          this._selected.clear();
        }
        if (this._selected.has(row)) this._selected.delete(row);
        else this._selected.add(row);
        this._renderBody();
        this._fire("select", { rows: this.getSelected(), row });
        opts.onRowClick?.(row, e);
      });
      if (opts.checkboxes && opts.selectable === "multi") {
        const td = tr.insertCell();
        td.className = "arianna-wip-table__td arianna-wip-table__td--check";
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = this._selected.has(row);
        cb.addEventListener("change", (e) => {
          e.stopPropagation();
          if (cb.checked) this._selected.add(row);
          else this._selected.delete(row);
          if (cb.checked) tr.classList.add("selected");
          else tr.classList.remove("selected");
          this._fire("select", { rows: this.getSelected(), row });
        });
        td.appendChild(cb);
      }
      (opts.columns ?? []).filter((c) => c.visible !== false).forEach((col) => {
        const td = tr.insertCell();
        td.className = `arianna-table__td ${col.class ?? ""}`;
        td.setAttribute("role", "gridcell");
        if (col.align) td.style.textAlign = col.align;
        const v = col.value ? col.value(row) : row[col.key];
        if (col.render) {
          const r = col.render(v, row, col);
          if (typeof r === "string") td.innerHTML = r;
          else td.appendChild(r);
        } else {
          td.textContent = String(v ?? "");
        }
      });
    });
    this._renderFooter();
  }
  _renderFooter() {
    const opts = this._state.State;
    const paging = opts.paging;
    const info = this._dom.info;
    const pager = this._dom.pager;
    pager.innerHTML = "";
    if (opts.info) {
      if (paging) {
        const start2 = (this._page - 1) * this._pageSize + 1;
        const end2 = Math.min(this._page * this._pageSize, this._total);
        info.textContent = `${start2}\u2013${end2} of ${this._total}`;
      } else {
        info.textContent = `${this._total} rows`;
      }
    }
    if (!paging || this._total <= this._pageSize) return;
    const totalPages = Math.ceil(this._total / this._pageSize);
    if (paging.sizes && paging.sizes.length > 1) {
      const sel = document.createElement("select");
      sel.className = "arianna-wip-table__page-size";
      paging.sizes.forEach((s) => {
        const o = document.createElement("option");
        o.value = String(s);
        o.textContent = `${s} / page`;
        if (s === this._pageSize) o.selected = true;
        sel.appendChild(o);
      });
      sel.addEventListener("change", () => {
        this._pageSize = Number(sel.value);
        this._page = 1;
        this._load();
      });
      pager.appendChild(sel);
    }
    this._pageBtn(pager, "\u2039", this._page > 1, () => {
      this._page--;
      this._load();
    });
    const half = 2;
    const start = Math.max(1, Math.min(this._page - half, totalPages - 4));
    const end = Math.min(totalPages, start + 4);
    for (let p = start; p <= end; p++) {
      this._pageBtn(
        pager,
        String(p),
        true,
        () => {
          this._page = p;
          this._load();
        },
        p === this._page
      );
    }
    this._pageBtn(pager, "\u203A", this._page < totalPages, () => {
      this._page++;
      this._load();
    });
    this._fire("page", { page: this._page, pageSize: this._pageSize, total: this._total });
  }
  _pageBtn(parent, label, enabled, onClick, active = false) {
    const btn = document.createElement("button");
    btn.className = `arianna-table__page-btn${active ? " active" : ""}`;
    btn.textContent = label;
    btn.disabled = !enabled;
    btn.addEventListener("click", onClick);
    parent.appendChild(btn);
  }
  // ── Data processing ──────────────────────────────────────────────────────────
  async _load() {
    const fetchFn = this.get("fetch");
    if (fetchFn) {
      await this._fetchRemote(fetchFn);
    } else {
      await this._processLocal();
    }
    this._renderBody();
  }
  async _fetchRemote(fetchFn) {
    const cacheKey = JSON.stringify({
      page: this._page,
      pageSize: this._pageSize,
      sort: this._sort,
      filter: this._filter,
      colFilters: this._colFilters
    });
    if (this._cache) {
      const cached = this._cache.get(cacheKey);
      if (cached) {
        this._rows = cached.rows;
        this._total = cached.total;
        return;
      }
    }
    this._loading = true;
    this._renderBody();
    try {
      const result = await fetchFn({
        page: this._page,
        pageSize: this._pageSize,
        sort: this._sort,
        filter: this._filter,
        filters: this._colFilters
      });
      this._rows = result.rows;
      this._total = result.total;
      this._cache?.set(cacheKey, result);
      this._fire("load", { rows: this._rows, total: this._total });
    } catch (err) {
      this._fire("error", { error: err });
    } finally {
      this._loading = false;
    }
  }
  async _processLocal() {
    const paging = this.get("paging");
    const opts = this._state.State;
    if (this._worker && this._worker) {
      await this._processWithWorker();
    } else {
      this._processSync();
    }
    if (paging) {
      const start = (this._page - 1) * this._pageSize;
      this._rows = this._rows.slice(start, start + this._pageSize);
    }
    this._fire("load", { rows: this._rows, total: this._total });
  }
  _processSync() {
    const opts = this._state.State;
    let rows = this._data.slice();
    if (this._filter) {
      const q = this._filter.toLowerCase();
      rows = rows.filter(
        (row) => Object.values(row).some((v) => String(v ?? "").toLowerCase().includes(q))
      );
    }
    Object.entries(this._colFilters).forEach(([key, val]) => {
      if (!val) return;
      const q = val.toLowerCase();
      rows = rows.filter((row) => String(row[key] ?? "").toLowerCase().includes(q));
    });
    if (this._sort) {
      const { key, dir } = this._sort;
      const col = (opts.columns ?? []).find((c) => c.key === key);
      const d = dir === "asc" ? 1 : -1;
      rows.sort((a, b) => {
        if (col?.sort) return col.sort(a, b, dir);
        const av = col?.value ? col.value(a) : a[key] ?? "";
        const bv = col?.value ? col.value(b) : b[key] ?? "";
        return av < bv ? -d : av > bv ? d : 0;
      });
    }
    this._total = rows.length;
    this._rows = rows;
  }
  _processWithWorker() {
    return new Promise((resolve) => {
      this._workerResolve = (rows) => {
        this._rows = rows;
        resolve();
      };
      this._worker.postMessage({
        rows: this._data,
        sort: this._sort,
        filter: this._filter,
        columnFilters: this._colFilters,
        columns: this.get("columns") ?? [].map((c) => ({ key: c.key }))
      });
    });
  }
  // ── Sort ─────────────────────────────────────────────────────────────────────
  _toggleSort(col) {
    if (!this._sort || this._sort.key !== col.key) {
      this._sort = { key: col.key, dir: "asc" };
    } else if (this._sort.dir === "asc") {
      this._sort = { key: col.key, dir: "desc" };
    } else {
      this._sort = void 0;
    }
    this._page = 1;
    this._rebuildHeader();
    this._load();
    this._fire("sort", { column: col, sort: this._sort });
  }
  _rebuildHeader() {
    this._dom.thead.innerHTML = "";
    this._buildHeader();
  }
  // ── Column toggle ────────────────────────────────────────────────────────────
  _showColumnToggle(anchor) {
    const existing = document.querySelector(".arianna-wip-table__col-menu");
    if (existing) {
      existing.remove();
      return;
    }
    const menu = document.createElement("div");
    menu.className = "arianna-wip-table__col-menu";
    const rect = anchor.getBoundingClientRect();
    menu.style.position = "fixed";
    menu.style.top = rect.bottom + 4 + "px";
    menu.style.left = rect.left + "px";
    this.get("columns") ?? [].forEach((col) => {
      const row = document.createElement("label");
      row.className = "arianna-wip-table__col-menu-row";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = col.visible !== false;
      cb.addEventListener("change", () => {
        col.visible = cb.checked;
        this._rebuildHeader();
        this._renderBody();
      });
      row.appendChild(cb);
      row.appendChild(document.createTextNode(" " + col.label));
      menu.appendChild(row);
    });
    document.body.appendChild(menu);
    const close = (e) => {
      if (!menu.contains(e.target) && e.target !== anchor) {
        menu.remove();
        document.removeEventListener("click", close);
      }
    };
    setTimeout(() => document.addEventListener("click", close), 10);
  }
  // ── Process ──────────────────────────────────────────────────────────────────
  async _process() {
    return this._processLocal();
  }
};

// components/layout/Tabs.ts
var Tabs = class extends Control {
  _items = [];
  _active = "";
  constructor(container = null, opts = {}) {
    super(container, "div", { variant: "line", ...opts });
    this.el.className = `ar-tabs ar-tabs--${opts.variant ?? "line"}${opts.class ? " " + opts.class : ""}`;
  }
  set items(v) {
    this._items = v;
    if (!this._active && v.length) this._active = v[0].id;
    this._set("items", v);
  }
  set active(id) {
    this._active = id;
    this._build();
  }
  get active() {
    return this._active;
  }
  _build() {
    this.el.innerHTML = "";
    const nav = this._el("div", "ar-tabs__nav", this.el);
    const body = this._el("div", "ar-tabs__body", this.el);
    this._items.forEach((item) => {
      const btn = this._el("button", `ar-tabs__tab${item.id === this._active ? " ar-tabs__tab--active" : ""}${item.disabled ? " ar-tabs__tab--disabled" : ""}`, nav);
      btn.disabled = !!item.disabled;
      if (item.icon) {
        const ic = this._el("span", "ar-tabs__icon", btn);
        ic.textContent = item.icon;
      }
      const l = this._el("span", "", btn);
      l.textContent = item.label;
      if (item.badge !== void 0) {
        const b = this._el("span", "ar-tabs__badge", btn);
        b.textContent = String(item.badge);
      }
      btn.addEventListener("click", () => {
        if (!item.disabled) {
          this._active = item.id;
          this._emit("change", { id: item.id });
          this._build();
        }
      });
      if (item.id === this._active) {
        const pane = this._el("div", "ar-tabs__pane", body);
        if (typeof item.content === "string") pane.innerHTML = item.content;
        else pane.appendChild(item.content);
      }
    });
  }
};

// components/layout/Window.ts
var WIN_Z = 100;
var Window = class extends Control {
  _style;
  _title;
  _menu = [];
  _w;
  _h;
  _x;
  _y;
  _minW;
  _minH;
  _maximized = false;
  _minimized = false;
  _prevRect = null;
  _elTitle;
  _elBody;
  _elMenu;
  constructor(container, opts = {}) {
    super(container, "div", {
      style: "macos",
      title: "Untitled",
      width: 480,
      height: 320,
      minWidth: 200,
      minHeight: 120,
      resizable: true,
      chrome: true,
      focused: true,
      ...opts
    });
    const self = this;
    this._style = self._get("style", "macos");
    this._title = self._get("title", "Untitled");
    this._menu = (opts.menu ?? []).map((m) => ({ ...m, items: m.items ? [...m.items] : void 0 }));
    this._w = self._get("width", 480);
    this._h = self._get("height", 320);
    this._minW = self._get("minWidth", 200);
    this._minH = self._get("minHeight", 120);
    this._x = opts.x ?? -1;
    this._y = opts.y ?? -1;
    this._injectStyles();
    this._build();
    this._applyRect();
    if (opts.body) this.setBody(opts.body);
    if (self._get("focused", true)) this.focus();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  setTitle(t) {
    this._title = t;
    if (this._elTitle) this._elTitle.textContent = t;
    return this;
  }
  setBody(content) {
    if (!this._elBody) return this;
    this._elBody.innerHTML = "";
    if (typeof content === "string") this._elBody.innerHTML = content;
    else this._elBody.appendChild(content);
    return this;
  }
  setMenu(items) {
    this._menu = items.map((m) => ({ ...m, items: m.items ? [...m.items] : void 0 }));
    this._renderMenu();
    return this;
  }
  setStyle(s) {
    this._style = s;
    this._build();
    this._applyRect();
    return this;
  }
  getStyle() {
    return this._style;
  }
  moveTo(x, y) {
    this._x = x;
    this._y = y;
    this._applyRect();
    this._emit("move", { x, y });
    return this;
  }
  resizeTo(w, h) {
    this._w = Math.max(this._minW, w);
    this._h = Math.max(this._minH, h);
    this._applyRect();
    this._emit("resize", { w: this._w, h: this._h });
    return this;
  }
  focus() {
    WIN_Z += 1;
    this.el.style.zIndex = String(WIN_Z);
    this.el.classList.add("ar-window--focused");
    const self = this;
    const parent = self.el.parentElement;
    if (parent) {
      parent.querySelectorAll(".ar-window--focused").forEach((w) => {
        if (w !== self.el) w.classList.remove("ar-window--focused");
      });
    }
    this._emit("focus", {});
    return this;
  }
  minimize() {
    if (this._minimized) return this;
    this._minimized = true;
    this.el.classList.add("ar-window--minimized");
    this._emit("minimize", {});
    return this;
  }
  maximize() {
    if (this._maximized) return this;
    this._prevRect = { x: this._x, y: this._y, w: this._w, h: this._h };
    this._maximized = true;
    const self = this;
    self.el.classList.add("ar-window--maximized");
    const parent = self.el.parentElement;
    if (parent) {
      const r = parent.getBoundingClientRect();
      this._x = 0;
      this._y = 0;
      this._w = r.width;
      this._h = r.height;
      this._applyRect();
    }
    this._emit("maximize", {});
    return this;
  }
  restore() {
    const self = this;
    self.el.classList.remove("ar-window--minimized", "ar-window--maximized");
    this._minimized = false;
    this._maximized = false;
    if (this._prevRect) {
      ({ x: this._x, y: this._y, w: this._w, h: this._h } = this._prevRect);
      this._prevRect = null;
      this._applyRect();
    }
    this._emit("restore", {});
    return this;
  }
  close() {
    this._emit("close", {});
    const self = this;
    self.el.parentElement?.removeChild(self.el);
    return this;
  }
  // ── Build ──────────────────────────────────────────────────────────────
  _build() {
    const self = this;
    const showChrome = self._get("chrome", true);
    const resizable = self._get("resizable", true);
    const cls = self._get("class", "");
    self.el.className = `ar-window ar-window--${this._style}${cls ? " " + cls : ""}`;
    self.el.tabIndex = 0;
    const trafficLights = this._style === "macos" ? `<div class="ar-window__lights">
                 <button class="ar-window__light ar-window__light--close"    data-r="close"    aria-label="Close"></button>
                 <button class="ar-window__light ar-window__light--minimize" data-r="minimize" aria-label="Minimize"></button>
                 <button class="ar-window__light ar-window__light--maximize" data-r="maximize" aria-label="Maximize"></button>
               </div>` : "";
    const winButtons = this._style === "windows" ? `<div class="ar-window__btns">
                 <button class="ar-window__btn" data-r="minimize" aria-label="Minimize">\u2212</button>
                 <button class="ar-window__btn" data-r="maximize" aria-label="Maximize">\u25A2</button>
                 <button class="ar-window__btn ar-window__btn--close" data-r="close" aria-label="Close">\xD7</button>
               </div>` : "";
    self.el.innerHTML = `
<header class="ar-window__chrome" data-r="chrome">
  ${trafficLights}
  <div class="ar-window__title" data-r="title">${escapeAttr(this._title)}</div>
  ${winButtons}
</header>
<nav class="ar-window__menu" data-r="menu" hidden></nav>
<section class="ar-window__body" data-r="body"></section>
${resizable ? `
<div class="ar-window__edge ar-window__edge--n"  data-r="resize" data-edge="n"  aria-label="Resize north"></div>
<div class="ar-window__edge ar-window__edge--s"  data-r="resize" data-edge="s"  aria-label="Resize south"></div>
<div class="ar-window__edge ar-window__edge--w"  data-r="resize" data-edge="w"  aria-label="Resize west"></div>
<div class="ar-window__edge ar-window__edge--e"  data-r="resize" data-edge="e"  aria-label="Resize east"></div>
<div class="ar-window__edge ar-window__edge--nw" data-r="resize" data-edge="nw" aria-label="Resize north-west"></div>
<div class="ar-window__edge ar-window__edge--ne" data-r="resize" data-edge="ne" aria-label="Resize north-east"></div>
<div class="ar-window__edge ar-window__edge--sw" data-r="resize" data-edge="sw" aria-label="Resize south-west"></div>
<div class="ar-window__edge ar-window__edge--se" data-r="resize" data-edge="se" aria-label="Resize south-east"></div>` : ""}`;
    this._elTitle = self.el.querySelector('[data-r="title"]');
    this._elBody = self.el.querySelector('[data-r="body"]');
    this._elMenu = self.el.querySelector('[data-r="menu"]');
    if (showChrome) {
      self.el.querySelector('[data-r="close"]')?.addEventListener("click", (e) => {
        e.stopPropagation();
        this.close();
      });
      self.el.querySelector('[data-r="minimize"]')?.addEventListener("click", (e) => {
        e.stopPropagation();
        this.minimize();
      });
      self.el.querySelector('[data-r="maximize"]')?.addEventListener("click", (e) => {
        e.stopPropagation();
        if (this._maximized) this.restore();
        else this.maximize();
      });
    }
    const chrome = self.el.querySelector('[data-r="chrome"]');
    this._wireDrag(chrome);
    if (resizable) {
      self.el.querySelectorAll('[data-r="resize"]').forEach((h) => this._wireResize(h));
    }
    self.el.addEventListener("pointerdown", () => this.focus());
    this._renderMenu();
  }
  _renderMenu() {
    if (!this._elMenu) return;
    if (this._menu.length === 0) {
      this._elMenu.hidden = true;
      return;
    }
    this._elMenu.hidden = false;
    this._elMenu.innerHTML = "";
    for (const item of this._menu) {
      const btn = document.createElement("button");
      btn.className = "ar-window__menu-item";
      btn.textContent = item.label;
      btn.dataset.id = item.id;
      btn.addEventListener("click", () => {
        this._emit("menu", { id: item.id, label: item.label });
      });
      this._elMenu.appendChild(btn);
    }
  }
  _applyRect() {
    const self = this;
    if (this._x < 0 || this._y < 0) {
      const p = self.el.parentElement?.getBoundingClientRect();
      if (p) {
        this._x = Math.max(0, (p.width - this._w) / 2);
        this._y = Math.max(0, (p.height - this._h) / 2);
      } else {
        this._x = 32;
        this._y = 32;
      }
    }
    self.el.style.left = `${this._x}px`;
    self.el.style.top = `${this._y}px`;
    self.el.style.width = `${this._w}px`;
    self.el.style.height = `${this._h}px`;
  }
  _wireDrag(handle) {
    let sx = 0, sy = 0, ox = 0, oy = 0, dragging = false;
    handle.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      if (this._maximized) return;
      dragging = true;
      sx = e.clientX;
      sy = e.clientY;
      ox = this._x;
      oy = this._y;
      handle.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    handle.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      this._x = ox + (e.clientX - sx);
      this._y = Math.max(0, oy + (e.clientY - sy));
      this._applyRect();
      this._emit("move", { x: this._x, y: this._y });
    });
    const stop = (e) => {
      if (!dragging) return;
      dragging = false;
      try {
        handle.releasePointerCapture(e.pointerId);
      } catch {
      }
    };
    handle.addEventListener("pointerup", stop);
    handle.addEventListener("pointercancel", stop);
  }
  _wireResize(handle) {
    const edge = handle.dataset.edge ?? "se";
    const moveTop = edge.includes("n");
    const moveBottom = edge.includes("s");
    const moveLeft = edge.includes("w");
    const moveRight = edge.includes("e");
    let sx = 0, sy = 0, ow = 0, oh = 0, ox = 0, oy = 0, dragging = false;
    handle.addEventListener("pointerdown", (e) => {
      if (this._maximized) return;
      dragging = true;
      sx = e.clientX;
      sy = e.clientY;
      ow = this._w;
      oh = this._h;
      ox = this._x;
      oy = this._y;
      handle.setPointerCapture(e.pointerId);
      e.preventDefault();
      e.stopPropagation();
    });
    handle.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - sx;
      const dy = e.clientY - sy;
      if (moveRight) {
        this._w = Math.max(this._minW, ow + dx);
      }
      if (moveLeft) {
        const clampedDx = Math.min(dx, ow - this._minW);
        this._w = ow - clampedDx;
        this._x = ox + clampedDx;
      }
      if (moveBottom) {
        this._h = Math.max(this._minH, oh + dy);
      }
      if (moveTop) {
        let clampedDy = Math.min(dy, oh - this._minH);
        if (oy + clampedDy < 0) clampedDy = -oy;
        this._h = oh - clampedDy;
        this._y = oy + clampedDy;
      }
      this._applyRect();
      this._emit("resize", { w: this._w, h: this._h });
      if (moveLeft || moveTop) {
        this._emit("move", { x: this._x, y: this._y });
      }
    });
    const stop = (e) => {
      if (!dragging) return;
      dragging = false;
      try {
        handle.releasePointerCapture(e.pointerId);
      } catch {
      }
    };
    handle.addEventListener("pointerup", stop);
    handle.addEventListener("pointercancel", stop);
  }
  _injectStyles() {
    if (document.getElementById("ar-window-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-window-styles";
    s.textContent = `
.ar-window {
    position: absolute;
    display: flex; flex-direction: column;
    background: #1e1e1e;
    color: #d4d4d4;
    font: 13px -apple-system, system-ui, sans-serif;
    box-shadow: 0 8px 32px rgba(0,0,0,.55), 0 2px 8px rgba(0,0,0,.4);
    overflow: hidden;
    user-select: none;
}
.ar-window:not(.ar-window--focused) { opacity: 0.92; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
.ar-window__chrome {
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 12px;
    height: 30px; flex-shrink: 0;
    background: #2a2a2c;
    border-bottom: 1px solid #1a1a1a;
    cursor: grab;
    position: relative;
}
.ar-window__chrome:active { cursor: grabbing; }
.ar-window__title {
    flex: 1;
    text-align: center;
    font: 600 12px sans-serif;
    color: #d4d4d4;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    pointer-events: none;
}
.ar-window__menu {
    display: flex; align-items: center; gap: 14px;
    height: 26px; padding: 0 12px;
    background: #1f1f21;
    border-bottom: 1px solid #1a1a1a;
    font: 11px sans-serif;
}
.ar-window__menu-item {
    background: none; border: 0; color: #d4d4d4;
    padding: 2px 6px;
    cursor: pointer;
    border-radius: 3px;
    font: 11px sans-serif;
}
.ar-window__menu-item:hover { background: rgba(255,255,255,.08); }
.ar-window__body {
    flex: 1; min-height: 0;
    overflow: auto;
    background: #1e1e1e;
    user-select: text;
}
.ar-window__edge {
    position: absolute;
    /* Default invisible \u2014 handles are interaction-only hit areas. The corner
     * grips are drawn via the body's border-radius/box-shadow visuals; users
     * locate them by cursor change, not by a visible glyph. */
    background: transparent;
    z-index: 2;
    touch-action: none;
}
/* Edge strips \u2014 6px wide along each side, slightly inset from corners so
 * they don't fight with the 12\xD712 corner handles for pointer capture. */
.ar-window__edge--n { top:    -3px; left:  10px; right: 10px; height: 6px;  cursor: ns-resize; }
.ar-window__edge--s { bottom: -3px; left:  10px; right: 10px; height: 6px;  cursor: ns-resize; }
.ar-window__edge--w { left:   -3px; top:   10px; bottom: 10px; width: 6px;  cursor: ew-resize; }
.ar-window__edge--e { right:  -3px; top:   10px; bottom: 10px; width: 6px;  cursor: ew-resize; }
/* Corner squares \u2014 12\xD712 hit boxes overlapping the edges, so the four
 * corners win the pointer when the user lands within ~6px of each. */
.ar-window__edge--nw { top:    -3px; left:   -3px; width: 14px; height: 14px; cursor: nwse-resize; }
.ar-window__edge--ne { top:    -3px; right:  -3px; width: 14px; height: 14px; cursor: nesw-resize; }
.ar-window__edge--sw { bottom: -3px; left:   -3px; width: 14px; height: 14px; cursor: nesw-resize; }
.ar-window__edge--se { bottom: -3px; right:  -3px; width: 14px; height: 14px; cursor: nwse-resize;
    /* Keep the classic SE corner grip glyph visible \u2014 it's the universal
     * "this can be resized" affordance most users look for. */
    background:
        linear-gradient(135deg, transparent 0%, transparent 40%, #555 41%, #555 50%, transparent 51%, transparent 65%, #555 66%, #555 75%, transparent 76%);
}

/* \u2500\u2500 macOS style \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ar-window--macos {
    border-radius: 10px;
    border: 1px solid rgba(255,255,255,.05);
}
.ar-window--macos .ar-window__chrome {
    background: linear-gradient(180deg, #3a3a3c 0%, #2a2a2c 100%);
    height: 28px;
    border-radius: 10px 10px 0 0;
}
.ar-window--macos .ar-window__lights {
    display: flex; gap: 6px; align-items: center;
    position: relative; z-index: 1;
}
.ar-window__light {
    width: 12px; height: 12px; border-radius: 50%;
    border: 0; cursor: pointer; padding: 0;
    transition: filter .12s;
}
.ar-window__light:hover { filter: brightness(1.15); }
.ar-window__light--close    { background: #ff5f57; }
.ar-window__light--minimize { background: #ffbd2e; }
.ar-window__light--maximize { background: #28c940; }
.ar-window--macos:not(.ar-window--focused) .ar-window__light { background: #555; }

/* \u2500\u2500 Windows style \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ar-window--windows {
    border-radius: 0;
    border: 1px solid #444;
}
.ar-window--windows .ar-window__chrome {
    background: #1f1f23;
    border-bottom: 1px solid #444;
    height: 32px;
    padding-left: 12px;
    padding-right: 0;
}
.ar-window--windows .ar-window__title { text-align: left; }
.ar-window--windows .ar-window__btns {
    display: flex; height: 100%;
}
.ar-window__btn {
    background: none; border: 0; color: #d4d4d4;
    width: 44px; height: 100%;
    cursor: pointer;
    font: 14px sans-serif;
    display: flex; align-items: center; justify-content: center;
    transition: background .12s;
}
.ar-window__btn:hover { background: rgba(255,255,255,.08); }
.ar-window__btn--close:hover { background: #c42b1c; color: #fff; }

/* \u2500\u2500 States \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ar-window--minimized { display: none; }
.ar-window--maximized {
    border-radius: 0;
    box-shadow: none;
}
.ar-window--focused {
    box-shadow: 0 12px 40px rgba(0,0,0,.6), 0 4px 12px rgba(0,0,0,.4);
}

@media (max-width: 600px) {
    .ar-window__chrome { height: 26px; padding: 0 8px; }
    .ar-window__title { font-size: 11px; }
    .ar-window__btn { width: 36px; }
    .ar-window__menu { height: 22px; padding: 0 8px; gap: 10px; }
    .ar-window__menu-item { font-size: 10px; }
}
`;
    document.head.appendChild(s);
  }
};
function escapeAttr(s) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

// components/graphics/colors/ColorPicker.ts
var ColorPicker2 = class extends Control {
  // Canonical state — always store HSL, derive RGB/hex on demand
  _h = 325;
  // hue 0..360
  _s = 90;
  // saturation 0..100
  _l = 47;
  // lightness 0..100
  _a = 1;
  // alpha 0..1
  // DOM refs
  _elSv;
  _elSvDot;
  _elHue;
  _elHueDot;
  _elHex;
  _elR;
  _elG;
  _elB;
  _elHi;
  _elSi;
  _elLi;
  _elAlpha;
  _elPreview;
  constructor(container, opts = {}) {
    super(container, "div", {
      color: "#e40c88",
      alpha: false,
      showHex: true,
      showRGB: true,
      showHSL: true,
      ...opts
    });
    this.el.className = `ar-colorpicker${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
    this.setColor(this._get("color", "#e40c88"));
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /**
   * Get the current colour in all four representations + alpha.
   */
  getColor() {
    const rgb = hslToRgb(this._h, this._s, this._l);
    return {
      hex: rgbToHex(rgb.r, rgb.g, rgb.b),
      r: rgb.r,
      g: rgb.g,
      b: rgb.b,
      h: this._h,
      s: this._s,
      l: this._l,
      a: this._a
    };
  }
  /**
   * Set the current colour. Accepts a hex string, an RGB object, an HSL
   * object, or a plain `{ a }` to update only alpha. Missing channels are
   * preserved from the current state.
   */
  setColor(c) {
    if (typeof c === "string") {
      const parsed = parseHex(c);
      if (parsed) {
        const hsl = rgbToHsl(parsed.r, parsed.g, parsed.b);
        this._h = hsl.h;
        this._s = hsl.s;
        this._l = hsl.l;
      }
    } else if (c) {
      if ("r" in c || "g" in c || "b" in c) {
        const cur = hslToRgb(this._h, this._s, this._l);
        const r = Math.max(0, Math.min(255, Math.round(c.r ?? cur.r)));
        const g = Math.max(0, Math.min(255, Math.round(c.g ?? cur.g)));
        const b = Math.max(0, Math.min(255, Math.round(c.b ?? cur.b)));
        const hsl = rgbToHsl(r, g, b);
        this._h = hsl.h;
        this._s = hsl.s;
        this._l = hsl.l;
      } else if ("h" in c || "s" in c || "l" in c) {
        if ("h" in c) this._h = (c.h % 360 + 360) % 360;
        if ("s" in c) this._s = Math.max(0, Math.min(100, c.s));
        if ("l" in c) this._l = Math.max(0, Math.min(100, c.l));
      }
      if ("a" in c && typeof c.a === "number")
        this._a = Math.max(0, Math.min(1, c.a));
    }
    this._refresh();
    this._emitChange();
    return this;
  }
  // ── Internal: build UI ─────────────────────────────────────────────────
  _build() {
    const showHex = this._get("showHex", true);
    const showRGB = this._get("showRGB", true);
    const showHSL = this._get("showHSL", true);
    const alpha = this._get("alpha", false);
    this.el.innerHTML = `
<div class="ar-colorpicker__top">
  <div class="ar-colorpicker__sv"  data-r="sv">
    <div class="ar-colorpicker__sv-dot" data-r="svDot"></div>
  </div>
  <div class="ar-colorpicker__hue" data-r="hue">
    <div class="ar-colorpicker__hue-dot" data-r="hueDot"></div>
  </div>
</div>
<div class="ar-colorpicker__row">
  <div class="ar-colorpicker__preview" data-r="preview"></div>
  ${showHex ? `<input class="ar-colorpicker__inp ar-colorpicker__inp--hex" data-r="hex" type="text" maxlength="9" value="">` : ""}
</div>
${showRGB ? `
<div class="ar-colorpicker__row">
  <label>R</label><input class="ar-colorpicker__inp" data-r="r" type="number" min="0" max="255">
  <label>G</label><input class="ar-colorpicker__inp" data-r="g" type="number" min="0" max="255">
  <label>B</label><input class="ar-colorpicker__inp" data-r="b" type="number" min="0" max="255">
</div>` : ""}
${showHSL ? `
<div class="ar-colorpicker__row">
  <label>H</label><input class="ar-colorpicker__inp" data-r="hi" type="number" min="0" max="360">
  <label>S</label><input class="ar-colorpicker__inp" data-r="si" type="number" min="0" max="100">
  <label>L</label><input class="ar-colorpicker__inp" data-r="li" type="number" min="0" max="100">
</div>` : ""}
${alpha ? `
<div class="ar-colorpicker__row ar-colorpicker__row--alpha">
  <label>A</label><input class="ar-colorpicker__alpha" data-r="alpha" type="range" min="0" max="1" step="0.01" value="1">
</div>` : ""}`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._elSv = r("sv");
    this._elSvDot = r("svDot");
    this._elHue = r("hue");
    this._elHueDot = r("hueDot");
    this._elPreview = r("preview");
    if (showHex) this._elHex = r("hex");
    if (showRGB) {
      this._elR = r("r");
      this._elG = r("g");
      this._elB = r("b");
    }
    if (showHSL) {
      this._elHi = r("hi");
      this._elSi = r("si");
      this._elLi = r("li");
    }
    if (alpha) this._elAlpha = r("alpha");
    this._wireSV();
    this._wireHue();
    this._wireInputs();
  }
  _wireSV() {
    const updateFromEvent = (ev) => {
      const rect = this._elSv.getBoundingClientRect();
      const x = Math.max(0, Math.min(rect.width, ev.clientX - rect.left));
      const y = Math.max(0, Math.min(rect.height, ev.clientY - rect.top));
      this._s = x / rect.width * 100;
      this._l = (1 - y / rect.height) * 100;
      this._refresh();
      this._emitChange();
    };
    this._elSv.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      updateFromEvent(e);
      const move = (ev) => updateFromEvent(ev);
      const up = () => {
        this._elSv.removeEventListener("pointermove", move);
        this._elSv.removeEventListener("pointerup", up);
      };
      this._elSv.addEventListener("pointermove", move);
      this._elSv.addEventListener("pointerup", up);
    });
  }
  _wireHue() {
    const updateFromEvent = (ev) => {
      const rect = this._elHue.getBoundingClientRect();
      const y = Math.max(0, Math.min(rect.height, ev.clientY - rect.top));
      this._h = y / rect.height * 360;
      this._refresh();
      this._emitChange();
    };
    this._elHue.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      updateFromEvent(e);
      const move = (ev) => updateFromEvent(ev);
      const up = () => {
        this._elHue.removeEventListener("pointermove", move);
        this._elHue.removeEventListener("pointerup", up);
      };
      this._elHue.addEventListener("pointermove", move);
      this._elHue.addEventListener("pointerup", up);
    });
  }
  _wireInputs() {
    if (this._elHex) this._elHex.addEventListener("change", () => {
      const v = this._elHex.value.trim();
      if (parseHex(v)) this.setColor(v);
    });
    const onRgb = () => {
      const r = parseInt(this._elR.value, 10) || 0;
      const g = parseInt(this._elG.value, 10) || 0;
      const b = parseInt(this._elB.value, 10) || 0;
      this.setColor({ r, g, b });
    };
    if (this._elR) this._elR.addEventListener("change", onRgb);
    if (this._elG) this._elG.addEventListener("change", onRgb);
    if (this._elB) this._elB.addEventListener("change", onRgb);
    const onHsl = () => {
      const h = parseInt(this._elHi.value, 10) || 0;
      const s = parseInt(this._elSi.value, 10) || 0;
      const l = parseInt(this._elLi.value, 10) || 0;
      this.setColor({ h, s, l });
    };
    if (this._elHi) this._elHi.addEventListener("change", onHsl);
    if (this._elSi) this._elSi.addEventListener("change", onHsl);
    if (this._elLi) this._elLi.addEventListener("change", onHsl);
    if (this._elAlpha) this._elAlpha.addEventListener("input", () => {
      this._a = parseFloat(this._elAlpha.value);
      this._refresh();
      this._emitChange();
    });
  }
  /** Refresh the entire UI to reflect _h/_s/_l/_a state. */
  _refresh() {
    const c = this.getColor();
    this._elSv.style.background = `linear-gradient(to top,    rgba(0,0,0,1),  rgba(0,0,0,0)),
             linear-gradient(to right,  rgba(255,255,255,1), rgba(255,255,255,0)),
             hsl(${this._h}, 100%, 50%)`;
    const px = this._s, py = 100 - this._l;
    this._elSvDot.style.left = px + "%";
    this._elSvDot.style.top = py + "%";
    this._elHueDot.style.top = this._h / 360 * 100 + "%";
    if (this._elHex) this._elHex.value = c.hex;
    if (this._elR) this._elR.value = String(c.r);
    if (this._elG) this._elG.value = String(c.g);
    if (this._elB) this._elB.value = String(c.b);
    if (this._elHi) this._elHi.value = String(Math.round(c.h));
    if (this._elSi) this._elSi.value = String(Math.round(c.s));
    if (this._elLi) this._elLi.value = String(Math.round(c.l));
    const previewBg = this._a < 1 ? `rgba(${c.r},${c.g},${c.b},${this._a})` : c.hex;
    this._elPreview.style.background = previewBg;
  }
  _emitChange() {
    this._emit("change", this.getColor());
  }
  _injectStyles() {
    if (document.getElementById("ar-colorpicker-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-colorpicker-styles";
    s.textContent = `
.ar-colorpicker { display:inline-flex; flex-direction:column; gap:8px; padding:10px; background:#1e1e1e; border:1px solid #333; border-radius:6px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; user-select:none; width:240px; }
.ar-colorpicker__top { display:flex; gap:8px; align-items:stretch; }
.ar-colorpicker__sv  { position:relative; flex:1; height:150px; border-radius:3px; cursor:crosshair; overflow:hidden; }
.ar-colorpicker__sv-dot { position:absolute; width:12px; height:12px; border:2px solid #fff; border-radius:50%; box-shadow:0 0 2px rgba(0,0,0,0.7); transform:translate(-50%, -50%); pointer-events:none; }
.ar-colorpicker__hue { position:relative; width:18px; height:150px; border-radius:3px; cursor:ns-resize; overflow:hidden;
    background:linear-gradient(to bottom, #f00 0%, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%); }
.ar-colorpicker__hue-dot { position:absolute; left:0; right:0; height:2px; background:#fff; box-shadow:0 0 2px rgba(0,0,0,0.7); transform:translateY(-50%); pointer-events:none; }
.ar-colorpicker__row { display:flex; gap:6px; align-items:center; }
.ar-colorpicker__row label { font:10px ui-monospace,monospace; color:#888; min-width:8px; text-align:right; }
.ar-colorpicker__inp { flex:1; min-width:0; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:3px 6px; font:11px ui-monospace,monospace; border-radius:3px; }
.ar-colorpicker__inp--hex { font:12px ui-monospace,monospace; text-align:center; }
.ar-colorpicker__preview { width:24px; height:24px; border:1px solid #333; border-radius:3px; flex-shrink:0;
    background-image:linear-gradient(45deg,#888 25%,transparent 25%),linear-gradient(-45deg,#888 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#888 75%),linear-gradient(-45deg,transparent 75%,#888 75%);
    background-size:8px 8px; background-position:0 0,0 4px,4px -4px,-4px 0px; }
.ar-colorpicker__alpha { flex:1; -webkit-appearance:none; height:14px; border-radius:2px; background:linear-gradient(to right, transparent, #fff); border:1px solid #333; cursor:pointer; }
`;
    document.head.appendChild(s);
  }
};
function parseHex(s) {
  if (!s) return null;
  let h = s.trim().toLowerCase();
  if (h.startsWith("#")) h = h.slice(1);
  if (/^[0-9a-f]{3}$/.test(h)) {
    const r = parseInt(h[0] + h[0], 16);
    const g = parseInt(h[1] + h[1], 16);
    const b = parseInt(h[2] + h[2], 16);
    return { r, g, b, a: 1 };
  }
  if (/^[0-9a-f]{6}$/.test(h)) {
    return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: 1 };
  }
  if (/^[0-9a-f]{8}$/.test(h)) {
    return {
      r: parseInt(h.slice(0, 2), 16),
      g: parseInt(h.slice(2, 4), 16),
      b: parseInt(h.slice(4, 6), 16),
      a: parseInt(h.slice(6, 8), 16) / 255
    };
  }
  return null;
}
function rgbToHex(r, g, b) {
  const c = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
  return "#" + c(r) + c(g) + c(b);
}
function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h *= 60;
  }
  return { h, s: s * 100, l: l * 100 };
}
function hslToRgb(h, s, l) {
  h = (h % 360 + 360) % 360 / 360;
  s = Math.max(0, Math.min(100, s)) / 100;
  l = Math.max(0, Math.min(100, l)) / 100;
  const hue2rgb = (p, q, t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}

// additionals/Colors.ts
var clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
var clamp01 = (n) => clamp(n, 0, 1);
var wrap360 = (n) => (n % 360 + 360) % 360;
function parseHex2(hex) {
  let s = hex.trim().replace(/^#/, "");
  if (s.length === 3) s = s.split("").map((c) => c + c).join("");
  if (s.length !== 6 && s.length !== 8) return null;
  if (!/^[0-9a-fA-F]+$/.test(s)) return null;
  const r = parseInt(s.slice(0, 2), 16);
  const g = parseInt(s.slice(2, 4), 16);
  const b = parseInt(s.slice(4, 6), 16);
  const a = s.length === 8 ? parseInt(s.slice(6, 8), 16) / 255 : 1;
  return { r, g, b, a };
}
function rgbToHex2({ r, g, b, a }) {
  const rr = clamp(Math.round(r), 0, 255).toString(16).padStart(2, "0");
  const gg = clamp(Math.round(g), 0, 255).toString(16).padStart(2, "0");
  const bb = clamp(Math.round(b), 0, 255).toString(16).padStart(2, "0");
  if (a !== void 0 && a < 1) {
    const aa = clamp(Math.round(a * 255), 0, 255).toString(16).padStart(2, "0");
    return `#${rr}${gg}${bb}${aa}`;
  }
  return `#${rr}${gg}${bb}`;
}
function rgbToHsl2({ r, g, b, a }) {
  const R = r / 255, G = g / 255, B = b / 255;
  const max = Math.max(R, G, B), min = Math.min(R, G, B);
  const l = (max + min) / 2;
  let h = 0, s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case R:
        h = (G - B) / d + (G < B ? 6 : 0);
        break;
      case G:
        h = (B - R) / d + 2;
        break;
      case B:
        h = (R - G) / d + 4;
        break;
    }
    h *= 60;
  }
  return { h: wrap360(h), s: s * 100, l: l * 100, a };
}
function hslToRgb2({ h, s, l, a }) {
  const H = wrap360(h) / 360;
  const S = clamp01(s / 100);
  const L = clamp01(l / 100);
  if (S === 0) {
    const v = Math.round(L * 255);
    return { r: v, g: v, b: v, a };
  }
  const q = L < 0.5 ? L * (1 + S) : L + S - L * S;
  const p = 2 * L - q;
  const conv = (t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  return {
    r: Math.round(conv(H + 1 / 3) * 255),
    g: Math.round(conv(H) * 255),
    b: Math.round(conv(H - 1 / 3) * 255),
    a
  };
}
function rgbToHsv({ r, g, b, a }) {
  const R = r / 255, G = g / 255, B = b / 255;
  const max = Math.max(R, G, B), min = Math.min(R, G, B);
  const d = max - min;
  let h = 0;
  const s = max === 0 ? 0 : d / max;
  if (d !== 0) {
    switch (max) {
      case R:
        h = (G - B) / d + (G < B ? 6 : 0);
        break;
      case G:
        h = (B - R) / d + 2;
        break;
      case B:
        h = (R - G) / d + 4;
        break;
    }
    h *= 60;
  }
  return { h: wrap360(h), s: s * 100, v: max * 100, a };
}
function hsvToRgb({ h, s, v, a }) {
  const H = wrap360(h) / 60;
  const S = clamp01(s / 100);
  const V = clamp01(v / 100);
  const i = Math.floor(H);
  const f = H - i;
  const p = V * (1 - S);
  const q = V * (1 - S * f);
  const t = V * (1 - S * (1 - f));
  let R = 0, G = 0, B = 0;
  switch (i % 6) {
    case 0:
      R = V;
      G = t;
      B = p;
      break;
    case 1:
      R = q;
      G = V;
      B = p;
      break;
    case 2:
      R = p;
      G = V;
      B = t;
      break;
    case 3:
      R = p;
      G = q;
      B = V;
      break;
    case 4:
      R = t;
      G = p;
      B = V;
      break;
    case 5:
      R = V;
      G = p;
      B = q;
      break;
  }
  return { r: Math.round(R * 255), g: Math.round(G * 255), b: Math.round(B * 255), a };
}
function rgbToCmyk({ r, g, b, a }) {
  const R = clamp01(r / 255), G = clamp01(g / 255), B = clamp01(b / 255);
  const k = 1 - Math.max(R, G, B);
  if (k >= 1) return { c: 0, m: 0, y: 0, k: 100, a };
  const c = (1 - R - k) / (1 - k);
  const m = (1 - G - k) / (1 - k);
  const y = (1 - B - k) / (1 - k);
  return { c: c * 100, m: m * 100, y: y * 100, k: k * 100, a };
}
function cmykToRgb({ c, m, y, k, a }) {
  const C = clamp01(c / 100), M = clamp01(m / 100), Y = clamp01(y / 100), K = clamp01(k / 100);
  const r = 255 * (1 - C) * (1 - K);
  const g = 255 * (1 - M) * (1 - K);
  const b = 255 * (1 - Y) * (1 - K);
  return { r: Math.round(r), g: Math.round(g), b: Math.round(b), a };
}
var srgbToLinear = (v) => v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
var linearToSrgb = (v) => v <= 31308e-7 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055;
function rgbToXyz({ r, g, b, a }) {
  const R = srgbToLinear(r / 255);
  const G = srgbToLinear(g / 255);
  const B = srgbToLinear(b / 255);
  return {
    X: R * 0.4124564 + G * 0.3575761 + B * 0.1804375,
    Y: R * 0.2126729 + G * 0.7151522 + B * 0.072175,
    Z: R * 0.0193339 + G * 0.119192 + B * 0.9503041,
    a
  };
}
function xyzToRgb({ X, Y, Z, a }) {
  const R = X * 3.2404542 - Y * 1.5371385 - Z * 0.4985314;
  const G = -X * 0.969266 + Y * 1.8760108 + Z * 0.041556;
  const B = X * 0.0556434 - Y * 0.2040259 + Z * 1.0572252;
  return {
    r: Math.round(clamp01(linearToSrgb(R)) * 255),
    g: Math.round(clamp01(linearToSrgb(G)) * 255),
    b: Math.round(clamp01(linearToSrgb(B)) * 255),
    a
  };
}
var D65 = { X: 0.95047, Y: 1, Z: 1.08883 };
var U_REF = 4 * D65.X / (D65.X + 15 * D65.Y + 3 * D65.Z);
var V_REF = 9 * D65.Y / (D65.X + 15 * D65.Y + 3 * D65.Z);
function rgbToCieluv(rgb) {
  const xyz = rgbToXyz(rgb);
  const { X, Y, Z, a } = xyz;
  const denom = X + 15 * Y + 3 * Z;
  const u_ = denom === 0 ? 0 : 4 * X / denom;
  const v_ = denom === 0 ? 0 : 9 * Y / denom;
  const Yr = Y / D65.Y;
  const L = Yr > 8856e-6 ? 116 * Math.cbrt(Yr) - 16 : 903.3 * Yr;
  const u = 13 * L * (u_ - U_REF);
  const v = 13 * L * (v_ - V_REF);
  const C = Math.sqrt(u * u + v * v);
  const h = wrap360(Math.atan2(v, u) * 180 / Math.PI);
  return { L, C, h, a };
}
function cieluvToRgb({ L, C, h, a }) {
  const hr = wrap360(h) * Math.PI / 180;
  const u = C * Math.cos(hr);
  const v = C * Math.sin(hr);
  const Y = L > 8 ? D65.Y * Math.pow((L + 16) / 116, 3) : D65.Y * L / 903.3;
  const u_ = U_REF + u / (13 * L);
  const v_ = V_REF + v / (13 * L);
  const X = L === 0 ? 0 : Y * (9 * u_) / (4 * v_);
  const Z = L === 0 ? 0 : Y * (12 - 3 * u_ - 20 * v_) / (4 * v_);
  return xyzToRgb({ X, Y, Z, a });
}
function rgbToOklch({ r, g, b, a }) {
  const R = srgbToLinear(r / 255);
  const G = srgbToLinear(g / 255);
  const B = srgbToLinear(b / 255);
  const l = 0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B;
  const m = 0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B;
  const s = 0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B;
  const l_ = Math.cbrt(l);
  const m_ = Math.cbrt(m);
  const s_ = Math.cbrt(s);
  const L = 0.2104542553 * l_ + 0.793617785 * m_ - 0.0040720468 * s_;
  const aa = 1.9779984951 * l_ - 2.428592205 * m_ + 0.4505937099 * s_;
  const bb = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.808675766 * s_;
  const C = Math.sqrt(aa * aa + bb * bb);
  const h = wrap360(Math.atan2(bb, aa) * 180 / Math.PI);
  return { L, C, h, a };
}
function oklchToRgb({ L, C, h, a }) {
  const hr = wrap360(h) * Math.PI / 180;
  const aa = C * Math.cos(hr);
  const bb = C * Math.sin(hr);
  const l_ = L + 0.3963377774 * aa + 0.2158037573 * bb;
  const m_ = L - 0.1055613458 * aa - 0.0638541728 * bb;
  const s_ = L - 0.0894841775 * aa - 1.291485548 * bb;
  const l = l_ * l_ * l_;
  const m = m_ * m_ * m_;
  const s = s_ * s_ * s_;
  const R = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
  const G = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
  const B = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s;
  return {
    r: Math.round(clamp01(linearToSrgb(R)) * 255),
    g: Math.round(clamp01(linearToSrgb(G)) * 255),
    b: Math.round(clamp01(linearToSrgb(B)) * 255),
    a
  };
}
function rgbToCube({ r, g, b }) {
  return clamp(Math.round(r), 0, 255) << 16 | clamp(Math.round(g), 0, 255) << 8 | clamp(Math.round(b), 0, 255);
}
function cubeToRgb(i) {
  return {
    r: i >> 16 & 255,
    g: i >> 8 & 255,
    b: i & 255
  };
}
function formatCss(space, color) {
  switch (space) {
    case "rgb": {
      const c = color;
      return c.a !== void 0 && c.a < 1 ? `rgba(${c.r}, ${c.g}, ${c.b}, ${c.a})` : `rgb(${c.r}, ${c.g}, ${c.b})`;
    }
    case "hsl": {
      const c = color;
      return c.a !== void 0 && c.a < 1 ? `hsla(${c.h.toFixed(0)}, ${c.s.toFixed(1)}%, ${c.l.toFixed(1)}%, ${c.a})` : `hsl(${c.h.toFixed(0)}, ${c.s.toFixed(1)}%, ${c.l.toFixed(1)}%)`;
    }
    case "hsv":
      return formatCss("hex", hsvToRgb(color));
    case "cmyk":
      return formatCss("hex", cmykToRgb(color));
    case "cieluv": {
      const c = color;
      return `lch(${c.L.toFixed(1)}% ${c.C.toFixed(1)} ${c.h.toFixed(0)})`;
    }
    case "oklch": {
      const c = color;
      return `oklch(${(c.L * 100).toFixed(1)}% ${c.C.toFixed(3)} ${c.h.toFixed(0)})`;
    }
    case "hex":
      return rgbToHex2(color);
  }
}
var Colors = {
  // HEX
  parseHex: parseHex2,
  rgbToHex: rgbToHex2,
  // HSL ⇄ RGB
  rgbToHsl: rgbToHsl2,
  hslToRgb: hslToRgb2,
  // HSV ⇄ RGB
  rgbToHsv,
  hsvToRgb,
  // CMYK ⇄ RGB
  rgbToCmyk,
  cmykToRgb,
  // CIELUV ⇄ RGB
  rgbToCieluv,
  cieluvToRgb,
  // OKLCH ⇄ RGB
  rgbToOklch,
  oklchToRgb,
  // Cube ⇄ RGB
  rgbToCube,
  cubeToRgb,
  // CSS formatter
  formatCss
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Colors")) {
  try {
    Object.defineProperty(window, "Colors", {
      value: Colors,
      writable: false,
      enumerable: false,
      configurable: false
    });
  } catch {
  }
}

// components/graphics/colors/ColorPickerWheel.ts
var ColorPickerWheel = class extends Control {
  _h = 0;
  _s = 100;
  _v = 100;
  _a = 1;
  _wheel;
  _sv;
  _huePin;
  _svPin;
  _readout;
  constructor(container, opts = {}) {
    super(container, "div", {
      color: "#e40c88",
      alpha: false,
      size: 240,
      readout: true,
      ...opts
    });
    this.el.className = `ar-cpw${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
    this.setColor(this._get("color", "#e40c88"));
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Set the active colour from any hex / RGB-ish input. */
  setColor(hex) {
    const rgb = parseHex2(hex);
    if (!rgb) return this;
    const hsv = rgbToHsv(rgb);
    this._h = hsv.h;
    this._s = hsv.s;
    this._v = hsv.v;
    if (rgb.a !== void 0) this._a = rgb.a;
    this._refresh();
    return this;
  }
  /** Current colour in every supported space. */
  getColor() {
    const rgb = hsvToRgb({ h: this._h, s: this._s, v: this._v, a: this._a });
    return {
      rgb,
      hex: rgbToHex2(rgb),
      hsl: rgbToHsl2(rgb),
      hsv: { h: this._h, s: this._s, v: this._v, a: this._a },
      cmyk: rgbToCmyk(rgb),
      cieluv: rgbToCieluv(rgb),
      oklch: rgbToOklch(rgb),
      cube: rgbToCube(rgb)
    };
  }
  // ── Build / render ─────────────────────────────────────────────────────
  _build() {
    const size = this._get("size", 240);
    this.el.innerHTML = `
<div class="ar-cpw__wheel-wrap" style="width:${size}px;height:${size}px">
  <canvas class="ar-cpw__wheel" data-r="wheel" width="${size}" height="${size}"></canvas>
  <canvas class="ar-cpw__sv"    data-r="sv"    width="${Math.round(size * 0.55)}" height="${Math.round(size * 0.55)}"></canvas>
  <div class="ar-cpw__hue-pin" data-r="hue-pin"></div>
  <div class="ar-cpw__sv-pin"  data-r="sv-pin"></div>
</div>
${this._get("readout", true) ? `<div class="ar-cpw__readout" data-r="readout"></div>` : ""}`;
    this._wheel = this.el.querySelector('[data-r="wheel"]');
    this._sv = this.el.querySelector('[data-r="sv"]');
    this._huePin = this.el.querySelector('[data-r="hue-pin"]');
    this._svPin = this.el.querySelector('[data-r="sv-pin"]');
    this._readout = this.el.querySelector('[data-r="readout"]') ?? void 0;
    this._drawWheel();
    this._wireHue();
    this._wireSv();
  }
  _drawWheel() {
    const ctx = this._wheel.getContext("2d");
    if (!ctx) return;
    const size = this._wheel.width;
    const cx = size / 2, cy = size / 2;
    const ro = size / 2;
    const ri = size / 2 - Math.max(18, size * 0.14);
    const img = ctx.createImageData(size, size);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x - cx, dy = y - cy;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d > ro || d < ri) continue;
        const ang = Math.atan2(dy, dx) * 180 / Math.PI;
        const hue = (ang + 90 + 360) % 360;
        const rgb = hsvToRgb({ h: hue, s: 100, v: 100 });
        const i = (y * size + x) * 4;
        img.data[i] = rgb.r;
        img.data[i + 1] = rgb.g;
        img.data[i + 2] = rgb.b;
        img.data[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    const svSize = this._sv.width;
    const half = svSize / 2;
    this._sv.style.left = `${cx - half}px`;
    this._sv.style.top = `${cy - half}px`;
  }
  _drawSv() {
    const ctx = this._sv.getContext("2d");
    if (!ctx) return;
    const w = this._sv.width, h = this._sv.height;
    const img = ctx.createImageData(w, h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const s = x / (w - 1) * 100;
        const v = (1 - y / (h - 1)) * 100;
        const rgb = hsvToRgb({ h: this._h, s, v });
        const i = (y * w + x) * 4;
        img.data[i] = rgb.r;
        img.data[i + 1] = rgb.g;
        img.data[i + 2] = rgb.b;
        img.data[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  }
  _wireHue() {
    const handle = (e) => {
      const rect = this._wheel.getBoundingClientRect();
      const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
      const ang = Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI;
      this._h = (ang + 90 + 360) % 360;
      this._refresh();
    };
    this._wheel.addEventListener("pointerdown", (e) => {
      this._wheel.setPointerCapture?.(e.pointerId);
      handle(e);
    });
    this._wheel.addEventListener("pointermove", (e) => {
      if (e.buttons) handle(e);
    });
  }
  _wireSv() {
    const handle = (e) => {
      const rect = this._sv.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      this._s = Math.max(0, Math.min(100, x * 100));
      this._v = Math.max(0, Math.min(100, (1 - y) * 100));
      this._refresh();
    };
    this._sv.addEventListener("pointerdown", (e) => {
      this._sv.setPointerCapture?.(e.pointerId);
      handle(e);
    });
    this._sv.addEventListener("pointermove", (e) => {
      if (e.buttons) handle(e);
    });
  }
  _refresh() {
    this._drawSv();
    const size = this._wheel.width;
    const cx = size / 2, cy = size / 2;
    const ringRadius = size / 2 - Math.max(9, size * 0.07);
    const ang = (this._h - 90) * Math.PI / 180;
    const hx = cx + Math.cos(ang) * ringRadius;
    const hy = cy + Math.sin(ang) * ringRadius;
    this._huePin.style.left = `${hx}px`;
    this._huePin.style.top = `${hy}px`;
    const svRect = this._sv.getBoundingClientRect();
    const wheelRect = this._wheel.getBoundingClientRect();
    const offX = svRect.left - wheelRect.left;
    const offY = svRect.top - wheelRect.top;
    const sx = offX + this._s / 100 * this._sv.width;
    const sy = offY + (1 - this._v / 100) * this._sv.height;
    this._svPin.style.left = `${sx}px`;
    this._svPin.style.top = `${sy}px`;
    const rgb = hsvToRgb({ h: this._h, s: this._s, v: this._v });
    this._svPin.style.background = rgbToHex2(rgb);
    if (this._readout) this._renderReadout();
    this._emit("change", this.getColor());
  }
  _renderReadout() {
    if (!this._readout) return;
    const c = this.getColor();
    this._readout.innerHTML = `
<div class="ar-cpw__row"><span>HEX</span><code>${c.hex}</code></div>
<div class="ar-cpw__row"><span>RGB</span><code>${c.rgb.r}, ${c.rgb.g}, ${c.rgb.b}</code></div>
<div class="ar-cpw__row"><span>HSL</span><code>${c.hsl.h.toFixed(0)}\xB0, ${c.hsl.s.toFixed(0)}%, ${c.hsl.l.toFixed(0)}%</code></div>
<div class="ar-cpw__row"><span>HSV</span><code>${c.hsv.h.toFixed(0)}\xB0, ${c.hsv.s.toFixed(0)}%, ${c.hsv.v.toFixed(0)}%</code></div>
<div class="ar-cpw__row"><span>CMYK</span><code>${c.cmyk.c.toFixed(0)}, ${c.cmyk.m.toFixed(0)}, ${c.cmyk.y.toFixed(0)}, ${c.cmyk.k.toFixed(0)}</code></div>
<div class="ar-cpw__row"><span>OKLCH</span><code>${(c.oklch.L * 100).toFixed(1)}% ${c.oklch.C.toFixed(3)} ${c.oklch.h.toFixed(0)}\xB0</code></div>
<div class="ar-cpw__row"><span>CIELUV</span><code>${c.cieluv.L.toFixed(1)} ${c.cieluv.C.toFixed(1)} ${c.cieluv.h.toFixed(0)}\xB0</code></div>
<div class="ar-cpw__row"><span>Cube</span><code>${c.cube}</code></div>`;
  }
  _injectStyles() {
    if (document.getElementById("ar-cpw-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-cpw-styles";
    s.textContent = `
.ar-cpw { display:inline-flex; gap:14px; padding:14px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; }
.ar-cpw__wheel-wrap { position:relative; flex:none; }
.ar-cpw__wheel { display:block; cursor:crosshair; border-radius:50%; }
.ar-cpw__sv    { position:absolute; cursor:crosshair; }
.ar-cpw__hue-pin, .ar-cpw__sv-pin { position:absolute; width:12px; height:12px; margin:-6px 0 0 -6px; border:2px solid #fff; border-radius:50%; pointer-events:none; box-shadow:0 0 0 1px rgba(0,0,0,0.6); }
.ar-cpw__readout { display:flex; flex-direction:column; gap:4px; min-width:220px; }
.ar-cpw__row { display:flex; gap:8px; padding:4px 8px; background:#0d0d0d; border-radius:3px; align-items:center; }
.ar-cpw__row span { width:50px; font:10px sans-serif; color:#888; text-transform:uppercase; }
.ar-cpw__row code { font:11px ui-monospace,monospace; color:#d4d4d4; flex:1; }
`;
    document.head.appendChild(s);
  }
};

// components/graphics/colors/ColorPickerSquare.ts
var ColorPickerSquare = class extends Control {
  _h = 0;
  _s = 100;
  _v = 100;
  _a = 1;
  _sv;
  _hue;
  _alpha;
  _svPin;
  _huePin;
  _alphaPin;
  _readout;
  constructor(container, opts = {}) {
    super(container, "div", { color: "#e40c88", alpha: false, size: 220, ...opts });
    this.el.className = `ar-cps${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
    this.setColor(this._get("color", "#e40c88"));
  }
  setColor(hex) {
    const rgb = parseHex2(hex);
    if (!rgb) return this;
    const hsv = rgbToHsv(rgb);
    this._h = hsv.h;
    this._s = hsv.s;
    this._v = hsv.v;
    if (rgb.a !== void 0) this._a = rgb.a;
    this._refresh();
    return this;
  }
  getColor() {
    const rgb = hsvToRgb({ h: this._h, s: this._s, v: this._v, a: this._a });
    return {
      rgb,
      hex: rgbToHex2(rgb),
      hsl: rgbToHsl2(rgb),
      hsv: { h: this._h, s: this._s, v: this._v, a: this._a },
      cmyk: rgbToCmyk(rgb),
      cieluv: rgbToCieluv(rgb),
      oklch: rgbToOklch(rgb),
      cube: rgbToCube(rgb)
    };
  }
  _build() {
    const size = this._get("size", 220);
    const showAlpha = this._get("alpha", false);
    this.el.innerHTML = `
<div class="ar-cps__main">
  <div class="ar-cps__sv-wrap" style="width:${size}px;height:${size}px">
    <canvas class="ar-cps__sv" data-r="sv" width="${size}" height="${size}"></canvas>
    <div class="ar-cps__sv-pin" data-r="sv-pin"></div>
  </div>
  <div class="ar-cps__strips">
    <div class="ar-cps__hue-wrap" style="height:${size}px">
      <canvas class="ar-cps__hue" data-r="hue" width="18" height="${size}"></canvas>
      <div class="ar-cps__hue-pin" data-r="hue-pin"></div>
    </div>
    ${showAlpha ? `
    <div class="ar-cps__alpha-wrap" style="height:${size}px">
      <canvas class="ar-cps__alpha" data-r="alpha" width="18" height="${size}"></canvas>
      <div class="ar-cps__alpha-pin" data-r="alpha-pin"></div>
    </div>` : ""}
  </div>
</div>
<div class="ar-cps__readout" data-r="readout"></div>`;
    const r = (n) => this.el.querySelector(`[data-r="${n}"]`);
    this._sv = r("sv");
    this._hue = r("hue");
    this._svPin = r("sv-pin");
    this._huePin = r("hue-pin");
    if (showAlpha) {
      this._alpha = r("alpha");
      this._alphaPin = r("alpha-pin");
    }
    this._readout = r("readout");
    this._drawHue();
    this._wireSv();
    this._wireHue();
    if (showAlpha) this._wireAlpha();
  }
  _drawHue() {
    const ctx = this._hue.getContext("2d");
    if (!ctx) return;
    const h = this._hue.height;
    for (let y = 0; y < h; y++) {
      const hue = y / h * 360;
      const rgb = hsvToRgb({ h: hue, s: 100, v: 100 });
      ctx.fillStyle = rgbToHex2(rgb);
      ctx.fillRect(0, y, this._hue.width, 1);
    }
  }
  _drawSv() {
    const ctx = this._sv.getContext("2d");
    if (!ctx) return;
    const w = this._sv.width, h = this._sv.height;
    const img = ctx.createImageData(w, h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const s = x / (w - 1) * 100;
        const v = (1 - y / (h - 1)) * 100;
        const rgb = hsvToRgb({ h: this._h, s, v });
        const i = (y * w + x) * 4;
        img.data[i] = rgb.r;
        img.data[i + 1] = rgb.g;
        img.data[i + 2] = rgb.b;
        img.data[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  }
  _drawAlpha() {
    if (!this._alpha) return;
    const ctx = this._alpha.getContext("2d");
    if (!ctx) return;
    const w = this._alpha.width, h = this._alpha.height;
    const cs = 6;
    for (let y = 0; y < h; y += cs)
      for (let x = 0; x < w; x += cs) {
        ctx.fillStyle = x / cs + y / cs & 1 ? "#444" : "#888";
        ctx.fillRect(x, y, cs, cs);
      }
    const rgb = hsvToRgb({ h: this._h, s: this._s, v: this._v });
    for (let y = 0; y < h; y++) {
      ctx.fillStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},${1 - y / h})`;
      ctx.fillRect(0, y, w, 1);
    }
  }
  _wireSv() {
    const handle = (e) => {
      const rect = this._sv.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      this._s = Math.max(0, Math.min(100, x * 100));
      this._v = Math.max(0, Math.min(100, (1 - y) * 100));
      this._refresh();
    };
    this._sv.addEventListener("pointerdown", (e) => {
      this._sv.setPointerCapture?.(e.pointerId);
      handle(e);
    });
    this._sv.addEventListener("pointermove", (e) => {
      if (e.buttons) handle(e);
    });
  }
  _wireHue() {
    const handle = (e) => {
      const rect = this._hue.getBoundingClientRect();
      const y = (e.clientY - rect.top) / rect.height;
      this._h = Math.max(0, Math.min(360, y * 360));
      this._refresh();
    };
    this._hue.addEventListener("pointerdown", (e) => {
      this._hue.setPointerCapture?.(e.pointerId);
      handle(e);
    });
    this._hue.addEventListener("pointermove", (e) => {
      if (e.buttons) handle(e);
    });
  }
  _wireAlpha() {
    if (!this._alpha) return;
    const handle = (e) => {
      const rect = this._alpha.getBoundingClientRect();
      const y = (e.clientY - rect.top) / rect.height;
      this._a = Math.max(0, Math.min(1, 1 - y));
      this._refresh();
    };
    this._alpha.addEventListener("pointerdown", (e) => {
      this._alpha.setPointerCapture?.(e.pointerId);
      handle(e);
    });
    this._alpha.addEventListener("pointermove", (e) => {
      if (e.buttons) handle(e);
    });
  }
  _refresh() {
    this._drawSv();
    this._drawAlpha();
    const svRect = this._sv.getBoundingClientRect();
    const svParent = this._svPin.parentElement.getBoundingClientRect();
    const sx = svRect.left - svParent.left + this._s / 100 * this._sv.width;
    const sy = svRect.top - svParent.top + (1 - this._v / 100) * this._sv.height;
    this._svPin.style.left = `${sx}px`;
    this._svPin.style.top = `${sy}px`;
    this._svPin.style.background = rgbToHex2(hsvToRgb({ h: this._h, s: this._s, v: this._v }));
    const hy = this._h / 360 * this._hue.height;
    this._huePin.style.top = `${hy}px`;
    if (this._alpha && this._alphaPin) {
      this._alphaPin.style.top = `${(1 - this._a) * this._alpha.height}px`;
    }
    this._renderReadout();
    this._emit("change", this.getColor());
  }
  _renderReadout() {
    const c = this.getColor();
    this._readout.innerHTML = `
<label class="ar-cps__line"><span>HEX</span>   <input data-edit="hex"  value="${c.hex}"></label>
<label class="ar-cps__line"><span>RGB</span>   <input data-edit="rgb"  value="${c.rgb.r}, ${c.rgb.g}, ${c.rgb.b}"></label>
<label class="ar-cps__line"><span>HSL</span>   <input data-edit="hsl"  value="${c.hsl.h.toFixed(0)}, ${c.hsl.s.toFixed(0)}%, ${c.hsl.l.toFixed(0)}%"></label>
<label class="ar-cps__line"><span>HSV</span>   <input data-edit="hsv"  value="${c.hsv.h.toFixed(0)}, ${c.hsv.s.toFixed(0)}%, ${(c.hsv.v ?? 0).toFixed(0)}%"></label>
<label class="ar-cps__line"><span>CMYK</span>  <input data-edit="cmyk" value="${c.cmyk.c.toFixed(0)}, ${c.cmyk.m.toFixed(0)}, ${c.cmyk.y.toFixed(0)}, ${c.cmyk.k.toFixed(0)}"></label>
<label class="ar-cps__line"><span>OKLCH</span> <input data-edit="oklch" value="${(c.oklch.L * 100).toFixed(1)}% ${c.oklch.C.toFixed(3)} ${c.oklch.h.toFixed(0)}"></label>
<label class="ar-cps__line"><span>LUV</span>   <input data-edit="luv"  value="${c.cieluv.L.toFixed(1)} ${c.cieluv.C.toFixed(1)} ${c.cieluv.h.toFixed(0)}"></label>
<label class="ar-cps__line"><span>Cube</span>  <code>${c.cube}</code></label>`;
    this._wireReadout();
  }
  _wireReadout() {
    const inputs = this._readout.querySelectorAll("input[data-edit]");
    inputs.forEach((inp) => {
      inp.addEventListener("change", () => this._handleEdit(inp.dataset.edit, inp.value));
    });
  }
  _handleEdit(field, value) {
    const nums = value.split(/[\s,%]+/).filter(Boolean).map(Number);
    let rgb = null;
    switch (field) {
      case "hex":
        rgb = parseHex2(value);
        break;
      case "rgb":
        if (nums.length >= 3) rgb = { r: nums[0], g: nums[1], b: nums[2] };
        break;
      case "hsl":
        if (nums.length >= 3) rgb = hslToRgb2({ h: nums[0], s: nums[1], l: nums[2] });
        break;
      case "hsv":
        if (nums.length >= 3) rgb = hsvToRgb({ h: nums[0], s: nums[1], v: nums[2] });
        break;
      case "cmyk":
        if (nums.length >= 4) rgb = cmykToRgb({ c: nums[0], m: nums[1], y: nums[2], k: nums[3] });
        break;
      case "oklch":
        if (nums.length >= 3) rgb = oklchToRgb({ L: nums[0] / 100, C: nums[1], h: nums[2] });
        break;
      case "luv":
        if (nums.length >= 3) rgb = cieluvToRgb({ L: nums[0], C: nums[1], h: nums[2] });
        break;
    }
    if (rgb) {
      const hsv = rgbToHsv(rgb);
      this._h = hsv.h;
      this._s = hsv.s;
      this._v = hsv.v;
      this._refresh();
    }
  }
  _injectStyles() {
    if (document.getElementById("ar-cps-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-cps-styles";
    s.textContent = `
.ar-cps { display:inline-flex; gap:14px; padding:14px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; }
.ar-cps__main { display:flex; gap:10px; }
.ar-cps__sv-wrap, .ar-cps__hue-wrap, .ar-cps__alpha-wrap { position:relative; }
.ar-cps__sv, .ar-cps__hue, .ar-cps__alpha { display:block; cursor:crosshair; border-radius:3px; }
.ar-cps__sv-pin   { position:absolute; width:12px; height:12px; margin:-6px 0 0 -6px; border:2px solid #fff; border-radius:50%; pointer-events:none; box-shadow:0 0 0 1px rgba(0,0,0,0.6); }
.ar-cps__hue-pin, .ar-cps__alpha-pin { position:absolute; left:0; right:0; height:3px; margin-top:-1px; background:#fff; pointer-events:none; box-shadow:0 0 0 1px rgba(0,0,0,0.6); }
.ar-cps__strips { display:flex; gap:6px; }
.ar-cps__readout { display:flex; flex-direction:column; gap:3px; min-width:240px; }
.ar-cps__line { display:flex; gap:6px; align-items:center; }
.ar-cps__line span { width:50px; font:10px sans-serif; color:#888; text-transform:uppercase; }
.ar-cps__line input { flex:1; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:4px 6px; font:11px ui-monospace,monospace; border-radius:2px; }
.ar-cps__line input:focus { outline:none; border-color:#e40c88; }
.ar-cps__line code { flex:1; font:11px ui-monospace,monospace; color:#888; padding:4px 6px; }
`;
    document.head.appendChild(s);
  }
};

// components/graphics/colors/ColorPickerTile.ts
var PALETTES = {
  "tailwind": [
    "#ef4444",
    "#f97316",
    "#eab308",
    "#22c55e",
    "#06b6d4",
    "#3b82f6",
    "#8b5cf6",
    "#ec4899",
    "#dc2626",
    "#ea580c",
    "#ca8a04",
    "#16a34a",
    "#0891b2",
    "#2563eb",
    "#7c3aed",
    "#db2777",
    "#991b1b",
    "#9a3412",
    "#854d0e",
    "#15803d",
    "#0e7490",
    "#1d4ed8",
    "#6d28d9",
    "#9d174d",
    "#1e1e1e",
    "#374151",
    "#6b7280",
    "#9ca3af",
    "#d1d5db",
    "#e5e7eb",
    "#f3f4f6",
    "#ffffff"
  ],
  "material": [
    "#f44336",
    "#e91e63",
    "#9c27b0",
    "#673ab7",
    "#3f51b5",
    "#2196f3",
    "#03a9f4",
    "#00bcd4",
    "#009688",
    "#4caf50",
    "#8bc34a",
    "#cddc39",
    "#ffeb3b",
    "#ffc107",
    "#ff9800",
    "#ff5722",
    "#795548",
    "#9e9e9e",
    "#607d8b",
    "#000000",
    "#ffffff",
    "#212121",
    "#424242",
    "#757575"
  ],
  "pastel": [
    "#ffd1dc",
    "#ffb3c1",
    "#ffd6e0",
    "#ffe5d9",
    "#fef3c7",
    "#d9f99d",
    "#bbf7d0",
    "#a7f3d0",
    "#bae6fd",
    "#bfdbfe",
    "#c7d2fe",
    "#ddd6fe",
    "#e9d5ff",
    "#f5d0fe",
    "#fce7f3",
    "#fbcfe8"
  ],
  "web-safe": [
    "#000000",
    "#000033",
    "#000066",
    "#000099",
    "#0000cc",
    "#0000ff",
    "#003300",
    "#003333",
    "#003366",
    "#003399",
    "#0033cc",
    "#0033ff",
    "#006600",
    "#006633",
    "#006666",
    "#006699",
    "#0066cc",
    "#0066ff",
    "#009900",
    "#009933",
    "#009966",
    "#009999",
    "#0099cc",
    "#0099ff",
    "#00cc00",
    "#00cc33",
    "#00cc66",
    "#00cc99",
    "#00cccc",
    "#00ccff",
    "#00ff00",
    "#00ff33",
    "#00ff66",
    "#00ff99",
    "#00ffcc",
    "#00ffff"
  ],
  "mac-os-classic": [
    "#000000",
    "#404040",
    "#808080",
    "#bfbfbf",
    "#ffffff",
    "#7f0000",
    "#ff0000",
    "#7f7f00",
    "#ffff00",
    "#007f00",
    "#00ff00",
    "#007f7f",
    "#00ffff",
    "#00007f",
    "#0000ff",
    "#7f007f",
    "#ff00ff",
    "#ff7f00",
    "#7f3f00",
    "#ffbf7f",
    "#7f7f3f"
  ]
};
var ColorPickerTile = class extends Control {
  _selected = "#000000";
  _recent = [];
  _elGrid;
  _elRecent;
  _elInput;
  constructor(container, opts = {}) {
    super(container, "div", {
      palette: "tailwind",
      showRecent: true,
      recentMax: 12,
      showInput: true,
      columns: 8,
      tileSize: 28,
      ...opts
    });
    this.el.className = `ar-cpt${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
    const init = this._get("color", "");
    if (init) this.setColor(init);
  }
  // ── Public API ─────────────────────────────────────────────────────────
  /** Set the selected colour and add to recents. */
  setColor(hex) {
    const rgb = parseHex2(hex);
    if (!rgb) return this;
    this._selected = rgbToHex2(rgb);
    this._addRecent(this._selected);
    this._refreshSelection();
    if (this._elInput) this._elInput.value = this._selected;
    this._emit("change", this.getColor());
    return this;
  }
  /** Currently-selected colour in every supported space. */
  getColor() {
    const rgb = parseHex2(this._selected) || { r: 0, g: 0, b: 0 };
    return {
      rgb,
      hex: this._selected,
      hsl: rgbToHsl2(rgb),
      hsv: rgbToHsv(rgb),
      cmyk: rgbToCmyk(rgb),
      cieluv: rgbToCieluv(rgb),
      oklch: rgbToOklch(rgb),
      cube: rgbToCube(rgb)
    };
  }
  /** Recent-colours history (newest first). */
  getRecent() {
    return this._recent.slice();
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    const showRecent = this._get("showRecent", true);
    const showInput = this._get("showInput", true);
    this.el.innerHTML = `
<div class="ar-cpt__grid" data-r="grid"></div>
${showRecent ? `<div class="ar-cpt__sep">Recent</div><div class="ar-cpt__recent" data-r="recent"></div>` : ""}
${showInput ? `<div class="ar-cpt__input-row">
  <input class="ar-cpt__inp" data-r="inp" type="text" placeholder="#rrggbb">
  <input class="ar-cpt__cpc" data-r="cpc" type="color">
</div>` : ""}`;
    this._elGrid = this.el.querySelector('[data-r="grid"]');
    this._elRecent = this.el.querySelector('[data-r="recent"]') ?? void 0;
    this._elInput = this.el.querySelector('[data-r="inp"]') ?? void 0;
    const cpc = this.el.querySelector('[data-r="cpc"]');
    this._renderGrid();
    if (this._elInput) {
      this._elInput.addEventListener("change", () => this.setColor(this._elInput.value));
    }
    if (cpc) {
      cpc.addEventListener("input", () => this.setColor(cpc.value));
    }
  }
  _renderGrid() {
    const palette = this._resolvePalette();
    const cols = this._get("columns", 8);
    const size = this._get("tileSize", 28);
    this._elGrid.style.gridTemplateColumns = `repeat(${cols}, ${size}px)`;
    this._elGrid.innerHTML = "";
    for (const hex of palette) {
      const tile = document.createElement("button");
      tile.type = "button";
      tile.className = "ar-cpt__tile" + (hex.toLowerCase() === this._selected.toLowerCase() ? " ar-cpt__tile--sel" : "");
      tile.style.background = hex;
      tile.style.width = `${size}px`;
      tile.style.height = `${size}px`;
      tile.title = hex;
      tile.dataset.color = hex;
      tile.addEventListener("click", () => this.setColor(hex));
      this._elGrid.appendChild(tile);
    }
  }
  _resolvePalette() {
    const p = this._get("palette", "tailwind");
    if (Array.isArray(p)) return p;
    return PALETTES[p] || PALETTES["tailwind"];
  }
  _addRecent(hex) {
    const max = this._get("recentMax", 12);
    const idx = this._recent.indexOf(hex);
    if (idx >= 0) this._recent.splice(idx, 1);
    this._recent.unshift(hex);
    if (this._recent.length > max) this._recent.length = max;
    this._renderRecent();
  }
  _renderRecent() {
    if (!this._elRecent) return;
    const size = this._get("tileSize", 28);
    this._elRecent.innerHTML = this._recent.map(
      (c) => `<button type="button" class="ar-cpt__tile" style="background:${c};width:${size}px;height:${size}px" data-color="${c}" title="${c}"></button>`
    ).join("");
    this._elRecent.querySelectorAll("[data-color]").forEach((btn) => {
      btn.addEventListener("click", () => this.setColor(btn.dataset.color));
    });
  }
  _refreshSelection() {
    const sel = this._selected.toLowerCase();
    this._elGrid.querySelectorAll(".ar-cpt__tile").forEach((t) => {
      t.classList.toggle("ar-cpt__tile--sel", t.dataset.color?.toLowerCase() === sel);
    });
  }
  _injectStyles() {
    if (document.getElementById("ar-cpt-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-cpt-styles";
    s.textContent = `
.ar-cpt { display:inline-flex; flex-direction:column; gap:8px; padding:12px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; }
.ar-cpt__grid, .ar-cpt__recent { display:grid; gap:3px; }
.ar-cpt__recent { grid-template-columns:repeat(auto-fill, 28px); }
.ar-cpt__sep { font:600 10px sans-serif; color:#888; letter-spacing:.06em; text-transform:uppercase; padding-top:4px; }
.ar-cpt__tile { border:1px solid #444; border-radius:3px; cursor:pointer; padding:0; transition:transform .08s; }
.ar-cpt__tile:hover { transform:scale(1.12); border-color:#fff; z-index:1; }
.ar-cpt__tile--sel { border-color:#e40c88; box-shadow:0 0 0 2px rgba(228,12,136,0.4); }
.ar-cpt__input-row { display:flex; gap:6px; align-items:center; }
.ar-cpt__inp { flex:1; background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:5px 8px; font:12px ui-monospace,monospace; border-radius:3px; }
.ar-cpt__inp:focus { outline:none; border-color:#e40c88; }
.ar-cpt__cpc { width:32px; height:28px; border:1px solid #333; border-radius:3px; padding:0; background:transparent; cursor:pointer; }
`;
    document.head.appendChild(s);
  }
};

// components/graphics/colors/GradientEditor.ts
var GradientEditorBase = class _GradientEditorBase extends Control {
  _stops;
  _selected = 0;
  _elStrip;
  _elPins;
  _elInspector;
  constructor(container, tag, opts) {
    super(container, tag, opts);
    this._stops = (opts.stops ?? _GradientEditorBase.defaultStops()).slice();
    this._sortStops();
  }
  /** Default 2-stop black→white gradient. */
  static defaultStops() {
    return [
      { t: 0, color: { r: 0, g: 0, b: 0, a: 1 } },
      { t: 1, color: { r: 255, g: 255, b: 255, a: 1 } }
    ];
  }
  // ── Public API: stops ──────────────────────────────────────────────────
  getStops() {
    return this._stops.map((s) => ({ ...s, color: { ...s.color } }));
  }
  setStops(stops) {
    this._stops = stops.map((s) => ({ ...s, color: { ...s.color } }));
    this._sortStops();
    if (this._selected >= this._stops.length) this._selected = 0;
    this._render();
    this._emit("change", { stops: this.getStops() });
    return this;
  }
  addStop(t, color) {
    const rgb = typeof color === "string" ? parseHex2(color) ?? { r: 0, g: 0, b: 0, a: 1 } : color;
    const stop = { t: clamp012(t), color: { ...rgb, a: rgb.a ?? 1 } };
    this._stops.push(stop);
    this._sortStops();
    this._selected = this._stops.indexOf(stop);
    this._render();
    this._emit("change", { stops: this.getStops() });
    return stop;
  }
  removeStop(index) {
    if (this._stops.length <= 2) return this;
    if (index < 0 || index >= this._stops.length) return this;
    this._stops.splice(index, 1);
    if (this._selected >= this._stops.length) this._selected = this._stops.length - 1;
    this._render();
    this._emit("change", { stops: this.getStops() });
    return this;
  }
  updateStop(index, patch) {
    const s = this._stops[index];
    if (!s) return this;
    if (patch.t !== void 0) s.t = clamp012(patch.t);
    if (patch.color !== void 0) s.color = { ...patch.color };
    if (patch.midpoint !== void 0) s.midpoint = clamp012(patch.midpoint);
    this._sortStops();
    this._render();
    this._emit("change", { stops: this.getStops() });
    return this;
  }
  select(index) {
    this._selected = Math.max(0, Math.min(this._stops.length - 1, index));
    this._render();
    return this;
  }
  getSelected() {
    return this._selected;
  }
  // ── Shared utilities ────────────────────────────────────────────────────
  _sortStops() {
    this._stops.sort((a, b) => a.t - b.t);
  }
  /** Build a CSS colour-stops list e.g. `red 0%, blue 100%`. */
  _stopsToCss() {
    return this._stops.map((s) => {
      const c = s.color;
      const css = c.a !== void 0 && c.a < 1 ? `rgba(${Math.round(c.r)}, ${Math.round(c.g)}, ${Math.round(c.b)}, ${c.a.toFixed(3)})` : rgbToHex2(c);
      return `${css} ${(s.t * 100).toFixed(2)}%`;
    }).join(", ");
  }
  /** Common stop-strip DOM (used inside subclasses). */
  _renderStripDom(host, css) {
    host.innerHTML = `
<div class="ar-grad__strip" data-r="strip" style="background:${css}"></div>
<div class="ar-grad__pins"  data-r="pins"></div>`;
    this._elStrip = host.querySelector('[data-r="strip"]');
    this._elPins = host.querySelector('[data-r="pins"]');
    this._wireStrip();
    this._renderPins();
  }
  _wireStrip() {
    this._elStrip.addEventListener("click", (e) => {
      const rect = this._elStrip.getBoundingClientRect();
      const t = (e.clientX - rect.left) / rect.width;
      const c = this._sampleAt(t);
      this.addStop(t, c);
    });
  }
  _renderPins() {
    this._elPins.innerHTML = "";
    for (let i = 0; i < this._stops.length; i++) {
      const s = this._stops[i];
      const pin = document.createElement("div");
      pin.className = "ar-grad__pin" + (i === this._selected ? " ar-grad__pin--sel" : "");
      pin.style.left = `${s.t * 100}%`;
      pin.style.background = rgbToHex2(s.color);
      pin.title = `Stop ${i + 1} \xB7 ${rgbToHex2(s.color)} @ ${(s.t * 100).toFixed(1)}%`;
      pin.addEventListener("pointerdown", (e) => {
        e.stopPropagation();
        this.select(i);
        pin.setPointerCapture?.(e.pointerId);
        const move = (ev) => {
          const rect = this._elStrip.getBoundingClientRect();
          const t = clamp012((ev.clientX - rect.left) / rect.width);
          this.updateStop(i, { t });
        };
        const up = () => {
          pin.removeEventListener("pointermove", move);
          pin.removeEventListener("pointerup", up);
        };
        pin.addEventListener("pointermove", move);
        pin.addEventListener("pointerup", up);
      });
      pin.addEventListener("dblclick", (e) => {
        e.stopPropagation();
        this.removeStop(i);
      });
      this._elPins.appendChild(pin);
    }
  }
  /** Sample the gradient at parameter t — used when adding new stops. */
  _sampleAt(t) {
    if (!this._stops.length) return { r: 0, g: 0, b: 0, a: 1 };
    if (t <= this._stops[0].t) return { ...this._stops[0].color };
    if (t >= this._stops[this._stops.length - 1].t) return { ...this._stops[this._stops.length - 1].color };
    for (let i = 0; i < this._stops.length - 1; i++) {
      const a = this._stops[i], b = this._stops[i + 1];
      if (t >= a.t && t <= b.t) {
        const f = (t - a.t) / (b.t - a.t || 1);
        return {
          r: Math.round(a.color.r + (b.color.r - a.color.r) * f),
          g: Math.round(a.color.g + (b.color.g - a.color.g) * f),
          b: Math.round(a.color.b + (b.color.b - a.color.b) * f),
          a: (a.color.a ?? 1) + ((b.color.a ?? 1) - (a.color.a ?? 1)) * f
        };
      }
    }
    return { ...this._stops[0].color };
  }
  /** Inspector for the selected stop — colour + t input + alpha. */
  _renderInspector(host) {
    const s = this._stops[this._selected];
    if (!s) {
      host.innerHTML = "";
      return;
    }
    const css = rgbToHex2(s.color);
    host.innerHTML = `
<label class="ar-grad__field"><span>Color</span>
  <input data-r="ins-col" type="color" value="${css}">
  <input data-r="ins-hex" type="text"  value="${css}">
</label>
<label class="ar-grad__field"><span>Position</span>
  <input data-r="ins-t" type="number" min="0" max="100" step="0.1" value="${(s.t * 100).toFixed(1)}">%
</label>
<label class="ar-grad__field"><span>Alpha</span>
  <input data-r="ins-a" type="number" min="0" max="1"   step="0.01" value="${(s.color.a ?? 1).toFixed(2)}">
</label>
<div class="ar-grad__btns">
  <button data-r="ins-del" class="ar-grad__btn ar-grad__btn--danger" type="button">Remove stop</button>
</div>`;
    const r = (n) => host.querySelector(`[data-r="${n}"]`);
    const idx = this._selected;
    const colInp = r("ins-col");
    const hexInp = r("ins-hex");
    const tInp = r("ins-t");
    const aInp = r("ins-a");
    const delBtn = host.querySelector('[data-r="ins-del"]');
    colInp.addEventListener("input", () => {
      const c = parseHex2(colInp.value);
      if (c) this.updateStop(idx, { color: { ...c, a: parseFloat(aInp.value) } });
    });
    hexInp.addEventListener("change", () => {
      const c = parseHex2(hexInp.value);
      if (c) this.updateStop(idx, { color: { ...c, a: parseFloat(aInp.value) } });
    });
    tInp.addEventListener("change", () => this.updateStop(idx, { t: parseFloat(tInp.value) / 100 }));
    aInp.addEventListener("change", () => {
      const cur = this._stops[idx];
      if (cur) this.updateStop(idx, { color: { ...cur.color, a: parseFloat(aInp.value) } });
    });
    delBtn.addEventListener("click", () => this.removeStop(idx));
  }
  _injectGradientStyles() {
    if (document.getElementById("ar-grad-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-grad-styles";
    s.textContent = `
.ar-grad { display:flex; flex-direction:column; gap:10px; padding:12px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; }
.ar-grad__strip { position:relative; height:30px; border-radius:3px; cursor:copy; box-shadow:inset 0 0 0 1px #333; background-image:linear-gradient(45deg, #444 25%, transparent 25%), linear-gradient(-45deg, #444 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #444 75%), linear-gradient(-45deg, transparent 75%, #444 75%); background-size:8px 8px; background-position:0 0, 0 4px, 4px -4px, -4px 0px; }
.ar-grad__pins  { position:relative; height:14px; }
.ar-grad__pin   { position:absolute; top:0; width:12px; height:14px; transform:translateX(-50%); border:2px solid #fff; border-radius:2px; box-shadow:0 0 0 1px rgba(0,0,0,0.6); cursor:grab; }
.ar-grad__pin--sel { border-color:#e40c88; transform:translateX(-50%) scale(1.15); }
.ar-grad__field { display:flex; gap:8px; align-items:center; }
.ar-grad__field span { width:70px; font:10px sans-serif; color:#888; text-transform:uppercase; }
.ar-grad__field input[type="text"], .ar-grad__field input[type="number"] { background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:4px 6px; font:11px ui-monospace,monospace; border-radius:2px; flex:1; min-width:0; }
.ar-grad__field input[type="color"] { width:30px; height:24px; border:1px solid #333; padding:0; background:transparent; cursor:pointer; }
.ar-grad__field input:focus { outline:none; border-color:#e40c88; }
.ar-grad__btns { margin-top:6px; }
.ar-grad__btn  { background:transparent; border:1px solid #444; color:#d4d4d4; padding:5px 10px; font:11px sans-serif; border-radius:3px; cursor:pointer; }
.ar-grad__btn:hover { background:#2a2a2a; }
.ar-grad__btn--danger:hover { background:#dc2626; border-color:#dc2626; color:#fff; }
.ar-grad__preview { width:100%; height:60px; border-radius:4px; box-shadow:inset 0 0 0 1px #333; }
.ar-grad__row { display:flex; gap:14px; align-items:flex-start; }
.ar-grad__col { flex:1; min-width:0; }
.ar-grad__inspector { width:240px; flex-shrink:0; display:flex; flex-direction:column; gap:6px; }
`;
    document.head.appendChild(s);
  }
};
var clamp012 = (n) => Math.max(0, Math.min(1, n));

// components/graphics/colors/LinearGradientEditor.ts
var LinearGradientEditor = class extends GradientEditorBase {
  _angle;
  _interp;
  _elPreview;
  _elInspectorHost;
  constructor(container, opts = {}) {
    super(container, "div", { angle: 90, interp: "srgb", alpha: true, ...opts });
    this._angle = this._get("angle", 90);
    this._interp = this._get("interp", "srgb");
    this.el.className = `ar-grad ar-grad--linear${opts.class ? " " + opts.class : ""}`;
    this._injectGradientStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  setAngle(deg) {
    this._angle = (deg % 360 + 360) % 360;
    this._render();
    this._emit("change", { stops: this.getStops(), angle: this._angle });
    return this;
  }
  getAngle() {
    return this._angle;
  }
  setInterp(space) {
    this._interp = space;
    this._render();
    this._emit("change", { stops: this.getStops(), interp: this._interp });
    return this;
  }
  getInterp() {
    return this._interp;
  }
  /** Render the gradient as a CSS `linear-gradient(...)` string. */
  toCSS() {
    const stops = this._stopsToCss();
    const space = this._interp === "srgb" ? "" : ` in ${this._interp}`;
    return `linear-gradient(${this._angle}deg${space}, ${stops})`;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    this.el.innerHTML = `
<div class="ar-grad__row">
  <div class="ar-grad__col">
    <div data-r="strip-host"></div>
    <div class="ar-grad__field" style="margin-top:10px">
      <span>Angle</span>
      <input data-r="angle"  type="number" min="0" max="360" step="1" value="${this._angle}">\xB0
      <span style="margin-left:10px">Space</span>
      <select data-r="interp">
        <option value="srgb"  ${this._interp === "srgb" ? "selected" : ""}>sRGB</option>
        <option value="oklab" ${this._interp === "oklab" ? "selected" : ""}>OKLab</option>
        <option value="oklch" ${this._interp === "oklch" ? "selected" : ""}>OKLCH</option>
        <option value="hsl"   ${this._interp === "hsl" ? "selected" : ""}>HSL</option>
      </select>
    </div>
    <div class="ar-grad__preview" data-r="preview" style="margin-top:10px"></div>
  </div>
  <div class="ar-grad__inspector" data-r="inspector"></div>
</div>`;
    const stripHost = this.el.querySelector('[data-r="strip-host"]');
    this._elInspectorHost = this.el.querySelector('[data-r="inspector"]');
    this._elPreview = this.el.querySelector('[data-r="preview"]');
    this._renderStripDom(stripHost, `linear-gradient(to right, ${this._stopsToCss()})`);
    const angleInp = this.el.querySelector('[data-r="angle"]');
    angleInp.addEventListener("change", () => this.setAngle(parseFloat(angleInp.value) || 0));
    const interpSel = this.el.querySelector('[data-r="interp"]');
    interpSel.addEventListener("change", () => this.setInterp(interpSel.value));
    this._render();
  }
  _render() {
    if (this._elStrip) this._elStrip.style.background = `linear-gradient(to right, ${this._stopsToCss()})`;
    if (this._elPins) {
      this._elPins.innerHTML = "";
      const stripHost = this.el.querySelector('[data-r="strip-host"]');
      if (stripHost) this._renderStripDom(stripHost, `linear-gradient(to right, ${this._stopsToCss()})`);
    }
    if (this._elPreview) this._elPreview.style.background = this.toCSS();
    if (this._elInspectorHost) this._renderInspector(this._elInspectorHost);
  }
};

// components/graphics/colors/RadialGradientEditor.ts
var RadialGradientEditor = class extends GradientEditorBase {
  _shape;
  _size;
  _cx;
  _cy;
  _interp;
  _elPreview;
  _elInspectorHost;
  constructor(container, opts = {}) {
    super(container, "div", {
      shape: "circle",
      size: "farthest-corner",
      cx: 50,
      cy: 50,
      interp: "srgb",
      ...opts
    });
    this._shape = this._get("shape", "circle");
    this._size = this._get("size", "farthest-corner");
    this._cx = this._get("cx", 50);
    this._cy = this._get("cy", 50);
    this._interp = this._get("interp", "srgb");
    this.el.className = `ar-grad ar-grad--radial${opts.class ? " " + opts.class : ""}`;
    this._injectGradientStyles();
    this._build();
  }
  // ── Public API ─────────────────────────────────────────────────────────
  setShape(shape) {
    this._shape = shape;
    this._render();
    this._fireChange();
    return this;
  }
  setSize(size) {
    this._size = size;
    this._render();
    this._fireChange();
    return this;
  }
  setCenter(cx, cy) {
    this._cx = Math.max(0, Math.min(100, cx));
    this._cy = Math.max(0, Math.min(100, cy));
    this._render();
    this._fireChange();
    return this;
  }
  getCenter() {
    return { cx: this._cx, cy: this._cy };
  }
  getShape() {
    return this._shape;
  }
  getSize() {
    return this._size;
  }
  toCSS() {
    const stops = this._stopsToCss();
    const space = this._interp === "srgb" ? "" : ` in ${this._interp}`;
    return `radial-gradient(${this._shape} ${this._size} at ${this._cx}% ${this._cy}%${space}, ${stops})`;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _fireChange() {
    this._emit("change", {
      stops: this.getStops(),
      shape: this._shape,
      size: this._size,
      cx: this._cx,
      cy: this._cy,
      interp: this._interp
    });
  }
  _build() {
    this.el.innerHTML = `
<div class="ar-grad__row">
  <div class="ar-grad__col">
    <div data-r="strip-host"></div>
    <div class="ar-grad__field" style="margin-top:10px">
      <span>Shape</span>
      <select data-r="shape">
        <option value="circle"  ${this._shape === "circle" ? "selected" : ""}>Circle</option>
        <option value="ellipse" ${this._shape === "ellipse" ? "selected" : ""}>Ellipse</option>
      </select>
      <span style="margin-left:10px">Size</span>
      <select data-r="size">
        <option value="closest-side"     ${this._size === "closest-side" ? "selected" : ""}>Closest side</option>
        <option value="farthest-side"    ${this._size === "farthest-side" ? "selected" : ""}>Farthest side</option>
        <option value="closest-corner"   ${this._size === "closest-corner" ? "selected" : ""}>Closest corner</option>
        <option value="farthest-corner"  ${this._size === "farthest-corner" ? "selected" : ""}>Farthest corner</option>
      </select>
    </div>
    <div class="ar-grad__field">
      <span>Center</span>
      <input data-r="cx" type="number" min="0" max="100" step="1" value="${this._cx}">%
      <input data-r="cy" type="number" min="0" max="100" step="1" value="${this._cy}">%
      <span style="margin-left:10px">Space</span>
      <select data-r="interp">
        <option value="srgb"  ${this._interp === "srgb" ? "selected" : ""}>sRGB</option>
        <option value="oklab" ${this._interp === "oklab" ? "selected" : ""}>OKLab</option>
        <option value="oklch" ${this._interp === "oklch" ? "selected" : ""}>OKLCH</option>
      </select>
    </div>
    <div class="ar-grad__preview" data-r="preview" style="margin-top:10px;cursor:crosshair;position:relative;height:160px"></div>
  </div>
  <div class="ar-grad__inspector" data-r="inspector"></div>
</div>`;
    const stripHost = this.el.querySelector('[data-r="strip-host"]');
    this._elInspectorHost = this.el.querySelector('[data-r="inspector"]');
    this._elPreview = this.el.querySelector('[data-r="preview"]');
    this._renderStripDom(stripHost, `linear-gradient(to right, ${this._stopsToCss()})`);
    const shapeSel = this.el.querySelector('[data-r="shape"]');
    const sizeSel = this.el.querySelector('[data-r="size"]');
    const cxInp = this.el.querySelector('[data-r="cx"]');
    const cyInp = this.el.querySelector('[data-r="cy"]');
    const interpSel = this.el.querySelector('[data-r="interp"]');
    shapeSel.addEventListener("change", () => this.setShape(shapeSel.value));
    sizeSel.addEventListener("change", () => this.setSize(sizeSel.value));
    cxInp.addEventListener("change", () => this.setCenter(parseFloat(cxInp.value), this._cy));
    cyInp.addEventListener("change", () => this.setCenter(this._cx, parseFloat(cyInp.value)));
    interpSel.addEventListener("change", () => {
      this._interp = interpSel.value;
      this._render();
      this._fireChange();
    });
    this._elPreview.addEventListener("pointerdown", (e) => {
      this._elPreview.setPointerCapture?.(e.pointerId);
      const handle = (ev) => {
        const rect = this._elPreview.getBoundingClientRect();
        const cx = (ev.clientX - rect.left) / rect.width * 100;
        const cy = (ev.clientY - rect.top) / rect.height * 100;
        cxInp.value = cx.toFixed(0);
        cyInp.value = cy.toFixed(0);
        this.setCenter(cx, cy);
      };
      handle(e);
      this._elPreview.addEventListener("pointermove", handle);
      this._elPreview.addEventListener("pointerup", () => {
        this._elPreview.removeEventListener("pointermove", handle);
      }, { once: true });
    });
    this._render();
  }
  _render() {
    if (this._elStrip) {
      const stripHost = this.el.querySelector('[data-r="strip-host"]');
      if (stripHost) this._renderStripDom(stripHost, `linear-gradient(to right, ${this._stopsToCss()})`);
    }
    if (this._elPreview) this._elPreview.style.background = this.toCSS();
    if (this._elInspectorHost) this._renderInspector(this._elInspectorHost);
  }
};

// components/graphics/colors/ShapeGradientEditor.ts
var ShapeGradientEditor = class _ShapeGradientEditor extends Control {
  _stops;
  _selected = 0;
  _canvas;
  _overlay;
  _inspector;
  constructor(container, opts = {}) {
    super(container, "div", {
      width: 360,
      height: 240,
      speed: 2,
      stops: _ShapeGradientEditor.defaultStops(),
      ...opts
    });
    this._stops = (this._get("stops", []) || []).slice();
    this.el.className = `ar-grad ar-grad--shape${opts.class ? " " + opts.class : ""}`;
    this._injectStyles();
    this._build();
  }
  /** Default 4-corner gradient. */
  static defaultStops() {
    return [
      { x: 0.15, y: 0.2, color: { r: 228, g: 12, b: 136, a: 1 }, radius: 0.45 },
      { x: 0.85, y: 0.25, color: { r: 59, g: 130, b: 246, a: 1 }, radius: 0.45 },
      { x: 0.2, y: 0.8, color: { r: 34, g: 197, b: 94, a: 1 }, radius: 0.45 },
      { x: 0.8, y: 0.78, color: { r: 250, g: 204, b: 21, a: 1 }, radius: 0.45 }
    ];
  }
  // ── Public API ─────────────────────────────────────────────────────────
  getStops() {
    return this._stops.map((s) => ({ ...s, color: { ...s.color } }));
  }
  setStops(stops) {
    this._stops = stops.map((s) => ({ ...s, color: { ...s.color } }));
    if (this._selected >= this._stops.length) this._selected = 0;
    this._render();
    this._emit("change", { stops: this.getStops() });
    return this;
  }
  addStop(s) {
    this._stops.push({ ...s, color: { ...s.color } });
    this._selected = this._stops.length - 1;
    this._render();
    this._emit("change", { stops: this.getStops() });
    return this._stops[this._selected];
  }
  removeStop(i) {
    if (this._stops.length <= 1) return this;
    if (i < 0 || i >= this._stops.length) return this;
    this._stops.splice(i, 1);
    if (this._selected >= this._stops.length) this._selected = this._stops.length - 1;
    this._render();
    this._emit("change", { stops: this.getStops() });
    return this;
  }
  updateStop(i, patch) {
    const s = this._stops[i];
    if (!s) return this;
    if (patch.x !== void 0) s.x = clamp013(patch.x);
    if (patch.y !== void 0) s.y = clamp013(patch.y);
    if (patch.color !== void 0) s.color = { ...patch.color };
    if (patch.radius !== void 0) s.radius = Math.max(0.01, Math.min(2, patch.radius));
    this._render();
    this._emit("change", { stops: this.getStops() });
    return this;
  }
  select(i) {
    this._selected = i;
    this._render();
    return this;
  }
  /** Approximate SVG output: union of radial-gradient `<radialGradient>`s with multiply blend. */
  toSVG() {
    const w = this._get("width", 360);
    const h = this._get("height", 240);
    const defs = this._stops.map((s, i) => `
<radialGradient id="ar-grad-${i}" cx="${s.x * 100}%" cy="${s.y * 100}%" r="${s.radius * 100}%">
  <stop offset="0%"   stop-color="${rgbToHex2(s.color)}" stop-opacity="${s.color.a ?? 1}"/>
  <stop offset="100%" stop-color="${rgbToHex2(s.color)}" stop-opacity="0"/>
</radialGradient>`).join("");
    const rects = this._stops.map(
      (_, i) => `<rect width="100%" height="100%" fill="url(#ar-grad-${i})" style="mix-blend-mode:lighten"/>`
    ).join("");
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}"><defs>${defs}</defs>${rects}</svg>`;
  }
  // ── Internal ───────────────────────────────────────────────────────────
  _build() {
    const w = this._get("width", 360);
    const h = this._get("height", 240);
    this.el.innerHTML = `
<div class="ar-grad__row">
  <div class="ar-grad__col">
    <div class="ar-shgrad__stage" style="width:${w}px;height:${h}px;position:relative">
      <canvas data-r="canvas" width="${w}" height="${h}" class="ar-shgrad__canvas"></canvas>
      <div class="ar-shgrad__overlay" data-r="overlay"></div>
    </div>
    <div class="ar-shgrad__hint">
      Click empty area to add a stop \xB7 drag stops \xB7 double-click a stop to remove
    </div>
  </div>
  <div class="ar-grad__inspector" data-r="inspector"></div>
</div>`;
    this._canvas = this.el.querySelector('[data-r="canvas"]');
    this._overlay = this.el.querySelector('[data-r="overlay"]');
    this._inspector = this.el.querySelector('[data-r="inspector"]');
    this._wireOverlay();
    this._render();
  }
  _wireOverlay() {
    this._overlay.addEventListener("click", (e) => {
      if (e.target.classList.contains("ar-shgrad__pin")) return;
      const rect = this._overlay.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      const c = this._sample(x, y);
      this.addStop({ x, y, color: c, radius: 0.3 });
    });
  }
  _render() {
    this._renderCanvas();
    this._renderPins();
    this._renderInspector();
  }
  _renderCanvas() {
    const ctx = this._canvas.getContext("2d");
    if (!ctx) return;
    const fullW = this._canvas.width;
    const fullH = this._canvas.height;
    const div = Math.max(1, this._get("speed", 2));
    const w = Math.max(2, Math.floor(fullW / div));
    const h = Math.max(2, Math.floor(fullH / div));
    const img = ctx.createImageData(w, h);
    for (let py = 0; py < h; py++) {
      for (let px = 0; px < w; px++) {
        const c = this._sample(px / (w - 1), py / (h - 1));
        const i = (py * w + px) * 4;
        img.data[i] = c.r;
        img.data[i + 1] = c.g;
        img.data[i + 2] = c.b;
        img.data[i + 3] = Math.round((c.a ?? 1) * 255);
      }
    }
    const tmp = document.createElement("canvas");
    tmp.width = w;
    tmp.height = h;
    tmp.getContext("2d").putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.clearRect(0, 0, fullW, fullH);
    ctx.drawImage(tmp, 0, 0, fullW, fullH);
  }
  /** Inverse-distance-weighted blend of all stops at point (x,y). */
  _sample(x, y) {
    let totalW = 0;
    let r = 0, g = 0, b = 0, a = 0;
    for (const s of this._stops) {
      const dx = x - s.x, dy = y - s.y;
      const d = Math.sqrt(dx * dx + dy * dy);
      const t = Math.min(1, d / s.radius);
      const wgt = (1 - t * t) * (1 - t * t) + 1e-6;
      totalW += wgt;
      r += s.color.r * wgt;
      g += s.color.g * wgt;
      b += s.color.b * wgt;
      a += (s.color.a ?? 1) * wgt;
    }
    if (totalW === 0) return { r: 0, g: 0, b: 0, a: 1 };
    return {
      r: Math.round(r / totalW),
      g: Math.round(g / totalW),
      b: Math.round(b / totalW),
      a: a / totalW
    };
  }
  _renderPins() {
    this._overlay.innerHTML = "";
    for (let i = 0; i < this._stops.length; i++) {
      const s = this._stops[i];
      const pin = document.createElement("div");
      pin.className = "ar-shgrad__pin" + (i === this._selected ? " ar-shgrad__pin--sel" : "");
      pin.style.left = `${s.x * 100}%`;
      pin.style.top = `${s.y * 100}%`;
      pin.style.background = rgbToHex2(s.color);
      pin.title = `Stop ${i + 1}`;
      pin.addEventListener("pointerdown", (e) => {
        e.stopPropagation();
        this.select(i);
        pin.setPointerCapture?.(e.pointerId);
        const move = (ev) => {
          const rect = this._overlay.getBoundingClientRect();
          const x = clamp013((ev.clientX - rect.left) / rect.width);
          const y = clamp013((ev.clientY - rect.top) / rect.height);
          this.updateStop(i, { x, y });
        };
        const up = () => {
          pin.removeEventListener("pointermove", move);
          pin.removeEventListener("pointerup", up);
        };
        pin.addEventListener("pointermove", move);
        pin.addEventListener("pointerup", up);
      });
      pin.addEventListener("dblclick", (e) => {
        e.stopPropagation();
        this.removeStop(i);
      });
      this._overlay.appendChild(pin);
    }
  }
  _renderInspector() {
    const s = this._stops[this._selected];
    if (!s) {
      this._inspector.innerHTML = "";
      return;
    }
    const hex = rgbToHex2(s.color);
    this._inspector.innerHTML = `
<label class="ar-grad__field"><span>Color</span>
  <input data-r="col"  type="color" value="${hex}">
  <input data-r="hex"  type="text"  value="${hex}">
</label>
<label class="ar-grad__field"><span>X</span>
  <input data-r="x"    type="number" min="0" max="100" step="0.1" value="${(s.x * 100).toFixed(1)}">%
</label>
<label class="ar-grad__field"><span>Y</span>
  <input data-r="y"    type="number" min="0" max="100" step="0.1" value="${(s.y * 100).toFixed(1)}">%
</label>
<label class="ar-grad__field"><span>Radius</span>
  <input data-r="rad"  type="number" min="0.05" max="2" step="0.05" value="${s.radius.toFixed(2)}">
</label>
<label class="ar-grad__field"><span>Alpha</span>
  <input data-r="a"    type="number" min="0" max="1" step="0.01" value="${(s.color.a ?? 1).toFixed(2)}">
</label>
<div class="ar-grad__btns">
  <button data-r="del" class="ar-grad__btn ar-grad__btn--danger" type="button">Remove stop</button>
</div>`;
    const idx = this._selected;
    const get = (name) => this._inspector.querySelector(`[data-r="${name}"]`);
    get("col").addEventListener("input", () => {
      const c = parseHex2(get("col").value);
      if (c) this.updateStop(idx, { color: { ...c, a: parseFloat(get("a").value) } });
    });
    get("hex").addEventListener("change", () => {
      const c = parseHex2(get("hex").value);
      if (c) this.updateStop(idx, { color: { ...c, a: parseFloat(get("a").value) } });
    });
    get("x").addEventListener("change", () => this.updateStop(idx, { x: parseFloat(get("x").value) / 100 }));
    get("y").addEventListener("change", () => this.updateStop(idx, { y: parseFloat(get("y").value) / 100 }));
    get("rad").addEventListener("change", () => this.updateStop(idx, { radius: parseFloat(get("rad").value) }));
    get("a").addEventListener("change", () => {
      const cur = this._stops[idx];
      if (!cur) return;
      this.updateStop(idx, { color: { ...cur.color, a: parseFloat(get("a").value) } });
    });
    get("del").addEventListener("click", () => this.removeStop(idx));
  }
  _injectStyles() {
    if (document.getElementById("ar-shgrad-styles")) return;
    const s = document.createElement("style");
    s.id = "ar-shgrad-styles";
    s.textContent = `
.ar-shgrad__stage { border:1px solid #333; border-radius:6px; overflow:hidden; }
.ar-shgrad__canvas { position:absolute; inset:0; }
.ar-shgrad__overlay { position:absolute; inset:0; cursor:copy; }
.ar-shgrad__pin { position:absolute; width:14px; height:14px; margin:-7px 0 0 -7px; border:2px solid #fff; border-radius:50%; cursor:grab; box-shadow:0 0 0 1px rgba(0,0,0,0.6); }
.ar-shgrad__pin--sel { border-color:#e40c88; transform:scale(1.2); }
.ar-shgrad__hint { font:11px sans-serif; color:#888; padding-top:6px; }
`;
    document.head.appendChild(s);
    if (!document.getElementById("ar-grad-styles")) {
      const sb = document.createElement("style");
      sb.id = "ar-grad-styles";
      sb.textContent = `
.ar-grad { display:flex; flex-direction:column; gap:10px; padding:12px; background:#1e1e1e; border:1px solid #333; border-radius:8px; color:#d4d4d4; font:12px -apple-system,system-ui,sans-serif; }
.ar-grad__row { display:flex; gap:14px; align-items:flex-start; }
.ar-grad__col { flex:1; min-width:0; }
.ar-grad__inspector { width:240px; flex-shrink:0; display:flex; flex-direction:column; gap:6px; }
.ar-grad__field { display:flex; gap:8px; align-items:center; }
.ar-grad__field span { width:70px; font:10px sans-serif; color:#888; text-transform:uppercase; }
.ar-grad__field input[type="text"], .ar-grad__field input[type="number"] { background:#0d0d0d; border:1px solid #333; color:#d4d4d4; padding:4px 6px; font:11px ui-monospace,monospace; border-radius:2px; flex:1; min-width:0; }
.ar-grad__field input[type="color"] { width:30px; height:24px; border:1px solid #333; padding:0; background:transparent; cursor:pointer; }
.ar-grad__btn { background:transparent; border:1px solid #444; color:#d4d4d4; padding:5px 10px; font:11px sans-serif; border-radius:3px; cursor:pointer; }
.ar-grad__btn--danger:hover { background:#dc2626; border-color:#dc2626; color:#fff; }
`;
      document.head.appendChild(sb);
    }
  }
};
var clamp013 = (n) => Math.max(0, Math.min(1, n));
export {
  Accordion,
  AlertBadge,
  AliPay,
  AppleMap,
  ApplePay,
  ArrayModifier,
  AudioComponent,
  AudioEditor,
  AudioPlayer,
  AudioTrackEditor,
  Avatar,
  BRTTracker,
  Badge,
  Banner,
  BarChart,
  LineChart as BasicLineChart,
  BendModifier,
  BevelModifier,
  BezierEditor,
  BillboardModifier,
  BingMap,
  Breadcrumb,
  Button,
  Calendar,
  CameraViewer3D,
  CandlestickChart,
  Canvas2D,
  Card,
  ChannelStrip,
  Chat,
  Checkbox,
  Chip2 as Chip,
  ColorPicker2 as ColorPicker,
  ColorPickerSquare,
  ColorPickerTile,
  ColorPickerWheel,
  Control,
  CreditCard,
  DHLTracker,
  DatePicker,
  DecimateModifier,
  DepthChart,
  Chip as DisplayChip,
  Divider,
  Dock,
  DragModifier,
  Drawer,
  Dropdown,
  FadeModifier,
  FedExTracker,
  FileUpload,
  FinanceComponents,
  GoogleMap,
  GooglePay,
  GradientEditorBase,
  Header,
  HeatmapChart,
  Icon,
  InflateModifier,
  ColorPicker as InputColorPicker,
  RichTextEditor as InputRichTextEditor,
  KeyframeEditor,
  LODModifier,
  LayersPanel,
  Table2 as LayoutTable,
  LineChart2 as LineChart,
  LinearGradientEditor,
  LinesPalette2D,
  List,
  MapEmbed,
  Menu,
  MirrorModifier,
  Modal,
  Modifier2D,
  Modifier3D,
  D_default as Modifiers2D,
  D_default2 as Modifiers3D,
  Mover,
  NavRail,
  Nexi,
  NodeEditor,
  OpenStreetMap,
  OrderBook,
  Pagination,
  PaletteMaterials,
  PaletteModifiers3D,
  Panel,
  PayPal,
  PaymentGateway,
  PianoRoll,
  PieChart,
  PnLChart,
  PortfolioDonut,
  ProgressBar,
  ProgressCircular,
  RadialGradientEditor,
  Radio,
  RangeSlider,
  Rating,
  Reflector,
  Resizer,
  RiskGauge,
  Rotator,
  Rounder,
  Satispay,
  Screener,
  SearchBar,
  ShapeGradientEditor,
  Sidebar,
  Skeleton,
  Skewer,
  SmoothModifier,
  Snackbar,
  SnapModifier,
  Sparkline,
  Splitter,
  Stepper,
  Stripe,
  SubdivisionModifier,
  Switch,
  Table,
  Tabs,
  Tag,
  TextField,
  Theme,
  TimePicker,
  ToolsPalette,
  Tooltip,
  Tracker,
  TrackingMulti,
  TransportBar,
  TreeView,
  TwistModifier,
  UPSTracker,
  VideoPlayer,
  VideoTrackEditor,
  WaveModifier,
  Window,
  _cloneGeom,
  _recomputeNormals,
  _resolveTargets,
  _v3,
  _vAdd,
  _vCross,
  _vLen,
  _vLerp,
  _vNorm,
  _vScale,
  _vSub,
  animate,
  audioContext,
  detectBrand,
  easing,
  fadeIn,
  fadeOut,
  formatBars,
  formatCardNumber,
  formatSMPTE,
  formatSampleRate,
  parseTimeSig,
  resumeAudio,
  slideDown,
  slideUp,
  stagger,
  validateLuhn
};
/**
 * @module    Animation
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2024 All Rights Reserved
 * @license   AGPL-3.0 / Commercial
 *
 * Migrated and extended from Golem CSS Animation system (2012-2018).
 *
 * ── Original Golem Animation system ──────────────────────────────────────────
 *
 *   The original was an IIFE (Immediately Invoked Function Expression) that:
 *   - Maintained a requestAnimationFrame loop at 60fps
 *   - Tracked _animationElements (map of elements being animated)
 *   - Maintained _animationFrames (array of frame snapshots)
 *   - Had _animationFrameRate (default 60fps)
 *   - Exposed Start(AnimationEventArguments) / Stop(Id) functions
 *   - Fired 4 callbacks:
 *       onAnimation          — every frame
 *       onAnimationStart     — when animation begins
 *       onAnimationStop      — when animation ends
 *       onAnimationIteration — on each iteration/loop
 *
 *   All of this is preserved in the AnimationLoop class below.
 *
 * ── Extensions (new in AriannA 1.0) ──────────────────────────────────────────
 *
 *   Tween    — value interpolation with 12 easing functions
 *   Spring   — physics-based animation (stiffness/damping/mass)
 *   Timeline — sequence/parallel composition of tweens
 *   Keyframe — CSS keyframe equivalent
 *
 * @example
 *   import { Animation, AnimationLoop, Tween, Spring } from "./Animation.ts";
 *   Core.use(Animation);
 *
 *   // Original Golem API preserved
 *   const loop = new AnimationLoop({ frameRate: 60 });
 *   loop.onAnimation = (frame) => { myEl.style.left = frame.Index + "px"; };
 *   loop.Start();
 *   setTimeout(() => loop.Stop(), 3000);
 *
 *   // New Tween API
 *   new Tween(el.style, {
 *     opacity : [0, 1],
 *     duration: 0.6,
 *     easing  : "easeOutCubic",
 *   });
 *
 *   // Spring
 *   const spring = new Spring(0, 100, { stiffness: 200, damping: 20 }, v => {
 *     el.style.transform = `translateX(${v}px)`;
 *   });
 */
/**
 * @module    components/animations/KeyframeEditor
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026 All Rights Reserved
 * @license   AGPL-3.0 / Commercial
 *
 * KeyframeEditor — 3ds Max / Blender / After Effects style timeline editor
 * for hand-keyed animation. Drives any object that exposes a `set(prop, values)`
 * method (Three.js nodes, DOM properties, audio params, Two.ts shapes, …).
 *
 * ── Layout ───────────────────────────────────────────────────────────────────
 *
 *   ┌─────────────────────────────────────────────────────────────────────────┐
 *   │ Assets Preview │ Console │ Animation                                  ☰ │
 *   │ Clips: anim ▾  ⏮ ⏪ ▶ ⏩ ⏭ ⏹  Time ▾  0-09  Spacing: 1   ☴⚡⚙        │
 *   │ ─────────────────────────────────────────────────────────────────────── │
 *   │ Node list ◉ Enter           0-00          0-05         0-10            │
 *   │ ▸ Cube                  ◆────◆────◆──┃─◆──────◆                       │
 *   │ ▸ Node                                                                  │
 *   │ ─────────────────────────────────────────────────────────────────────── │
 *   │ Property list +  scale.z  [1]                                          │
 *   │ ▸ position              ◆────◆────◆──┃─◆──────                         │
 *   │ ▸ scale                          ◆──┃─◆                                │
 *   │ ─────────────────────────────────────────────────────────────────────── │
 *   │ WrapMode Normal ▾   Sample 60   Speed 0.2   Duration: 0.15 (0.75)s    │
 *   └─────────────────────────────────────────────────────────────────────────┘
 *
 * ── Features (beyond the 3ds Max screenshot) ─────────────────────────────────
 *
 *   • Multi-clip support — switch between named animation clips.
 *   • Per-property channels — every track is a curve, not just a row of dots.
 *   • Easing & interpolation — linear, step, cubic-bezier, all 12 named
 *     curves from additionals/Animation (linear, easeIn/Out/InOut Quad/Cubic/
 *     Quart/Expo, easeOutBack, easeOutBounce, easeOutElastic).
 *   • Drag, copy, paste, delete, snap keyframes; multi-select with shift.
 *   • Time / frame display toggle.
 *   • Wrap modes — normal, loop, ping-pong, clamp-forever.
 *   • Sample (fps) and Speed (playback multiplier) controls.
 *   • Live playhead with cursor scrubbing.
 *   • Per-keyframe right-click context menu (set easing, copy, delete).
 *   • Drives a generic IKeyframeTarget contract — works for any object.
 *
 * ── Marriage with additionals/Physics ────────────────────────────────────────
 *
 *   The Physics additional reads `editor.sample(nodeId, propId, t)` to follow
 *   keyframed motion with a kinematic body, and writes baked simulation
 *   results back into clips via the public `_clips` state. See Physics.ts.
 *
 * @example
 *   import { KeyframeEditor } from 'arianna/components/animations';
 *
 *   const editor = new KeyframeEditor('#mount', {
 *     clips: [{
 *       id: 'anim-1', name: 'animation1', sampleRate: 60, duration: 0.75,
 *       nodes: [{
 *         id: 'cube', label: 'Cube',
 *         properties: [
 *           { id: 'position', label: 'position', channels: ['x','y','z'],
 *             keyframes: [
 *               { time: 0.00, values: [0, 0, 0] },
 *               { time: 0.15, values: [1, 0, 0], easing: 'easeOutCubic' },
 *               { time: 0.30, values: [1, 1, 0] },
 *             ] },
 *         ],
 *       }],
 *     }],
 *     wrapMode: 'loop', speed: 0.5,
 *   });
 *
 *   editor.bind('cube', {
 *     set: (prop, vals) => {
 *       if (prop === 'position') threeCube.position.set(...vals);
 *     },
 *   });
 *   editor.play();
 */
/**
 * @module    components/modifiers/2D/Resizer
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * 8-direction resize handles on any HTML element.
 *
 * Cross-anchor behavior
 * ---------------------
 * The dragged edge follows the pointer freely. When it crosses the
 * opposite (anchor) edge, the rectangle keeps resizing on the other
 * side: width keeps growing, the box appears past the anchor, and
 * the anchor edge stays nailed to its original position.
 *
 * Content is NOT mirrored. The DOM rect simply repositions and resizes.
 * If you need a visual mirror (Photoshop-style), add scaleX/scaleY
 * yourself in the onResize callback.
 *
 * Math (per axis where the handle moves)
 * --------------------------------------
 *   anchor    = position of the edge that stays still (snapshot at mousedown)
 *   pointer   = position of the dragged edge (follows the cursor)
 *   width     = | pointer - anchor |
 *   leftOrTop = min(anchor, pointer)
 *
 * That's it. No flip state. No transform manipulation.
 *
 * If `allowCross: false` (default true), the dragged edge clamps at
 * the anchor minus minWidth/minHeight, so the rect cannot pass through.
 */
/**
 * @module    components/modifiers/2D/Rotator
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Drag-to-rotate handle with optional angle snap.
 */
/**
 * @module    components/modifiers/2D/Skewer
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * skewX / skewY via drag handle.
 */
/**
 * @module    components/modifiers/2D/Rounder
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Border-radius drag control with optional per-corner support.
 *
 * Backward compatible
 * -------------------
 * - `new Rounder(target, { r: 20 })` produces the legacy single-handle
 *   rounder with a uniform border-radius on all four corners.
 * - `new Rounder(target, { topLeft: 0, topRight: 20, bottomRight: 40, bottomLeft: 0 })`
 *   produces four independent corner handles, each with its own current
 *   value.
 * - Setting any of `topLeft / topRight / bottomLeft / bottomRight` switches
 *   the modifier into per-corner mode; otherwise legacy uniform mode is used.
 *
 * Drag direction
 * --------------
 * - Legacy uniform handle: horizontal drag (right = larger).
 * - Per-corner handles: VERTICAL drag (down = larger radius), so the
 *   direction is intuitive at every corner regardless of position.
 */
/**
 * @module    components/modifiers/2D/Reflector
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Flip / mirror buttons with animated CSS transform.
 */
/**
 * @module    components/modifiers/2D/Mover
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Drag-to-move modifier for any HTML element.
 *
 * Features
 * --------
 *  - Axis lock (x | y | both)
 *  - Independent horizontal / vertical grid snap (snapX, snapY)
 *  - Discrete point snap with threshold
 *  - Bounds: 'parent' | 'viewport' | HTMLElement | DOMRect | custom
 *  - Drag-handle selector
 *  - Threshold (anti-click)
 *  - Pointer events (mouse + touch + pen)
 *  - Z-index lift during drag, restored on drop
 *  - Public mass / damping / stiffness fields, ready for the future physics
 *    engine. _physicsTick(dt) is a no-op placeholder so the API is stable
 *    from v1.1.0 onward; when the engine arrives, the integration point is
 *    already here.
 */
/**
 * @module    components/modifiers/2D
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. 2D Modifiers — barrel export.
 *
 * Import individually for tree-shaking:
 *   import { Resizer } from '.../components/modifiers/2D/Resizer.ts';
 *
 * Or use the bundle:
 *   import { Modifiers2D } from '.../components/modifiers/2D/index.ts';
 */
/**
 * @module    components/modifiers/3D/SubdivisionModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Catmull-Clark subdivision surface.
 */
/**
 * @module    components/modifiers/3D/DecimateModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Greedy triangle decimation — reduces polygon count by a target ratio.
 */
/**
 * @module    components/modifiers/3D/BevelModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Edge bevel / chamfer — adds loop vertices offset along face normals.
 */
/**
 * @module    components/modifiers/3D/MirrorModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Mirror geometry on X, Y or Z axis with optional vertex welding on the plane.
 */
/**
 * @module    components/modifiers/3D/ArrayModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Linear or radial instance array of a mesh.
 */
/**
 * @module    components/modifiers/3D/BendModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Bend geometry along an axis by a given angle (radians).
 */
/**
 * @module    components/modifiers/3D/TwistModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Twist geometry around an axis by a given angle (radians).
 */
/**
 * @module    components/modifiers/3D/WaveModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Sinusoidal displacement along an axis.
 */
/**
 * @module    components/modifiers/3D/InflateModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Expand geometry along vertex normals.
 */
/**
 * @module    components/modifiers/3D/SmoothModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Laplacian smoothing — iteratively average vertices toward their neighbors.
 */
/**
 * @module    components/modifiers/3D/DragModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Mouse drag to move a mesh in world space on a chosen plane.
 */
/**
 * @module    components/modifiers/3D/SnapModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Snap position and rotation to a grid.
 */
/**
 * @module    components/modifiers/3D/LODModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Level-of-detail — swap geometry based on camera distance.
 */
/**
 * @module    components/modifiers/3D/FadeModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Distance-based opacity fade — hides mesh beyond a far threshold.
 */
/**
 * @module    components/modifiers/3D/BillboardModifier
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Always face the camera — optional per-axis lock.
 */
/**
 * @module    components/modifiers/3D
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. 3D Modifiers — barrel export.
 *
 * Import individually for tree-shaking:
 *   import { SubdivisionModifier } from '.../components/modifiers/3D/SubdivisionModifier.ts';
 *
 * Or use the bundle:
 *   import { Modifiers3D } from '.../components/modifiers/3D/index.ts';
 */
/**
 * @module    components/payments/ApplePay
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Apple Pay button + sheet integration. Wraps the W3C `PaymentRequest` API
 * with the Apple Pay-specific payment method `https://apple.com/apple-pay`,
 * which is the cross-browser way Apple recommends since 2024.
 *
 * The button is rendered following Apple's Human Interface Guidelines
 * (rounded, black with white wordmark, "Buy with Apple Pay" text). The
 * widget hides itself if the device cannot pay, unless `forceShow` is set.
 *
 * REQUIREMENTS for Apple Pay to actually work in production:
 *   • Served over HTTPS
 *   • Domain associated with merchantId in the Apple Developer portal
 *   • `apple-developer-merchantid-domain-association` file at the well-known URL
 *   • Browser: Safari 10+, or Chrome/Firefox via PaymentRequest API on supported devices
 *
 * The component does NOT perform any backend handshake — once the user
 * approves the sheet, the resulting payment token is forwarded via the
 * `success` event for the merchant's own server to forward to its PSP.
 *
 * @example
 *   import { ApplePay } from 'ariannajs/components/payments';
 *
 *   const ap = new ApplePay('#applepay', {
 *       merchantId : 'merchant.com.example.shop',
 *       countryCode: 'IT',
 *       currency   : 'EUR',
 *       amount     : 99.00,
 *       label      : 'AriannA Pro license',
 *       supportedNetworks: ['visa', 'masterCard', 'amex'],
 *   });
 *   ap.on('success', e => api.processApplePayToken(e.token));
 *   ap.on('error',   e => showToast(e.message));
 *   ap.on('cancel',  () => console.log('User cancelled'));
 */
/**
 * @module    components/payments/GooglePay
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Google Pay button + sheet integration. Uses the Google Pay JS API
 * (`pay.js`) loaded on demand from `pay.google.com/gp/p/js/pay.js`. The
 * widget is renderer-agnostic and only emits events; the merchant's server
 * is responsible for forwarding the encrypted payment token to its PSP.
 *
 * The button follows Google Pay's brand guidelines (black, white, plain).
 *
 * REQUIREMENTS for Google Pay to actually work in production:
 *   • Served over HTTPS (or localhost during development)
 *   • Merchant registered in the Google Pay Business Console
 *   • Gateway integration set up (Stripe, Adyen, Worldpay, …) — Google Pay
 *     is a *wallet*, not a *gateway* — the merchant still needs a PSP
 *
 * @example
 *   import { GooglePay } from 'ariannajs/components/payments';
 *
 *   const gp = new GooglePay('#gpay', {
 *       merchantId    : '01234567890123456789',
 *       merchantName  : 'AriannA',
 *       amount        : 99.00,
 *       currency      : 'EUR',
 *       countryCode   : 'IT',
 *       gateway       : 'stripe',
 *       gatewayMerchantId: 'acct_1A2B3C',
 *       allowedCardNetworks: ['VISA', 'MASTERCARD', 'AMEX'],
 *   });
 *   gp.on('success', e => api.processGooglePayToken(e.token));
 *   gp.on('cancel',  () => console.log('User cancelled'));
 */
/**
 * @module    components/payments/CreditCard
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Generic credit/debit card form. Detects the brand from the card number
 * (Visa, Mastercard, Amex, Maestro), validates with Luhn, formats input as
 * the user types, and emits a `submit` event with the (un-tokenised) card
 * data when the form is valid.
 *
 * IMPORTANT — PCI compliance: this component handles raw PAN/CVV in memory.
 * Production deployments MUST tokenise via the gateway (Stripe Elements,
 * Adyen Web Components, etc.) before transmitting to your servers, or be
 * served via a PCI-compliant iframe. This component is intended for:
 *
 *   • UI prototyping
 *   • Self-hosted closed-loop gift cards / loyalty
 *   • Developer environments with sandbox-only flows
 *   • Internal admin tooling where PCI scope is already managed
 *
 * Visual layout (Illustrator-style card preview + form fields):
 *
 *   ┌─────────────────────────────┐
 *   │  ╔═══════════════════════╗  │
 *   │  ║      VISA / MC        ║  │  ← live preview of brand
 *   │  ║  •••• •••• •••• 4242  ║  │
 *   │  ║  CARDHOLDER     12/28 ║  │
 *   │  ╚═══════════════════════╝  │
 *   │                             │
 *   │  Card number  [____________]│
 *   │  Cardholder   [____________]│
 *   │  MM/YY [__]   CVV [___]     │
 *   │  Country [▾]  ZIP [_____]   │
 *   │  ☐ Save card                │
 *   │  [    PAY EUR 99.00      ]  │
 *   └─────────────────────────────┘
 *
 * Built-in brands: Visa, Mastercard, American Express, Maestro. The
 * `detectBrand` helper is exported so consumers can apply the same logic
 * elsewhere.
 *
 * @example
 *   import { CreditCard } from 'ariannajs/components/payments';
 *
 *   const cc = new CreditCard('#pay', {
 *       amount: 99.00,
 *       currency: 'EUR',
 *       saveOption: true,
 *   });
 *   cc.on('submit', e => api.charge(e.card));
 *   cc.on('error',  e => showToast(e.message));
 */
/**
 * @module    components/payments/PayPal
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * PayPal Smart Button. Loads the PayPal JS SDK on demand
 * (`paypal.com/sdk/js?client-id=…`) and renders the official PayPal button
 * which itself opens the PayPal pop-up / redirect / in-context flow when
 * clicked. The component handles createOrder / onApprove / onCancel /
 * onError lifecycle and emits `success`, `cancel`, and `error` events.
 *
 * The PayPal SDK supports many flow modes; this widget targets the standard
 * "Checkout" flow with a single payment. For subscriptions or vault flows,
 * pass the relevant `intent` and `vault` options.
 *
 * @example
 *   import { PayPal } from 'ariannajs/components/payments';
 *
 *   const pp = new PayPal('#paypal', {
 *       clientId : 'AYxxxxxxxxxxxxxxxxxxx',
 *       amount   : 99.00,
 *       currency : 'EUR',
 *       description: 'AriannA Pro license',
 *   });
 *   pp.on('success', e => api.confirm(e.orderId));
 *   pp.on('cancel',  () => console.log('Cancelled'));
 *   pp.on('error',   e => showToast(e.message));
 */
/**
 * @module    components/payments/Stripe
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Stripe Elements wrapper. Loads Stripe.js on demand
 * (`js.stripe.com/v3/`) and mounts the unified `payment` element which
 * Stripe routes to the appropriate UI (card, SEPA, iDEAL, …) based on the
 * customer's country and the payment intent's `payment_method_types`.
 *
 * The widget needs a Payment Intent to be created server-side first; the
 * client-side just confirms the intent. The flow is:
 *
 *   1. Server creates PaymentIntent → returns `client_secret`
 *   2. Browser instantiates this widget with `clientSecret`
 *   3. User fills the card form (Stripe-hosted iframe → PCI-safe)
 *   4. User clicks Pay → `stripe.confirmPayment(clientSecret)`
 *   5. Stripe redirects (3DS) or returns success/error inline
 *
 * @example
 *   import { Stripe } from 'ariannajs/components/payments';
 *
 *   // 1. Backend creates PaymentIntent and returns client_secret
 *   const { clientSecret } = await api.createIntent({ amount: 9900, currency: 'eur' });
 *
 *   // 2. Mount widget
 *   const sp = new Stripe('#stripe', {
 *       publishableKey: 'pk_test_…',
 *       clientSecret  : clientSecret,
 *       returnUrl     : 'https://example.com/checkout/return',
 *   });
 *   sp.on('success', e => api.confirmOrder(e.intent.id));
 *   sp.on('error',   e => showToast(e.message));
 */
/**
 * @module    components/payments/Satispay
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Satispay payment integration. Satispay (Italian wallet, 4M+ users) uses
 * a server-driven flow: the merchant creates a payment via the Satispay
 * Business API and receives a `redirect_url`. The user clicks the button,
 * is redirected to the Satispay app (or web flow on desktop), authorises,
 * then comes back to the merchant via `redirect_url`.
 *
 * Like AliPay this widget is a button + redirect — the actual payment
 * creation happens server-side. The Satispay-Business-API requires:
 *   • Activation Code from the Satispay Dashboard
 *   • RSA key pair for request signing (server-only)
 *
 * @example
 *   import { Satispay } from 'ariannajs/components/payments';
 *
 *   // 1. Backend: POST /api/v1/payments → returns { redirect_url, payment_id }
 *   const { redirect_url, payment_id } = await api.createSatispayPayment(amount);
 *
 *   // 2. Mount widget
 *   const sp = new Satispay('#satispay', {
 *       redirectUrl: redirect_url,
 *       amount     : 99.00,
 *   });
 *   sp.on('click', () => analytics.track('satispay_clicked', { payment_id }));
 */
/**
 * @module    components/payments/Nexi
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Nexi (formerly XPay) hosted payment gateway integration. Nexi is the
 * dominant Italian acquirer / processor; many Italian banks issue cards
 * routed through Nexi. The standard flow is "Hosted Payment Page": the
 * merchant generates a signed redirect URL server-side and the user is
 * sent to the Nexi-branded checkout page, then back to the merchant's
 * return URL with the transaction outcome.
 *
 * This widget renders the Nexi-branded button + redirects on click. It
 * does NOT compute the MAC signature itself — that requires the merchant's
 * secret key and must happen server-side. The caller passes the fully-
 * formed `redirectUrl` returned by their backend.
 *
 * Note: Nexi also offers a JS SDK for inline iframe checkout; that's a
 * future enhancement (would mirror the Stripe.ts pattern).
 *
 * @example
 *   import { Nexi } from 'ariannajs/components/payments';
 *
 *   // 1. Backend signs payment request → returns { redirectUrl, transactionCode }
 *   const { redirectUrl, transactionCode } = await api.createNexiPayment(amount);
 *
 *   // 2. Mount widget
 *   const nx = new Nexi('#nexi', {
 *       redirectUrl: redirectUrl,
 *       amount     : 99.00,
 *       transactionCode: transactionCode,
 *   });
 */
/**
 * @module    components/payments/AliPay
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Alipay payment integration. Alipay is server-driven: the merchant creates
 * a payment URL on the backend, redirects the user (or shows a QR code),
 * the user authorises in the Alipay app, and Alipay calls back to the
 * merchant's notify URL.
 *
 * This widget renders the official Alipay button or QR code. It does NOT
 * perform any handshake itself — the caller provides either the redirect URL
 * (for desktop) or the QR code data URL (typically generated server-side).
 *
 *   • `redirectUrl` — desktop / mobile web: clicking the button navigates here.
 *   • `qrCode`      — desktop with QR display: rendered as <img>.
 *
 * @example
 *   import { AliPay } from 'ariannajs/components/payments';
 *
 *   const ap = new AliPay('#alipay', {
 *       mode    : 'redirect',
 *       redirectUrl: 'https://openapi.alipay.com/gateway.do?…',
 *       amount  : 99.00,
 *       currency: 'CNY',
 *   });
 *   ap.on('click', () => analytics.track('alipay_clicked'));
 */
/**
 * @module    components/payments/PaymentGateway
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Compound widget that presents *all* enabled payment methods in a single
 * checkout UI, lets the user pick one, and forwards the appropriate event
 * to the merchant code. This is the single integration point most apps
 * actually want — instead of mounting ApplePay / GPay / Stripe / Satispay
 * separately, drop in `PaymentGateway` and configure which methods to
 * expose for the current order.
 *
 *   ┌─────────────────────────────────────┐
 *   │ Choose how to pay                   │
 *   ├─────────────────────────────────────┤
 *   │ ◉ Apple Pay         [    Pay    ]   │
 *   │ ○ Google Pay                        │
 *   │ ○ Credit / Debit Card                │
 *   │ ○ PayPal                            │
 *   │ ○ Stripe                            │
 *   │ ○ Satispay                          │
 *   │ ○ Nexi                              │
 *   │ ○ Alipay                            │
 *   └─────────────────────────────────────┘
 *
 * The component instantiates the underlying widgets *lazily* — only when a
 * method is selected does it create the corresponding ApplePay / GPay / …
 * instance. Events from the underlying widget bubble up through this one.
 *
 * @example
 *   import { PaymentGateway } from 'ariannajs/components/payments';
 *
 *   const pg = new PaymentGateway('#checkout', {
 *       amount  : 99.00,
 *       currency: 'EUR',
 *       methods : {
 *           applePay : { merchantId: 'merchant.com.example', countryCode: 'IT' },
 *           googlePay: { merchantId: '01234567', merchantName: 'X', countryCode: 'IT', gateway: 'stripe', gatewayMerchantId: 'acct_1' },
 *           card     : { saveOption: true },
 *           paypal   : { clientId: 'AYxxx' },
 *           stripe   : { publishableKey: 'pk_test_…', clientSecret: '…', returnUrl: 'https://…' },
 *           satispay : { redirectUrl: 'https://online.satispay.com/…' },
 *           nexi     : { redirectUrl: 'https://ecommerce.nexi.it/…' },
 *           alipay   : { mode: 'redirect', redirectUrl: 'https://openapi.alipay.com/…' },
 *       },
 *   });
 *   pg.on('success', e => api.confirm(e.method, e.payload));
 *   pg.on('error',   e => showToast(`${e.method}: ${e.message}`));
 *   pg.on('cancel',  e => console.log('cancelled', e.method));
 */
/**
 * @module    components/tracking/Tracker
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Carrier-agnostic shipment-tracker base widget. Renders a unified timeline
 * of `TrackingEvent`s with status icon, location, timestamp, and a final
 * "Track on <carrier> →" button that opens the carrier's own tracking page
 * in a new tab. The 4 carrier-specific subclasses (DHL, UPS, FedEx, BRT)
 * configure brand colours, logos, the public tracking URL pattern, and a
 * regex for tracking-number validation; everything else is shared.
 *
 *   ┌─────────────────────────────────────────────┐
 *   │ DHL · 1234567890                            │
 *   ├─────────────────────────────────────────────┤
 *   │ ● Delivered — Roma, IT — 06 May, 14:22       │
 *   │ │                                            │
 *   │ ● Out for delivery — Roma, IT — 06 May, 09:11│
 *   │ │                                            │
 *   │ ○ Arrived at hub — Milano, IT — 05 May, 23:14│
 *   │ │                                            │
 *   │ ○ In transit — DE → IT — 05 May, 06:00       │
 *   │ │                                            │
 *   │ ○ Picked up — Berlin, DE — 04 May, 18:30     │
 *   ├─────────────────────────────────────────────┤
 *   │       [ Track on DHL → ]                     │
 *   └─────────────────────────────────────────────┘
 *
 * IMPORTANT — API access: live carrier APIs require server-side credentials
 * (DHL Tracking API key, UPS OAuth, FedEx API client, BRT auth) that must
 * NEVER ship to the browser. The widget therefore expects the merchant
 * server to fetch, normalise, and feed it the events. As an escape hatch,
 * the widget can also operate in pure "link" mode where no events are
 * displayed and only the public tracking URL is exposed.
 *
 * @example
 *   import { DHLTracker } from 'ariannajs/components/tracking';
 *
 *   const t = new DHLTracker('#track', { trackingNumber: '1234567890' });
 *
 *   // Server fetched the events server-side; pass them in:
 *   t.setEvents([
 *       { kind: 'delivered',    location: 'Roma, IT',    at: Date.now() },
 *       { kind: 'out-delivery', location: 'Roma, IT',    at: Date.now() - 18000000 },
 *       { kind: 'arrived',      location: 'Milano, IT',  at: Date.now() - 50000000 },
 *   ]);
 *
 *   t.on('open-portal', e => analytics.track('tracker_external_open', { carrier: 'dhl' }));
 */
/**
 * @module    components/tracking/DHLTracker
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * DHL shipment tracker. Renders the shared timeline UI from `Tracker.ts`
 * with DHL-specific branding (red #d40511 + yellow #ffcc00) and links out
 * to the official DHL public tracking portal.
 *
 * DHL tracking number formats are heterogeneous across services:
 *   • Express AWB        : 10 or 11 digits
 *   • eCommerce / Parcel : 10–39 chars, alphanumeric
 *   • DHL Global Forwarding (sea/air): 3-letter prefix + 7 digits
 *
 * The default regex accepts the common cases. Override `pattern` if you
 * only handle a specific DHL service.
 *
 * @example
 *   import { DHLTracker } from 'ariannajs/components/tracking';
 *
 *   const t = new DHLTracker('#track', { trackingNumber: '1234567890' });
 *   t.setEvents(await api.fetchDhlEvents('1234567890'));
 */
/**
 * @module    components/tracking/UPSTracker
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * UPS shipment tracker. UPS tracking numbers are very recognisable: they
 * almost always start with `1Z` followed by 16 alphanumeric characters
 * (account + service + package digits + check digit). Brand color is
 * UPS Brown #644117.
 *
 *   1Z  + 6 chars (shipper) + 2 chars (service) + 7 chars (package) + 1 (check)
 *   = 18 chars total, "1Z" prefix
 *
 * @example
 *   import { UPSTracker } from 'ariannajs/components/tracking';
 *
 *   const t = new UPSTracker('#track', { trackingNumber: '1Z999AA10123456784' });
 */
/**
 * @module    components/tracking/FedExTracker
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * FedEx shipment tracker. FedEx tracking numbers come in three lengths,
 * all numeric:
 *   • 12 digits — domestic Express
 *   • 15 digits — Ground / SmartPost
 *   • 20 digits — older systems & some international services
 *
 * Brand: FedEx purple #4d148c + orange #ff6600 (the famous "hidden arrow"
 * logo isn't representable inline; we use the wordmark).
 *
 * @example
 *   import { FedExTracker } from 'ariannajs/components/tracking';
 *
 *   const t = new FedExTracker('#track', { trackingNumber: '123456789012' });
 */
/**
 * @module    components/tracking/BRTTracker
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * BRT shipment tracker. BRT (ex Bartolini, rebranded 2018) is the largest
 * Italian-domestic courier, dominant for B2C e-commerce in Italy. Tracking
 * numbers are 10–12 digit numeric "spedizione" numbers (the legacy
 * "Numero Spedizione" / "Numero Lettera di Vettura").
 *
 * Public tracking URL pattern uses BRT's VAS (Valore Aggiunto Spedizioni)
 * portal. The widget links to the public form pre-filled.
 *
 * Brand color: BRT red #e3000b.
 *
 * @example
 *   import { BRTTracker } from 'ariannajs/components/tracking';
 *
 *   const t = new BRTTracker('#track', { trackingNumber: '12345678901' });
 */
/**
 * @module    components/tracking/TrackingMulti
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Multi-carrier shipment tracker. Given a tracking number, it auto-detects
 * the most likely carrier by matching against each carrier's regex and
 * mounts the corresponding subcomponent. If multiple carriers match (which
 * happens with ambiguous numeric formats), it presents a small picker.
 *
 *   ┌──────────────────────────────────────┐
 *   │ Tracking number                      │
 *   │ [123456789012345        ] [Track]    │
 *   ├──────────────────────────────────────┤
 *   │ ⚠ Multiple carriers match this number│
 *   │   ◯ FedEx   ◯ DHL                   │
 *   ├──────────────────────────────────────┤
 *   │  …mounted DHLTracker / FedExTracker… │
 *   └──────────────────────────────────────┘
 *
 * Programmatic API: `setNumber(n)`, `setCarrier(id)`, `getCarrier()`,
 * `setEvents(events)`, `getActive()`. Events from the active subcomponent
 * bubble up through this widget tagged with the carrier id.
 *
 * @example
 *   import { TrackingMulti } from 'ariannajs/components/tracking';
 *
 *   const t = new TrackingMulti('#tracker');
 *   t.setNumber('1Z999AA10123456784');     // → auto-detected as UPS
 *   t.on('detected', e => console.log('Carrier:', e.carrier));
 *   t.setEvents(await api.fetchEvents(t.getCarrier(), t.getNumber()));
 */
/**
 * @module    components/finance/CandlestickChart
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * OHLCV candlestick/bar chart — pure SVG, zero dependencies.
 */
/**
 * @module    components/finance/LineChart
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Multi-series line chart — pure SVG, zero dependencies.
 */
/**
 * @module    components/finance/DepthChart
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Order book depth chart (cumulative bid/ask area) — pure SVG.
 */
/**
 * @module    components/finance/HeatmapChart
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Correlation / sector heatmap — pure SVG.
 */
/**
 * @module    components/finance/PortfolioDonut
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Asset allocation donut chart — pure SVG.
 */
/**
 * @module    components/finance/PnLChart
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Profit & loss bar chart — pure SVG.
 */
/**
 * @module    components/finance/RiskGauge
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Semi-circular risk gauge — pure SVG.
 */
/**
 * @module    components/finance/OrderBook
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Bid/ask ladder table — pure HTML.
 */
/**
 * @module    components/finance/Screener
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Filterable instrument table — pure HTML.
 */
/**
 * @module    components/finance/Sparkline
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Mini inline price sparkline — pure SVG.
 */
/**
 * @module    components/finance/AlertBadge
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Price alert indicator badge — pure HTML.
 */
/**
 * @module    components/finance
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. Finance Components — barrel export.
 *
 * Import individual components for tree-shaking:
 *   import { CandlestickChart } from '.../components/finance/CandlestickChart.ts';
 *
 * Or import the full bundle:
 *   import { FinanceComponents } from '.../components/finance/index.ts';
 */
/**
 * @module    additionals/Colors
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * AriannA Colors addon — pure colour-space conversion library shared by
 * every colour-picker and gradient-editor component. Single module, zero
 * dependencies, all pure functions. Sits alongside the other AriannA
 * addons (Three, Two, AI, Finance, Video, Audio, IO) and provides the
 * mathematics layer the components in `components/graphics/colors/`
 * assemble into UI.
 *
 * Supported spaces:
 *
 *   • RGB     — sRGB linearised through the standard companding curve.
 *   • HEX     — `#rgb` / `#rrggbb` / `#rrggbbaa` parsing & formatting.
 *   • HSL     — derived from sRGB.
 *   • HSV     — derived from sRGB.
 *   • CMYK    — naive CMYK from sRGB (suitable for screen mock-ups; for
 *               print accuracy you must round-trip through ICC profiles —
 *               not in scope here).
 *   • CIELUV  — D65 illuminant, CIE 1976 L*u*v* polar form (Lch_uv).
 *   • OKLCH   — Björn Ottosson's 2020 OKLab in cylindrical (L, C, h).
 *   • Cube    — 256-step uniform RGB cube indexed by R*65536 + G*256 + B,
 *               useful for palette quantisation / lookup tables.
 *
 * All functions are stateless and side-effect-free. Inputs are clamped /
 * normalised at every public entry point so callers can pass typed user
 * input without worrying about ranges.
 *
 * @example
 *   import { parseHex, rgbToOklch, oklchToRgb, formatCss } from 'ariannajs/additionals/Colors';
 *
 *   const rgb   = parseHex('#e40c88')!;
 *   const oklch = rgbToOklch(rgb);            // { L, C, h, a? }
 *   const back  = oklchToRgb(oklch);          // approximate round-trip
 *   const css   = formatCss('oklch', oklch);  // "oklch(...)"
 */
/**
 * @module    components/graphics/2D/ColorPickerWheel
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Illustrator-style colour wheel: outer ring picks Hue (HSV/HSL),
 * inner square picks Saturation × Value. Wheel is rendered as an SVG
 * conic gradient using Canvas → data URL fallback for browsers without
 * `conic-gradient` SVG support.
 *
 *           ╭────────────╮
 *         ╱   ┌──────┐    ╲
 *        │   │ S × V │     │   ← inner square (saturation horizontal,
 *        │   │       │     │     value vertical)
 *         ╲   └──────┘    ╱
 *           ╰────────────╯
 *                 ↑ outer ring = hue
 *
 * Side panel exposes editable values for every supported colour space:
 *   RGB, HEX, HSL, HSV, CMYK, OKLCH, CIELUV, plus the 24-bit Cube index.
 *
 * @example
 *   import { ColorPickerWheel } from 'ariannajs/components/graphics/2D';
 *
 *   const cp = new ColorPickerWheel('#wheel', { color: '#e40c88', alpha: true });
 *   cp.on('change', e => brush.setColor(e.hex));
 */
/**
 * @module    components/graphics/2D/ColorPickerSquare
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Photoshop-style colour picker: large square for Saturation × Value,
 * vertical hue strip on the right, optional alpha strip below the hue,
 * and full numeric readouts for every supported colour space:
 *
 *   ┌────────────────┬────┐
 *   │                │ │  │
 *   │   S × V        │ H  │
 *   │   square       │ u  │
 *   │                │ e  │
 *   │                │ │  │
 *   └────────────────┼────┤
 *                    │ α  │
 *                    └────┘
 *
 *   ┌─────────────────────┐
 *   │ HEX  [#e40c88     ] │
 *   │ RGB  [228] [12] [136]│
 *   │ HSL  [328] [90] [47]│
 *   │ HSV  …              │
 *   │ CMYK …              │
 *   │ OKLCH/CIELUV …      │
 *   └─────────────────────┘
 *
 * @example
 *   import { ColorPickerSquare } from 'ariannajs/components/graphics/2D';
 *
 *   const cp = new ColorPickerSquare('#picker', { color: '#e40c88', alpha: true });
 *   cp.on('change', e => fill.set(e.hex));
 */
/**
 * @module    components/graphics/2D/ColorPickerTile
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Tile-style colour picker — the third member of the colour-picker
 * family alongside `ColorPickerWheel` and `ColorPickerSquare`. Renders a
 * grid of swatches that the user can click. Supports:
 *
 *   • Built-in tile palettes: `material`, `tailwind`, `pastel`, `web-safe`,
 *     `mac-os-classic`, or any custom array of hex strings.
 *   • A "recent colours" strip that auto-grows as the user picks.
 *   • Per-tile tooltip with the colour value in the requested space.
 *   • Optional eyedropper / hex input on the side.
 *
 *   ┌────────────────────────────┐
 *   │ ▣ ▣ ▣ ▣ ▣ ▣ ▣ ▣           │
 *   │ ▣ ▣ ▣ ▣ ▣ ▣ ▣ ▣           │
 *   │ ▣ ▣ ▣ ▣ ▣ ▣ ▣ ▣           │
 *   ├────────────────────────────┤
 *   │ Recent: ▣ ▣ ▣ ▣            │
 *   ├────────────────────────────┤
 *   │ HEX [#e40c88 ]    [Pick]   │
 *   └────────────────────────────┘
 *
 * The displayed colour is exposed in every space supported by `additionals/Colors`:
 * RGB / HEX / HSL / HSV / CMYK / OKLCH / CIELUV / Cube.
 *
 * @example
 *   import { ColorPickerTile } from 'ariannajs/components/graphics/2D';
 *
 *   const cp = new ColorPickerTile('#tiles', { palette: 'material' });
 *   cp.on('change', e => brush.setColor(e.hex));
 */
/**
 * @module    components/graphics/2D/GradientEditor
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Shared abstract base for the three gradient editors:
 *
 *   • LinearGradientEditor — angle + stops along a straight line
 *   • RadialGradientEditor — centre + radius + stops along a ray
 *   • ShapeGradientEditor  — Illustrator "freeform mesh" gradient with
 *                            arbitrary 2D control points each carrying a
 *                            colour and influence falloff.
 *
 * Every editor owns the same data model: an ordered list of `GradientStop`
 * each with a normalised `t ∈ [0,1]` parameter, an RGBA colour, and an
 * optional `midpoint` (the "0.5" handle between this stop and the next
 * one — the same control Illustrator exposes as a tiny diamond on the
 * gradient bar). Subclasses add geometry on top.
 *
 * Output: each editor exposes `toCSS()` returning a `linear-gradient(...)`
 * / `radial-gradient(...)` / SVG-mesh string suitable to paint a fill.
 *
 * The shared base also renders the *stop strip* — the horizontal bar with
 * stop pins, midpoints, add-stop click area, and double-click-to-remove.
 *
 * Design rules:
 *   • Stops are always kept sorted by `t`.
 *   • Two stops may share a `t` (Illustrator allows hard transitions).
 *   • Removing a stop falls back gracefully to keeping at least 2.
 *   • Selection is by stop index; subclasses display their geometry pins.
 */
/**
 * @module    components/graphics/2D/LinearGradientEditor
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Linear gradient editor — Illustrator/Photoshop style. Edits the two
 * dimensions specific to a linear gradient on top of the shared
 * `GradientEditorBase` (stops, colours, positions): the **angle** in
 * degrees (0° = top→bottom by CSS convention) and an optional
 * **interpolation space** (linear sRGB, OKLab, OKLCH, HSL).
 *
 *   ┌──────────────────────────────────┬────────────────────┐
 *   │ ████████████████████████████████ │ Color [#e40c88]    │
 *   │ ▣  ◆  ▣          ▣            ▣ │ Position [42.0]%   │
 *   ├──────────────────────────────────┤ Alpha   [1.00]     │
 *   │ Angle [   90 ]°  Space [oklab ▾] │ [Remove stop]      │
 *   ├──────────────────────────────────┤                    │
 *   │ Preview swatch                   │                    │
 *   │ (60×60, applies the gradient)    │                    │
 *   └──────────────────────────────────┴────────────────────┘
 *
 * @example
 *   import { LinearGradientEditor } from 'ariannajs/components/graphics/2D';
 *
 *   const ed = new LinearGradientEditor('#grad', { angle: 45 });
 *   ed.on('change', e => fill.setBackground(ed.toCSS()));
 */
/**
 * @module    components/graphics/2D/RadialGradientEditor
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Radial gradient editor — Illustrator/Photoshop style. On top of the
 * shared stop strip from `GradientEditorBase`, exposes the geometry
 * specific to a CSS `radial-gradient(...)`:
 *
 *   • Shape: `circle` or `ellipse`
 *   • Size :  `closest-side`, `farthest-side`, `closest-corner`, `farthest-corner`,
 *             or explicit `length-percentage` pair
 *   • Center: `cx%, cy%` — interactive picker on a small canvas
 *   • Aspect ratio : ellipse only — separate radius-x / radius-y
 *
 *   ┌──────────────────────────────────┬────────────────────┐
 *   │ ████████████████████████████████ │ Color [#e40c88]    │
 *   │ ▣  ◆  ▣          ▣            ▣ │ Position [42.0]%   │
 *   ├──────────────────────────────────┤ Alpha   [1.00]     │
 *   │ Shape [circle ▾]  Size [farthest-corner ▾] │            │
 *   │ Center: [50]% [50]%   ◯ ← drag in preview │            │
 *   ├──────────────────────────────────┤                    │
 *   │ Preview swatch                   │                    │
 *   └──────────────────────────────────┴────────────────────┘
 */
/**
 * @module    components/graphics/2D/ShapeGradientEditor
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * Illustrator-style "freeform shape" gradient editor — the third member of
 * the gradient-editor trio alongside `LinearGradientEditor` and
 * `RadialGradientEditor`. Instead of a single stop axis, the user places
 * arbitrary 2D **control points**, each carrying an RGBA colour and a
 * **radius of influence**. The renderer mixes contributions from every
 * point using inverse-distance weighting, producing soft mesh-like
 * blends that follow whatever shape the user wants.
 *
 *      ┌────────────────────────────────┐
 *      │                                │
 *      │      ●╮                        │
 *      │       ╲╲                       │
 *      │        ●           ●           │
 *      │       ╱╱╲╲        ╱╲           │
 *      │      ●   ●     ──●  ●          │
 *      │                                │
 *      └────────────────────────────────┘
 *      ↑
 *      drag points to reposition; click empty area to add; double-click
 *      a point to remove; click a point and edit its colour/radius in
 *      the inspector.
 *
 * The editor renders into a `<canvas>` (per-pixel sampling) so the
 * preview is the actual gradient. `toSVG()` exports an SVG `<filter>` /
 * radial-gradient-blend approximation suitable for static reuse.
 *
 * NOTE: this component intentionally does NOT inherit from
 * `GradientEditorBase` — its data model isn't a 1-D stop list. It still
 * speaks the same colour space (`additionals/Colors`) and exposes a familiar
 * `change` event.
 */
