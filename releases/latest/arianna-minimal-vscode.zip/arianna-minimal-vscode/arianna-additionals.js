// additionals/AI.ts
var _gpuDevice = null;
var _GPU_BUF = {
  COPY_SRC: 4,
  COPY_DST: 8,
  STORAGE: 128,
  UNIFORM: 64,
  MAP_READ: 1
};
async function _getGPU() {
  if (_gpuDevice) return _gpuDevice;
  if (!navigator.gpu) return null;
  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter) return null;
  _gpuDevice = await adapter.requestDevice();
  return _gpuDevice;
}
function _gpuBuf(device, data, usage) {
  const buf = device.createBuffer({ size: data.byteLength, usage: usage | _GPU_BUF.COPY_DST });
  device.queue.writeBuffer(buf, 0, data);
  return buf;
}
async function _gpuReadback(device, buf, size) {
  const readBuf = device.createBuffer({ size, usage: _GPU_BUF.MAP_READ | _GPU_BUF.COPY_DST });
  const enc = device.createCommandEncoder();
  enc.copyBufferToBuffer(buf, 0, readBuf, 0, size);
  device.queue.submit([enc.finish()]);
  await device.queue.onSubmittedWorkDone();
  const ab = readBuf.getMappedRange();
  const result = new Float32Array(ab.slice(0));
  readBuf.unmap();
  readBuf.destroy();
  return result;
}
var Tensor = class _Tensor {
  shape;
  data;
  size;
  constructor(shape, data) {
    this.shape = shape;
    this.size = shape.reduce((a, b) => a * b, 1);
    if (data) {
      this.data = data instanceof Float32Array ? data : new Float32Array(data);
    } else {
      this.data = new Float32Array(this.size);
    }
  }
  get rank() {
    return this.shape.length;
  }
  // ── Element-wise CPU ops ─────────────────────────────────────────────────
  add(other) {
    const out = new Float32Array(this.size);
    if (typeof other === "number") for (let i = 0; i < this.size; i++) out[i] = this.data[i] + other;
    else for (let i = 0; i < this.size; i++) out[i] = this.data[i] + other.data[i % other.size];
    return new _Tensor(this.shape, out);
  }
  sub(other) {
    const out = new Float32Array(this.size);
    if (typeof other === "number") for (let i = 0; i < this.size; i++) out[i] = this.data[i] - other;
    else for (let i = 0; i < this.size; i++) out[i] = this.data[i] - other.data[i % other.size];
    return new _Tensor(this.shape, out);
  }
  mul(other) {
    const out = new Float32Array(this.size);
    if (typeof other === "number") for (let i = 0; i < this.size; i++) out[i] = this.data[i] * other;
    else for (let i = 0; i < this.size; i++) out[i] = this.data[i] * other.data[i % other.size];
    return new _Tensor(this.shape, out);
  }
  div(other) {
    const out = new Float32Array(this.size);
    if (typeof other === "number") for (let i = 0; i < this.size; i++) out[i] = this.data[i] / other;
    else for (let i = 0; i < this.size; i++) out[i] = this.data[i] / (other.data[i % other.size] || 1e-8);
    return new _Tensor(this.shape, out);
  }
  // ── Activations ───────────────────────────────────────────────────────────
  relu() {
    return new _Tensor(this.shape, this.data.map((v) => Math.max(0, v)));
  }
  sigmoid() {
    return new _Tensor(this.shape, this.data.map((v) => 1 / (1 + Math.exp(-v))));
  }
  tanh() {
    return new _Tensor(this.shape, this.data.map((v) => Math.tanh(v)));
  }
  log() {
    return new _Tensor(this.shape, this.data.map((v) => Math.log(v + 1e-8)));
  }
  exp() {
    return new _Tensor(this.shape, this.data.map((v) => Math.exp(v)));
  }
  abs() {
    return new _Tensor(this.shape, this.data.map((v) => Math.abs(v)));
  }
  sqrt() {
    return new _Tensor(this.shape, this.data.map((v) => Math.sqrt(Math.max(0, v))));
  }
  neg() {
    return new _Tensor(this.shape, this.data.map((v) => -v));
  }
  softmax(axis = -1) {
    const out = new Float32Array(this.data);
    const cols = this.shape[this.shape.length - 1];
    const rows = this.size / cols;
    for (let r = 0; r < rows; r++) {
      let max = -Infinity;
      for (let c = 0; c < cols; c++) max = Math.max(max, out[r * cols + c]);
      let sum = 0;
      for (let c = 0; c < cols; c++) {
        out[r * cols + c] = Math.exp(out[r * cols + c] - max);
        sum += out[r * cols + c];
      }
      for (let c = 0; c < cols; c++) out[r * cols + c] /= sum;
    }
    return new _Tensor(this.shape, out);
  }
  layerNorm(eps = 1e-5) {
    const out = new Float32Array(this.data);
    const cols = this.shape[this.shape.length - 1];
    const rows = this.size / cols;
    for (let r = 0; r < rows; r++) {
      let mean = 0, variance = 0;
      for (let c = 0; c < cols; c++) mean += out[r * cols + c];
      mean /= cols;
      for (let c = 0; c < cols; c++) variance += (out[r * cols + c] - mean) ** 2;
      variance /= cols;
      const std = Math.sqrt(variance + eps);
      for (let c = 0; c < cols; c++) out[r * cols + c] = (out[r * cols + c] - mean) / std;
    }
    return new _Tensor(this.shape, out);
  }
  // ── Reduction ops ────────────────────────────────────────────────────────
  sum() {
    return this.data.reduce((a, v) => a + v, 0);
  }
  mean() {
    return this.sum() / this.size;
  }
  max() {
    return Math.max(...this.data);
  }
  min() {
    return Math.min(...this.data);
  }
  argmax() {
    let best = 0;
    for (let i = 1; i < this.size; i++) if (this.data[i] > this.data[best]) best = i;
    return best;
  }
  // ── Shape ops ────────────────────────────────────────────────────────────
  reshape(shape) {
    const newSize = shape.reduce((a, b) => a * b, 1);
    if (newSize !== this.size) throw new Error(`reshape: ${this.size} \u2192 ${newSize} size mismatch`);
    return new _Tensor(shape, new Float32Array(this.data));
  }
  transpose() {
    if (this.rank !== 2) throw new Error("transpose: only 2D tensors");
    const [r, c] = this.shape;
    const out = new Float32Array(r * c);
    for (let i = 0; i < r; i++) for (let j = 0; j < c; j++) out[j * r + i] = this.data[i * c + j];
    return new _Tensor([c, r], out);
  }
  slice(start, end) {
    if (this.rank !== 2) throw new Error("slice: only 2D for now");
    const [rs, cs] = start, [re, ce] = end;
    const rows = re - rs, cols = ce - cs;
    const out = new Float32Array(rows * cols);
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++)
      out[r * cols + c] = this.data[(rs + r) * this.shape[1] + (cs + c)];
    return new _Tensor([rows, cols], out);
  }
  concat(other, axis = 0) {
    if (axis === 0 && this.rank === 2 && this.shape[1] === other.shape[1]) {
      const out = new Float32Array(this.size + other.size);
      out.set(this.data, 0);
      out.set(other.data, this.size);
      return new _Tensor([this.shape[0] + other.shape[0], this.shape[1]], out);
    }
    if (axis === 1 && this.rank === 2 && this.shape[0] === other.shape[0]) {
      const rows = this.shape[0], c1 = this.shape[1], c2 = other.shape[1];
      const out = new Float32Array(rows * (c1 + c2));
      for (let r = 0; r < rows; r++) {
        out.set(this.data.subarray(r * c1, (r + 1) * c1), r * (c1 + c2));
        out.set(other.data.subarray(r * c2, (r + 1) * c2), r * (c1 + c2) + c1);
      }
      return new _Tensor([rows, c1 + c2], out);
    }
    throw new Error("concat: unsupported axis/shape combination");
  }
  flatten() {
    return this.reshape([this.size]);
  }
  pad(paddings) {
    if (this.rank !== 2) throw new Error("pad: only 2D");
    const [pr, pc] = paddings;
    const [r, c] = this.shape;
    const nr = r + pr[0] + pr[1], nc = c + pc[0] + pc[1];
    const out = new Float32Array(nr * nc);
    for (let i = 0; i < r; i++) for (let j = 0; j < c; j++)
      out[(i + pr[0]) * nc + (j + pc[0])] = this.data[i * c + j];
    return new _Tensor([nr, nc], out);
  }
  // ── Matrix multiply (CPU) ────────────────────────────────────────────────
  matmul(other) {
    if (this.rank !== 2 || other.rank !== 2) throw new Error("matmul: requires 2D tensors");
    if (this.shape[1] !== other.shape[0]) throw new Error(`matmul shape mismatch: ${this.shape} \xD7 ${other.shape}`);
    const [m, k] = this.shape, n = other.shape[1];
    const out = new Float32Array(m * n);
    for (let i = 0; i < m; i++)
      for (let j = 0; j < n; j++) {
        let s = 0;
        for (let p = 0; p < k; p++) s += this.data[i * k + p] * other.data[p * n + j];
        out[i * n + j] = s;
      }
    return new _Tensor([m, n], out);
  }
  // ── GPU matmul via WGSL compute ──────────────────────────────────────────
  async matmulGPU(other) {
    const device = await _getGPU();
    if (!device) return this.matmul(other);
    const [M, K] = this.shape, N = other.shape[1];
    const wgsl = `
@group(0) @binding(0) var<storage,read> A: array<f32>;
@group(0) @binding(1) var<storage,read> B: array<f32>;
@group(0) @binding(2) var<storage,read_write> C: array<f32>;
struct Dim { M: u32, K: u32, N: u32 }
@group(0) @binding(3) var<uniform> dim: Dim;
@compute @workgroup_size(8,8)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let row = gid.x; let col = gid.y;
    if (row >= dim.M || col >= dim.N) { return; }
    var s = 0.0;
    for (var k = 0u; k < dim.K; k++) { s += A[row*dim.K+k] * B[k*dim.N+col]; }
    C[row*dim.N+col] = s;
}`;
    const aBuf = _gpuBuf(device, this.data, _GPU_BUF.STORAGE | _GPU_BUF.COPY_DST);
    const bBuf = _gpuBuf(device, other.data, _GPU_BUF.STORAGE | _GPU_BUF.COPY_DST);
    const cBuf = device.createBuffer({ size: M * N * 4, usage: _GPU_BUF.STORAGE | _GPU_BUF.COPY_SRC });
    const dBuf = device.createBuffer({ size: 12, usage: _GPU_BUF.UNIFORM | _GPU_BUF.COPY_DST, mappedAtCreation: true });
    new Uint32Array(dBuf.getMappedRange()).set([M, K, N]);
    dBuf.unmap();
    const bgl = device.createBindGroupLayout({ entries: [
      { binding: 0, visibility: 4, buffer: { type: "read-only-storage" } },
      { binding: 1, visibility: 4, buffer: { type: "read-only-storage" } },
      { binding: 2, visibility: 4, buffer: { type: "storage" } },
      { binding: 3, visibility: 4, buffer: { type: "uniform" } }
    ] });
    const pipeline = device.createComputePipeline({
      layout: device.createPipelineLayout({ bindGroupLayouts: [bgl] }),
      compute: { module: device.createShaderModule({ code: wgsl }), entryPoint: "main" }
    });
    const bg = device.createBindGroup({ layout: bgl, entries: [
      { binding: 0, resource: { buffer: aBuf } },
      { binding: 1, resource: { buffer: bBuf } },
      { binding: 2, resource: { buffer: cBuf } },
      { binding: 3, resource: { buffer: dBuf } }
    ] });
    const enc = device.createCommandEncoder();
    const pass = enc.beginComputePass();
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bg);
    pass.dispatchWorkgroups(Math.ceil(M / 8), Math.ceil(N / 8));
    pass.end();
    device.queue.submit([enc.finish()]);
    const result = await _gpuReadback(device, cBuf, M * N * 4);
    [aBuf, bBuf, cBuf, dBuf].forEach((b) => b.destroy());
    return new _Tensor([M, N], result);
  }
  // ── Factory ───────────────────────────────────────────────────────────────
  static zeros(shape) {
    return new _Tensor(shape);
  }
  static ones(shape) {
    return new _Tensor(shape, new Float32Array(shape.reduce((a, b) => a * b, 1)).fill(1));
  }
  static rand(shape) {
    const d = new Float32Array(shape.reduce((a, b) => a * b, 1));
    for (let i = 0; i < d.length; i++) d[i] = Math.random();
    return new _Tensor(shape, d);
  }
  static randn(shape) {
    const d = new Float32Array(shape.reduce((a, b) => a * b, 1));
    for (let i = 0; i < d.length; i += 2) {
      const u1 = 1 - Math.random(), u2 = Math.random();
      const r = Math.sqrt(-2 * Math.log(u1));
      d[i] = r * Math.cos(2 * Math.PI * u2);
      if (i + 1 < d.length) d[i + 1] = r * Math.sin(2 * Math.PI * u2);
    }
    return new _Tensor(shape, d);
  }
  static eye(n) {
    const d = new Float32Array(n * n);
    for (let i = 0; i < n; i++) d[i * n + i] = 1;
    return new _Tensor([n, n], d);
  }
  static from2D(rows) {
    const r = rows.length, c = rows[0].length;
    const d = new Float32Array(r * c);
    rows.forEach((row, i) => row.forEach((v, j) => d[i * c + j] = v));
    return new _Tensor([r, c], d);
  }
};
var Layer = class {
  outputShape(inputShape) {
    return inputShape;
  }
  trainable = true;
};
function _xavier(fan_in, fan_out) {
  const limit = Math.sqrt(6 / (fan_in + fan_out));
  const d = new Float32Array(fan_in * fan_out);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * limit;
  return d;
}
function _he(fan_in, fan_out) {
  const std = Math.sqrt(2 / fan_in);
  const d = new Float32Array(fan_in * fan_out);
  for (let i = 0; i < d.length; i++) {
    const u = 1 - Math.random(), v = Math.random();
    d[i] = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v) * std;
  }
  return d;
}
function _activate(x, act) {
  switch (act) {
    case "relu":
      return x.relu();
    case "sigmoid":
      return x.sigmoid();
    case "tanh":
      return x.tanh();
    case "softmax":
      return x.softmax();
    case "gelu": {
      const d = x.data.map((v) => 0.5 * v * (1 + Math.tanh(Math.sqrt(2 / Math.PI) * (v + 0.044715 * v ** 3))));
      return new Tensor(x.shape, d);
    }
    default:
      return x;
  }
}
var Dense = class extends Layer {
  constructor(units, opts = {}) {
    super();
    this.units = units;
    this.activation = opts.activation ?? "linear";
    const inputDim = opts.inputDim ?? units;
    this.W = new Tensor([inputDim, units], _he(inputDim, units));
    this.b = Tensor.zeros([1, units]);
    this.trainable = opts.trainable ?? true;
  }
  units;
  W;
  b;
  activation;
  forward(x) {
    const out = x.matmul(this.W).add(this.b);
    return _activate(out, this.activation);
  }
  get weights() {
    return [this.W, this.b];
  }
  outputShape(s) {
    return [s[0], this.units];
  }
};
var Flatten = class extends Layer {
  forward(x) {
    return new Tensor([x.shape[0], x.size / x.shape[0]], new Float32Array(x.data));
  }
  get weights() {
    return [];
  }
  outputShape(s) {
    return [s[0], s.slice(1).reduce((a, b) => a * b, 1)];
  }
};
var Dropout = class extends Layer {
  #rate;
  #training = false;
  constructor(rate = 0.5) {
    super();
    this.#rate = rate;
  }
  setTraining(v) {
    this.#training = v;
  }
  forward(x) {
    if (!this.#training) return x;
    const mask = new Float32Array(x.size).map(() => Math.random() > this.#rate ? 1 / (1 - this.#rate) : 0);
    return x.mul(new Tensor(x.shape, mask));
  }
  get weights() {
    return [];
  }
};
var BatchNorm = class extends Layer {
  gamma;
  beta;
  #running_mean;
  #running_var;
  #momentum;
  #training = false;
  #dim;
  constructor(dim, opts = {}) {
    super();
    this.#dim = dim;
    this.#momentum = opts.momentum ?? 0.1;
    this.gamma = Tensor.ones([1, dim]);
    this.beta = Tensor.zeros([1, dim]);
    this.#running_mean = new Float32Array(dim);
    this.#running_var = new Float32Array(dim).fill(1);
  }
  setTraining(v) {
    this.#training = v;
  }
  forward(x) {
    const [n, d] = x.shape;
    const mean = new Float32Array(d), vari = new Float32Array(d);
    for (let j = 0; j < d; j++) {
      let m = 0, v = 0;
      for (let i = 0; i < n; i++) m += x.data[i * d + j];
      m /= n;
      for (let i = 0; i < n; i++) v += (x.data[i * d + j] - m) ** 2;
      v /= n;
      mean[j] = m;
      vari[j] = v;
    }
    if (this.#training) {
      for (let j = 0; j < d; j++) {
        this.#running_mean[j] = (1 - this.#momentum) * this.#running_mean[j] + this.#momentum * mean[j];
        this.#running_var[j] = (1 - this.#momentum) * this.#running_var[j] + this.#momentum * vari[j];
      }
    }
    const usedMean = this.#training ? mean : this.#running_mean;
    const usedVar = this.#training ? vari : this.#running_var;
    const out = new Float32Array(n * d);
    for (let i = 0; i < n; i++) for (let j = 0; j < d; j++) {
      const norm = (x.data[i * d + j] - usedMean[j]) / Math.sqrt(usedVar[j] + 1e-5);
      out[i * d + j] = this.gamma.data[j] * norm + this.beta.data[j];
    }
    return new Tensor([n, d], out);
  }
  get weights() {
    return [this.gamma, this.beta];
  }
};
var LayerNormLayer = class extends Layer {
  gamma;
  beta;
  constructor(dim) {
    super();
    this.gamma = Tensor.ones([1, dim]);
    this.beta = Tensor.zeros([1, dim]);
  }
  forward(x) {
    return x.layerNorm().mul(this.gamma).add(this.beta);
  }
  get weights() {
    return [this.gamma, this.beta];
  }
};
var Embedding = class extends Layer {
  E;
  constructor(vocabSize, dim) {
    super();
    this.E = Tensor.randn([vocabSize, dim]).mul(0.01);
  }
  forward(x) {
    const rowArrays = Array.from(x.data).map((idx) => Array.from(this.E.data.slice(Math.floor(idx) * this.E.shape[1], (Math.floor(idx) + 1) * this.E.shape[1])));
    const rows = [];
    for (const r of rowArrays) for (const v of r) rows.push(v);
    return new Tensor([x.size, this.E.shape[1]], new Float32Array(rows));
  }
  get weights() {
    return [this.E];
  }
};
var Attention = class extends Layer {
  Wq;
  Wk;
  Wv;
  Wo;
  #heads;
  #dim;
  #headDim;
  constructor(dim, heads = 8) {
    super();
    this.#dim = dim;
    this.#heads = heads;
    this.#headDim = Math.floor(dim / heads);
    this.Wq = new Tensor([dim, dim], _xavier(dim, dim));
    this.Wk = new Tensor([dim, dim], _xavier(dim, dim));
    this.Wv = new Tensor([dim, dim], _xavier(dim, dim));
    this.Wo = new Tensor([dim, dim], _xavier(dim, dim));
  }
  forward(x, mask) {
    const [seq, dim] = x.shape;
    const Q = x.matmul(this.Wq);
    const K = x.matmul(this.Wk);
    const V2 = x.matmul(this.Wv);
    const scale = Math.sqrt(this.#headDim);
    const scores = Q.matmul(K.transpose()).mul(1 / scale);
    const masked = mask ? scores.add(mask) : scores;
    const attn = masked.softmax();
    return attn.matmul(V2).matmul(this.Wo);
  }
  get weights() {
    return [this.Wq, this.Wk, this.Wv, this.Wo];
  }
};
var GRU = class extends Layer {
  Wz;
  Wr;
  Wh;
  Uz;
  Ur;
  Uh;
  bz;
  br;
  bh;
  #units;
  constructor(units, inputDim) {
    super();
    this.#units = units;
    const w = (r, c) => new Tensor([r, c], _xavier(r, c));
    const b = (n) => Tensor.zeros([1, n]);
    this.Wz = w(inputDim, units);
    this.Wr = w(inputDim, units);
    this.Wh = w(inputDim, units);
    this.Uz = w(units, units);
    this.Ur = w(units, units);
    this.Uh = w(units, units);
    this.bz = b(units);
    this.br = b(units);
    this.bh = b(units);
  }
  forward(x) {
    const seq = x.shape[0];
    let h = Tensor.zeros([1, this.#units]);
    for (let t = 0; t < seq; t++) {
      const xt = x.slice([t, 0], [t + 1, x.shape[1]]);
      const z = xt.matmul(this.Wz).add(h.matmul(this.Uz)).add(this.bz).sigmoid();
      const r = xt.matmul(this.Wr).add(h.matmul(this.Ur)).add(this.br).sigmoid();
      const hc = xt.matmul(this.Wh).add(r.mul(h).matmul(this.Uh)).add(this.bh).tanh();
      h = z.neg().add(1).mul(hc).add(z.mul(h));
    }
    return h;
  }
  get weights() {
    return [this.Wz, this.Wr, this.Wh, this.Uz, this.Ur, this.Uh, this.bz, this.br, this.bh];
  }
};
var Sequential = class {
  layers = [];
  #lr = 1e-3;
  #loss = "mse";
  #opt = "adam";
  // Adam state
  #m = [];
  #v = [];
  #t = 0;
  add(layer) {
    this.layers.push(layer);
    return this;
  }
  compile(opts = {}) {
    this.#loss = opts.loss ?? "mse";
    this.#opt = opts.optimizer ?? "adam";
    this.#lr = opts.lr ?? 1e-3;
    const ws = this.layers.flatMap((l) => l.weights);
    this.#m = ws.map((w) => new Float32Array(w.size));
    this.#v = ws.map((w) => new Float32Array(w.size));
    return this;
  }
  predict(x) {
    let out = x;
    for (const layer of this.layers) out = layer.forward(out);
    return out;
  }
  #computeLoss(pred, target) {
    switch (this.#loss) {
      case "mae":
        return pred.sub(target).abs().mean();
      case "crossEntropy":
        return pred.log().mul(target).neg().mean();
      case "binaryCrossEntropy": {
        const p = pred.data, t = target.data;
        let l = 0;
        for (let i = 0; i < p.length; i++) l -= t[i] * Math.log(p[i] + 1e-8) + (1 - t[i]) * Math.log(1 - p[i] + 1e-8);
        return l / p.length;
      }
      default: {
        const d = pred.sub(target);
        return d.mul(d).mean();
      }
    }
  }
  #gradW(layer, x, delta) {
    const dW = x.transpose().matmul(delta);
    const db = new Tensor([1, delta.shape[1]], delta.data.reduce((a, v, i) => {
      a[i % delta.shape[1]] = (a[i % delta.shape[1]] ?? 0) + v;
      return a;
    }, []).map((v) => v / delta.shape[0]));
    return { dW, db };
  }
  #adamUpdate(ws, grads) {
    this.#t++;
    const b1 = 0.9, b2 = 0.999, eps = 1e-8;
    ws.forEach((w, wi) => {
      const g = grads[wi].data;
      for (let i = 0; i < g.length; i++) {
        this.#m[wi][i] = b1 * this.#m[wi][i] + (1 - b1) * g[i];
        this.#v[wi][i] = b2 * this.#v[wi][i] + (1 - b2) * g[i] ** 2;
        const mh = this.#m[wi][i] / (1 - b1 ** this.#t);
        const vh = this.#v[wi][i] / (1 - b2 ** this.#t);
        w.data[i] -= this.#lr * mh / (Math.sqrt(vh) + eps);
      }
    });
  }
  async fit(x, y, opts = {}) {
    const epochs = opts.epochs ?? 10;
    const batchSize = opts.batchSize ?? 32;
    const losses = [];
    for (let ep = 0; ep < epochs; ep++) {
      let epochLoss = 0, batches = 0;
      for (let b = 0; b < x.shape[0]; b += batchSize) {
        const end = Math.min(b + batchSize, x.shape[0]);
        const xb = x.slice([b, 0], [end, x.shape[1]]);
        const yb = y.slice([b, 0], [end, y.shape[1]]);
        const pred = this.predict(xb);
        epochLoss += this.#computeLoss(pred, yb);
        batches++;
        let delta = pred.sub(yb).mul(2 / xb.shape[0]);
        const denseWs = [], denseGs = [];
        const denseLayers = this.layers.filter((l) => l instanceof Dense);
        const inputs = [xb];
        let cur = xb;
        for (const l of denseLayers) {
          cur = l.forward(cur);
          inputs.push(cur);
        }
        for (let li = denseLayers.length - 1; li >= 0; li--) {
          const inp = inputs[li];
          const { dW, db } = this.#gradW(denseLayers[li], inp, delta);
          denseWs.push(denseLayers[li].W, denseLayers[li].b);
          denseGs.push(dW, db);
          delta = delta.matmul(denseLayers[li].W.transpose());
        }
        if (denseWs.length) this.#adamUpdate(denseWs, denseGs);
      }
      const loss = epochLoss / batches;
      losses.push(loss);
      if (opts.verbose) console.log(`Epoch ${ep + 1}/${epochs} \u2014 loss: ${loss.toFixed(6)}`);
      opts.onEpoch?.(ep + 1, loss);
    }
    return losses;
  }
};
var TransformerBlock = class {
  attn;
  ff1;
  ff2;
  ln1;
  ln2;
  constructor(dim, heads, ffDim) {
    this.attn = new Attention(dim, heads);
    this.ff1 = new Dense(ffDim, { activation: "gelu", inputDim: dim });
    this.ff2 = new Dense(dim, { activation: "linear", inputDim: ffDim });
    this.ln1 = new LayerNormLayer(dim);
    this.ln2 = new LayerNormLayer(dim);
  }
  forward(x, mask) {
    const attnOut = this.attn.forward(x, mask);
    const x1 = this.ln1.forward(x.add(attnOut));
    const ffOut = this.ff2.forward(this.ff1.forward(x1));
    return this.ln2.forward(x1.add(ffOut));
  }
  get weights() {
    return [...this.attn.weights, ...this.ff1.weights, ...this.ff2.weights, ...this.ln1.weights, ...this.ln2.weights];
  }
};
var Transformer = class {
  #cfg;
  embedding;
  posEmb;
  blocks;
  lmHead;
  constructor(cfg) {
    this.#cfg = { ffDim: cfg.dim * 4, dropout: 0.1, ...cfg };
    const { vocabSize, dim, heads, layers, maxSeqLen, ffDim } = this.#cfg;
    this.embedding = new Embedding(vocabSize, dim);
    this.posEmb = this.#sinusoidalPE(maxSeqLen, dim);
    this.blocks = Array.from({ length: layers }, () => new TransformerBlock(dim, heads, ffDim));
    this.lmHead = new Dense(vocabSize, { inputDim: dim });
  }
  #sinusoidalPE(seq, dim) {
    const pe = new Float32Array(seq * dim);
    for (let pos = 0; pos < seq; pos++)
      for (let i = 0; i < dim; i += 2) {
        const angle = pos / Math.pow(1e4, i / dim);
        pe[pos * dim + i] = Math.sin(angle);
        pe[pos * dim + i + 1] = Math.cos(angle);
      }
    return new Tensor([seq, dim], pe);
  }
  #causalMask(seq) {
    const d = new Float32Array(seq * seq);
    for (let i = 0; i < seq; i++) for (let j = i + 1; j < seq; j++) d[i * seq + j] = -1e9;
    return new Tensor([seq, seq], d);
  }
  forward(tokenIds) {
    const seq = tokenIds.length;
    let x = this.embedding.forward(new Tensor([seq], new Float32Array(tokenIds)));
    const pe = this.posEmb.slice([0, 0], [seq, this.#cfg.dim]);
    x = x.add(pe);
    const mask = this.#causalMask(seq);
    for (const block of this.blocks) x = block.forward(x, mask);
    return this.lmHead.forward(x);
  }
  /**
   * Generate text tokens given a prompt (token ids).
   * @param promptIds  - Initial token ids
   * @param maxNew     - Max new tokens to generate
   * @param temperature- Sampling temperature (default: 1.0)
   * @param topK       - Top-K sampling (default: 40)
   */
  generate(promptIds, maxNew = 50, temperature = 1, topK = 40) {
    const ids = [...promptIds];
    for (let i = 0; i < maxNew; i++) {
      const ctx = ids.slice(-this.#cfg.maxSeqLen);
      const logits = this.forward(ctx);
      const last = logits.slice([ctx.length - 1, 0], [ctx.length, this.#cfg.vocabSize]);
      const scaled = last.mul(1 / temperature);
      const probs = scaled.softmax();
      const topKIdx = Array.from(probs.data).map((p, i2) => [p, i2]).sort((a, b) => b[0] - a[0]).slice(0, topK);
      const total = topKIdx.reduce((s, [p]) => s + p, 0);
      let rand = Math.random() * total;
      let next = topKIdx[0][1];
      for (const [p, idx] of topKIdx) {
        rand -= p;
        if (rand <= 0) {
          next = idx;
          break;
        }
      }
      ids.push(next);
    }
    return ids.slice(promptIds.length);
  }
};
var Tokenizer = class _Tokenizer {
  #vocab = /* @__PURE__ */ new Map();
  #inverse = /* @__PURE__ */ new Map();
  #unk;
  #bos;
  #eos;
  constructor() {
    this.#vocab.set("[UNK]", 0);
    this.#inverse.set(0, "[UNK]");
    this.#vocab.set("[BOS]", 1);
    this.#inverse.set(1, "[BOS]");
    this.#vocab.set("[EOS]", 2);
    this.#inverse.set(2, "[EOS]");
    this.#vocab.set("[PAD]", 3);
    this.#inverse.set(3, "[PAD]");
    this.#unk = 0;
    this.#bos = 1;
    this.#eos = 2;
  }
  /** Train on corpus text — builds character or word vocabulary. */
  fit(text, mode = "word") {
    const tokens = mode === "char" ? [...text] : text.split(/\s+/);
    for (const t of tokens) if (!this.#vocab.has(t)) {
      const id = this.#vocab.size;
      this.#vocab.set(t, id);
      this.#inverse.set(id, t);
    }
    return this;
  }
  encode(text, mode = "word", addSpecial = false) {
    const tokens = mode === "char" ? [...text] : text.split(/\s+/);
    const ids = tokens.map((t) => this.#vocab.get(t) ?? this.#unk);
    return addSpecial ? [this.#bos, ...ids, this.#eos] : ids;
  }
  decode(ids, mode = "word") {
    const tokens = ids.map((id) => this.#inverse.get(id) ?? "[UNK]").filter((t) => !["[BOS]", "[EOS]", "[PAD]"].includes(t));
    return mode === "char" ? tokens.join("") : tokens.join(" ");
  }
  get vocabSize() {
    return this.#vocab.size;
  }
  toJSON() {
    return { vocab: Object.fromEntries(this.#vocab) };
  }
  static fromJSON(json) {
    const t = new _Tokenizer();
    for (const [k, v] of Object.entries(json.vocab)) {
      t.addToken(k, v);
    }
    return t;
  }
  addToken(k, v) {
    this.#vocab.set(k, v);
    this.#inverse.set(v, k);
  }
};
var MarkovChain = class {
  #table = /* @__PURE__ */ new Map();
  #order;
  constructor(order = 2) {
    this.#order = order;
  }
  train(text, mode = "word") {
    const tokens = mode === "char" ? [...text] : text.split(/\s+/);
    for (let i = 0; i < tokens.length - this.#order; i++) {
      const key = tokens.slice(i, i + this.#order).join("\0");
      const next = tokens[i + this.#order];
      if (!this.#table.has(key)) this.#table.set(key, /* @__PURE__ */ new Map());
      const m = this.#table.get(key);
      m.set(next, (m.get(next) ?? 0) + 1);
    }
    return this;
  }
  generate(seed, length = 50, mode = "word") {
    const tokens = [...seed];
    for (let i = 0; i < length; i++) {
      const key = tokens.slice(-this.#order).join("\0");
      const m = this.#table.get(key);
      if (!m || m.size === 0) break;
      const total = Array.from(m.values()).reduce((a, b) => a + b, 0);
      let rand = Math.random() * total;
      let next = m.keys().next().value;
      for (const [tok, cnt] of m) {
        rand -= cnt;
        if (rand <= 0) {
          next = tok;
          break;
        }
      }
      tokens.push(next);
    }
    return tokens.slice(seed.length);
  }
};
var AIUtils = {
  oneHot(indices, depth) {
    const d = new Float32Array(indices.length * depth);
    indices.forEach((idx, i) => {
      d[i * depth + idx] = 1;
    });
    return new Tensor([indices.length, depth], d);
  },
  normalize(t, min = 0, max = 1) {
    const tmin = t.min(), tmax = t.max(), range = tmax - tmin || 1;
    return t.sub(tmin).div(range).mul(max - min).add(min);
  },
  standardize(t) {
    const mean = t.mean();
    const std = Math.sqrt(t.sub(mean).mul(t.sub(mean)).mean());
    return t.sub(mean).div(std || 1);
  },
  shuffle(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  },
  trainTestSplit(x, y, testRatio = 0.2) {
    const n = x.shape[0];
    const split = Math.floor(n * (1 - testRatio));
    return {
      xTrain: x.slice([0, 0], [split, x.shape[1]]),
      yTrain: y.slice([0, 0], [split, y.shape[1]]),
      xTest: x.slice([split, 0], [n, x.shape[1]]),
      yTest: y.slice([split, 0], [n, y.shape[1]])
    };
  },
  accuracy(pred, target) {
    let correct = 0;
    const n = pred.shape[0], c = pred.shape[1];
    for (let i = 0; i < n; i++) {
      const pi = pred.slice([i, 0], [i + 1, c]).argmax();
      const ti = target.slice([i, 0], [i + 1, c]).argmax();
      if (pi === ti) correct++;
    }
    return correct / n;
  }
};
var AI = {
  Tensor,
  Dense,
  Flatten,
  Dropout,
  BatchNorm,
  LayerNorm: LayerNormLayer,
  Embedding,
  Attention,
  GRU,
  Sequential,
  Transformer,
  TransformerBlock,
  Tokenizer,
  MarkovChain,
  utils: AIUtils
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "AI")) {
  try {
    Object.defineProperty(window, "AI", { value: AI, writable: false, enumerable: false, configurable: false });
  } catch {
  }
}
var AI_default = AI;

// additionals/Animation.ts
var AnimationLoop = class {
  _elements = {};
  _frames = [];
  _frameRate;
  _duration;
  _id = false;
  _running = false;
  _callbacks = {
    onAnimation: (_frame) => {
    },
    onAnimationStart: (_frame) => {
    },
    onAnimationStop: () => {
    },
    onAnimationIteration: () => {
    }
  };
  constructor(opts = {}) {
    this._frameRate = opts.frameRate ?? 60;
    this._duration = 1 / this._frameRate;
  }
  // Original Golem callbacks
  get onAnimation() {
    return this._callbacks.onAnimation;
  }
  set onAnimation(fn) {
    this._callbacks.onAnimation = fn;
  }
  get onAnimationStart() {
    return this._callbacks.onAnimationStart;
  }
  set onAnimationStart(fn) {
    this._callbacks.onAnimationStart = fn;
  }
  get onAnimationStop() {
    return this._callbacks.onAnimationStop;
  }
  set onAnimationStop(fn) {
    this._callbacks.onAnimationStop = fn;
  }
  get onAnimationIteration() {
    return this._callbacks.onAnimationIteration;
  }
  set onAnimationIteration(fn) {
    this._callbacks.onAnimationIteration = fn;
  }
  get IsRunning() {
    return this._running;
  }
  get Frames() {
    return this._frames;
  }
  get FrameRate() {
    return this._frameRate;
  }
  // Original Golem Add/Remove element
  Add(id, el) {
    this._elements[id] = el;
    return this;
  }
  Remove(id) {
    delete this._elements[id];
    return this;
  }
  // Original Golem Start — migrated from IIFE function
  Start(_args) {
    if (this._running) return this;
    this._running = true;
    const animate = (_time) => {
      if (!this._running) return;
      const frameIndex = this._frames.length;
      const frame = {
        Name: `AriannA-Frame-${frameIndex}`,
        Duration: this._duration,
        Rate: this._frameRate,
        Index: frameIndex,
        Elements: this._elements,
        Keyframe: false
      };
      this._frames.push(frame);
      if (frameIndex === 0) {
        this._callbacks.onAnimationStart(frame);
      }
      this._callbacks.onAnimation(frame);
      if (frameIndex > 0 && frameIndex % this._frameRate === 0) {
        this._callbacks.onAnimationIteration();
      }
      this._id = requestAnimationFrame(animate);
    };
    this._id = requestAnimationFrame(animate);
    return this;
  }
  // Original Golem Stop — migrated
  Stop(id) {
    this._running = false;
    const cancelId = id !== void 0 ? typeof id === "string" ? parseInt(id) : id : this._id || 0;
    cancelAnimationFrame(cancelId);
    this._id = false;
    this._callbacks.onAnimationStop();
    return this;
  }
  Reset() {
    this._frames = [];
    return this;
  }
};
var Easing = {
  linear: (t) => t,
  easeInQuad: (t) => t * t,
  easeOutQuad: (t) => t * (2 - t),
  easeInOutQuad: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  easeInCubic: (t) => t * t * t,
  easeOutCubic: (t) => --t * t * t + 1,
  easeInOutCubic: (t) => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
  easeInQuart: (t) => t * t * t * t,
  easeOutQuart: (t) => 1 - --t * t * t * t,
  easeInExpo: (t) => t === 0 ? 0 : Math.pow(2, 10 * t - 10),
  easeOutExpo: (t) => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
  easeInOutExpo: (t) => t === 0 ? 0 : t === 1 ? 1 : t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2,
  easeOutBack: (t) => {
    const c1 = 1.70158, c3 = c1 + 1;
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2;
  },
  easeOutBounce: (t) => {
    const n = 7.5625, d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
    if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
    return n * (t -= 2.625 / d) * t + 0.984375;
  },
  easeOutElastic: (t) => {
    if (t === 0 || t === 1) return t;
    return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1;
  }
};
var Tween = class {
  _from = {};
  _to = {};
  _target;
  _opts;
  _start = 0;
  _running = false;
  _raf = 0;
  _reps = 0;
  _forward = true;
  constructor(target, opts) {
    this._target = target;
    this._opts = opts;
    for (const [key, val] of Object.entries(opts)) {
      if (Array.isArray(val) && val.length === 2) {
        this._from[key] = val[0];
        this._to[key] = val[1];
        target[key] = val[0];
      }
    }
    setTimeout(() => this.play(), (opts.delay ?? 0) * 1e3);
  }
  play() {
    this._running = true;
    this._start = performance.now();
    this._tick();
    return this;
  }
  pause() {
    this._running = false;
    cancelAnimationFrame(this._raf);
    return this;
  }
  stop() {
    this.pause();
    this._reps = 0;
    this._forward = true;
    return this;
  }
  _tick() {
    if (!this._running) return;
    const elapsed = (performance.now() - this._start) / 1e3;
    const t = Math.min(elapsed / this._opts.duration, 1);
    const easeFn = typeof this._opts.easing === "function" ? this._opts.easing : Easing[this._opts.easing ?? "linear"] ?? Easing.linear;
    const e = this._forward ? easeFn(t) : easeFn(1 - t);
    for (const key of Object.keys(this._from)) {
      this._target[key] = this._from[key] + (this._to[key] - this._from[key]) * e;
    }
    this._opts.onUpdate?.(t);
    if (t >= 1) {
      this._reps++;
      const maxReps = this._opts.repeat === "infinite" ? Infinity : (this._opts.repeat ?? 0) + 1;
      if (this._reps < maxReps) {
        if (this._opts.yoyo) this._forward = !this._forward;
        this._start = performance.now();
        this._raf = requestAnimationFrame(() => this._tick());
      } else {
        this._running = false;
        this._opts.onComplete?.();
      }
    } else {
      this._raf = requestAnimationFrame(() => this._tick());
    }
  }
};
var Spring = class {
  _pos;
  _vel = 0;
  _target;
  _opts;
  _cb;
  _running = false;
  _raf = 0;
  constructor(from, to, opts = {}, onUpdate) {
    this._pos = from;
    this._target = to;
    this._cb = onUpdate;
    this._opts = {
      stiffness: opts.stiffness ?? 150,
      damping: opts.damping ?? 20,
      mass: opts.mass ?? 1,
      precision: opts.precision ?? 1e-3
    };
    this.play();
  }
  setTarget(to) {
    this._target = to;
    if (!this._running) this.play();
    return this;
  }
  play() {
    this._running = true;
    let last = performance.now();
    const tick = (now) => {
      const dt = Math.min((now - last) / 1e3, 0.064);
      last = now;
      const force = -this._opts.stiffness * (this._pos - this._target) - this._opts.damping * this._vel;
      this._vel += force / this._opts.mass * dt;
      this._pos += this._vel * dt;
      this._cb(this._pos);
      if (Math.abs(this._vel) < this._opts.precision && Math.abs(this._pos - this._target) < this._opts.precision) {
        this._pos = this._target;
        this._cb(this._pos);
        this._running = false;
      } else {
        this._raf = requestAnimationFrame(tick);
      }
    };
    this._raf = requestAnimationFrame(tick);
    return this;
  }
  pause() {
    this._running = false;
    cancelAnimationFrame(this._raf);
    return this;
  }
};
var Timeline = class {
  _items = [];
  _duration = 0;
  add(tween, at) {
    const t = typeof at === "string" ? this._duration + parseFloat(at.slice(2)) : at;
    this._items.push({ tween, at: t });
    this._duration = Math.max(this._duration, t + tween._opts.duration);
    return this;
  }
  play() {
    const start = performance.now();
    this._items.forEach(({ tween, at }) => {
      setTimeout(() => tween.play(), at * 1e3);
    });
    return this;
  }
};
var Animation = {
  name: "Animation",
  version: "1.0.0",
  install(_core) {
    try {
      Object.assign(window, { AnimationLoop, Easing, Tween, Spring, Timeline });
    } catch {
    }
  }
};
var Animation_default = Animation;

// additionals/Audio.ts
var AudioEngine = class {
  #ctx = null;
  #master = null;
  #compressor = null;
  get context() {
    if (!this.#ctx) {
      this.#ctx = new AudioContext();
      this.#master = this.#ctx.createGain();
      this.#compressor = this.#ctx.createDynamicsCompressor();
      this.#master.connect(this.#compressor);
      this.#compressor.connect(this.#ctx.destination);
    }
    return this.#ctx;
  }
  get master() {
    this.context;
    return this.#master;
  }
  get destination() {
    return this.master;
  }
  async resume() {
    if (this.#ctx?.state === "suspended") await this.#ctx.resume();
  }
  async suspend() {
    await this.#ctx?.suspend();
  }
  close() {
    this.#ctx?.close();
    this.#ctx = null;
  }
  get time() {
    return this.#ctx?.currentTime ?? 0;
  }
  set volume(v) {
    if (this.#master) this.#master.gain.value = Math.max(0, Math.min(1, v));
  }
  get volume() {
    return this.#master?.gain.value ?? 1;
  }
};
var _engine = new AudioEngine();
var AudioPlayer = class {
  #buf = null;
  #src = null;
  #gain;
  #engine;
  constructor(engine = _engine) {
    this.#engine = engine;
    this.#gain = engine.context.createGain();
    this.#gain.connect(engine.destination);
  }
  async load(src) {
    const ctx = this.#engine.context;
    let ab;
    if (src instanceof ArrayBuffer) {
      ab = src;
    } else if (src instanceof Blob) {
      ab = await src.arrayBuffer();
    } else {
      ab = await (await fetch(src)).arrayBuffer();
    }
    this.#buf = await ctx.decodeAudioData(ab);
    return this;
  }
  play(offset = 0, duration) {
    this.#engine.resume();
    this.stop();
    const ctx = this.#engine.context;
    this.#src = ctx.createBufferSource();
    this.#src.buffer = this.#buf;
    this.#src.connect(this.#gain);
    this.#src.start(0, offset, duration);
    return this;
  }
  stop() {
    try {
      this.#src?.stop();
    } catch {
    }
    this.#src = null;
    return this;
  }
  set volume(v) {
    this.#gain.gain.value = Math.max(0, v);
  }
  get volume() {
    return this.#gain.gain.value;
  }
  set loop(v) {
    if (this.#src) this.#src.loop = v;
  }
  set playbackRate(r) {
    if (this.#src) this.#src.playbackRate.value = r;
  }
  connect(node) {
    this.#gain.disconnect();
    this.#gain.connect(node);
    return this;
  }
  get buffer() {
    return this.#buf;
  }
  get duration() {
    return this.#buf?.duration ?? 0;
  }
};
var AudioRecorder = class {
  #stream = null;
  #recorder = null;
  #chunks = [];
  async start(constraints = { audio: true }) {
    this.#stream = await navigator.mediaDevices.getUserMedia(constraints);
    this.#chunks = [];
    this.#recorder = new MediaRecorder(this.#stream);
    this.#recorder.ondataavailable = (e) => {
      if (e.data.size > 0) this.#chunks.push(e.data);
    };
    this.#recorder.start();
    return this;
  }
  async stop() {
    return new Promise((res) => {
      if (!this.#recorder) {
        res(new Blob());
        return;
      }
      this.#recorder.onstop = () => res(new Blob(this.#chunks, { type: "audio/webm" }));
      this.#recorder.stop();
      this.#stream?.getTracks().forEach((t) => t.stop());
    });
  }
};
var Oscillator = class {
  #osc = null;
  #gain;
  #engine;
  #type;
  #freq;
  constructor(freq = 440, type = "sine", engine = _engine) {
    this.#engine = engine;
    this.#type = type;
    this.#freq = freq;
    this.#gain = engine.context.createGain();
    this.#gain.connect(engine.destination);
  }
  start(volume = 0.5) {
    this.#engine.resume();
    this.stop();
    const ctx = this.#engine.context;
    this.#osc = ctx.createOscillator();
    this.#osc.type = this.#type;
    this.#osc.frequency.value = this.#freq;
    this.#gain.gain.value = volume;
    this.#osc.connect(this.#gain);
    this.#osc.start();
    return this;
  }
  stop() {
    try {
      this.#osc?.stop();
    } catch {
    }
    this.#osc = null;
    return this;
  }
  set frequency(f) {
    this.#freq = f;
    if (this.#osc) this.#osc.frequency.setValueAtTime(f, this.#engine.context.currentTime);
  }
  set volume(v) {
    this.#gain.gain.value = Math.max(0, v);
  }
  set detune(cents) {
    if (this.#osc) this.#osc.detune.value = cents;
  }
  connect(node) {
    this.#gain.disconnect();
    this.#gain.connect(node);
    return this;
  }
};
var NoiseGenerator = class {
  #script = null;
  #gain;
  #engine;
  #noiseType;
  #b0 = 0;
  #b1 = 0;
  #b2 = 0;
  #b3 = 0;
  #b4 = 0;
  #b5 = 0;
  #b6 = 0;
  #lastOut = 0;
  constructor(type = "white", engine = _engine) {
    this.#engine = engine;
    this.#noiseType = type;
    this.#gain = engine.context.createGain();
    this.#gain.connect(engine.destination);
  }
  start(volume = 0.1) {
    this.stop();
    const ctx = this.#engine.context;
    this.#script = ctx.createScriptProcessor(4096, 1, 1);
    this.#script.onaudioprocess = (e) => {
      const out = e.outputBuffer.getChannelData(0);
      for (let i = 0; i < out.length; i++) {
        const white = Math.random() * 2 - 1;
        if (this.#noiseType === "white") {
          out[i] = white;
        } else if (this.#noiseType === "pink") {
          this.#b0 = 0.99886 * this.#b0 + white * 0.0555179;
          this.#b1 = 0.99332 * this.#b1 + white * 0.0750759;
          this.#b2 = 0.969 * this.#b2 + white * 0.153852;
          this.#b3 = 0.8665 * this.#b3 + white * 0.3104856;
          this.#b4 = 0.55 * this.#b4 + white * 0.5329522;
          this.#b5 = -0.7616 * this.#b5 - white * 0.016898;
          out[i] = (this.#b0 + this.#b1 + this.#b2 + this.#b3 + this.#b4 + this.#b5 + this.#b6 + white * 0.5362) * 0.11;
          this.#b6 = white * 0.115926;
        } else {
          out[i] = this.#lastOut = (this.#lastOut + 0.02 * white) / 1.02;
        }
      }
    };
    this.#gain.gain.value = volume;
    this.#script.connect(this.#gain);
    return this;
  }
  stop() {
    this.#script?.disconnect();
    this.#script = null;
    return this;
  }
  set volume(v) {
    this.#gain.gain.value = Math.max(0, v);
  }
};
var Reverb = class {
  #convolver;
  #wet;
  #dry;
  #output;
  constructor(engine = _engine, opts = {}) {
    const ctx = engine.context;
    const decay = opts.decay ?? 2;
    const sr = ctx.sampleRate, len = Math.round(decay * sr);
    const buf = ctx.createBuffer(2, len, sr);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
    this.#convolver = ctx.createConvolver();
    this.#convolver.buffer = buf;
    this.#wet = ctx.createGain();
    this.#dry = ctx.createGain();
    this.#output = ctx.createGain();
    this.#wet.gain.value = opts.wet ?? 0.3;
    this.#dry.gain.value = 1 - (opts.wet ?? 0.3);
    this.#convolver.connect(this.#wet);
    this.#wet.connect(this.#output);
    this.#dry.connect(this.#output);
  }
  get input() {
    return this.#dry;
  }
  get output() {
    return this.#output;
  }
  set wet(v) {
    this.#wet.gain.value = Math.max(0, Math.min(1, v));
    this.#dry.gain.value = 1 - v;
  }
};
var Delay = class {
  #node;
  #gain;
  #output;
  constructor(engine = _engine, opts = {}) {
    const ctx = engine.context;
    this.#node = ctx.createDelay(5);
    this.#node.delayTime.value = opts.time ?? 0.3;
    this.#gain = ctx.createGain();
    this.#gain.gain.value = opts.feedback ?? 0.4;
    this.#output = ctx.createGain();
    this.#node.connect(this.#gain);
    this.#gain.connect(this.#node);
    this.#node.connect(this.#output);
  }
  get input() {
    return this.#node;
  }
  get output() {
    return this.#output;
  }
  set time(t) {
    this.#node.delayTime.value = Math.max(0, Math.min(5, t));
  }
  set feedback(v) {
    this.#gain.gain.value = Math.max(0, Math.min(0.99, v));
  }
};
var Filter = class {
  #node;
  constructor(engine = _engine, opts = {}) {
    this.#node = engine.context.createBiquadFilter();
    this.#node.type = opts.type ?? "lowpass";
    this.#node.frequency.value = opts.freq ?? 1e3;
    this.#node.Q.value = opts.Q ?? 1;
    this.#node.gain.value = opts.gain ?? 0;
  }
  get node() {
    return this.#node;
  }
  set frequency(f) {
    this.#node.frequency.value = f;
  }
  set Q(v) {
    this.#node.Q.value = v;
  }
};
var Analyser = class {
  #node;
  #fftBuf;
  #timeBuf;
  constructor(engine = _engine, fftSize = 2048) {
    this.#node = engine.context.createAnalyser();
    this.#node.fftSize = fftSize;
    this.#fftBuf = new Float32Array(this.#node.frequencyBinCount);
    this.#timeBuf = new Float32Array(fftSize);
    engine.destination.connect(this.#node);
  }
  get node() {
    return this.#node;
  }
  getSpectrum() {
    this.#node.getFloatFrequencyData(this.#fftBuf);
    return this.#fftBuf;
  }
  getWaveform() {
    this.#node.getFloatTimeDomainData(this.#timeBuf);
    return this.#timeBuf;
  }
  getPeak() {
    return Math.max(...this.getWaveform().map(Math.abs));
  }
  getRMS() {
    const w = this.getWaveform();
    return Math.sqrt(w.reduce((a, v) => a + v * v, 0) / w.length);
  }
};
var Sequencer = class {
  #steps;
  #bpm;
  #interval = null;
  #step = 0;
  #callbacks = [];
  constructor(steps = 16, bpm = 120) {
    this.#steps = new Array(steps).fill(false);
    this.#bpm = bpm;
  }
  set(step, active) {
    this.#steps[step] = active;
    return this;
  }
  setPattern(pattern) {
    this.#steps = [...pattern];
    return this;
  }
  onStep(cb) {
    this.#callbacks.push(cb);
    return this;
  }
  set bpm(v) {
    this.#bpm = v;
    if (this.#interval) {
      this.stop();
      this.start();
    }
  }
  start() {
    this.stop();
    const ms = 60 / this.#bpm / 4 * 1e3;
    this.#interval = setInterval(() => {
      if (this.#steps[this.#step]) this.#callbacks.forEach((cb) => cb(this.#step, _engine.time));
      this.#step = (this.#step + 1) % this.#steps.length;
    }, ms);
    return this;
  }
  stop() {
    if (this.#interval) {
      clearInterval(this.#interval);
      this.#interval = null;
    }
    this.#step = 0;
    return this;
  }
  get currentStep() {
    return this.#step;
  }
};
var Audio = {
  engine: _engine,
  AudioEngine,
  AudioPlayer,
  AudioRecorder,
  Oscillator,
  NoiseGenerator,
  Reverb,
  Delay,
  Filter,
  Analyser,
  Sequencer
};
if (typeof window !== "undefined") {
  try {
    delete window.Audio;
  } catch {
  }
  try {
    window.Audio = Audio;
  } catch {
  }
}
var Audio_default = Audio;

// additionals/Colors.ts
var clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
var clamp01 = (n) => clamp(n, 0, 1);
var wrap360 = (n) => (n % 360 + 360) % 360;
function parseHex(hex) {
  let s = hex.trim().replace(/^#/, "");
  if (s.length === 3) s = s.split("").map((c) => c + c).join("");
  if (s.length !== 6 && s.length !== 8) return null;
  if (!/^[0-9a-fA-F]+$/.test(s)) return null;
  const r = parseInt(s.slice(0, 2), 16);
  const g = parseInt(s.slice(2, 4), 16);
  const b = parseInt(s.slice(4, 6), 16);
  const a = s.length === 8 ? parseInt(s.slice(6, 8), 16) / 255 : 1;
  return { r, g, b, a };
}
function rgbToHex({ r, g, b, a }) {
  const rr = clamp(Math.round(r), 0, 255).toString(16).padStart(2, "0");
  const gg = clamp(Math.round(g), 0, 255).toString(16).padStart(2, "0");
  const bb = clamp(Math.round(b), 0, 255).toString(16).padStart(2, "0");
  if (a !== void 0 && a < 1) {
    const aa = clamp(Math.round(a * 255), 0, 255).toString(16).padStart(2, "0");
    return `#${rr}${gg}${bb}${aa}`;
  }
  return `#${rr}${gg}${bb}`;
}
function rgbToHsl({ r, g, b, a }) {
  const R = r / 255, G = g / 255, B = b / 255;
  const max = Math.max(R, G, B), min = Math.min(R, G, B);
  const l = (max + min) / 2;
  let h = 0, s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case R:
        h = (G - B) / d + (G < B ? 6 : 0);
        break;
      case G:
        h = (B - R) / d + 2;
        break;
      case B:
        h = (R - G) / d + 4;
        break;
    }
    h *= 60;
  }
  return { h: wrap360(h), s: s * 100, l: l * 100, a };
}
function hslToRgb({ h, s, l, a }) {
  const H = wrap360(h) / 360;
  const S = clamp01(s / 100);
  const L = clamp01(l / 100);
  if (S === 0) {
    const v = Math.round(L * 255);
    return { r: v, g: v, b: v, a };
  }
  const q = L < 0.5 ? L * (1 + S) : L + S - L * S;
  const p = 2 * L - q;
  const conv = (t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  return {
    r: Math.round(conv(H + 1 / 3) * 255),
    g: Math.round(conv(H) * 255),
    b: Math.round(conv(H - 1 / 3) * 255),
    a
  };
}
function rgbToHsv({ r, g, b, a }) {
  const R = r / 255, G = g / 255, B = b / 255;
  const max = Math.max(R, G, B), min = Math.min(R, G, B);
  const d = max - min;
  let h = 0;
  const s = max === 0 ? 0 : d / max;
  if (d !== 0) {
    switch (max) {
      case R:
        h = (G - B) / d + (G < B ? 6 : 0);
        break;
      case G:
        h = (B - R) / d + 2;
        break;
      case B:
        h = (R - G) / d + 4;
        break;
    }
    h *= 60;
  }
  return { h: wrap360(h), s: s * 100, v: max * 100, a };
}
function hsvToRgb({ h, s, v, a }) {
  const H = wrap360(h) / 60;
  const S = clamp01(s / 100);
  const V2 = clamp01(v / 100);
  const i = Math.floor(H);
  const f = H - i;
  const p = V2 * (1 - S);
  const q = V2 * (1 - S * f);
  const t = V2 * (1 - S * (1 - f));
  let R = 0, G = 0, B = 0;
  switch (i % 6) {
    case 0:
      R = V2;
      G = t;
      B = p;
      break;
    case 1:
      R = q;
      G = V2;
      B = p;
      break;
    case 2:
      R = p;
      G = V2;
      B = t;
      break;
    case 3:
      R = p;
      G = q;
      B = V2;
      break;
    case 4:
      R = t;
      G = p;
      B = V2;
      break;
    case 5:
      R = V2;
      G = p;
      B = q;
      break;
  }
  return { r: Math.round(R * 255), g: Math.round(G * 255), b: Math.round(B * 255), a };
}
function rgbToCmyk({ r, g, b, a }) {
  const R = clamp01(r / 255), G = clamp01(g / 255), B = clamp01(b / 255);
  const k = 1 - Math.max(R, G, B);
  if (k >= 1) return { c: 0, m: 0, y: 0, k: 100, a };
  const c = (1 - R - k) / (1 - k);
  const m = (1 - G - k) / (1 - k);
  const y = (1 - B - k) / (1 - k);
  return { c: c * 100, m: m * 100, y: y * 100, k: k * 100, a };
}
function cmykToRgb({ c, m, y, k, a }) {
  const C = clamp01(c / 100), M = clamp01(m / 100), Y = clamp01(y / 100), K = clamp01(k / 100);
  const r = 255 * (1 - C) * (1 - K);
  const g = 255 * (1 - M) * (1 - K);
  const b = 255 * (1 - Y) * (1 - K);
  return { r: Math.round(r), g: Math.round(g), b: Math.round(b), a };
}
var srgbToLinear = (v) => v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
var linearToSrgb = (v) => v <= 31308e-7 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055;
function rgbToXyz({ r, g, b, a }) {
  const R = srgbToLinear(r / 255);
  const G = srgbToLinear(g / 255);
  const B = srgbToLinear(b / 255);
  return {
    X: R * 0.4124564 + G * 0.3575761 + B * 0.1804375,
    Y: R * 0.2126729 + G * 0.7151522 + B * 0.072175,
    Z: R * 0.0193339 + G * 0.119192 + B * 0.9503041,
    a
  };
}
function xyzToRgb({ X, Y, Z, a }) {
  const R = X * 3.2404542 - Y * 1.5371385 - Z * 0.4985314;
  const G = -X * 0.969266 + Y * 1.8760108 + Z * 0.041556;
  const B = X * 0.0556434 - Y * 0.2040259 + Z * 1.0572252;
  return {
    r: Math.round(clamp01(linearToSrgb(R)) * 255),
    g: Math.round(clamp01(linearToSrgb(G)) * 255),
    b: Math.round(clamp01(linearToSrgb(B)) * 255),
    a
  };
}
var D65 = { X: 0.95047, Y: 1, Z: 1.08883 };
var U_REF = 4 * D65.X / (D65.X + 15 * D65.Y + 3 * D65.Z);
var V_REF = 9 * D65.Y / (D65.X + 15 * D65.Y + 3 * D65.Z);
function rgbToCieluv(rgb) {
  const xyz = rgbToXyz(rgb);
  const { X, Y, Z, a } = xyz;
  const denom = X + 15 * Y + 3 * Z;
  const u_ = denom === 0 ? 0 : 4 * X / denom;
  const v_ = denom === 0 ? 0 : 9 * Y / denom;
  const Yr = Y / D65.Y;
  const L = Yr > 8856e-6 ? 116 * Math.cbrt(Yr) - 16 : 903.3 * Yr;
  const u = 13 * L * (u_ - U_REF);
  const v = 13 * L * (v_ - V_REF);
  const C = Math.sqrt(u * u + v * v);
  const h = wrap360(Math.atan2(v, u) * 180 / Math.PI);
  return { L, C, h, a };
}
function cieluvToRgb({ L, C, h, a }) {
  const hr = wrap360(h) * Math.PI / 180;
  const u = C * Math.cos(hr);
  const v = C * Math.sin(hr);
  const Y = L > 8 ? D65.Y * Math.pow((L + 16) / 116, 3) : D65.Y * L / 903.3;
  const u_ = U_REF + u / (13 * L);
  const v_ = V_REF + v / (13 * L);
  const X = L === 0 ? 0 : Y * (9 * u_) / (4 * v_);
  const Z = L === 0 ? 0 : Y * (12 - 3 * u_ - 20 * v_) / (4 * v_);
  return xyzToRgb({ X, Y, Z, a });
}
function rgbToOklch({ r, g, b, a }) {
  const R = srgbToLinear(r / 255);
  const G = srgbToLinear(g / 255);
  const B = srgbToLinear(b / 255);
  const l = 0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B;
  const m = 0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B;
  const s = 0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B;
  const l_ = Math.cbrt(l);
  const m_ = Math.cbrt(m);
  const s_ = Math.cbrt(s);
  const L = 0.2104542553 * l_ + 0.793617785 * m_ - 0.0040720468 * s_;
  const aa = 1.9779984951 * l_ - 2.428592205 * m_ + 0.4505937099 * s_;
  const bb = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.808675766 * s_;
  const C = Math.sqrt(aa * aa + bb * bb);
  const h = wrap360(Math.atan2(bb, aa) * 180 / Math.PI);
  return { L, C, h, a };
}
function oklchToRgb({ L, C, h, a }) {
  const hr = wrap360(h) * Math.PI / 180;
  const aa = C * Math.cos(hr);
  const bb = C * Math.sin(hr);
  const l_ = L + 0.3963377774 * aa + 0.2158037573 * bb;
  const m_ = L - 0.1055613458 * aa - 0.0638541728 * bb;
  const s_ = L - 0.0894841775 * aa - 1.291485548 * bb;
  const l = l_ * l_ * l_;
  const m = m_ * m_ * m_;
  const s = s_ * s_ * s_;
  const R = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
  const G = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
  const B = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s;
  return {
    r: Math.round(clamp01(linearToSrgb(R)) * 255),
    g: Math.round(clamp01(linearToSrgb(G)) * 255),
    b: Math.round(clamp01(linearToSrgb(B)) * 255),
    a
  };
}
function rgbToCube({ r, g, b }) {
  return clamp(Math.round(r), 0, 255) << 16 | clamp(Math.round(g), 0, 255) << 8 | clamp(Math.round(b), 0, 255);
}
function cubeToRgb(i) {
  return {
    r: i >> 16 & 255,
    g: i >> 8 & 255,
    b: i & 255
  };
}
function formatCss(space, color) {
  switch (space) {
    case "rgb": {
      const c = color;
      return c.a !== void 0 && c.a < 1 ? `rgba(${c.r}, ${c.g}, ${c.b}, ${c.a})` : `rgb(${c.r}, ${c.g}, ${c.b})`;
    }
    case "hsl": {
      const c = color;
      return c.a !== void 0 && c.a < 1 ? `hsla(${c.h.toFixed(0)}, ${c.s.toFixed(1)}%, ${c.l.toFixed(1)}%, ${c.a})` : `hsl(${c.h.toFixed(0)}, ${c.s.toFixed(1)}%, ${c.l.toFixed(1)}%)`;
    }
    case "hsv":
      return formatCss("hex", hsvToRgb(color));
    case "cmyk":
      return formatCss("hex", cmykToRgb(color));
    case "cieluv": {
      const c = color;
      return `lch(${c.L.toFixed(1)}% ${c.C.toFixed(1)} ${c.h.toFixed(0)})`;
    }
    case "oklch": {
      const c = color;
      return `oklch(${(c.L * 100).toFixed(1)}% ${c.C.toFixed(3)} ${c.h.toFixed(0)})`;
    }
    case "hex":
      return rgbToHex(color);
  }
}
var Colors = {
  // HEX
  parseHex,
  rgbToHex,
  // HSL ⇄ RGB
  rgbToHsl,
  hslToRgb,
  // HSV ⇄ RGB
  rgbToHsv,
  hsvToRgb,
  // CMYK ⇄ RGB
  rgbToCmyk,
  cmykToRgb,
  // CIELUV ⇄ RGB
  rgbToCieluv,
  cieluvToRgb,
  // OKLCH ⇄ RGB
  rgbToOklch,
  oklchToRgb,
  // Cube ⇄ RGB
  rgbToCube,
  cubeToRgb,
  // CSS formatter
  formatCss
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Colors")) {
  try {
    Object.defineProperty(window, "Colors", {
      value: Colors,
      writable: false,
      enumerable: false,
      configurable: false
    });
  } catch {
  }
}
var Colors_default = Colors;

// additionals/Data.ts
var DAG = class {
  #nodes = /* @__PURE__ */ new Map();
  addNode(n) {
    if (!this.#nodes.has(n)) this.#nodes.set(n, /* @__PURE__ */ new Set());
    return this;
  }
  addEdge(from, to) {
    this.addNode(from);
    this.addNode(to);
    if (this.#wouldCycle(from, to)) throw new Error(`DAG cycle: ${from} \u2192 ${to}`);
    this.#nodes.get(from).add(to);
    return this;
  }
  #wouldCycle(from, to) {
    const visited = /* @__PURE__ */ new Set();
    const dfs = (n) => {
      if (n === from) return true;
      if (visited.has(n)) return false;
      visited.add(n);
      for (const next of this.#nodes.get(n) ?? []) if (dfs(next)) return true;
      return false;
    };
    return dfs(to);
  }
  /** Kahn's algorithm topological sort. */
  topoSort() {
    const inDegree = /* @__PURE__ */ new Map();
    for (const n of this.#nodes.keys()) inDegree.set(n, 0);
    for (const [, edges] of this.#nodes) for (const e of edges) inDegree.set(e, (inDegree.get(e) ?? 0) + 1);
    const queue = [...inDegree.entries()].filter(([, d]) => d === 0).map(([n]) => n);
    const result = [];
    while (queue.length) {
      const n = queue.shift();
      result.push(n);
      for (const next of this.#nodes.get(n) ?? []) {
        const d = (inDegree.get(next) ?? 1) - 1;
        inDegree.set(next, d);
        if (d === 0) queue.push(next);
      }
    }
    if (result.length !== this.#nodes.size) throw new Error("DAG cycle detected in topoSort");
    return result;
  }
  /** Ancestors of a node (all nodes that have a path TO it). */
  ancestors(node) {
    const result = /* @__PURE__ */ new Set();
    const dfs = (n) => {
      for (const [from, edges] of this.#nodes) {
        if (edges.has(n) && !result.has(from)) {
          result.add(from);
          dfs(from);
        }
      }
    };
    dfs(node);
    return result;
  }
  /** Descendants of a node. */
  descendants(node) {
    const result = /* @__PURE__ */ new Set();
    const dfs = (n) => {
      for (const next of this.#nodes.get(n) ?? []) if (!result.has(next)) {
        result.add(next);
        dfs(next);
      }
    };
    dfs(node);
    return result;
  }
  get nodes() {
    return [...this.#nodes.keys()];
  }
  edges() {
    const out = [];
    for (const [f, es] of this.#nodes) for (const t of es) out.push([f, t]);
    return out;
  }
};
var Graph = class {
  #adj = /* @__PURE__ */ new Map();
  #directed;
  constructor(directed = true) {
    this.#directed = directed;
  }
  addNode(id) {
    if (!this.#adj.has(id)) this.#adj.set(id, []);
    return this;
  }
  addEdge(from, to, weight = 1) {
    this.addNode(from);
    this.addNode(to);
    this.#adj.get(from).push({ to, weight });
    if (!this.#directed) this.#adj.get(to).push({ to: from, weight });
    return this;
  }
  bfs(start) {
    const visited = /* @__PURE__ */ new Set([start]), queue = [start], out = [start];
    while (queue.length) {
      const n = queue.shift();
      for (const { to } of this.#adj.get(n) ?? []) if (!visited.has(to)) {
        visited.add(to);
        queue.push(to);
        out.push(to);
      }
    }
    return out;
  }
  dfs(start) {
    const visited = /* @__PURE__ */ new Set(), out = [];
    const rec = (n) => {
      visited.add(n);
      out.push(n);
      for (const { to } of this.#adj.get(n) ?? []) if (!visited.has(to)) rec(to);
    };
    rec(start);
    return out;
  }
  /** Dijkstra shortest paths from start. Returns { dist, prev } maps. */
  dijkstra(start) {
    const dist = /* @__PURE__ */ new Map();
    const prev = /* @__PURE__ */ new Map();
    const pq = new PriorityQueue((a, b) => a.d - b.d);
    for (const id of this.#adj.keys()) {
      dist.set(id, Infinity);
      prev.set(id, null);
    }
    dist.set(start, 0);
    pq.push({ id: start, d: 0 });
    while (!pq.empty()) {
      const { id, d } = pq.pop();
      if (d > dist.get(id)) continue;
      for (const { to, weight } of this.#adj.get(id) ?? []) {
        const nd = d + weight;
        if (nd < dist.get(to)) {
          dist.set(to, nd);
          prev.set(to, id);
          pq.push({ id: to, d: nd });
        }
      }
    }
    return { dist, prev };
  }
  /** A* shortest path. heuristic(node) → estimated cost to goal. */
  aStar(start, goal, heuristic) {
    const gScore = /* @__PURE__ */ new Map([[start, 0]]);
    const fScore = /* @__PURE__ */ new Map([[start, heuristic(start)]]);
    const prev = /* @__PURE__ */ new Map();
    const open = new PriorityQueue((a, b) => a.f - b.f);
    open.push({ id: start, f: heuristic(start) });
    while (!open.empty()) {
      const { id } = open.pop();
      if (id === goal) {
        const path = [goal];
        let cur = goal;
        while (prev.has(cur)) {
          cur = prev.get(cur);
          path.unshift(cur);
        }
        return path;
      }
      for (const { to, weight } of this.#adj.get(id) ?? []) {
        const ng = (gScore.get(id) ?? Infinity) + weight;
        if (ng < (gScore.get(to) ?? Infinity)) {
          prev.set(to, id);
          gScore.set(to, ng);
          const f = ng + heuristic(to);
          fScore.set(to, f);
          open.push({ id: to, f });
        }
      }
    }
    return null;
  }
  get nodeCount() {
    return this.#adj.size;
  }
};
var FSM = class {
  #state;
  #initial;
  #trans;
  #history = [];
  #listeners = /* @__PURE__ */ new Map();
  #maxHistory;
  constructor(initial, transitions, maxHistory = 50) {
    this.#state = initial;
    this.#initial = initial;
    this.#trans = transitions;
    this.#maxHistory = maxHistory;
  }
  get state() {
    return this.#state;
  }
  get history() {
    return [...this.#history];
  }
  /** Send an event. Returns true if a transition fired. */
  send(event, ctx) {
    const match = this.#trans.find(
      (t) => (t.from === "*" || t.from === this.#state) && t.event === event && (!t.guard || t.guard(ctx))
    );
    if (!match) return false;
    const from = this.#state;
    match.action?.(ctx, event);
    this.#state = match.to;
    this.#history.push(from);
    if (this.#history.length > this.#maxHistory) this.#history.shift();
    const key = `${from}\u2192${match.to}`;
    this.#listeners.get(key)?.forEach((fn) => fn(from, match.to, event));
    this.#listeners.get("*")?.forEach((fn) => fn(from, match.to, event));
    return true;
  }
  /** Returns all events valid from current state. */
  validEvents() {
    return this.#trans.filter((t) => t.from === "*" || t.from === this.#state).map((t) => t.event);
  }
  /** Can we go back? (if previous state reachable via any transition) */
  canUndo() {
    return this.#history.length > 0;
  }
  undo(ctx) {
    const prev = this.#history.pop();
    if (!prev) return false;
    this.#state = prev;
    return true;
  }
  reset() {
    this.#state = this.#initial;
    this.#history = [];
    return this;
  }
  on(transition, fn) {
    const key = transition;
    if (!this.#listeners.has(key)) this.#listeners.set(key, []);
    this.#listeners.get(key).push(fn);
    return () => {
      const arr = this.#listeners.get(key) ?? [];
      this.#listeners.set(key, arr.filter((l) => l !== fn));
    };
  }
  /** Export to DOT format for visualization. */
  toDOT(name = "FSM") {
    const edges = this.#trans.map((t) => `  "${t.from}" -> "${t.to}" [label="${t.event}"];`).join("\n");
    return `digraph ${name} {
  rankdir=LR;
  "${this.#state}" [shape=doublecircle];
${edges}
}`;
  }
};
var Trie = class {
  #root = { children: /* @__PURE__ */ new Map(), isEnd: false };
  #size = 0;
  insert(key, value) {
    let node = this.#root;
    for (const ch of key) {
      if (!node.children.has(ch)) node.children.set(ch, { children: /* @__PURE__ */ new Map(), isEnd: false });
      node = node.children.get(ch);
    }
    if (!node.isEnd) this.#size++;
    node.isEnd = true;
    node.value = value;
    return this;
  }
  get(key) {
    let node = this.#root;
    for (const ch of key) {
      node = node.children.get(ch);
      if (!node) return void 0;
    }
    return node.isEnd ? node.value : void 0;
  }
  has(key) {
    return this.get(key) !== void 0 || this.#find(key)?.isEnd === true;
  }
  #find(key) {
    let node = this.#root;
    for (const ch of key) {
      const n = node.children.get(ch);
      if (!n) return null;
      node = n;
    }
    return node;
  }
  /** All keys with given prefix. */
  autocomplete(prefix, limit = 20) {
    const node = this.#find(prefix);
    if (!node) return [];
    const results = [];
    const dfs = (n, path) => {
      if (results.length >= limit) return;
      if (n.isEnd) results.push(path);
      for (const [ch, child] of n.children) dfs(child, path + ch);
    };
    dfs(node, prefix);
    return results;
  }
  delete(key) {
    const stack = [];
    let node = this.#root;
    for (const ch of key) {
      const n = node.children.get(ch);
      if (!n) return false;
      stack.push([node, ch]);
      node = n;
    }
    if (!node.isEnd) return false;
    node.isEnd = false;
    this.#size--;
    for (let i = stack.length - 1; i >= 0; i--) {
      const [parent, ch] = stack[i];
      const child = parent.children.get(ch);
      if (child.children.size === 0 && !child.isEnd) parent.children.delete(ch);
      else break;
    }
    return true;
  }
  get size() {
    return this.#size;
  }
  longestPrefix(query) {
    let node = this.#root, longest = "";
    for (let i = 0; i < query.length; i++) {
      const n = node.children.get(query[i]);
      if (!n) break;
      node = n;
      if (node.isEnd) longest = query.slice(0, i + 1);
    }
    return longest;
  }
};
var PriorityQueue = class _PriorityQueue {
  #heap = [];
  #cmp;
  constructor(comparator = (a, b) => a - b) {
    this.#cmp = comparator;
  }
  push(item) {
    this.#heap.push(item);
    this.#bubbleUp(this.#heap.length - 1);
    return this;
  }
  pop() {
    if (!this.#heap.length) return void 0;
    const top = this.#heap[0];
    const last = this.#heap.pop();
    if (this.#heap.length) {
      this.#heap[0] = last;
      this.#sinkDown(0);
    }
    return top;
  }
  peek() {
    return this.#heap[0];
  }
  get size() {
    return this.#heap.length;
  }
  empty() {
    return this.#heap.length === 0;
  }
  #bubbleUp(i) {
    while (i > 0) {
      const parent = i - 1 >> 1;
      if (this.#cmp(this.#heap[i], this.#heap[parent]) >= 0) break;
      [this.#heap[i], this.#heap[parent]] = [this.#heap[parent], this.#heap[i]];
      i = parent;
    }
  }
  #sinkDown(i) {
    const n = this.#heap.length;
    while (true) {
      let smallest = i;
      const l = 2 * i + 1, r = 2 * i + 2;
      if (l < n && this.#cmp(this.#heap[l], this.#heap[smallest]) < 0) smallest = l;
      if (r < n && this.#cmp(this.#heap[r], this.#heap[smallest]) < 0) smallest = r;
      if (smallest === i) break;
      [this.#heap[i], this.#heap[smallest]] = [this.#heap[smallest], this.#heap[i]];
      i = smallest;
    }
  }
  toSortedArray() {
    const clone = new _PriorityQueue(this.#cmp);
    clone.#heap = [...this.#heap];
    const out = [];
    while (!clone.empty()) out.push(clone.pop());
    return out;
  }
};
var Deque = class {
  #buf;
  #head;
  #tail;
  #size;
  #cap;
  constructor(initialCapacity = 16) {
    this.#cap = initialCapacity;
    this.#buf = new Array(initialCapacity);
    this.#head = 0;
    this.#tail = 0;
    this.#size = 0;
  }
  pushFront(item) {
    this.#grow();
    this.#head = (this.#head - 1 + this.#cap) % this.#cap;
    this.#buf[this.#head] = item;
    this.#size++;
  }
  pushBack(item) {
    this.#grow();
    this.#buf[this.#tail] = item;
    this.#tail = (this.#tail + 1) % this.#cap;
    this.#size++;
  }
  popFront() {
    if (!this.#size) return void 0;
    const v = this.#buf[this.#head];
    this.#buf[this.#head] = void 0;
    this.#head = (this.#head + 1) % this.#cap;
    this.#size--;
    return v;
  }
  popBack() {
    if (!this.#size) return void 0;
    this.#tail = (this.#tail - 1 + this.#cap) % this.#cap;
    const v = this.#buf[this.#tail];
    this.#buf[this.#tail] = void 0;
    this.#size--;
    return v;
  }
  peekFront() {
    return this.#buf[this.#head];
  }
  peekBack() {
    return this.#buf[(this.#tail - 1 + this.#cap) % this.#cap];
  }
  get size() {
    return this.#size;
  }
  isEmpty() {
    return this.#size === 0;
  }
  #grow() {
    if (this.#size < this.#cap) return;
    const newCap = this.#cap * 2;
    const newBuf = new Array(newCap);
    for (let i = 0; i < this.#size; i++) newBuf[i] = this.#buf[(this.#head + i) % this.#cap];
    this.#buf = newBuf;
    this.#head = 0;
    this.#tail = this.#size;
    this.#cap = newCap;
  }
};
var LRUCache = class {
  #cap;
  #cache;
  constructor(capacity) {
    this.#cap = capacity;
    this.#cache = /* @__PURE__ */ new Map();
  }
  get(key) {
    if (!this.#cache.has(key)) return void 0;
    const val = this.#cache.get(key);
    this.#cache.delete(key);
    this.#cache.set(key, val);
    return val;
  }
  put(key, value) {
    if (this.#cache.has(key)) this.#cache.delete(key);
    else if (this.#cache.size >= this.#cap) this.#cache.delete(this.#cache.keys().next().value);
    this.#cache.set(key, value);
  }
  has(key) {
    return this.#cache.has(key);
  }
  delete(key) {
    return this.#cache.delete(key);
  }
  clear() {
    this.#cache.clear();
  }
  get size() {
    return this.#cache.size;
  }
  get capacity() {
    return this.#cap;
  }
  /** Keys from least to most recently used. */
  keys() {
    return this.#cache.keys();
  }
};
var SegmentTree = class {
  #n;
  #tree;
  #lazy;
  #op;
  constructor(data, op = "sum") {
    this.#n = data.length;
    this.#op = op;
    this.#tree = new Array(4 * this.#n).fill(op === "min" ? Infinity : op === "max" ? -Infinity : 0);
    this.#lazy = new Array(4 * this.#n).fill(0);
    this.#build(data, 1, 0, this.#n - 1);
  }
  #combine(a, b) {
    return this.#op === "sum" ? a + b : this.#op === "min" ? Math.min(a, b) : Math.max(a, b);
  }
  #build(data, node, start, end) {
    if (start === end) {
      this.#tree[node] = data[start];
      return;
    }
    const mid = start + end >> 1;
    this.#build(data, 2 * node, start, mid);
    this.#build(data, 2 * node + 1, mid + 1, end);
    this.#tree[node] = this.#combine(this.#tree[2 * node], this.#tree[2 * node + 1]);
  }
  query(l, r) {
    return this.#query(1, 0, this.#n - 1, l, r);
  }
  #query(node, start, end, l, r) {
    if (r < start || end < l) return this.#op === "min" ? Infinity : this.#op === "max" ? -Infinity : 0;
    if (l <= start && end <= r) return this.#tree[node];
    const mid = start + end >> 1;
    return this.#combine(
      this.#query(2 * node, start, mid, l, r),
      this.#query(2 * node + 1, mid + 1, end, l, r)
    );
  }
  update(i, val) {
    this.#update(1, 0, this.#n - 1, i, val);
  }
  #update(node, start, end, i, val) {
    if (start === end) {
      this.#tree[node] = val;
      return;
    }
    const mid = start + end >> 1;
    if (i <= mid) this.#update(2 * node, start, mid, i, val);
    else this.#update(2 * node + 1, mid + 1, end, i, val);
    this.#tree[node] = this.#combine(this.#tree[2 * node], this.#tree[2 * node + 1]);
  }
  get length() {
    return this.#n;
  }
};
var DisjointSet = class {
  #parent;
  #rank;
  #count;
  constructor(n) {
    this.#parent = Array.from({ length: n }, (_, i) => i);
    this.#rank = new Array(n).fill(0);
    this.#count = n;
  }
  find(x) {
    if (this.#parent[x] !== x) this.#parent[x] = this.find(this.#parent[x]);
    return this.#parent[x];
  }
  union(x, y) {
    const px = this.find(x), py = this.find(y);
    if (px === py) return false;
    if (this.#rank[px] < this.#rank[py]) this.#parent[px] = py;
    else if (this.#rank[px] > this.#rank[py]) this.#parent[py] = px;
    else {
      this.#parent[py] = px;
      this.#rank[px]++;
    }
    this.#count--;
    return true;
  }
  connected(x, y) {
    return this.find(x) === this.find(y);
  }
  get componentCount() {
    return this.#count;
  }
};
var ObservableMap = class extends Map {
  #listeners = [];
  subscribe(fn) {
    this.#listeners.push(fn);
    return () => {
      this.#listeners = this.#listeners.filter((l) => l !== fn);
    };
  }
  #emit(e) {
    this.#listeners.forEach((l) => l(e));
  }
  set(key, value) {
    super.set(key, value);
    this.#emit({ type: "set", key, value });
    return this;
  }
  delete(key) {
    const r = super.delete(key);
    if (r) this.#emit({ type: "delete", key });
    return r;
  }
  clear() {
    super.clear();
    this.#emit({ type: "clear" });
  }
};
var ObservableArray = class _ObservableArray extends Array {
  #listeners = [];
  subscribe(fn) {
    this.#listeners.push(fn);
    return () => {
      this.#listeners = this.#listeners.filter((l) => l !== fn);
    };
  }
  #emit(e) {
    this.#listeners.forEach((l) => l(e));
  }
  push(...items) {
    const r = super.push(...items);
    this.#emit({ type: "push", items });
    return r;
  }
  pop() {
    const r = super.pop();
    this.#emit({ type: "pop", removed: r !== void 0 ? [r] : [] });
    return r;
  }
  splice(start, deleteCount, ...items) {
    const removed = deleteCount !== void 0 ? super.splice(start, deleteCount, ...items) : super.splice(start);
    this.#emit({ type: "splice", index: start, items, removed });
    return removed;
  }
  static from(arr) {
    const oa = new _ObservableArray();
    oa.push(...arr);
    return oa;
  }
};
var Data = {
  DAG,
  Graph,
  FSM,
  Trie,
  PriorityQueue,
  Deque,
  LRUCache,
  SegmentTree,
  DisjointSet,
  ObservableMap,
  ObservableArray
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Data")) {
  try {
    Object.defineProperty(window, "Data", {
      value: Data,
      writable: false,
      enumerable: false,
      configurable: false
    });
  } catch {
  }
}
var Data_default = Data;

// additionals/Finance.ts
var _finGPU = null;
async function _getFinGPU() {
  if (_finGPU) return _finGPU;
  const nav = navigator;
  if (!nav.gpu) return null;
  const adapter = await nav.gpu.requestAdapter();
  if (!adapter) return null;
  _finGPU = await adapter.requestDevice();
  return _finGPU;
}
var Indicators = {
  sma(series, period) {
    const out = new Array(period - 1).fill(NaN);
    for (let i = period - 1; i < series.length; i++) {
      let s = 0;
      for (let j = 0; j < period; j++) s += series[i - j];
      out.push(s / period);
    }
    return out;
  },
  ema(series, period) {
    const k = 2 / (period + 1);
    const out = [];
    let prev = series[0];
    for (const v of series) {
      prev = v * k + prev * (1 - k);
      out.push(prev);
    }
    return out;
  },
  wma(series, period) {
    const out = new Array(period - 1).fill(NaN);
    const denom = period * (period + 1) / 2;
    for (let i = period - 1; i < series.length; i++) {
      let s = 0;
      for (let j = 0; j < period; j++) s += series[i - j] * (period - j);
      out.push(s / denom);
    }
    return out;
  },
  dema(series, period) {
    const e1 = Indicators.ema(series, period);
    const e2 = Indicators.ema(e1, period);
    return e1.map((v, i) => 2 * v - e2[i]);
  },
  tema(series, period) {
    const e1 = Indicators.ema(series, period);
    const e2 = Indicators.ema(e1, period);
    const e3 = Indicators.ema(e2, period);
    return e1.map((v, i) => 3 * v - 3 * e2[i] + e3[i]);
  },
  rsi(series, period = 14) {
    const out = new Array(period).fill(NaN);
    let avgGain = 0, avgLoss = 0;
    for (let i = 1; i <= period; i++) {
      const d = series[i] - series[i - 1];
      if (d > 0) avgGain += d;
      else avgLoss -= d;
    }
    avgGain /= period;
    avgLoss /= period;
    for (let i = period; i < series.length; i++) {
      const d = series[i] - series[i - 1];
      const g = d > 0 ? d : 0, l = d < 0 ? -d : 0;
      avgGain = (avgGain * (period - 1) + g) / period;
      avgLoss = (avgLoss * (period - 1) + l) / period;
      out.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));
    }
    return out;
  },
  macd(series, fast = 12, slow = 26, signal = 9) {
    const eFast = Indicators.ema(series, fast);
    const eSlow = Indicators.ema(series, slow);
    const macd = eFast.map((v, i) => v - eSlow[i]);
    const sig = Indicators.ema(macd, signal);
    const hist = macd.map((v, i) => v - sig[i]);
    return { macd, signal: sig, histogram: hist };
  },
  bollinger(series, period = 20, stdMult = 2) {
    const middle = Indicators.sma(series, period);
    const upper = [], lower = [], bw = [];
    for (let i = 0; i < series.length; i++) {
      if (i < period - 1) {
        upper.push(NaN);
        lower.push(NaN);
        bw.push(NaN);
        continue;
      }
      let variance = 0;
      for (let j = 0; j < period; j++) variance += (series[i - j] - middle[i]) ** 2;
      const std = Math.sqrt(variance / period);
      upper.push(middle[i] + stdMult * std);
      lower.push(middle[i] - stdMult * std);
      bw.push((upper[i] - lower[i]) / middle[i]);
    }
    return { upper, middle, lower, bandwidth: bw };
  },
  atr(bars, period = 14) {
    const tr = [bars[0].high - bars[0].low];
    for (let i = 1; i < bars.length; i++) {
      tr.push(Math.max(bars[i].high - bars[i].low, Math.abs(bars[i].high - bars[i - 1].close), Math.abs(bars[i].low - bars[i - 1].close)));
    }
    return Indicators.ema(tr, period);
  },
  stochastic(bars, kPeriod = 14, dPeriod = 3) {
    const k = new Array(kPeriod - 1).fill(NaN);
    for (let i = kPeriod - 1; i < bars.length; i++) {
      const slice = bars.slice(i - kPeriod + 1, i + 1);
      const lo = Math.min(...slice.map((b) => b.low));
      const hi = Math.max(...slice.map((b) => b.high));
      k.push(hi === lo ? 50 : 100 * (bars[i].close - lo) / (hi - lo));
    }
    return { k, d: Indicators.sma(k.filter((v) => !isNaN(v)), dPeriod) };
  },
  vwap(bars) {
    let cumPV = 0, cumV = 0;
    return bars.map((b) => {
      const tp = (b.high + b.low + b.close) / 3;
      cumPV += tp * b.volume;
      cumV += b.volume;
      return cumV === 0 ? tp : cumPV / cumV;
    });
  },
  obv(bars) {
    let obv = 0;
    return bars.map((b, i) => {
      if (i > 0) obv += bars[i].close > bars[i - 1].close ? b.volume : bars[i].close < bars[i - 1].close ? -b.volume : 0;
      return obv;
    });
  },
  cci(bars, period = 20) {
    const out = new Array(period - 1).fill(NaN);
    for (let i = period - 1; i < bars.length; i++) {
      const slice = bars.slice(i - period + 1, i + 1);
      const tp = slice.map((b) => (b.high + b.low + b.close) / 3);
      const mean = tp.reduce((a, b) => a + b, 0) / period;
      const md = tp.reduce((a, b) => a + Math.abs(b - mean), 0) / period;
      out.push((tp[tp.length - 1] - mean) / (0.015 * md));
    }
    return out;
  },
  williamsR(bars, period = 14) {
    const out = new Array(period - 1).fill(NaN);
    for (let i = period - 1; i < bars.length; i++) {
      const sl = bars.slice(i - period + 1, i + 1);
      const hi = Math.max(...sl.map((b) => b.high));
      const lo = Math.min(...sl.map((b) => b.low));
      out.push(hi === lo ? -50 : -100 * (hi - bars[i].close) / (hi - lo));
    }
    return out;
  },
  adx(bars, period = 14) {
    const tr = [], dmPlus = [], dmMinus = [];
    for (let i = 1; i < bars.length; i++) {
      const b = bars[i], p = bars[i - 1];
      tr.push(Math.max(b.high - b.low, Math.abs(b.high - p.close), Math.abs(b.low - p.close)));
      const up = b.high - p.high, down = p.low - b.low;
      dmPlus.push(up > down && up > 0 ? up : 0);
      dmMinus.push(down > up && down > 0 ? down : 0);
    }
    const atr14 = Indicators.ema(tr, period);
    const smoothP = Indicators.ema(dmPlus, period);
    const smoothM = Indicators.ema(dmMinus, period);
    const diPlus = smoothP.map((v, i) => atr14[i] ? 100 * v / atr14[i] : 0);
    const diMinus = smoothM.map((v, i) => atr14[i] ? 100 * v / atr14[i] : 0);
    const dx = diPlus.map((p, i) => {
      const s = p + diMinus[i];
      return s ? 100 * Math.abs(p - diMinus[i]) / s : 0;
    });
    return { adx: Indicators.ema(dx, period), diPlus, diMinus };
  }
};
var Portfolio = {
  returns(prices) {
    return prices.slice(1).map((p, i) => (p - prices[i]) / prices[i]);
  },
  logReturns(prices) {
    return prices.slice(1).map((p, i) => Math.log(p / prices[i]));
  },
  sharpe(returns, riskFree = 0, annualize = 252) {
    const excess = returns.map((r) => r - riskFree / annualize);
    const mean = excess.reduce((a, v) => a + v, 0) / excess.length;
    const std = Math.sqrt(excess.reduce((a, v) => a + (v - mean) ** 2, 0) / excess.length);
    return std ? mean / std * Math.sqrt(annualize) : 0;
  },
  sortino(returns, riskFree = 0, annualize = 252) {
    const excess = returns.map((r) => r - riskFree / annualize);
    const mean = excess.reduce((a, v) => a + v, 0) / excess.length;
    const downDev = Math.sqrt(excess.filter((r) => r < 0).reduce((a, v) => a + v ** 2, 0) / excess.length);
    return downDev ? mean / downDev * Math.sqrt(annualize) : 0;
  },
  maxDrawdown(equity) {
    let peak = equity[0], maxDD = 0;
    for (const v of equity) {
      if (v > peak) peak = v;
      maxDD = Math.max(maxDD, (peak - v) / peak);
    }
    return maxDD;
  },
  calmar(returns, equity, annualize = 252) {
    const ann = returns.reduce((a, v) => a + v, 0) / returns.length * annualize;
    const dd = Portfolio.maxDrawdown(equity);
    return dd ? ann / dd : 0;
  },
  /** Minimum variance portfolio weights (Markowitz). */
  minVariance(covMatrix, expectedReturns) {
    const n = expectedReturns.length;
    let w = new Array(n).fill(1 / n);
    const lr = 0.01, iters = 1e3;
    for (let it = 0; it < iters; it++) {
      const grad = new Array(n).fill(0);
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) grad[i] += 2 * covMatrix[i][j] * w[j];
      const step = grad.map((g) => g * lr);
      w = w.map((v, i) => Math.max(0, v - step[i]));
      const sum = w.reduce((a, v) => a + v, 0);
      w = w.map((v) => v / sum);
    }
    return w;
  },
  /** Maximum Sharpe ratio portfolio (tangency portfolio). */
  maxSharpe(covMatrix, expectedReturns, riskFree = 0) {
    const n = expectedReturns.length;
    let w = new Array(n).fill(1 / n);
    const lr = 1e-3, iters = 2e3;
    const computeSharpe = (weights) => {
      const ret = weights.reduce((a, v, i) => a + v * expectedReturns[i], 0);
      let variance = 0;
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) variance += weights[i] * weights[j] * covMatrix[i][j];
      const std = Math.sqrt(variance);
      return std ? (ret - riskFree) / std : 0;
    };
    for (let it = 0; it < iters; it++) {
      const grad = new Array(n).fill(0);
      const baseSharpe = computeSharpe(w);
      for (let i = 0; i < n; i++) {
        const wPlus = [...w];
        wPlus[i] += 1e-5;
        const wSum = wPlus.reduce((a, v) => a + v, 0);
        const wNorm = wPlus.map((v) => v / wSum);
        grad[i] = (computeSharpe(wNorm) - baseSharpe) / 1e-5;
      }
      w = w.map((v, i) => Math.max(0, v + grad[i] * lr));
      const sum = w.reduce((a, v) => a + v, 0);
      w = w.map((v) => v / sum);
    }
    return w;
  },
  covarianceMatrix(returnSeries) {
    const n = returnSeries.length;
    const means = returnSeries.map((s) => s.reduce((a, v) => a + v, 0) / s.length);
    const cov = Array.from({ length: n }, () => new Array(n).fill(0));
    const T = returnSeries[0].length;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      for (let t = 0; t < T; t++) cov[i][j] += (returnSeries[i][t] - means[i]) * (returnSeries[j][t] - means[j]);
      cov[i][j] /= T - 1;
    }
    return cov;
  }
};
function _norm(x) {
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x);
  const t = 1 / (1 + p * x);
  const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return 0.5 * (1 + sign * y);
}
function _normPDF(x) {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}
var BlackScholes = {
  /** Price a European call or put option. */
  price(S, K, T, r, sigma, type = "call") {
    const d1 = (Math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * Math.sqrt(T));
    const d2 = d1 - sigma * Math.sqrt(T);
    return type === "call" ? S * _norm(d1) - K * Math.exp(-r * T) * _norm(d2) : K * Math.exp(-r * T) * _norm(-d2) - S * _norm(-d1);
  },
  /** Full Greeks for call or put. */
  greeks(S, K, T, r, sigma, type = "call") {
    const sqrtT = Math.sqrt(T);
    const d1 = (Math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * sqrtT);
    const d2 = d1 - sigma * sqrtT;
    const phi = _normPDF(d1);
    const delta = type === "call" ? _norm(d1) : _norm(d1) - 1;
    const gamma = phi / (S * sigma * sqrtT);
    const vega = S * phi * sqrtT / 100;
    const theta = type === "call" ? (-S * phi * sigma / (2 * sqrtT) - r * K * Math.exp(-r * T) * _norm(d2)) / 365 : (-S * phi * sigma / (2 * sqrtT) + r * K * Math.exp(-r * T) * _norm(-d2)) / 365;
    const rho = type === "call" ? K * T * Math.exp(-r * T) * _norm(d2) / 100 : -K * T * Math.exp(-r * T) * _norm(-d2) / 100;
    return { delta, gamma, vega, theta, rho, d1, d2 };
  },
  /** Implied volatility via Brent's method. */
  impliedVol(marketPrice, S, K, T, r, type = "call") {
    let lo = 1e-3, hi = 5, mid = 0;
    for (let i = 0; i < 100; i++) {
      mid = (lo + hi) / 2;
      const price = BlackScholes.price(S, K, T, r, mid, type);
      if (Math.abs(price - marketPrice) < 1e-6) break;
      if (price > marketPrice) hi = mid;
      else lo = mid;
    }
    return mid;
  },
  /** Binomial tree option pricing. */
  binomialTree(S, K, T, r, sigma, steps = 100, type = "call", american = false) {
    const dt = T / steps, u = Math.exp(sigma * Math.sqrt(dt));
    const d = 1 / u, p = (Math.exp(r * dt) - d) / (u - d);
    const disc = Math.exp(-r * dt);
    let prices = Array.from({ length: steps + 1 }, (_, i) => S * Math.pow(u, steps - 2 * i));
    let values = prices.map((s) => type === "call" ? Math.max(0, s - K) : Math.max(0, K - s));
    for (let step = steps - 1; step >= 0; step--) {
      prices = Array.from({ length: step + 1 }, (_, i) => S * Math.pow(u, step - 2 * i));
      values = values.slice(0, step + 1).map((v, i) => {
        const cont = disc * (p * v + (1 - p) * values[i + 1]);
        return american ? Math.max(cont, type === "call" ? prices[i] - K : K - prices[i]) : cont;
      });
    }
    return values[0];
  }
};
var MonteCarlo = {
  /** CPU Monte Carlo option pricing. */
  option(S, K, T, r, sigma, paths = 1e5, type = "call") {
    const dt = T / 252, sqrtDt = Math.sqrt(dt);
    const steps = Math.round(T * 252);
    let sum = 0, sum2 = 0;
    for (let p = 0; p < paths; p++) {
      let S_ = S;
      for (let t = 0; t < steps; t++) {
        const z = _boxMuller();
        S_ *= Math.exp((r - 0.5 * sigma ** 2) * dt + sigma * sqrtDt * z);
      }
      const payoff = type === "call" ? Math.max(0, S_ - K) : Math.max(0, K - S_);
      sum += payoff;
      sum2 += payoff ** 2;
    }
    const mean = sum / paths * Math.exp(-r * T);
    const std = Math.sqrt((sum2 / paths - (sum / paths) ** 2) * Math.exp(-2 * r * T));
    return { price: mean, stdError: std / Math.sqrt(paths) };
  },
  /** GPU-accelerated Monte Carlo via WebGPU compute. ~100x paths/sec vs CPU. */
  async optionGPU(S, K, T, r, sigma, paths = 1e6, type = "call") {
    const device = await _getFinGPU();
    if (!device) return MonteCarlo.option(S, K, T, r, sigma, Math.min(paths, 1e5), type);
    const steps = Math.round(T * 252);
    const WGSL = `
@group(0) @binding(0) var<storage,read_write> results: array<f32>;
struct Params { S: f32, K: f32, T: f32, r: f32, sigma: f32, steps: u32, isCall: u32, paths: u32, seed: u32 }
@group(0) @binding(1) var<uniform> p: Params;

fn rand(state: ptr<function,u32>) -> f32 {
    *state ^= (*state << 13u); *state ^= (*state >> 17u); *state ^= (*state << 5u);
    return f32(*state) / 4294967295.0;
}
fn normSample(state: ptr<function,u32>) -> f32 {
    let u1 = max(rand(state), 1e-7); let u2 = rand(state);
    return sqrt(-2.0*log(u1))*cos(6.28318530718*u2);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if (idx >= p.paths) { return; }
    var state = p.seed ^ (idx * 2654435761u);
    let dt = p.T / f32(p.steps);
    let sqrtDt = sqrt(dt);
    var S_ = p.S;
    for (var t = 0u; t < p.steps; t++) {
        S_ *= exp((p.r - 0.5*p.sigma*p.sigma)*dt + p.sigma*sqrtDt*normSample(&state));
    }
    let payoff = select(max(0.0, p.K - S_), max(0.0, S_ - p.K), p.isCall == 1u);
    results[idx] = payoff * exp(-p.r * p.T);
}`;
    const resultBuf = device.createBuffer({ size: paths * 4, usage: 128 | 4 });
    const paramData = new Float32Array(8);
    paramData.set([S, K, T, r, sigma]);
    const paramU32 = new Uint32Array(paramData.buffer);
    paramU32[5] = steps;
    paramU32[6] = type === "call" ? 1 : 0;
    paramU32[7] = paths;
    const paramBuf = device.createBuffer({ size: 36, usage: 64 | 8, mappedAtCreation: true });
    new Uint8Array(paramBuf.getMappedRange()).set(new Uint8Array(paramData.buffer));
    paramBuf.unmap();
    const seedBuf = device.createBuffer({ size: 4, usage: 64 | 8, mappedAtCreation: true });
    new Uint32Array(seedBuf.getMappedRange()).set([Math.floor(Math.random() * 4294967295)]);
    seedBuf.unmap();
    const bgl = device.createBindGroupLayout({ entries: [
      { binding: 0, visibility: 4, buffer: { type: "storage" } },
      { binding: 1, visibility: 4, buffer: { type: "uniform" } }
    ] });
    const pipeline = device.createComputePipeline({
      layout: device.createPipelineLayout({ bindGroupLayouts: [bgl] }),
      compute: { module: device.createShaderModule({ code: WGSL }), entryPoint: "main" }
    });
    const bg = device.createBindGroup({ layout: bgl, entries: [
      { binding: 0, resource: { buffer: resultBuf } },
      { binding: 1, resource: { buffer: paramBuf } }
    ] });
    const enc = device.createCommandEncoder();
    const pass = enc.beginComputePass();
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bg);
    pass.dispatchWorkgroups(Math.ceil(paths / 64));
    pass.end();
    device.queue.submit([enc.finish()]);
    await device.queue.onSubmittedWorkDone();
    const readBuf = device.createBuffer({ size: paths * 4, usage: 1 | 8 });
    const enc2 = device.createCommandEncoder();
    enc2.copyBufferToBuffer(resultBuf, 0, readBuf, 0, paths * 4);
    device.queue.submit([enc2.finish()]);
    await device.queue.onSubmittedWorkDone();
    const ab = readBuf.getMappedRange();
    const data = new Float32Array(ab.slice(0));
    readBuf.unmap();
    [resultBuf, paramBuf, seedBuf, readBuf].forEach((b) => b.destroy());
    const mean = data.reduce((a, v) => a + v, 0) / paths;
    const std = Math.sqrt(data.reduce((a, v) => a + (v - mean) ** 2, 0) / paths);
    return { price: mean, stdError: std / Math.sqrt(paths) };
  },
  /** GBM price path simulation. */
  gbmPaths(S0, mu, sigma, T, steps, paths) {
    const dt = T / steps, sqrtDt = Math.sqrt(dt);
    return Array.from({ length: paths }, () => {
      const path = new Float32Array(steps + 1);
      path[0] = S0;
      for (let t = 1; t <= steps; t++) path[t] = path[t - 1] * Math.exp((mu - 0.5 * sigma ** 2) * dt + sigma * sqrtDt * _boxMuller());
      return path;
    });
  }
};
function _boxMuller() {
  const u1 = Math.random(), u2 = Math.random();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
var Backtest = {
  run(bars, strategy, initialCapital = 1e5, commission = 1e-3) {
    let cash = initialCapital, position = 0, entryPrice = 0, entryIdx = 0;
    const equity = [initialCapital];
    const trades = [];
    for (let i = 1; i < bars.length; i++) {
      const signal = strategy(bars, i, position);
      const price = bars[i].close;
      if (signal === "buy" && position === 0) {
        const size = Math.floor(cash / price);
        cash -= size * price * (1 + commission);
        position = size;
        entryPrice = price;
        entryIdx = i;
      } else if (signal === "sell" && position > 0) {
        const proceeds = position * price * (1 - commission);
        const pnl = proceeds - position * entryPrice;
        trades.push({ entryTime: entryIdx, exitTime: i, side: "long", entryPrice, exitPrice: price, size: position, pnl });
        cash += proceeds;
        position = 0;
      }
      equity.push(cash + position * price);
    }
    if (position > 0) {
      const price = bars[bars.length - 1].close;
      trades.push({ entryTime: entryIdx, exitTime: bars.length - 1, side: "long", entryPrice, exitPrice: price, size: position, pnl: position * (price - entryPrice) });
    }
    const returns = Portfolio.returns(equity);
    const winRate = trades.length ? trades.filter((t) => t.pnl > 0).length / trades.length : 0;
    const totalReturn = (equity[equity.length - 1] - initialCapital) / initialCapital;
    return {
      trades,
      equity,
      sharpe: Portfolio.sharpe(returns),
      sortino: Portfolio.sortino(returns),
      maxDrawdown: Portfolio.maxDrawdown(equity),
      totalReturn,
      winRate
    };
  }
};
function _normCDF(x) {
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x);
  const t = 1 / (1 + p * x);
  const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return 0.5 * (1 + sign * y);
}
function _normPDF2(x) {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}
var Bachelier = {
  /**
   * Bachelier (Normal Black) option price.
   * Unlike Black-Scholes, assumes dF = σ·dW (additive vol, no log).
   * Valid when underlying can go negative (rates, spreads).
   *
   * @param F    - Forward price (or rate)
   * @param K    - Strike
   * @param T    - Time to expiry (years)
   * @param sigma - Normal volatility (σ_N, NOT lognormal)
   * @param r    - Discount rate
   * @param type - 'call' | 'put'
   */
  price(F, K, T, sigma, r = 0, type = "call") {
    const vol = sigma * Math.sqrt(T);
    if (vol < 1e-10) return Math.exp(-r * T) * Math.max(0, type === "call" ? F - K : K - F);
    const d = (F - K) / vol;
    const sign = type === "call" ? 1 : -1;
    return Math.exp(-r * T) * sign * ((F - K) * _normCDF(sign * d) + vol * _normPDF2(d));
  },
  /** Bachelier Greeks. */
  greeks(F, K, T, sigma, r = 0, type = "call") {
    const vol = sigma * Math.sqrt(T);
    const d = (F - K) / vol;
    const sign = type === "call" ? 1 : -1;
    const delta = Math.exp(-r * T) * sign * _normCDF(sign * d);
    const gamma = Math.exp(-r * T) * _normPDF2(d) / vol;
    const vega = Math.exp(-r * T) * Math.sqrt(T) * _normPDF2(d);
    const theta = -(Math.exp(-r * T) * sigma * _normPDF2(d)) / (2 * Math.sqrt(T));
    return { delta, gamma, vega, theta };
  },
  /**
   * Implied normal volatility from a market price (Bachelier inverse).
   * Uses Jaeckel's approximation + Newton refinement.
   */
  impliedVol(marketPrice, F, K, T, r = 0, type = "call") {
    const disc = Math.exp(-r * T);
    let lo = 1e-8, hi = Math.abs(F) * 10;
    for (let i = 0; i < 64; i++) {
      const mid = (lo + hi) / 2;
      if (Bachelier.price(F, K, T, mid, r, type) > marketPrice) hi = mid;
      else lo = mid;
      if (hi - lo < 1e-8) break;
    }
    return (lo + hi) / 2;
  },
  /**
   * Convert Black-Scholes (lognormal) vol to Bachelier (normal) vol.
   * Approximation: σ_N ≈ σ_BS · F · φ((ln(F/K) + σ²T/2)/(σ√T))
   */
  fromBlackVol(sigmaBs, F, K, T) {
    const sqrtT = Math.sqrt(T);
    const d1 = (Math.log(F / K) + 0.5 * sigmaBs ** 2 * T) / (sigmaBs * sqrtT);
    return sigmaBs * Math.sqrt(F * K) * _normPDF2(d1) * sqrtT / (_normCDF(d1) - _normCDF(d1 - sigmaBs * sqrtT) + 1e-12) * (sigmaBs * sqrtT);
  }
};
var Heston = {
  /**
   * Heston price via semi-analytical formula (Carr-Madan / Lewis).
   * Uses 64-point Gauss-Laguerre quadrature.
   */
  price(S, K, T, r, params, type = "call") {
    const { v0, kappa, theta, sigma, rho } = params;
    const x = Math.log(S / K);
    const n = 64;
    const nodes = [], weights = [];
    for (let i = 1; i <= n; i++) {
      const z = Math.PI * (i - 0.25) / (n + 0.5);
      nodes.push(z * z);
      weights.push(2 * z / (n + 0.5));
    }
    const cf = (phi, j) => {
      const u = j === 1 ? 0.5 : -0.5;
      const b = j === 1 ? kappa - rho * sigma : kappa;
      const d_re = (rho * sigma * phi - b) ** 2 - sigma ** 2 * (-phi * phi - phi * (j === 1 ? 1 : -1) * 2 * u);
      const d_im = 0;
      const d = Math.sqrt(Math.max(0, d_re));
      const g_re = (b - rho * sigma * phi + d) / (b - rho * sigma * phi - d);
      const exp_dT = Math.exp(-d * T);
      const C_re = r * phi * T + kappa * theta / sigma ** 2 * ((b - rho * sigma * phi + d) * T - 2 * Math.log(Math.max(1e-20, (1 - g_re * exp_dT) / (1 - g_re))));
      const D_re = (b - rho * sigma * phi + d) / sigma ** 2 * ((1 - exp_dT) / (1 - g_re * exp_dT));
      const re = Math.exp(-D_re * v0) * Math.cos(C_re + u * x * phi);
      const im = Math.exp(-D_re * v0) * Math.sin(C_re + u * x * phi);
      return [re, im];
    };
    let P1 = 0.5, P2 = 0.5;
    for (let i = 0; i < n; i++) {
      const phi = nodes[i], w = weights[i];
      const [re1, im1] = cf(phi, 1);
      const [re2, im2] = cf(phi, 2);
      const integrand1 = (re1 * Math.sin(phi * Math.log(K / S)) - im1 * Math.cos(phi * Math.log(K / S))) / phi;
      const integrand2 = (re2 * Math.sin(phi * Math.log(K / S)) - im2 * Math.cos(phi * Math.log(K / S))) / phi;
      P1 += w * integrand1 / Math.PI;
      P2 += w * integrand2 / Math.PI;
    }
    const call = S * Math.max(0, Math.min(1, P1)) - K * Math.exp(-r * T) * Math.max(0, Math.min(1, P2));
    return type === "call" ? Math.max(0, call) : Math.max(0, call - S + K * Math.exp(-r * T));
  },
  /**
   * Calibrate Heston params to a vol surface via Nelder-Mead minimization.
   * @param surface - Array of { K, T, marketVol } data points
   * @param S       - Spot price
   * @param r       - Risk-free rate
   */
  calibrate(surface, S, r, maxIter = 500) {
    let params = { v0: 0.04, kappa: 2, theta: 0.04, sigma: 0.3, rho: -0.7 };
    const loss = (p) => surface.reduce((sum, { K, T, marketVol }) => {
      const mktPrice = BlackScholes.price(S, K, T, r, marketVol, "call");
      const modelPrice = Heston.price(S, K, T, r, p, "call");
      return sum + (mktPrice - modelPrice) ** 2;
    }, 0);
    const keys = Object.keys(params);
    const step = { v0: 0.01, kappa: 0.1, theta: 0.01, sigma: 0.05, rho: 0.05 };
    const bounds = {
      v0: [1e-3, 1],
      kappa: [0.1, 10],
      theta: [1e-3, 1],
      sigma: [0.01, 2],
      rho: [-0.99, 0.99]
    };
    for (let iter = 0; iter < maxIter; iter++) {
      for (const key of keys) {
        const cur = params[key];
        const [lo, hi] = bounds[key];
        const s = step[key] * (1 - iter / maxIter);
        const plus = { ...params, [key]: Math.min(hi, cur + s) };
        const minus = { ...params, [key]: Math.max(lo, cur - s) };
        const base = loss(params);
        if (loss(plus) < base) params = plus;
        else if (loss(minus) < base) params = minus;
      }
    }
    return params;
  }
};
var Finance = { Indicators, Portfolio, BlackScholes, Bachelier, Heston, MonteCarlo, Backtest };
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Finance")) {
  try {
    Object.defineProperty(window, "Finance", { value: Finance, writable: false, enumerable: false, configurable: false });
  } catch {
  }
}
var Finance_default = Finance;

// additionals/Math.ts
var MathConstants = Object.freeze({
  // Mathematical
  E: Math.E,
  PI: Math.PI,
  Pi: Math.PI,
  pi: Math.PI,
  P: Math.PI,
  Sqrt2: Math.sqrt(2),
  Sqrt3: Math.sqrt(3),
  Sqrt5: Math.sqrt(5),
  Sqrt6: Math.sqrt(6),
  Sqrt7: Math.sqrt(7),
  P2: Math.log(1 + Math.sqrt(2)) + Math.sqrt(2),
  Gamma: 0.5772156649015329,
  Phi: (1 + Math.sqrt(5)) * 0.5,
  // Physical constants (SI)
  N: 602214129e15,
  // Avogadro (mol⁻¹)
  H: 662606957e-42,
  // Planck (J·s)
  h: 105457172647e-45,
  // Reduced Planck ħ (J·s)
  l: 1616199e-41,
  // Planck length (m)
  m: 217651e-13,
  // Planck mass (kg)
  K: 13806488e-30,
  // Boltzmann (J/K)
  Epsilon: 885418782e-20,
  // Vacuum permittivity (F/m)
  G: 667384e-16,
  // Gravitational (m³/kg·s²)
  g: 9.80665,
  // Standard gravity (m/s²)
  c: 299792458,
  // Speed of light (m/s)
  F: 602214129e15 * Math.E,
  // Faraday (C/mol)
  R: 8.314462175,
  // Gas constant (J/mol·K)
  Mu: 12566370614e-16,
  // Vacuum permeability (H/m)
  Z: 376.73031,
  // Impedance free space (Ω)
  Ke: 8987551787,
  // Coulomb (N·m²/C²)
  e: 160217656535e-30,
  // Elementary charge (C)
  Kj: 48359787011e4,
  // Josephson (Hz/V)
  Phi0: 206783375846e-26,
  // Magnetic flux quantum (Wb)
  Rydberg: 1097373156853955e-8
  // Rydberg (m⁻¹)
});
var Numbers = {
  isNatural(n) {
    return n !== void 0 && !isNaN(n) && n % 1 === 0 && n >= 0;
  },
  isRelative(n) {
    return n !== void 0 && typeof n === "number" && !isNaN(n) && n % 1 === 0;
  },
  isRational(n) {
    return n !== void 0 && typeof n === "number" && !isNaN(n) && isFinite(n);
  },
  isReal(n) {
    return n !== void 0 && typeof n === "number" && !isNaN(n);
  }
};
var Fraction = class _Fraction {
  _n;
  _d;
  _r;
  _rd;
  constructor(numerator, denominator = 1) {
    if (typeof numerator === "string") {
      const p = _Fraction.Parse(numerator);
      this._n = p._n;
      this._d = p._d;
    } else {
      this._n = numerator;
      this._d = denominator;
    }
    if (this._d === 0) throw new Error("Fraction: denominator cannot be zero");
    if (this._d < 0) {
      this._n = -this._n;
      this._d = -this._d;
    }
    const g = _Fraction._gcd(Math.abs(this._n), this._d);
    this._r = this._n / g;
    this._rd = this._d / g;
  }
  // Original the legacy library properties
  get Numerator() {
    return this._n;
  }
  get Denominator() {
    return this._d;
  }
  get Reduced() {
    return `${this._r}/${this._rd}`;
  }
  get Value() {
    return this._n / this._d;
  }
  get IsInteger() {
    return this._rd === 1;
  }
  get IsProper() {
    return Math.abs(this._n) < this._d;
  }
  // New — MathML and LaTeX output
  get MathML() {
    return `<math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><mn>${this._n}</mn><mn>${this._d}</mn></mfrac></math>`;
  }
  get LaTeX() {
    return `\frac{${this._n}}{${this._d}}`;
  }
  static Is(v) {
    return v instanceof _Fraction;
  }
  static Parse(s) {
    const parts = String(s).split("/");
    if (parts.length === 2) return new _Fraction(parseInt(parts[0]), parseInt(parts[1]));
    const n = parseFloat(s);
    if (!isNaN(n)) {
      const dec = s.includes(".") ? s.split(".")[1].length : 0;
      const d = Math.pow(10, dec);
      return new _Fraction(Math.round(n * d), d);
    }
    throw new Error(`Fraction.Parse: cannot parse "${s}"`);
  }
  static _gcd(a, b) {
    return b === 0 ? a : _Fraction._gcd(b, a % b);
  }
  static _lcm(a, b) {
    return a * b / _Fraction._gcd(a, b);
  }
  // Original the legacy library operations
  Sum(b) {
    const f = b instanceof _Fraction ? b : new _Fraction(b);
    const d = _Fraction._lcm(this._d, f._d);
    return new _Fraction(this._n * (d / this._d) + f._n * (d / f._d), d);
  }
  Subtract(b) {
    const f = b instanceof _Fraction ? b : new _Fraction(b);
    return this.Sum(new _Fraction(-f._n, f._d));
  }
  Multiply(b) {
    const f = b instanceof _Fraction ? b : new _Fraction(b);
    return new _Fraction(this._n * f._n, this._d * f._d);
  }
  Divide(b) {
    const f = b instanceof _Fraction ? b : new _Fraction(b);
    if (f._n === 0) throw new Error("Division by zero");
    return new _Fraction(this._n * f._d, this._d * f._n);
  }
  Power(exp) {
    return exp < 0 ? new _Fraction(Math.pow(this._d, -exp), Math.pow(this._n, -exp)) : new _Fraction(Math.pow(this._n, exp), Math.pow(this._d, exp));
  }
  Root(n) {
    return Math.pow(this.Value, 1 / n);
  }
  Exponential() {
    return Math.exp(this.Value);
  }
  Logarithm(base = Math.E) {
    return Math.log(this.Value) / Math.log(base);
  }
  Reduce() {
    return new _Fraction(this._r, this._rd);
  }
  // New
  Equals(b) {
    return this._r === b._r && this._rd === b._rd;
  }
  LessThan(b) {
    return this.Value < b.Value;
  }
  GreaterThan(b) {
    return this.Value > b.Value;
  }
  valueOf() {
    return this.Value;
  }
  toString() {
    return `${this._n}/${this._d}`;
  }
};
var MathFunctions = {
  Absolute: (x) => Math.abs(x),
  Sign: (x) => Math.sign(x),
  Sum: (...a) => a.reduce((s, v) => s + v, 0),
  Subtract: (a, b) => a - b,
  Product: (...a) => a.reduce((p, v) => p * v, 1),
  Division: (a, b) => {
    if (b === 0) throw new Error("Division by zero");
    return a / b;
  },
  Power: (b, e) => Math.pow(b, e),
  Root: (x, n = 2) => Math.pow(x, 1 / n),
  Exponential: (x) => Math.exp(x),
  Logarithm: (x, base = Math.E) => Math.log(x) / Math.log(base),
  LeastCommonMultiplier: (a, b) => {
    const gcd = (x, y) => y === 0 ? x : gcd(y, x % y);
    return Math.abs(a * b) / gcd(Math.abs(a), Math.abs(b));
  },
  GreatestCommonDivisor: (a, b) => {
    const gcd = (x, y) => y === 0 ? x : gcd(y, x % y);
    return gcd(Math.abs(a), Math.abs(b));
  },
  Factorial: (n) => {
    if (n < 0) throw new Error("Factorial undefined for negatives");
    let r = 1;
    for (let i = 2; i <= n; i++) r *= i;
    return r;
  },
  Sine: (x) => Math.sin(x),
  Cosine: (x) => Math.cos(x),
  Tangent: (x) => Math.tan(x),
  Cotangent: (x) => 1 / Math.tan(x),
  Secant: (x) => 1 / Math.cos(x),
  Cosecant: (x) => 1 / Math.sin(x),
  HyperbolicSine: (x) => Math.sinh(x),
  HyperbolicCosine: (x) => Math.cosh(x),
  HyperbolicTangent: (x) => Math.tanh(x),
  HyperbolicCotangent: (x) => 1 / Math.tanh(x),
  HyperbolicSecant: (x) => 1 / Math.cosh(x),
  HyperbolicCosecant: (x) => 1 / Math.sinh(x),
  Random: (min = 0, max = 1) => min + Math.random() * (max - min),
  GetUUID: () => crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`
};
var Range = class _Range {
  constructor(Start, End, Step = 1) {
    this.Start = Start;
    this.End = End;
    this.Step = Step;
    if (Step === 0) throw new Error("Range: step cannot be zero");
  }
  Start;
  End;
  Step;
  get Length() {
    return Math.ceil((this.End - this.Start) / this.Step);
  }
  get Values() {
    const arr = [];
    for (let v = this.Start; this.Step > 0 ? v <= this.End : v >= this.End; v += this.Step) arr.push(v);
    return arr;
  }
  Contains(v) {
    return v >= Math.min(this.Start, this.End) && v <= Math.max(this.Start, this.End);
  }
  Intersect(r) {
    const s = Math.max(Math.min(this.Start, this.End), Math.min(r.Start, r.End));
    const e = Math.min(Math.max(this.Start, this.End), Math.max(r.Start, r.End));
    return s <= e ? new _Range(s, e) : null;
  }
  toString() {
    return `[${this.Start}..${this.End} step ${this.Step}]`;
  }
};
var Monomial = class _Monomial {
  constructor(Coefficient, Variable = "x", Degree = 1) {
    this.Coefficient = Coefficient;
    this.Variable = Variable;
    this.Degree = Degree;
  }
  Coefficient;
  Variable;
  Degree;
  Evaluate(x) {
    return this.Coefficient * Math.pow(x, this.Degree);
  }
  Derivative() {
    if (this.Degree === 0) return new _Monomial(0, this.Variable, 0);
    return new _Monomial(this.Coefficient * this.Degree, this.Variable, this.Degree - 1);
  }
  Integral(C = 0) {
    if (this.Degree === -1) throw new Error("Use Logarithm for degree -1");
    return new _Monomial(this.Coefficient / (this.Degree + 1), this.Variable, this.Degree + 1);
  }
  Sum(m) {
    if (m.Variable !== this.Variable || m.Degree !== this.Degree) throw new Error("Can only sum like terms");
    return new _Monomial(this.Coefficient + m.Coefficient, this.Variable, this.Degree);
  }
  Multiply(m) {
    return new _Monomial(this.Coefficient * m.Coefficient, this.Variable, this.Degree + m.Degree);
  }
  get MathML() {
    if (this.Degree === 0) return `<mn>${this.Coefficient}</mn>`;
    if (this.Degree === 1) return `<mrow><mn>${this.Coefficient}</mn><mi>${this.Variable}</mi></mrow>`;
    return `<mrow><mn>${this.Coefficient}</mn><msup><mi>${this.Variable}</mi><mn>${this.Degree}</mn></msup></mrow>`;
  }
  get LaTeX() {
    if (this.Degree === 0) return `${this.Coefficient}`;
    if (this.Degree === 1) return `${this.Coefficient}${this.Variable}`;
    return `${this.Coefficient}${this.Variable}^{${this.Degree}}`;
  }
  toString() {
    return this.LaTeX;
  }
};
var LinearFunction = class _LinearFunction {
  constructor(slope, intercept) {
    this.slope = slope;
    this.intercept = intercept;
  }
  slope;
  intercept;
  evaluate(x) {
    return this.slope * x + this.intercept;
  }
  zero() {
    return -this.intercept / this.slope;
  }
  inverse() {
    return new _LinearFunction(1 / this.slope, -this.intercept / this.slope);
  }
  get LaTeX() {
    return `y = ${this.slope}x + ${this.intercept}`;
  }
  get MathML() {
    return `<math><mrow><mi>y</mi><mo>=</mo><mn>${this.slope}</mn><mi>x</mi><mo>+</mo><mn>${this.intercept}</mn></mrow></math>`;
  }
  toString() {
    return this.LaTeX;
  }
  static fromPoints(x1, y1, x2, y2) {
    if (x1 === x2) throw new Error("LinearFunction: points are vertical (undefined slope)");
    const s = (y2 - y1) / (x2 - x1);
    return new _LinearFunction(s, y1 - s * x1);
  }
  static fromSlopePoint(slope, x, y) {
    return new _LinearFunction(slope, y - slope * x);
  }
};
var QuadraticFunction = class {
  constructor(a, b, c) {
    this.a = a;
    this.b = b;
    this.c = c;
  }
  a;
  b;
  c;
  evaluate(x) {
    return this.a * x * x + this.b * x + this.c;
  }
  discriminant() {
    return this.b * this.b - 4 * this.a * this.c;
  }
  vertex() {
    const x = -this.b / (2 * this.a);
    return [x, this.evaluate(x)];
  }
  roots() {
    const d = this.discriminant();
    if (d < 0) return [];
    if (d === 0) return [-this.b / (2 * this.a)];
    return [(-this.b + Math.sqrt(d)) / (2 * this.a), (-this.b - Math.sqrt(d)) / (2 * this.a)];
  }
  derivative() {
    return new LinearFunction(2 * this.a, this.b);
  }
  get LaTeX() {
    return `${this.a}x^2 + ${this.b}x + ${this.c}`;
  }
  get MathML() {
    return `<math><mrow><mn>${this.a}</mn><msup><mi>x</mi><mn>2</mn></msup><mo>+</mo><mn>${this.b}</mn><mi>x</mi><mo>+</mo><mn>${this.c}</mn></mrow></math>`;
  }
};
var ExponentialFunction = class {
  constructor(coefficient, base, exponentCoeff = 1) {
    this.coefficient = coefficient;
    this.base = base;
    this.exponentCoeff = exponentCoeff;
  }
  coefficient;
  base;
  exponentCoeff;
  evaluate(x) {
    return this.coefficient * Math.pow(this.base, this.exponentCoeff * x);
  }
  get LaTeX() {
    return `${this.coefficient} cdot ${this.base}^{${this.exponentCoeff}x}`;
  }
};
var Vector2 = class _Vector2 {
  constructor(x = 0, y = 0) {
    this.x = x;
    this.y = y;
  }
  x;
  y;
  static zero = new _Vector2(0, 0);
  static one = new _Vector2(1, 1);
  static up = new _Vector2(0, 1);
  static right = new _Vector2(1, 0);
  add(v) {
    return new _Vector2(this.x + v.x, this.y + v.y);
  }
  sub(v) {
    return new _Vector2(this.x - v.x, this.y - v.y);
  }
  scale(s) {
    return new _Vector2(this.x * s, this.y * s);
  }
  dot(v) {
    return this.x * v.x + this.y * v.y;
  }
  length() {
    return Math.sqrt(this.x ** 2 + this.y ** 2);
  }
  normalize() {
    const l = this.length();
    return l > 0 ? this.scale(1 / l) : _Vector2.zero;
  }
  angle() {
    return Math.atan2(this.y, this.x);
  }
  rotate(rad) {
    const c = Math.cos(rad), s = Math.sin(rad);
    return new _Vector2(c * this.x - s * this.y, s * this.x + c * this.y);
  }
  lerp(v, t) {
    return this.add(v.sub(this).scale(t));
  }
  distance(v) {
    return this.sub(v).length();
  }
  toArray() {
    return [this.x, this.y];
  }
  clone() {
    return new _Vector2(this.x, this.y);
  }
  toString() {
    return `Vector2(${this.x}, ${this.y})`;
  }
};
var Vector3 = class _Vector3 {
  constructor(x = 0, y = 0, z = 0) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  x;
  y;
  z;
  static up = new _Vector3(0, 1, 0);
  static right = new _Vector3(1, 0, 0);
  static fwd = new _Vector3(0, 0, -1);
  static zero = new _Vector3(0, 0, 0);
  static one = new _Vector3(1, 1, 1);
  add(v) {
    return new _Vector3(this.x + v.x, this.y + v.y, this.z + v.z);
  }
  sub(v) {
    return new _Vector3(this.x - v.x, this.y - v.y, this.z - v.z);
  }
  scale(s) {
    return new _Vector3(this.x * s, this.y * s, this.z * s);
  }
  dot(v) {
    return this.x * v.x + this.y * v.y + this.z * v.z;
  }
  cross(v) {
    return new _Vector3(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
  }
  length() {
    return Math.sqrt(this.dot(this));
  }
  normalize() {
    const l = this.length();
    return l > 0 ? this.scale(1 / l) : _Vector3.zero;
  }
  lerp(v, t) {
    return this.add(v.sub(this).scale(t));
  }
  distance(v) {
    return this.sub(v).length();
  }
  reflect(n) {
    return this.sub(n.scale(2 * this.dot(n)));
  }
  toArray() {
    return [this.x, this.y, this.z];
  }
  toVec4(w = 1) {
    return new Vector4(this.x, this.y, this.z, w);
  }
  clone() {
    return new _Vector3(this.x, this.y, this.z);
  }
  toString() {
    return `Vector3(${this.x.toFixed(4)},${this.y.toFixed(4)},${this.z.toFixed(4)})`;
  }
};
var Vector4 = class _Vector4 {
  constructor(x = 0, y = 0, z = 0, w = 1) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
  }
  x;
  y;
  z;
  w;
  add(v) {
    return new _Vector4(this.x + v.x, this.y + v.y, this.z + v.z, this.w + v.w);
  }
  scale(s) {
    return new _Vector4(this.x * s, this.y * s, this.z * s, this.w * s);
  }
  toVec3() {
    return new Vector3(this.x / this.w, this.y / this.w, this.z / this.w);
  }
  toArray() {
    return [this.x, this.y, this.z, this.w];
  }
  toString() {
    return `Vector4(${this.x},${this.y},${this.z},${this.w})`;
  }
};
var Quaternion = class _Quaternion {
  constructor(x = 0, y = 0, z = 0, w = 1) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
  }
  x;
  y;
  z;
  w;
  static identity = new _Quaternion(0, 0, 0, 1);
  static fromAxisAngle(axis, rad) {
    const s = Math.sin(rad / 2), n = axis.normalize();
    return new _Quaternion(n.x * s, n.y * s, n.z * s, Math.cos(rad / 2));
  }
  static fromEuler(x, y, z) {
    const cx = Math.cos(x / 2), sx = Math.sin(x / 2), cy = Math.cos(y / 2), sy = Math.sin(y / 2), cz = Math.cos(z / 2), sz = Math.sin(z / 2);
    return new _Quaternion(sx * cy * cz + cx * sy * sz, cx * sy * cz - sx * cy * sz, cx * cy * sz + sx * sy * cz, cx * cy * cz - sx * sy * sz);
  }
  multiply(q) {
    return new _Quaternion(
      this.w * q.x + this.x * q.w + this.y * q.z - this.z * q.y,
      this.w * q.y - this.x * q.z + this.y * q.w + this.z * q.x,
      this.w * q.z + this.x * q.y - this.y * q.x + this.z * q.w,
      this.w * q.w - this.x * q.x - this.y * q.y - this.z * q.z
    );
  }
  rotate(v) {
    const qv = new _Quaternion(v.x, v.y, v.z, 0), inv = new _Quaternion(-this.x, -this.y, -this.z, this.w);
    const r = this.multiply(qv).multiply(inv);
    return new Vector3(r.x, r.y, r.z);
  }
  normalize() {
    const l = Math.sqrt(this.x ** 2 + this.y ** 2 + this.z ** 2 + this.w ** 2);
    return l > 0 ? new _Quaternion(this.x / l, this.y / l, this.z / l, this.w / l) : _Quaternion.identity;
  }
  slerp(q, t) {
    let dot = this.x * q.x + this.y * q.y + this.z * q.z + this.w * q.w;
    const qb = dot < 0 ? new _Quaternion(-q.x, -q.y, -q.z, -q.w) : q;
    dot = Math.abs(dot);
    if (dot > 0.9995) return new _Quaternion(this.x + (qb.x - this.x) * t, this.y + (qb.y - this.y) * t, this.z + (qb.z - this.z) * t, this.w + (qb.w - this.w) * t).normalize();
    const th0 = Math.acos(dot), th = th0 * t, s0 = Math.cos(th) - dot * Math.sin(th) / Math.sin(th0), s1 = Math.sin(th) / Math.sin(th0);
    return new _Quaternion(this.x * s0 + qb.x * s1, this.y * s0 + qb.y * s1, this.z * s0 + qb.z * s1, this.w * s0 + qb.w * s1);
  }
  toEuler() {
    const sinr_cosp = 2 * (this.w * this.x + this.y * this.z), cosr_cosp = 1 - 2 * (this.x ** 2 + this.y ** 2);
    const sinp = 2 * (this.w * this.y - this.z * this.x);
    const siny_cosp = 2 * (this.w * this.z + this.x * this.y), cosy_cosp = 1 - 2 * (this.y ** 2 + this.z ** 2);
    return [Math.atan2(sinr_cosp, cosr_cosp), Math.abs(sinp) >= 1 ? Math.sign(sinp) * Math.PI / 2 : Math.asin(sinp), Math.atan2(siny_cosp, cosy_cosp)];
  }
};
var Matrix4 = class _Matrix4 {
  _m;
  constructor(data) {
    this._m = data ? new Float32Array(data) : new Float32Array(16);
  }
  static identity() {
    return new _Matrix4([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
  }
  static translation(x, y, z) {
    return new _Matrix4([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]);
  }
  static scale(x, y, z) {
    return new _Matrix4([x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]);
  }
  static rotation(q) {
    const { x, y, z, w } = q;
    return new _Matrix4([1 - 2 * (y * y + z * z), 2 * (x * y + w * z), 2 * (x * z - w * y), 0, 2 * (x * y - w * z), 1 - 2 * (x * x + z * z), 2 * (y * z + w * x), 0, 2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y), 0, 0, 0, 0, 1]);
  }
  static rotationX(rad) {
    const c = Math.cos(rad), s = Math.sin(rad);
    return new _Matrix4([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]);
  }
  static rotationY(rad) {
    const c = Math.cos(rad), s = Math.sin(rad);
    return new _Matrix4([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]);
  }
  static rotationZ(rad) {
    const c = Math.cos(rad), s = Math.sin(rad);
    return new _Matrix4([c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
  }
  static perspective(fov, aspect, near, far) {
    const f = 1 / Math.tan(fov / 2), nf = 1 / (near - far);
    return new _Matrix4([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
  }
  static orthographic(l, r, b, t, n, f) {
    return new _Matrix4([2 / (r - l), 0, 0, 0, 0, 2 / (t - b), 0, 0, 0, 0, -2 / (f - n), 0, -(r + l) / (r - l), -(t + b) / (t - b), -(f + n) / (f - n), 1]);
  }
  static lookAt(eye, target, up) {
    const z = eye.sub(target).normalize(), x = up.cross(z).normalize(), y = z.cross(x);
    return new _Matrix4([x.x, y.x, z.x, 0, x.y, y.y, z.y, 0, x.z, y.z, z.z, 0, -x.dot(eye), -y.dot(eye), -z.dot(eye), 1]);
  }
  multiply(b) {
    const a = this._m, bm = b._m, out = new Float32Array(16);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) out[j * 4 + i] = a[i] * bm[j * 4] + a[4 + i] * bm[j * 4 + 1] + a[8 + i] * bm[j * 4 + 2] + a[12 + i] * bm[j * 4 + 3];
    return new _Matrix4(out);
  }
  transpose() {
    const m = this._m;
    return new _Matrix4([m[0], m[4], m[8], m[12], m[1], m[5], m[9], m[13], m[2], m[6], m[10], m[14], m[3], m[7], m[11], m[15]]);
  }
  transformPoint(v) {
    const m = this._m, x = m[0] * v.x + m[4] * v.y + m[8] * v.z + m[12], y = m[1] * v.x + m[5] * v.y + m[9] * v.z + m[13], z = m[2] * v.x + m[6] * v.y + m[10] * v.z + m[14], w = m[3] * v.x + m[7] * v.y + m[11] * v.z + m[15];
    return new Vector3(x / w, y / w, z / w);
  }
  toFloat32Array() {
    return new Float32Array(this._m);
  }
  toArray() {
    return Array.from(this._m);
  }
  toString() {
    const m = this._m;
    return `Matrix4:
[${m[0].toFixed(3)} ${m[4].toFixed(3)} ${m[8].toFixed(3)} ${m[12].toFixed(3)}]
[${m[1].toFixed(3)} ${m[5].toFixed(3)} ${m[9].toFixed(3)} ${m[13].toFixed(3)}]
[${m[2].toFixed(3)} ${m[6].toFixed(3)} ${m[10].toFixed(3)} ${m[14].toFixed(3)}]
[${m[3].toFixed(3)} ${m[7].toFixed(3)} ${m[11].toFixed(3)} ${m[15].toFixed(3)}]`;
  }
};
var Complex = class _Complex {
  constructor(re = 0, im = 0) {
    this.re = re;
    this.im = im;
  }
  re;
  im;
  add(c) {
    return new _Complex(this.re + c.re, this.im + c.im);
  }
  sub(c) {
    return new _Complex(this.re - c.re, this.im - c.im);
  }
  mul(c) {
    return new _Complex(this.re * c.re - this.im * c.im, this.re * c.im + this.im * c.re);
  }
  div(c) {
    const d = c.re ** 2 + c.im ** 2;
    return new _Complex((this.re * c.re + this.im * c.im) / d, (this.im * c.re - this.re * c.im) / d);
  }
  abs() {
    return Math.sqrt(this.re ** 2 + this.im ** 2);
  }
  arg() {
    return Math.atan2(this.im, this.re);
  }
  conjugate() {
    return new _Complex(this.re, -this.im);
  }
  pow(n) {
    const r = Math.pow(this.abs(), n), a = this.arg() * n;
    return new _Complex(r * Math.cos(a), r * Math.sin(a));
  }
  sqrt() {
    return this.pow(0.5);
  }
  exp() {
    const e = Math.exp(this.re);
    return new _Complex(e * Math.cos(this.im), e * Math.sin(this.im));
  }
  Norm() {
    return this.re ** 2 + this.im ** 2;
  }
  Argument() {
    return this.arg();
  }
  Conjugate() {
    return this.conjugate();
  }
  static fromPolar(r, theta) {
    return new _Complex(r * Math.cos(theta), r * Math.sin(theta));
  }
  get MathML() {
    return `<math><mrow><mn>${this.re}</mn><mo>+</mo><mn>${this.im}</mn><mi>i</mi></mrow></math>`;
  }
  get LaTeX() {
    return `${this.re}${this.im >= 0 ? "+" : ""}${this.im}i`;
  }
  toString() {
    return this.LaTeX;
  }
};
var Statistics = {
  mean: (d) => d.reduce((a, b) => a + b, 0) / d.length,
  sum: (d) => d.reduce((a, b) => a + b, 0),
  min: (d) => Math.min(...d),
  max: (d) => Math.max(...d),
  range: (d) => Math.max(...d) - Math.min(...d),
  median: (d) => {
    const s = [...d].sort((a, b) => a - b), m = Math.floor(s.length / 2);
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  },
  mode: (d) => {
    const c = /* @__PURE__ */ new Map();
    d.forEach((v) => c.set(v, (c.get(v) ?? 0) + 1));
    return [...c.entries()].sort((a, b) => b[1] - a[1])[0][0];
  },
  variance: (d) => {
    const m = Statistics.mean(d);
    return d.reduce((a, b) => a + (b - m) ** 2, 0) / d.length;
  },
  stdDev: (d) => Math.sqrt(Statistics.variance(d)),
  zScore: (d, x) => (x - Statistics.mean(d)) / Statistics.stdDev(d),
  percentile: (d, p) => {
    const s = [...d].sort((a, b) => a - b), i = p / 100 * (s.length - 1);
    const lo = Math.floor(i), hi = Math.ceil(i);
    return s[lo] + (s[hi] - s[lo]) * (i - lo);
  },
  histogram: (d, buckets) => {
    const mn = Math.min(...d), mx = Math.max(...d), w = (mx - mn) / buckets;
    const out = Array.from({ length: buckets }, (_, i) => ({ min: mn + i * w, max: mn + (i + 1) * w, count: 0, frequency: 0 }));
    d.forEach((v) => {
      const i = Math.min(Math.floor((v - mn) / w), buckets - 1);
      out[i].count++;
    });
    out.forEach((b) => b.frequency = b.count / d.length);
    return out;
  },
  linearRegression: (xs, ys) => {
    const n = xs.length, mx = Statistics.mean(xs), my = Statistics.mean(ys);
    const slope = xs.reduce((a, x, i) => a + (x - mx) * (ys[i] - my), 0) / xs.reduce((a, x) => a + (x - mx) ** 2, 0);
    const intercept = my - slope * mx;
    const predicted = xs.map((x) => slope * x + intercept);
    const ss_res = ys.reduce((a, y, i) => a + (y - predicted[i]) ** 2, 0);
    const ss_tot = ys.reduce((a, y) => a + (y - my) ** 2, 0);
    return { slope, intercept, r2: 1 - ss_res / ss_tot, predict: (x) => slope * x + intercept };
  }
};
var AriannaMath = Object.freeze({
  // ── Identity ──────────────────────────────────────────────────────────────
  name: "Math",
  version: "1.1.0",
  // ── Sub-modules (the public surface) ──────────────────────────────────────
  /** All mathematical & physical constants (PI, Phi, c, h, G, ...). */
  Constants: MathConstants,
  /** Number-theory helpers (isPrime, isNatural, gcd, lcm, ...). */
  Numbers,
  /** Generic mathematical free functions (clamp, lerp, factorial, ...). */
  Functions: MathFunctions,
  /** Statistics helpers (mean, variance, stdDev, median, ...). */
  Statistics,
  // ── Classes (constructors exposed as namespace members) ───────────────────
  Fraction,
  Range,
  Monomial,
  LinearFunction,
  QuadraticFunction,
  ExponentialFunction,
  Vector2,
  Vector3,
  Vector4,
  Quaternion,
  Matrix4,
  Complex,
  // ── Plugin install hook ───────────────────────────────────────────────────
  /**
   * AriannA plugin entry point. Registers the namespace + every class on
   * `window` for back-compat with the original 12-year codebase.
   */
  install(_core) {
    try {
      Object.assign(window, {
        // The full namespace (recommended)
        Math: AriannaMath,
        // Individual classes (legacy, for `new Vector3(...)` without import)
        Numbers,
        Fraction,
        MathFunctions,
        Range,
        Monomial,
        LinearFunction,
        QuadraticFunction,
        ExponentialFunction,
        Vector2,
        Vector3,
        Vector4,
        Quaternion,
        Matrix4,
        Complex,
        Statistics
      });
    } catch {
    }
  }
});
var Math_default = AriannaMath;
var _PERM = (() => {
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [p[i], p[j]] = [p[j], p[i]];
  }
  return [...p, ...p];
})();

// additionals/Geometry.ts
var Angle = class _Angle {
  _radians;
  constructor(value, unit = "Radians") {
    this._radians = _Angle._toRadians(value, unit);
  }
  // Unit conversions — all original the legacy library units
  get Radians() {
    return this._radians;
  }
  get Degrees() {
    return this._radians * 180 / Math.PI;
  }
  get Turns() {
    return this._radians / (2 * Math.PI);
  }
  get Quadrants() {
    return this._radians / (Math.PI / 2);
  }
  get Grads() {
    return this._radians * 200 / Math.PI;
  }
  get Mils() {
    return this._radians * 3200 / Math.PI;
  }
  get Sextants() {
    return this._radians / (Math.PI / 3);
  }
  get Points() {
    return this._radians * 32 / (2 * Math.PI);
  }
  get BinaryDegrees() {
    return this._radians * 256 / (2 * Math.PI);
  }
  get Hours() {
    return this._radians * 12 / Math.PI;
  }
  get Minutes() {
    return this.Hours * 60;
  }
  get Seconds() {
    return this.Hours * 3600;
  }
  // Trig values — original the legacy library
  get Sine() {
    return Math.sin(this._radians);
  }
  get Cosine() {
    return Math.cos(this._radians);
  }
  get Tangent() {
    return Math.tan(this._radians);
  }
  get Secant() {
    return 1 / Math.cos(this._radians);
  }
  get Cosecant() {
    return 1 / Math.sin(this._radians);
  }
  get Cotangent() {
    return 1 / Math.tan(this._radians);
  }
  // Operations
  add(b) {
    return new _Angle(this._radians + b._radians);
  }
  sub(b) {
    return new _Angle(this._radians - b._radians);
  }
  scale(s) {
    return new _Angle(this._radians * s);
  }
  normalize() {
    return new _Angle((this._radians % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI));
  }
  static Parse(s) {
    const n = parseFloat(s);
    if (s.includes("\xB0") || s.toLowerCase().includes("deg")) return new _Angle(n, "Degrees");
    if (s.toLowerCase().includes("grad")) return new _Angle(n, "Grads");
    if (s.toLowerCase().includes("turn")) return new _Angle(n, "Turns");
    return new _Angle(n, "Radians");
  }
  static Is(v) {
    return v instanceof _Angle;
  }
  static _toRadians(value, unit) {
    switch (unit) {
      case "Degrees":
        return value * Math.PI / 180;
      case "Turns":
        return value * 2 * Math.PI;
      case "Quadrants":
        return value * Math.PI / 2;
      case "Grads":
        return value * Math.PI / 200;
      case "Mils":
        return value * Math.PI / 3200;
      case "Sextants":
        return value * Math.PI / 3;
      case "Points":
        return value * 2 * Math.PI / 32;
      case "BinaryDegrees":
        return value * 2 * Math.PI / 256;
      case "Hours":
        return value * Math.PI / 12;
      case "Minutes":
        return value * Math.PI / 720;
      case "Seconds":
        return value * Math.PI / 43200;
      default:
        return value;
    }
  }
  valueOf() {
    return this._radians;
  }
  toString() {
    return `${this.Degrees.toFixed(4)}\xB0`;
  }
};
var Rotation = class _Rotation {
  _psi;
  _theta;
  _phi;
  constructor(psi = 0, theta = 0, phi = 0, unit = "Radians") {
    this._psi = psi instanceof Angle ? psi : new Angle(psi, unit);
    this._theta = theta instanceof Angle ? theta : new Angle(theta, unit);
    this._phi = phi instanceof Angle ? phi : new Angle(phi, unit);
  }
  get Psi() {
    return this._psi;
  }
  get Theta() {
    return this._theta;
  }
  get Phi() {
    return this._phi;
  }
  get Matrix() {
    return Matrix4.rotation(this.toQuaternion());
  }
  get Quaternion() {
    return this.toQuaternion();
  }
  toQuaternion() {
    return Quaternion.fromEuler(this._psi.Radians, this._theta.Radians, this._phi.Radians);
  }
  static Is(v) {
    return v instanceof _Rotation;
  }
  toString() {
    return `Rotation(\u03C8=${this._psi}, \u03B8=${this._theta}, \u03C6=${this._phi})`;
  }
};
var Size = class _Size {
  constructor(Width = 0, Height = 0, Depth = 0) {
    this.Width = Width;
    this.Height = Height;
    this.Depth = Depth;
  }
  Width;
  Height;
  Depth;
  get Area() {
    return this.Width * this.Height;
  }
  get Volume() {
    return this.Width * this.Height * this.Depth;
  }
  scale(s) {
    return new _Size(this.Width * s, this.Height * s, this.Depth * s);
  }
  toString() {
    return `Size(${this.Width}\xD7${this.Height}\xD7${this.Depth})`;
  }
};
var Point = class _Point {
  constructor(X = 0, Y = 0, Z = 0) {
    this.X = X;
    this.Y = Y;
    this.Z = Z;
  }
  X;
  Y;
  Z;
  distanceTo(p) {
    return Math.sqrt((p.X - this.X) ** 2 + (p.Y - this.Y) ** 2 + (p.Z - this.Z) ** 2);
  }
  toVector3() {
    return new Vector3(this.X, this.Y, this.Z);
  }
  translate(dx, dy, dz = 0) {
    return new _Point(this.X + dx, this.Y + dy, this.Z + dz);
  }
  toString() {
    return `Point(${this.X},${this.Y},${this.Z})`;
  }
};
var Matrix = class _Matrix {
  _data;
  rows;
  cols;
  constructor(data) {
    this._data = data.map((r) => [...r]);
    this.rows = data.length;
    this.cols = data[0]?.length ?? 0;
  }
  static identity(n) {
    return new _Matrix(Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_2, j) => i === j ? 1 : 0)));
  }
  static zeros(rows, cols) {
    return new _Matrix(Array.from({ length: rows }, () => new Array(cols).fill(0)));
  }
  static from(flat, rows, cols) {
    return new _Matrix(Array.from({ length: rows }, (_, i) => flat.slice(i * cols, (i + 1) * cols)));
  }
  static Is(v) {
    return v instanceof _Matrix;
  }
  get(r, c) {
    return this._data[r][c];
  }
  set(r, c, v) {
    this._data[r][c] = v;
    return this;
  }
  row(r) {
    return [...this._data[r]];
  }
  col(c) {
    return this._data.map((r) => r[c]);
  }
  // Original the legacy library methods
  Diagonal() {
    return Array.from({ length: Math.min(this.rows, this.cols) }, (_, i) => this._data[i][i]);
  }
  Trace() {
    return this.Diagonal().reduce((a, b) => a + b, 0);
  }
  Clone() {
    return new _Matrix(this._data);
  }
  Transpose() {
    return new _Matrix(Array.from({ length: this.cols }, (_, j) => Array.from({ length: this.rows }, (_2, i) => this._data[i][j])));
  }
  Sum(b) {
    return new _Matrix(this._data.map((r, i) => r.map((v, j) => v + b._data[i][j])));
  }
  Subtract(b) {
    return new _Matrix(this._data.map((r, i) => r.map((v, j) => v - b._data[i][j])));
  }
  Multiply(b) {
    const out = _Matrix.zeros(this.rows, b.cols);
    for (let i = 0; i < this.rows; i++) for (let j = 0; j < b.cols; j++) for (let k = 0; k < this.cols; k++) out._data[i][j] += this._data[i][k] * b._data[k][j];
    return out;
  }
  Divide(s) {
    return new _Matrix(this._data.map((r) => r.map((v) => v / s)));
  }
  Determinant() {
    if (this.rows !== this.cols) throw new Error("Determinant: matrix must be square");
    const n = this.rows;
    if (n === 1) return this._data[0][0];
    if (n === 2) return this._data[0][0] * this._data[1][1] - this._data[0][1] * this._data[1][0];
    let det = 0;
    for (let j = 0; j < n; j++) det += (j % 2 === 0 ? 1 : -1) * this._data[0][j] * this.GetMinor(0, j).Determinant();
    return det;
  }
  GetMinor(row, col) {
    return new _Matrix(this._data.filter((_, i) => i !== row).map((r) => r.filter((_, j) => j !== col)));
  }
  Invertible() {
    return Math.abs(this.Determinant()) > 1e-10;
  }
  Singular() {
    return !this.Invertible();
  }
  Inverse() {
    if (!this.Invertible()) throw new Error("Matrix.Inverse: matrix is singular");
    const n = this.rows, det = this.Determinant();
    const adj = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_2, j) => ((i + j) % 2 === 0 ? 1 : -1) * this.GetMinor(j, i).Determinant()));
    return new _Matrix(adj).Divide(det);
  }
  // LUP decomposition (original the legacy library)
  LUP() {
    const n = this.rows;
    const L = _Matrix.identity(n), U = this.Clone(), P = _Matrix.identity(n);
    for (let k = 0; k < n; k++) {
      let max = Math.abs(U._data[k][k]), maxRow = k;
      for (let i = k + 1; i < n; i++) if (Math.abs(U._data[i][k]) > max) {
        max = Math.abs(U._data[i][k]);
        maxRow = i;
      }
      [U._data[k], U._data[maxRow]] = [U._data[maxRow], U._data[k]];
      [P._data[k], P._data[maxRow]] = [P._data[maxRow], P._data[k]];
      for (let i = k + 1; i < n; i++) {
        const f = U._data[i][k] / U._data[k][k];
        L._data[i][k] = f;
        for (let j = k; j < n; j++) U._data[i][j] -= f * U._data[k][j];
      }
    }
    return { L, U, P };
  }
  Lower() {
    return this.LUP().L;
  }
  Upper() {
    return this.LUP().U;
  }
  Permutation() {
    return this.LUP().P;
  }
  // QR decomposition (original the legacy library)
  QR() {
    const n = this.rows, m = this.cols;
    const Q = _Matrix.zeros(n, m), R = _Matrix.zeros(m, m);
    const cols = Array.from({ length: m }, (_, j) => this.col(j));
    const qs = [];
    for (let j = 0; j < m; j++) {
      let u = [...cols[j]];
      for (const q of qs) {
        const dot = u.reduce((s, v, i) => s + v * q[i], 0);
        u = u.map((v, i) => v - dot * q[i]);
      }
      const norm = Math.sqrt(u.reduce((s, v) => s + v * v, 0));
      const e = norm > 1e-10 ? u.map((v) => v / norm) : u;
      qs.push(e);
      for (let i = 0; i < n; i++) Q._data[i][j] = e[i];
      for (let jj = j; jj < m; jj++) R._data[j][jj] = cols[jj].reduce((s, v, i) => s + v * e[i], 0);
    }
    return { Q, R };
  }
  Q() {
    return this.QR().Q;
  }
  R() {
    return this.QR().R;
  }
  H() {
    return this.Transpose();
  }
  // Hermitian (conjugate transpose — same as transpose for real)
  // RREF (Row Reduced Echelon Form)
  RREF() {
    const m = this.Clone();
    let lead = 0;
    for (let r = 0; r < m.rows; r++) {
      if (lead >= m.cols) break;
      let i = r;
      while (Math.abs(m._data[i][lead]) < 1e-10) {
        i++;
        if (i === m.rows) {
          i = r;
          lead++;
          if (lead === m.cols) return m;
        }
      }
      [m._data[i], m._data[r]] = [m._data[r], m._data[i]];
      const lv = m._data[r][lead];
      m._data[r] = m._data[r].map((v) => v / lv);
      for (let j = 0; j < m.rows; j++) if (j !== r) {
        const f = m._data[j][lead];
        m._data[j] = m._data[j].map((v, c) => v - f * m._data[r][c]);
      }
      lead++;
    }
    return m;
  }
  // EigenValues (power iteration for dominant eigenvalue; QR method for all)
  EigenValues() {
    if (this.rows !== this.cols) throw new Error("EigenValues: matrix must be square");
    let A = this.Clone();
    for (let iter = 0; iter < 100; iter++) {
      const { Q, R } = A.QR();
      A = R.Multiply(Q);
    }
    return A.Diagonal();
  }
  /**
   * Compute approximate eigenvectors using inverse power iteration with shifts.
   *
   * For each eigenvalue λ from {@link EigenValues}, solve `(A - λI) v = 0`
   * by repeatedly applying `(A - λI)⁻¹` to a random starting vector. The
   * largest eigenvalue (in magnitude) of `(A - λI)⁻¹` corresponds to the
   * eigenvector of `A` for `λ`.
   *
   * @returns Matrix whose columns are eigenvectors aligned with EigenValues().
   */
  EigenVectors() {
    const eigenvals = this.EigenValues();
    const n = this.rows;
    const vecs = [];
    for (const lambda of eigenvals) {
      const shifted = this.Clone();
      for (let i = 0; i < n; i++) shifted._data[i][i] -= lambda;
      const reg = this.Clone();
      for (let i = 0; i < n; i++) reg._data[i][i] = shifted._data[i][i] + 1e-9;
      let v = Array.from({ length: n }, () => Math.random() - 0.5);
      for (let iter = 0; iter < 100; iter++) {
        let w;
        try {
          w = reg.Inverse().Multiply(new _Matrix(v.map((x) => [x]))).col(0);
        } catch {
          w = v.slice();
        }
        const norm = Math.sqrt(w.reduce((s, x) => s + x * x, 0));
        if (norm < 1e-15) break;
        v = w.map((x) => x / norm);
      }
      vecs.push(v);
    }
    return new _Matrix(Array.from(
      { length: n },
      (_, i) => Array.from({ length: vecs.length }, (_2, j) => vecs[j][i])
    ));
  }
  toString() {
    return this._data.map((r) => "[" + r.map((v) => v.toFixed(4)).join(", ") + "]").join("\n");
  }
};
var Transform = class _Transform {
  _matrix;
  constructor(matrix) {
    this._matrix = matrix ?? Matrix4.identity();
  }
  get Matrix() {
    return this._matrix;
  }
  Translate(x, y, z = 0) {
    return new _Transform(this._matrix.multiply(Matrix4.translation(x, y, z)));
  }
  Scale(x, y, z = 1) {
    return new _Transform(this._matrix.multiply(Matrix4.scale(x, y, z)));
  }
  Rotate(angle, axis = new Vector3(0, 0, 1)) {
    return new _Transform(this._matrix.multiply(Matrix4.rotation(Quaternion.fromAxisAngle(axis, angle.Radians))));
  }
  Skew(ax, ay) {
    const m = Matrix4.identity();
    const arr = m.toArray();
    arr[4] = Math.tan(ax);
    arr[1] = Math.tan(ay);
    return new _Transform(this._matrix.multiply(new Matrix4(arr)));
  }
  Reflect(axis) {
    const s = { x: [-1, 1, 1], y: [1, -1, 1], z: [1, 1, -1] }[axis];
    return new _Transform(this._matrix.multiply(Matrix4.scale(s[0], s[1], s[2])));
  }
  get CSSMatrix() {
    const m = this._matrix.toArray();
    return `matrix3d(${m.map((v) => v.toFixed(6)).join(",")})`;
  }
  get CSS() {
    return `transform: ${this.CSSMatrix};`;
  }
  toString() {
    return this.CSSMatrix;
  }
};
var AABB = class _AABB {
  constructor(min, max) {
    this.min = min;
    this.max = max;
  }
  min;
  max;
  center() {
    return this.min.add(this.max).scale(0.5);
  }
  size() {
    return this.max.sub(this.min);
  }
  contains(p) {
    return p.x >= this.min.x && p.x <= this.max.x && p.y >= this.min.y && p.y <= this.max.y && p.z >= this.min.z && p.z <= this.max.z;
  }
  intersects(b) {
    return this.min.x <= b.max.x && this.max.x >= b.min.x && this.min.y <= b.max.y && this.max.y >= b.min.y && this.min.z <= b.max.z && this.max.z >= b.min.z;
  }
  expand(v) {
    return new _AABB(
      new Vector3(Math.min(this.min.x, v.x), Math.min(this.min.y, v.y), Math.min(this.min.z, v.z)),
      new Vector3(Math.max(this.max.x, v.x), Math.max(this.max.y, v.y), Math.max(this.max.z, v.z))
    );
  }
  merge(b) {
    return new _AABB(
      new Vector3(Math.min(this.min.x, b.min.x), Math.min(this.min.y, b.min.y), Math.min(this.min.z, b.min.z)),
      new Vector3(Math.max(this.max.x, b.max.x), Math.max(this.max.y, b.max.y), Math.max(this.max.z, b.max.z))
    );
  }
  volume() {
    const s = this.size();
    return s.x * s.y * s.z;
  }
  toString() {
    return `AABB(${this.min}, ${this.max})`;
  }
};
var Ray = class {
  origin;
  direction;
  constructor(origin, direction) {
    this.origin = origin;
    this.direction = direction.normalize();
  }
  at(t) {
    return this.origin.add(this.direction.scale(t));
  }
  intersectAABB(box) {
    const inv = new Vector3(1 / this.direction.x, 1 / this.direction.y, 1 / this.direction.z);
    const t1 = (box.min.x - this.origin.x) * inv.x, t2 = (box.max.x - this.origin.x) * inv.x;
    const t3 = (box.min.y - this.origin.y) * inv.y, t4 = (box.max.y - this.origin.y) * inv.y;
    const t5 = (box.min.z - this.origin.z) * inv.z, t6 = (box.max.z - this.origin.z) * inv.z;
    const tmin = Math.max(Math.min(t1, t2), Math.min(t3, t4), Math.min(t5, t6));
    const tmax = Math.min(Math.max(t1, t2), Math.max(t3, t4), Math.max(t5, t6));
    const hit = tmax >= 0 && tmin <= tmax;
    return { hit, t: tmin, point: hit ? this.at(tmin) : void 0 };
  }
  intersectPlane(normal, d) {
    const denom = normal.dot(this.direction);
    if (Math.abs(denom) < 1e-6) return { hit: false, t: 0 };
    const t = (d - normal.dot(this.origin)) / denom;
    return { hit: t >= 0, t, point: t >= 0 ? this.at(t) : void 0 };
  }
  intersectSphere(center, radius) {
    const oc = this.origin.sub(center);
    const b = oc.dot(this.direction), c = oc.dot(oc) - radius * radius, disc = b * b - c;
    if (disc < 0) return { hit: false, t: 0 };
    const t = -b - Math.sqrt(disc);
    return { hit: t >= 0, t };
  }
};
var Rectangle = class {
  constructor(x, y, width, height) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }
  x;
  y;
  width;
  height;
  get area() {
    return this.width * this.height;
  }
  get perimeter() {
    return 2 * (this.width + this.height);
  }
  get diagonal() {
    return Math.sqrt(this.width ** 2 + this.height ** 2);
  }
  contains(px, py) {
    return px >= this.x && px <= this.x + this.width && py >= this.y && py <= this.y + this.height;
  }
  intersects(r) {
    return !(r.x > this.x + this.width || r.x + r.width < this.x || r.y > this.y + this.height || r.y + r.height < this.y);
  }
  toSVG() {
    return `<rect x="${this.x}" y="${this.y}" width="${this.width}" height="${this.height}"/>`;
  }
  toHTML() {
    return `style="position:absolute;left:${this.x}px;top:${this.y}px;width:${this.width}px;height:${this.height}px"`;
  }
  toString() {
    return `Rectangle(${this.x},${this.y},${this.width}\xD7${this.height})`;
  }
};
var Circle = class {
  constructor(cx, cy, radius) {
    this.cx = cx;
    this.cy = cy;
    this.radius = radius;
  }
  cx;
  cy;
  radius;
  get area() {
    return Math.PI * this.radius ** 2;
  }
  get circumference() {
    return 2 * Math.PI * this.radius;
  }
  contains(px, py) {
    return (px - this.cx) ** 2 + (py - this.cy) ** 2 <= this.radius ** 2;
  }
  intersects(c) {
    return Math.sqrt((c.cx - this.cx) ** 2 + (c.cy - this.cy) ** 2) <= this.radius + c.radius;
  }
  toSVG() {
    return `<circle cx="${this.cx}" cy="${this.cy}" r="${this.radius}"/>`;
  }
  toString() {
    return `Circle(${this.cx},${this.cy},r=${this.radius})`;
  }
};
var Triangle = class {
  constructor(a, b, c) {
    this.a = a;
    this.b = b;
    this.c = c;
  }
  a;
  b;
  c;
  get area() {
    return Math.abs((this.b.X - this.a.X) * (this.c.Y - this.a.Y) - (this.c.X - this.a.X) * (this.b.Y - this.a.Y)) / 2;
  }
  get perimeter() {
    return this.a.distanceTo(this.b) + this.b.distanceTo(this.c) + this.c.distanceTo(this.a);
  }
  centroid() {
    return new Point((this.a.X + this.b.X + this.c.X) / 3, (this.a.Y + this.b.Y + this.c.Y) / 3);
  }
  contains(p) {
    const d1 = Math.sign((p.X - this.b.X) * (this.a.Y - this.b.Y) - (this.a.X - this.b.X) * (p.Y - this.b.Y));
    const d2 = Math.sign((p.X - this.c.X) * (this.b.Y - this.c.Y) - (this.b.X - this.c.X) * (p.Y - this.c.Y));
    const d3 = Math.sign((p.X - this.a.X) * (this.c.Y - this.a.Y) - (this.c.X - this.a.X) * (p.Y - this.a.Y));
    return !((d1 < 0 || d2 < 0 || d3 < 0) && (d1 > 0 || d2 > 0 || d3 > 0));
  }
  toSVG() {
    return `<polygon points="${this.a.X},${this.a.Y} ${this.b.X},${this.b.Y} ${this.c.X},${this.c.Y}"/>`;
  }
};
var Polygon = class {
  constructor(points) {
    this.points = points;
  }
  points;
  get area() {
    let a = 0;
    for (let i = 0, j = this.points.length - 1; i < this.points.length; j = i++) a += (this.points[j].X + this.points[i].X) * (this.points[j].Y - this.points[i].Y);
    return Math.abs(a) / 2;
  }
  get perimeter() {
    return this.points.reduce((s, p, i) => s + p.distanceTo(this.points[(i + 1) % this.points.length]), 0);
  }
  centroid() {
    const n = this.points.length;
    return new Point(this.points.reduce((s, p) => s + p.X, 0) / n, this.points.reduce((s, p) => s + p.Y, 0) / n);
  }
  toSVG() {
    return `<polygon points="${this.points.map((p) => `${p.X},${p.Y}`).join(" ")}"/>`;
  }
};
var Sphere = class {
  constructor(radius) {
    this.radius = radius;
  }
  radius;
  get volume() {
    return 4 / 3 * Math.PI * this.radius ** 3;
  }
  get surfaceArea() {
    return 4 * Math.PI * this.radius ** 2;
  }
  get diameter() {
    return 2 * this.radius;
  }
  toSVG(cx = 0, cy = 0) {
    return `<circle cx="${cx}" cy="${cy}" r="${this.radius}"/>`;
  }
  toString() {
    return `Sphere(r=${this.radius})`;
  }
};
var Box = class {
  constructor(width, height, depth) {
    this.width = width;
    this.height = height;
    this.depth = depth;
  }
  width;
  height;
  depth;
  get volume() {
    return this.width * this.height * this.depth;
  }
  get surfaceArea() {
    return 2 * (this.width * this.height + this.height * this.depth + this.depth * this.width);
  }
  get diagonal() {
    return Math.sqrt(this.width ** 2 + this.height ** 2 + this.depth ** 2);
  }
  toAABB(center = new Vector3()) {
    const h = new Vector3(this.width / 2, this.height / 2, this.depth / 2);
    return new AABB(center.sub(h), center.add(h));
  }
  toString() {
    return `Box(${this.width}\xD7${this.height}\xD7${this.depth})`;
  }
};
var Cylinder = class {
  constructor(radius, height) {
    this.radius = radius;
    this.height = height;
  }
  radius;
  height;
  get volume() {
    return Math.PI * this.radius ** 2 * this.height;
  }
  get surfaceArea() {
    return 2 * Math.PI * this.radius * (this.radius + this.height);
  }
  get lateralArea() {
    return 2 * Math.PI * this.radius * this.height;
  }
  toString() {
    return `Cylinder(r=${this.radius},h=${this.height})`;
  }
};
var Torus = class {
  constructor(majorRadius, minorRadius) {
    this.majorRadius = majorRadius;
    this.minorRadius = minorRadius;
  }
  majorRadius;
  minorRadius;
  get volume() {
    return 2 * Math.PI ** 2 * this.majorRadius * this.minorRadius ** 2;
  }
  get surfaceArea() {
    return 4 * Math.PI ** 2 * this.majorRadius * this.minorRadius;
  }
  toString() {
    return `Torus(R=${this.majorRadius},r=${this.minorRadius})`;
  }
};
var Cone = class {
  constructor(radius, height) {
    this.radius = radius;
    this.height = height;
  }
  radius;
  height;
  get slantHeight() {
    return Math.sqrt(this.radius ** 2 + this.height ** 2);
  }
  get volume() {
    return 1 / 3 * Math.PI * this.radius ** 2 * this.height;
  }
  get surfaceArea() {
    return Math.PI * this.radius * (this.radius + this.slantHeight);
  }
  toString() {
    return `Cone(r=${this.radius},h=${this.height})`;
  }
};
var Pyramid = class {
  constructor(baseWidth, baseDepth, height) {
    this.baseWidth = baseWidth;
    this.baseDepth = baseDepth;
    this.height = height;
  }
  baseWidth;
  baseDepth;
  height;
  get volume() {
    return 1 / 3 * this.baseWidth * this.baseDepth * this.height;
  }
  get baseArea() {
    return this.baseWidth * this.baseDepth;
  }
  toString() {
    return `Pyramid(${this.baseWidth}\xD7${this.baseDepth},h=${this.height})`;
  }
};
var Tube = class {
  constructor(outerRadius, innerRadius, height) {
    this.outerRadius = outerRadius;
    this.innerRadius = innerRadius;
    this.height = height;
  }
  outerRadius;
  innerRadius;
  height;
  get volume() {
    return Math.PI * (this.outerRadius ** 2 - this.innerRadius ** 2) * this.height;
  }
  get surfaceArea() {
    return 2 * Math.PI * (this.outerRadius + this.innerRadius) * this.height + 2 * Math.PI * (this.outerRadius ** 2 - this.innerRadius ** 2);
  }
  toString() {
    return `Tube(r=${this.outerRadius},ri=${this.innerRadius},h=${this.height})`;
  }
};
var Shapes = { Rectangle, Circle, Triangle, Polygon };
var Solids = { Sphere, Box, Cylinder, Torus, Cone, Pyramid, Tube };
var Plane3D = class _Plane3D {
  normal;
  constant;
  constructor(nx, ny, nz, d) {
    this.normal = { x: nx, y: ny, z: nz };
    this.constant = d;
  }
  static fromPoints(a, b, c) {
    const ab = { x: b.x - a.x, y: b.y - a.y, z: b.z - a.z };
    const ac = { x: c.x - a.x, y: c.y - a.y, z: c.z - a.z };
    const n = {
      x: ab.y * ac.z - ab.z * ac.y,
      y: ab.z * ac.x - ab.x * ac.z,
      z: ab.x * ac.y - ab.y * ac.x
    };
    const len = Math.sqrt(n.x ** 2 + n.y ** 2 + n.z ** 2) || 1;
    n.x /= len;
    n.y /= len;
    n.z /= len;
    const d = -(n.x * a.x + n.y * a.y + n.z * a.z);
    return new _Plane3D(n.x, n.y, n.z, d);
  }
  distanceToPoint(p) {
    return this.normal.x * p.x + this.normal.y * p.y + this.normal.z * p.z + this.constant;
  }
  projectPoint(p) {
    const d = this.distanceToPoint(p);
    return { x: p.x - d * this.normal.x, y: p.y - d * this.normal.y, z: p.z - d * this.normal.z };
  }
  /** Returns parameter t at which a ray hits this plane, or null. */
  rayIntersect(origin, dir) {
    const denom = this.normal.x * dir.x + this.normal.y * dir.y + this.normal.z * dir.z;
    if (Math.abs(denom) < 1e-6) return null;
    const t = -(this.normal.x * origin.x + this.normal.y * origin.y + this.normal.z * origin.z + this.constant) / denom;
    return t >= 0 ? t : null;
  }
};
var BVH = class {
  #root = null;
  build(triangles, maxLeaf = 4) {
    this.#root = this.#buildNode(triangles, 0, maxLeaf);
    return this;
  }
  #centroid(t) {
    return {
      x: (t.a.x + t.b.x + t.c.x) / 3,
      y: (t.a.y + t.b.y + t.c.y) / 3,
      z: (t.a.z + t.b.z + t.c.z) / 3
    };
  }
  #triBox(tris) {
    const pts = tris.flatMap((t) => [t.a, t.b, t.c]);
    return {
      min: { x: Math.min(...pts.map((p) => p.x)), y: Math.min(...pts.map((p) => p.y)), z: Math.min(...pts.map((p) => p.z)) },
      max: { x: Math.max(...pts.map((p) => p.x)), y: Math.max(...pts.map((p) => p.y)), z: Math.max(...pts.map((p) => p.z)) }
    };
  }
  #buildNode(tris, depth, maxLeaf) {
    const box = this.#triBox(tris);
    if (tris.length <= maxLeaf || depth > 20) return { box, tris };
    const axis = ["x", "y", "z"][[box.max.x - box.min.x, box.max.y - box.min.y, box.max.z - box.min.z].indexOf(Math.max(box.max.x - box.min.x, box.max.y - box.min.y, box.max.z - box.min.z))];
    const sorted = [...tris].sort((a, b) => this.#centroid(a)[axis] - this.#centroid(b)[axis]);
    const mid = Math.floor(sorted.length / 2);
    return {
      box,
      left: this.#buildNode(sorted.slice(0, mid), depth + 1, maxLeaf),
      right: this.#buildNode(sorted.slice(mid), depth + 1, maxLeaf)
    };
  }
  /** Ray-cast: returns nearest hit triangle index and t parameter, or null. */
  raycast(origin, dir) {
    let best = null;
    const traverse = (node) => {
      if (!node || !this.#rayHitsBox(origin, dir, node.box)) return;
      if (node.tris) {
        for (const tri of node.tris) {
          const t = this.#rayTriangle(origin, dir, tri);
          if (t !== null && (best === null || t < best.t)) best = { index: tri.index, t };
        }
      } else {
        traverse(node.left);
        traverse(node.right);
      }
    };
    traverse(this.#root ?? void 0);
    return best;
  }
  #rayHitsBox(o, d, box) {
    let tmin = -Infinity, tmax = Infinity;
    for (const axis of ["x", "y", "z"]) {
      if (Math.abs(d[axis]) < 1e-8) {
        if (o[axis] < box.min[axis] || o[axis] > box.max[axis]) return false;
      } else {
        const t1 = (box.min[axis] - o[axis]) / d[axis];
        const t2 = (box.max[axis] - o[axis]) / d[axis];
        tmin = Math.max(tmin, Math.min(t1, t2));
        tmax = Math.min(tmax, Math.max(t1, t2));
        if (tmax < tmin) return false;
      }
    }
    return true;
  }
  #rayTriangle(o, d, t) {
    const edge1 = { x: t.b.x - t.a.x, y: t.b.y - t.a.y, z: t.b.z - t.a.z };
    const edge2 = { x: t.c.x - t.a.x, y: t.c.y - t.a.y, z: t.c.z - t.a.z };
    const h = { x: d.y * edge2.z - d.z * edge2.y, y: d.z * edge2.x - d.x * edge2.z, z: d.x * edge2.y - d.y * edge2.x };
    const a = edge1.x * h.x + edge1.y * h.y + edge1.z * h.z;
    if (Math.abs(a) < 1e-8) return null;
    const f = 1 / a;
    const s = { x: o.x - t.a.x, y: o.y - t.a.y, z: o.z - t.a.z };
    const u = f * (s.x * h.x + s.y * h.y + s.z * h.z);
    if (u < 0 || u > 1) return null;
    const q = { x: s.y * edge1.z - s.z * edge1.y, y: s.z * edge1.x - s.x * edge1.z, z: s.x * edge1.y - s.y * edge1.x };
    const v = f * (d.x * q.x + d.y * q.y + d.z * q.z);
    if (v < 0 || u + v > 1) return null;
    const r = f * (edge2.x * q.x + edge2.y * q.y + edge2.z * q.z);
    return r > 1e-8 ? r : null;
  }
};
var Geometry = {
  name: "Geometry",
  version: "1.0.0",
  install(_core) {
    try {
      Object.assign(window, {
        Angle,
        Rotation,
        Size,
        Point,
        Matrix,
        Transform,
        AABB,
        Ray,
        Plane3D,
        BVH,
        Rectangle,
        Circle,
        Triangle,
        Polygon,
        Sphere,
        Box,
        Cylinder,
        Torus,
        Cone,
        Pyramid,
        Tube,
        Shapes,
        Solids
      });
    } catch {
    }
  }
};
var Geometry_default = Geometry;

// additionals/IO.ts
var FileIO = class {
  /** Open a file picker and return the selected File(s). */
  static async open(opts = {}) {
    if ("showOpenFilePicker" in window) {
      const handles = await window.showOpenFilePicker({
        multiple: opts.multiple ?? false,
        types: opts.filters
      });
      return Promise.all(handles.map((h) => h.getFile()));
    }
    return new Promise((res) => {
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = opts.multiple ?? false;
      if (opts.accept) input.accept = opts.accept;
      input.onchange = () => res(Array.from(input.files ?? []));
      input.click();
    });
  }
  /** Read File/Blob as text. */
  static readText(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = rej;
      r.readAsText(file);
    });
  }
  /** Read File/Blob as ArrayBuffer. */
  static readBinary(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = rej;
      r.readAsArrayBuffer(file);
    });
  }
  /** Read File/Blob as data URL. */
  static readDataURL(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = rej;
      r.readAsDataURL(file);
    });
  }
  /** Download content as a file. */
  static download(content, filename, type = "application/octet-stream") {
    let blob;
    if (typeof content === "string") blob = new Blob([content], { type: "text/plain" });
    else if (content instanceof ArrayBuffer) blob = new Blob([content], { type });
    else blob = content;
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement("a"), { href: url, download: filename });
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  }
  /** Setup drag-and-drop on an element. */
  static dropZone(el, onDrop, opts = {}) {
    const hl = opts.highlight ?? "rgba(228,12,136,0.08)";
    const orig = el.style.background;
    const over = (e) => {
      e.preventDefault();
      el.style.background = hl;
    };
    const leave = () => {
      el.style.background = orig;
    };
    const drop = (e) => {
      e.preventDefault();
      el.style.background = orig;
      const files = Array.from(e.dataTransfer?.files ?? []);
      if (files.length) onDrop(files);
    };
    el.addEventListener("dragover", over);
    el.addEventListener("dragleave", leave);
    el.addEventListener("drop", drop);
    return () => {
      el.removeEventListener("dragover", over);
      el.removeEventListener("dragleave", leave);
      el.removeEventListener("drop", drop);
    };
  }
};
var FSAccess = class {
  static isSupported() {
    return "showOpenFilePicker" in window;
  }
  static async readFile(filter) {
    const [handle] = await window.showOpenFilePicker({ types: filter });
    const file = await handle.getFile();
    return { name: file.name, text: () => file.text(), binary: () => file.arrayBuffer() };
  }
  static async writeFile(content, suggestedName = "file.txt", filter) {
    const handle = await window.showSaveFilePicker({ suggestedName, types: filter });
    const writable = await handle.createWritable();
    await writable.write(content);
    await writable.close();
  }
  static async openDirectory() {
    return window.showDirectoryPicker();
  }
};
var Http = class {
  #opts;
  constructor(opts = {}) {
    this.#opts = { baseURL: "", timeout: 3e4, retries: 0, retryDelay: 1e3, headers: {}, onRequest: () => {
    }, onResponse: () => {
    }, onError: () => {
    }, ...opts };
  }
  async #fetch(url, init = {}, retries = this.#opts.retries) {
    const fullURL = this.#opts.baseURL + url;
    const headers = { ...this.#opts.headers, ...init.headers ?? {} };
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.#opts.timeout);
    const req = { ...init, headers, signal: ctrl.signal, url: fullURL };
    this.#opts.onRequest(req);
    try {
      const res = await fetch(fullURL, req);
      clearTimeout(timer);
      this.#opts.onResponse(res);
      return res;
    } catch (err) {
      clearTimeout(timer);
      if (retries > 0) {
        await new Promise((r) => setTimeout(r, this.#opts.retryDelay));
        return this.#fetch(url, init, retries - 1);
      }
      this.#opts.onError(err);
      throw err;
    }
  }
  async get(url, opts) {
    return (await this.#fetch(url, { ...opts, method: "GET" })).json();
  }
  async post(url, body, opts) {
    return (await this.#fetch(url, { ...opts, method: "POST", body: JSON.stringify(body), headers: { "Content-Type": "application/json" } })).json();
  }
  async put(url, body, opts) {
    return (await this.#fetch(url, { ...opts, method: "PUT", body: JSON.stringify(body), headers: { "Content-Type": "application/json" } })).json();
  }
  async del(url, opts) {
    return (await this.#fetch(url, { ...opts, method: "DELETE" })).json();
  }
  async blob(url) {
    return (await this.#fetch(url)).blob();
  }
  async buffer(url) {
    return (await this.#fetch(url)).arrayBuffer();
  }
  async text(url) {
    return (await this.#fetch(url)).text();
  }
};
var http = new Http();
var SSE = class {
  #source = null;
  #handlers = /* @__PURE__ */ new Map();
  connect(url, withCredentials = false) {
    this.disconnect();
    this.#source = new EventSource(url, { withCredentials });
    this.#source.onmessage = (e) => this.#emit("message", e.data);
    this.#source.onerror = (e) => this.#emit("error", e);
    this.#source.onopen = (e) => this.#emit("open", e);
    return this;
  }
  on(event, handler) {
    if (!this.#handlers.has(event)) this.#handlers.set(event, []);
    this.#handlers.get(event).push(handler);
    this.#source?.addEventListener(event, (e) => handler(e.data));
    return this;
  }
  #emit(event, data) {
    this.#handlers.get(event)?.forEach((h) => h(data));
  }
  disconnect() {
    this.#source?.close();
    this.#source = null;
  }
  get readyState() {
    return this.#source?.readyState ?? -1;
  }
};
var WebSocketIO = class {
  #ws = null;
  #url;
  #queue = [];
  #handlers = /* @__PURE__ */ new Map();
  #reconnect;
  #reconnectMs;
  constructor(url, opts = {}) {
    this.#url = url;
    this.#reconnect = opts.reconnect ?? true;
    this.#reconnectMs = opts.reconnectMs ?? 3e3;
  }
  connect() {
    this.#ws = new WebSocket(this.#url);
    this.#ws.onopen = () => {
      this.#emit("open", null);
      this.#flush();
    };
    this.#ws.onmessage = (e) => {
      try {
        this.#emit("message", JSON.parse(e.data));
      } catch {
        this.#emit("message", e.data);
      }
    };
    this.#ws.onerror = (e) => this.#emit("error", e);
    this.#ws.onclose = (e) => {
      this.#emit("close", e);
      if (this.#reconnect) setTimeout(() => this.connect(), this.#reconnectMs);
    };
    return this;
  }
  send(data) {
    if (this.#ws?.readyState === 1) this.#ws.send(JSON.stringify(data));
    else this.#queue.push(data);
    return this;
  }
  #flush() {
    while (this.#queue.length) this.send(this.#queue.shift());
  }
  on(event, handler) {
    if (!this.#handlers.has(event)) this.#handlers.set(event, []);
    this.#handlers.get(event).push(handler);
    return this;
  }
  #emit(event, data) {
    this.#handlers.get(event)?.forEach((h) => h(data));
  }
  close() {
    this.#reconnect = false;
    this.#ws?.close();
  }
  get readyState() {
    return this.#ws?.readyState ?? -1;
  }
};
var LocalStore = class {
  #key;
  #default;
  #data;
  #listeners = [];
  constructor(key, defaults) {
    this.#key = key;
    this.#default = defaults;
    const raw = localStorage.getItem(key);
    this.#data = raw ? { ...defaults, ...JSON.parse(raw) } : { ...defaults };
  }
  get(key) {
    return this.#data[key];
  }
  set(key, value) {
    this.#data = { ...this.#data, [key]: value };
    localStorage.setItem(this.#key, JSON.stringify(this.#data));
    this.#listeners.forEach((l) => l(this.#data));
    return this;
  }
  reset() {
    this.#data = { ...this.#default };
    localStorage.setItem(this.#key, JSON.stringify(this.#data));
    this.#listeners.forEach((l) => l(this.#data));
    return this;
  }
  subscribe(fn) {
    this.#listeners.push(fn);
    return () => {
      this.#listeners = this.#listeners.filter((l) => l !== fn);
    };
  }
  get all() {
    return { ...this.#data };
  }
  clear() {
    localStorage.removeItem(this.#key);
  }
};
var IDBIO = class {
  #name;
  #version;
  #stores;
  #db = null;
  constructor(name, stores, version = 1) {
    this.#name = name;
    this.#stores = stores;
    this.#version = version;
  }
  async open() {
    return new Promise((res, rej) => {
      const req = indexedDB.open(this.#name, this.#version);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        for (const store of this.#stores) if (!db.objectStoreNames.contains(store)) db.createObjectStore(store, { keyPath: "id" });
      };
      req.onsuccess = (e) => {
        this.#db = e.target.result;
        res(this);
      };
      req.onerror = rej;
    });
  }
  async put(store, value) {
    return new Promise((res, rej) => {
      const tx = this.#db.transaction(store, "readwrite");
      tx.objectStore(store).put(value).onsuccess = () => res();
      tx.onerror = rej;
    });
  }
  async get(store, id) {
    return new Promise((res, rej) => {
      const req = this.#db.transaction(store, "readonly").objectStore(store).get(id);
      req.onsuccess = () => res(req.result);
      req.onerror = rej;
    });
  }
  async delete(store, id) {
    return new Promise((res, rej) => {
      const tx = this.#db.transaction(store, "readwrite");
      tx.objectStore(store).delete(id).onsuccess = () => res();
      tx.onerror = rej;
    });
  }
  async getAll(store) {
    return new Promise((res, rej) => {
      const req = this.#db.transaction(store, "readonly").objectStore(store).getAll();
      req.onsuccess = () => res(req.result);
      req.onerror = rej;
    });
  }
  close() {
    this.#db?.close();
  }
};
var Clipboard = {
  async readText() {
    return navigator.clipboard.readText();
  },
  async writeText(text) {
    return navigator.clipboard.writeText(text);
  },
  async readImage() {
    const items = await navigator.clipboard.read();
    for (const item of items) for (const type of item.types) if (type.startsWith("image/")) return item.getType(type);
    return null;
  },
  async writeImage(blob) {
    await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
  }
};
var Share = {
  isSupported() {
    return "share" in navigator;
  },
  async share(data) {
    if (!Share.isSupported()) throw new Error("Web Share API not supported");
    return navigator.share(data);
  },
  canShareFiles() {
    return "canShare" in navigator;
  }
};
var IO = { FileIO, FSAccess, Http, http, SSE, WebSocketIO, LocalStore, IDBIO, Clipboard, Share };
if (typeof window !== "undefined") {
  try {
    delete window.IO;
  } catch {
  }
  try {
    window.IO = IO;
  } catch {
  }
}
var IO_default = IO;

// additionals/Latex.ts
var GREEK = {
  alpha: "\u03B1",
  beta: "\u03B2",
  gamma: "\u03B3",
  delta: "\u03B4",
  epsilon: "\u03B5",
  varepsilon: "\u03B5",
  zeta: "\u03B6",
  eta: "\u03B7",
  theta: "\u03B8",
  vartheta: "\u03D1",
  iota: "\u03B9",
  kappa: "\u03BA",
  lambda: "\u03BB",
  mu: "\u03BC",
  nu: "\u03BD",
  xi: "\u03BE",
  omicron: "\u03BF",
  pi: "\u03C0",
  varpi: "\u03D6",
  rho: "\u03C1",
  varrho: "\u03F1",
  sigma: "\u03C3",
  varsigma: "\u03C2",
  tau: "\u03C4",
  upsilon: "\u03C5",
  phi: "\u03C6",
  varphi: "\u03C6",
  chi: "\u03C7",
  psi: "\u03C8",
  omega: "\u03C9",
  Gamma: "\u0393",
  Delta: "\u0394",
  Theta: "\u0398",
  Lambda: "\u039B",
  Xi: "\u039E",
  Pi: "\u03A0",
  Sigma: "\u03A3",
  Upsilon: "\u03A5",
  Phi: "\u03A6",
  Psi: "\u03A8",
  Omega: "\u03A9"
};
var OPERATORS = {
  pm: "\xB1",
  mp: "\u2213",
  times: "\xD7",
  div: "\xF7",
  ast: "\u2217",
  star: "\u22C6",
  cdot: "\xB7",
  cdots: "\u22EF",
  ldots: "\u2026",
  vdots: "\u22EE",
  ddots: "\u22F1",
  leq: "\u2264",
  le: "\u2264",
  geq: "\u2265",
  ge: "\u2265",
  neq: "\u2260",
  ne: "\u2260",
  approx: "\u2248",
  equiv: "\u2261",
  sim: "\u223C",
  simeq: "\u2243",
  cong: "\u2245",
  propto: "\u221D",
  infty: "\u221E",
  partial: "\u2202",
  nabla: "\u2207",
  forall: "\u2200",
  exists: "\u2203",
  emptyset: "\u2205",
  in: "\u2208",
  notin: "\u2209",
  subset: "\u2282",
  supset: "\u2283",
  subseteq: "\u2286",
  supseteq: "\u2287",
  cup: "\u222A",
  cap: "\u2229",
  setminus: "\u2216",
  wedge: "\u2227",
  vee: "\u2228",
  neg: "\xAC",
  rightarrow: "\u2192",
  leftarrow: "\u2190",
  leftrightarrow: "\u2194",
  Rightarrow: "\u21D2",
  Leftarrow: "\u21D0",
  Leftrightarrow: "\u21D4",
  to: "\u2192",
  mapsto: "\u21A6",
  implies: "\u27F9",
  iff: "\u27FA",
  perp: "\u22A5",
  parallel: "\u2225",
  angle: "\u2220",
  triangle: "\u25B3",
  aleph: "\u2135",
  hbar: "\u210F",
  ell: "\u2113",
  wp: "\u2118",
  Re: "\u211C",
  Im: "\u2111"
};
var BIG_OPS = {
  sum: "\u2211",
  prod: "\u220F",
  coprod: "\u2210",
  int: "\u222B",
  iint: "\u222C",
  iiint: "\u222D",
  oint: "\u222E",
  bigcup: "\u22C3",
  bigcap: "\u22C2",
  bigvee: "\u22C1",
  bigwedge: "\u22C0",
  bigoplus: "\u2A01",
  bigotimes: "\u2A02",
  lim: "lim",
  liminf: "lim inf",
  limsup: "lim sup",
  max: "max",
  min: "min",
  sup: "sup",
  inf: "inf",
  det: "det",
  arg: "arg",
  deg: "deg",
  dim: "dim",
  exp: "exp",
  gcd: "gcd",
  lcm: "lcm"
};
var FUNCTIONS = /* @__PURE__ */ new Set([
  "sin",
  "cos",
  "tan",
  "cot",
  "sec",
  "csc",
  "sinh",
  "cosh",
  "tanh",
  "coth",
  "arcsin",
  "arccos",
  "arctan",
  "log",
  "ln",
  "lg"
]);
function tokenize(src) {
  const tokens = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i] ?? "";
    if (/\s/.test(ch)) {
      tokens.push({ kind: "space" });
      i++;
      continue;
    }
    if (ch === "\\") {
      i++;
      if (src[i] === "\\") {
        tokens.push({ kind: "dbl_back" });
        i++;
        continue;
      }
      if (src[i] && !/[a-zA-Z]/.test(src[i] ?? "")) {
        tokens.push({ kind: "cmd", name: src[i] ?? "" });
        i++;
        continue;
      }
      let name = "";
      while (i < src.length && /[a-zA-Z]/.test(src[i] ?? "")) {
        name += src[i];
        i++;
      }
      tokens.push({ kind: "cmd", name });
      continue;
    }
    if (/[0-9.]/.test(ch)) {
      let num = "";
      while (i < src.length && /[0-9.]/.test(src[i] ?? "")) {
        num += src[i];
        i++;
      }
      tokens.push({ kind: "num", value: num });
      continue;
    }
    if (/[a-zA-Z]/.test(ch)) {
      tokens.push({ kind: "ident", value: ch });
      i++;
      continue;
    }
    switch (ch) {
      case "{":
        tokens.push({ kind: "lbrace" });
        i++;
        continue;
      case "}":
        tokens.push({ kind: "rbrace" });
        i++;
        continue;
      case "(":
        tokens.push({ kind: "lparen" });
        i++;
        continue;
      case ")":
        tokens.push({ kind: "rparen" });
        i++;
        continue;
      case "[":
        tokens.push({ kind: "lbrack" });
        i++;
        continue;
      case "]":
        tokens.push({ kind: "rbrack" });
        i++;
        continue;
      case "^":
        tokens.push({ kind: "caret" });
        i++;
        continue;
      case "_":
        tokens.push({ kind: "under" });
        i++;
        continue;
      case "&":
        tokens.push({ kind: "amp" });
        i++;
        continue;
    }
    tokens.push({ kind: "op", value: ch });
    i++;
  }
  return tokens;
}
var LatexParser = class {
  tokens;
  pos = 0;
  constructor(tokens) {
    this.tokens = tokens;
  }
  parse() {
    return this.parseGroup(false);
  }
  peek(offset = 0) {
    return this.tokens[this.pos + offset];
  }
  next() {
    return this.tokens[this.pos++];
  }
  skipSpace() {
    while (this.peek()?.kind === "space") this.pos++;
  }
  parseGroup(inBrace) {
    const out = [];
    while (this.pos < this.tokens.length) {
      const t = this.peek();
      if (!t) break;
      if (inBrace && t.kind === "rbrace") break;
      const atom = this.parseAtom();
      if (atom) out.push(atom);
    }
    return out.join("");
  }
  parseAtom() {
    this.skipSpace();
    const t = this.next();
    if (!t) return "";
    let base = "";
    switch (t.kind) {
      case "space":
        return "";
      case "num":
        base = `<mn>${t.value}</mn>`;
        break;
      case "ident":
        base = `<mi>${t.value}</mi>`;
        break;
      case "op":
        base = `<mo>${escapeXml(t.value)}</mo>`;
        break;
      case "lbrace":
        base = this.parseBraceGroup();
        break;
      case "rbrace":
        return "";
      case "lparen":
        base = `<mo>(</mo>${this.parseUntil("rparen")}<mo>)</mo>`;
        break;
      case "rparen":
        base = "<mo>)</mo>";
        break;
      case "lbrack":
        base = `<mo>[</mo>${this.parseUntil("rbrack")}<mo>]</mo>`;
        break;
      case "rbrack":
        base = "<mo>]</mo>";
        break;
      case "caret":
        return this.handleScript("msup");
      case "under":
        return this.handleScript("msub");
      case "amp":
        return "";
      case "dbl_back":
        return "";
      case "cmd":
        base = this.handleCommand(t.name);
        break;
    }
    return this.attachScripts(base);
  }
  parseBraceGroup() {
    const inner = this.parseGroup(true);
    const t = this.next();
    void t;
    return `<mrow>${inner}</mrow>`;
  }
  parseUntil(closer) {
    const out = [];
    while (this.pos < this.tokens.length) {
      const t = this.peek();
      if (!t || t.kind === closer) {
        if (t) this.pos++;
        break;
      }
      const atom = this.parseAtom();
      if (atom) out.push(atom);
    }
    return out.join("");
  }
  handleScript(kind) {
    const base = "<mrow></mrow>";
    const arg = this.parseScriptArg();
    return `<${kind}>${base}${arg}</${kind}>`;
  }
  parseScriptArg() {
    this.skipSpace();
    const t = this.peek();
    if (!t) return "<mrow></mrow>";
    if (t.kind === "lbrace") {
      this.pos++;
      return this.parseBraceGroup();
    }
    const atom = this.parseAtomBare();
    return atom || "<mrow></mrow>";
  }
  /** Same as parseAtom but does not consume trailing ^ or _. */
  parseAtomBare() {
    this.skipSpace();
    const t = this.next();
    if (!t) return "";
    switch (t.kind) {
      case "space":
        return "";
      case "num":
        return `<mn>${t.value}</mn>`;
      case "ident":
        return `<mi>${t.value}</mi>`;
      case "op":
        return `<mo>${escapeXml(t.value)}</mo>`;
      case "lbrace":
        return this.parseBraceGroup();
      case "rbrace":
        return "";
      case "lparen":
        return `<mo>(</mo>${this.parseUntil("rparen")}<mo>)</mo>`;
      case "rparen":
        return "<mo>)</mo>";
      case "lbrack":
        return `<mo>[</mo>${this.parseUntil("rbrack")}<mo>]</mo>`;
      case "rbrack":
        return "<mo>]</mo>";
      case "caret":
        return this.handleScript("msup");
      case "under":
        return this.handleScript("msub");
      case "amp":
        return "";
      case "dbl_back":
        return "";
      case "cmd":
        return this.handleCommand(t.name);
    }
  }
  attachScripts(base) {
    this.skipSpace();
    const next1 = this.peek();
    if (next1?.kind !== "caret" && next1?.kind !== "under") return base;
    this.pos++;
    const arg1 = this.parseScriptArg();
    this.skipSpace();
    const next2 = this.peek();
    const isOther = next2 && (next1.kind === "caret" && next2.kind === "under" || next1.kind === "under" && next2.kind === "caret");
    if (isOther) {
      this.pos++;
      const arg2 = this.parseScriptArg();
      if (next1.kind === "caret") return `<msubsup>${base}${arg2}${arg1}</msubsup>`;
      return `<msubsup>${base}${arg1}${arg2}</msubsup>`;
    }
    return next1.kind === "caret" ? `<msup>${base}${arg1}</msup>` : `<msub>${base}${arg1}</msub>`;
  }
  handleCommand(name) {
    if (name in GREEK) return `<mi>${GREEK[name]}</mi>`;
    if (name in OPERATORS) return `<mo>${OPERATORS[name]}</mo>`;
    if (name in BIG_OPS) return `<mo>${BIG_OPS[name]}</mo>`;
    if (FUNCTIONS.has(name)) return `<mi>${name}</mi>`;
    switch (name) {
      case "frac":
        return this.handleFrac();
      case "sqrt":
        return this.handleSqrt();
      case "vec":
        return this.handleAccent("\u2192");
      case "hat":
        return this.handleAccent("^");
      case "bar":
        return this.handleAccent("\u203E");
      case "tilde":
        return this.handleAccent("~");
      case "dot":
        return this.handleAccent("\u02D9");
      case "ddot":
        return this.handleAccent("\xA8");
      case "mathbf":
        return this.handleStyle("mathvariant", "bold");
      case "mathit":
        return this.handleStyle("mathvariant", "italic");
      case "mathrm":
        return this.handleStyle("mathvariant", "normal");
      case "mathcal":
        return this.handleStyle("mathvariant", "script");
      case "mathbb":
        return this.handleStyle("mathvariant", "double-struck");
      case "text":
        return this.handleText();
      case "left":
        return this.handleLeftRight();
      case "right":
        return "";
      case "begin":
        return this.handleEnvironment();
      case ",":
        return '<mspace width="0.166em"/>';
      case ";":
        return '<mspace width="0.222em"/>';
      case ":":
        return '<mspace width="0.222em"/>';
      case "!":
        return '<mspace width="-0.166em"/>';
      case "{":
        return "<mo>{</mo>";
      case "}":
        return "<mo>}</mo>";
      case "|":
        return "<mo>|</mo>";
    }
    return `<mi>\\${name}</mi>`;
  }
  handleFrac() {
    const num = this.parseScriptArg();
    const den = this.parseScriptArg();
    return `<mfrac>${num}${den}</mfrac>`;
  }
  handleSqrt() {
    this.skipSpace();
    if (this.peek()?.kind === "lbrack") {
      this.pos++;
      const idx = this.parseUntil("rbrack");
      const radicand2 = this.parseScriptArg();
      return `<mroot>${radicand2}<mrow>${idx}</mrow></mroot>`;
    }
    const radicand = this.parseScriptArg();
    return `<msqrt>${radicand}</msqrt>`;
  }
  handleAccent(accent) {
    const arg = this.parseScriptArg();
    return `<mover accent="true">${arg}<mo>${accent}</mo></mover>`;
  }
  handleStyle(attr, value) {
    const arg = this.parseScriptArg();
    return `<mstyle ${attr}="${value}">${arg}</mstyle>`;
  }
  handleText() {
    this.skipSpace();
    if (this.peek()?.kind !== "lbrace") return "";
    this.pos++;
    let body = "";
    while (this.pos < this.tokens.length) {
      const t = this.next();
      if (!t || t.kind === "rbrace") break;
      switch (t.kind) {
        case "space":
          body += " ";
          break;
        case "num":
          body += t.value;
          break;
        case "ident":
          body += t.value;
          break;
        case "op":
          body += t.value;
          break;
        case "lbrace":
          body += "{";
          break;
        case "cmd":
          body += "\\" + t.name;
          break;
        default:
          break;
      }
    }
    return `<mtext>${escapeXml(body)}</mtext>`;
  }
  handleLeftRight() {
    this.skipSpace();
    const t = this.next();
    let lDelim = "(";
    if (t) {
      if (t.kind === "op" || t.kind === "lparen" || t.kind === "lbrack")
        lDelim = t.value ?? "(";
      else if (t.kind === "cmd") lDelim = t.name === "{" ? "{" : OPERATORS[t.name] ?? "(";
    }
    const inner = [];
    while (this.pos < this.tokens.length) {
      const tk = this.peek();
      if (tk?.kind === "cmd" && tk.name === "right") {
        this.pos++;
        break;
      }
      const atom = this.parseAtom();
      if (atom) inner.push(atom);
    }
    this.skipSpace();
    let rDelim = ")";
    const r = this.next();
    if (r) {
      if (r.kind === "op" || r.kind === "rparen" || r.kind === "rbrack")
        rDelim = r.value ?? ")";
      else if (r.kind === "cmd") rDelim = r.name === "}" ? "}" : OPERATORS[r.name] ?? ")";
    }
    return `<mo stretchy="true">${escapeXml(lDelim)}</mo>${inner.join("")}<mo stretchy="true">${escapeXml(rDelim)}</mo>`;
  }
  handleEnvironment() {
    this.skipSpace();
    if (this.peek()?.kind !== "lbrace") return "";
    this.pos++;
    let envName = "";
    while (this.pos < this.tokens.length) {
      const t = this.next();
      if (!t || t.kind === "rbrace") break;
      if (t.kind === "ident") envName += t.value;
    }
    const delims = {
      matrix: ["", ""],
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["{", "}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\u2016", "\u2016"]
    };
    const [lD, rD] = delims[envName] ?? ["", ""];
    const rows = [[]];
    let cell = [];
    const flushCell = () => {
      rows[rows.length - 1].push(cell.join(""));
      cell = [];
    };
    while (this.pos < this.tokens.length) {
      const t = this.peek();
      if (!t) break;
      if (t.kind === "cmd" && t.name === "end") {
        this.pos++;
        if (this.peek()?.kind === "lbrace") {
          this.pos++;
          while (this.pos < this.tokens.length) {
            const n = this.next();
            if (!n || n.kind === "rbrace") break;
          }
        }
        break;
      }
      if (t.kind === "amp") {
        this.pos++;
        flushCell();
        continue;
      }
      if (t.kind === "dbl_back") {
        this.pos++;
        flushCell();
        rows.push([]);
        continue;
      }
      const atom = this.parseAtom();
      if (atom) cell.push(atom);
    }
    flushCell();
    if (rows.length > 0 && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0] === "")
      rows.pop();
    const tableBody = rows.map(
      (r) => `<mtr>${r.map((c) => `<mtd>${c}</mtd>`).join("")}</mtr>`
    ).join("");
    const table = `<mtable>${tableBody}</mtable>`;
    if (lD)
      return `<mo>${escapeXml(lD)}</mo>${table}<mo>${escapeXml(rD)}</mo>`;
    return table;
  }
};
function escapeXml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
var Latex = {
  /**
   * Convert a LaTeX string to a complete MathML document string.
   */
  toMathML(latex) {
    const tokens = tokenize(latex);
    const parser = new LatexParser(tokens);
    const body = parser.parse();
    return `<math xmlns="http://www.w3.org/1998/Math/MathML"><mrow>${body}</mrow></math>`;
  },
  /**
   * Render a LaTeX string as MathML inside the given DOM element.
   */
  render(el, latex) {
    el.innerHTML = Latex.toMathML(latex);
  },
  /**
   * Parse a simple infix expression and produce BOTH the equivalent
   * LaTeX source and the rendered MathML.
   */
  fromInfix(expr) {
    const ast = parseInfix(expr);
    const latex = astToLatex(ast);
    const mathml = Latex.toMathML(latex);
    return { latex, mathml };
  },
  /**
   * Numerically evaluate a simple infix expression.
   */
  evalInfix(expr, vars = {}) {
    return evalAst(parseInfix(expr), vars);
  }
};
var InfixParser = class {
  src;
  pos = 0;
  constructor(src) {
    this.src = src.replace(/\s+/g, "");
  }
  parse() {
    const ast = this.parseAddSub();
    if (this.pos < this.src.length)
      throw new Error(`Infix parse error at ${this.pos}: unexpected '${this.src[this.pos]}'`);
    return ast;
  }
  peek() {
    return this.src[this.pos] ?? "";
  }
  consume() {
    return this.src[this.pos++] ?? "";
  }
  parseAddSub() {
    let left = this.parseMulDiv();
    while (this.peek() === "+" || this.peek() === "-") {
      const op = this.consume();
      const right = this.parseMulDiv();
      left = { type: "bin", op, left, right };
    }
    return left;
  }
  parseMulDiv() {
    let left = this.parsePower();
    while (true) {
      const ch = this.peek();
      if (ch === "*" || ch === "/") {
        const op = this.consume();
        const right = this.parsePower();
        left = { type: "bin", op, left, right };
      } else if (ch && /[a-zA-Z(]/.test(ch) && (left.type === "num" || left.type === "var" || left.type === "call" || left.type === "bin" && left.op === "^")) {
        const right = this.parsePower();
        left = { type: "bin", op: "*", left, right };
      } else break;
    }
    return left;
  }
  parsePower() {
    const left = this.parseUnary();
    if (this.peek() === "^") {
      this.consume();
      const right = this.parsePower();
      return { type: "bin", op: "^", left, right };
    }
    return left;
  }
  parseUnary() {
    if (this.peek() === "-") {
      this.consume();
      return { type: "unary", op: "-", operand: this.parseUnary() };
    }
    if (this.peek() === "+") {
      this.consume();
      return this.parseUnary();
    }
    return this.parsePrimary();
  }
  parsePrimary() {
    const ch = this.peek();
    if (ch === "(") {
      this.consume();
      const inner = this.parseAddSub();
      if (this.consume() !== ")") throw new Error("Infix: missing closing )");
      return inner;
    }
    if (/[0-9.]/.test(ch)) {
      let num = "";
      while (this.pos < this.src.length && /[0-9.]/.test(this.peek())) num += this.consume();
      return { type: "num", value: parseFloat(num) };
    }
    if (/[a-zA-Z]/.test(ch)) {
      let name = "";
      while (this.pos < this.src.length && /[a-zA-Z]/.test(this.peek())) name += this.consume();
      if (this.peek() === "(") {
        this.consume();
        const arg = this.parseAddSub();
        if (this.consume() !== ")") throw new Error(`Infix: missing closing ) after ${name}(`);
        return { type: "call", fn: name, arg };
      }
      return { type: "var", name };
    }
    throw new Error(`Infix: unexpected '${ch}' at position ${this.pos}`);
  }
};
function parseInfix(src) {
  return new InfixParser(src).parse();
}
function astToLatex(node) {
  switch (node.type) {
    case "num":
      return String(node.value);
    case "var": {
      if (GREEK[node.name] !== void 0) return `\\${node.name}`;
      if (node.name === "pi") return "\\pi";
      if (node.name === "e") return "e";
      if (node.name.length === 1) return node.name;
      return `\\mathrm{${node.name}}`;
    }
    case "unary":
      return `-${astToLatex(node.operand)}`;
    case "call": {
      const a = astToLatex(node.arg);
      switch (node.fn) {
        case "sqrt":
          return `\\sqrt{${a}}`;
        case "abs":
          return `\\left|${a}\\right|`;
        default:
          if (FUNCTIONS.has(node.fn)) return `\\${node.fn}\\left(${a}\\right)`;
          return `\\mathrm{${node.fn}}\\left(${a}\\right)`;
      }
    }
    case "bin": {
      const l = astToLatex(node.left);
      const r = astToLatex(node.right);
      switch (node.op) {
        case "+":
          return `${l}+${r}`;
        case "-":
          return `${l}-${r}`;
        case "*":
          return `${l}\\cdot ${r}`;
        case "/":
          return `\\frac{${l}}{${r}}`;
        case "^": {
          const rEx = r.length > 1 ? `{${r}}` : r;
          const lEx = node.left.type === "bin" || node.left.type === "unary" ? `\\left(${l}\\right)` : l;
          return `${lEx}^${rEx}`;
        }
      }
    }
  }
}
function evalAst(node, vars) {
  switch (node.type) {
    case "num":
      return node.value;
    case "var": {
      if (node.name === "pi" || node.name === "PI") return Math.PI;
      if (node.name === "e" || node.name === "E") return Math.E;
      if (node.name in vars) return vars[node.name];
      throw new Error(`Undefined variable '${node.name}'`);
    }
    case "unary":
      return -evalAst(node.operand, vars);
    case "call": {
      const a = evalAst(node.arg, vars);
      const fns = {
        sqrt: Math.sqrt,
        abs: Math.abs,
        sin: Math.sin,
        cos: Math.cos,
        tan: Math.tan,
        asin: Math.asin,
        acos: Math.acos,
        atan: Math.atan,
        sinh: Math.sinh,
        cosh: Math.cosh,
        tanh: Math.tanh,
        log: Math.log10,
        ln: Math.log,
        exp: Math.exp
      };
      const fn = fns[node.fn];
      if (!fn) throw new Error(`Unknown function '${node.fn}'`);
      return fn(a);
    }
    case "bin": {
      const l = evalAst(node.left, vars);
      const r = evalAst(node.right, vars);
      switch (node.op) {
        case "+":
          return l + r;
        case "-":
          return l - r;
        case "*":
          return l * r;
        case "/":
          return l / r;
        case "^":
          return Math.pow(l, r);
      }
    }
  }
}
var LateX = {
  name: "LateX",
  version: "1.0.0",
  install(_core) {
    if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Latex")) {
      try {
        Object.defineProperty(window, "Latex", {
          value: Latex,
          writable: false,
          enumerable: false,
          configurable: false
        });
      } catch {
      }
    }
  }
};
var Latex_default = LateX;

// additionals/Midi.ts
var MidiEngine = class {
  #access = null;
  #handlers = [];
  #seq = 0;
  // monotonic noteId counter
  #activeNotes = /* @__PURE__ */ new Map();
  // `${ch}:${pitch}` → noteId
  async init() {
    if (typeof navigator === "undefined" || !("requestMIDIAccess" in navigator)) {
      return false;
    }
    try {
      this.#access = await navigator.requestMIDIAccess({ sysex: false });
      this.#access.inputs.forEach((input) => {
        input.onmidimessage = (e) => this.#parse(e);
      });
      return true;
    } catch {
      return false;
    }
  }
  #parse(e) {
    const data_ = e.data ? Array.from(e.data) : [0, 0, 0];
    const [status, d1, d2] = data_;
    const cmd = status >> 4;
    const ch = status & 15;
    const time = e.timeStamp || 0;
    let event = null;
    const key = `${ch}:${d1}`;
    if (cmd === 9 && d2 > 0) {
      const noteId = this.#newNoteId();
      this.#activeNotes.set(key, noteId);
      event = {
        type: "noteOn",
        time,
        channel: ch,
        noteId,
        pitch: d1,
        velocity: d2 << 9
        // 7-bit → 16-bit (preserve top bits)
      };
    } else if (cmd === 9 || cmd === 8) {
      const noteId = this.#activeNotes.get(key) ?? this.#newNoteId();
      this.#activeNotes.delete(key);
      event = {
        type: "noteOff",
        time,
        channel: ch,
        noteId,
        pitch: d1,
        velocity: d2 << 9
      };
    } else if (cmd === 11) {
      event = {
        type: "cc",
        time,
        channel: ch,
        control: d1,
        value: d2 << 9
      };
    } else if (cmd === 14) {
      const raw = d2 << 7 | d1;
      event = {
        type: "pitchBend",
        time,
        channel: ch,
        value: raw - 8192
      };
    } else if (cmd === 13) {
      event = {
        type: "pressure",
        time,
        channel: ch,
        value: d1 << 9
      };
    } else if (cmd === 12) {
      event = {
        type: "programChange",
        time,
        channel: ch,
        program: d1
      };
    } else {
      return;
    }
    this.#handlers.forEach((h) => h(event));
  }
  #newNoteId() {
    return `n-${(++this.#seq).toString(36)}-${Date.now().toString(36)}`;
  }
  on(handler) {
    this.#handlers.push(handler);
    return this;
  }
  /** Send a MidiEvent out to all available outputs (best-effort). */
  send(event) {
    if (!this.#access) return;
    const bytes = _eventToBytes(event);
    if (!bytes) return;
    this.#access.outputs.forEach((out) => out.send(bytes));
  }
  get inputs() {
    return this.#access?.inputs ?? null;
  }
  get outputs() {
    return this.#access?.outputs ?? null;
  }
};
function _eventToBytes(e) {
  switch (e.type) {
    case "noteOn":
      return [144 | e.channel & 15, e.pitch & 127, e.velocity >> 9 & 127];
    case "noteOff":
      return [128 | e.channel & 15, e.pitch & 127, e.velocity >> 9 & 127];
    case "cc":
      return [176 | e.channel & 15, e.control & 127, e.value >> 9 & 127];
    case "pitchBend": {
      const v = e.value + 8192;
      return [224 | e.channel & 15, v & 127, v >> 7 & 127];
    }
    case "pressure":
      return e.noteId !== void 0 && e.pitch !== void 0 ? [160 | e.channel & 15, e.pitch & 127, e.value >> 9 & 127] : [208 | e.channel & 15, e.value >> 9 & 127];
    // chan
    case "programChange":
      return [192 | e.channel & 15, e.program & 127];
    default:
      return null;
  }
}
var NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
function noteToFreq(note, pitchBendCents = 0) {
  return 440 * Math.pow(2, (note - 69 + pitchBendCents / 100) / 12);
}
function noteToName(note) {
  const n = NOTE_NAMES[(note % 12 + 12) % 12];
  const o = Math.floor(note / 12) - 1;
  return `${n}${o}`;
}
function nameToNote(name) {
  const m = name.match(/^([A-Ga-g])([#b]?)(-?\d+)$/);
  if (!m) return -1;
  const base = NOTE_NAMES.indexOf(m[1].toUpperCase());
  if (base < 0) return -1;
  const acc = m[2] === "#" ? 1 : m[2] === "b" ? -1 : 0;
  const oct = parseInt(m[3], 10);
  return base + acc + (oct + 1) * 12;
}
var AMID_MAGIC = 1095584068;
var AMID_VERSION = 1;
var KIND = {
  noteOn: 1,
  noteOff: 2,
  cc: 3,
  pitchBend: 4,
  pressure: 5,
  programChange: 6,
  perNoteExpression: 7,
  tempo: 8,
  timeSignature: 9,
  meta: 10
};
var KIND_TO_TYPE = {
  1: "noteOn",
  2: "noteOff",
  3: "cc",
  4: "pitchBend",
  5: "pressure",
  6: "programChange",
  7: "perNoteExpression",
  8: "tempo",
  9: "timeSignature",
  10: "meta"
};
var _W = class {
  buf = [];
  u8(v) {
    this.buf.push(v & 255);
  }
  u16(v) {
    this.buf.push(v >> 8 & 255, v & 255);
  }
  u32(v) {
    this.buf.push(v >>> 24 & 255, v >>> 16 & 255, v >>> 8 & 255, v & 255);
  }
  i16(v) {
    const u = v < 0 ? v + 65536 : v;
    this.u16(u);
  }
  i32(v) {
    const u = v < 0 ? v + 4294967296 : v;
    this.u32(u);
  }
  /** Variable-length encoding (SMF-style, 7 bits per byte, MSB = continuation). */
  vlq(v) {
    if (v < 0) v = 0;
    const out = [v & 127];
    v >>>= 7;
    while (v > 0) {
      out.unshift(v & 127 | 128);
      v >>>= 7;
    }
    for (const b of out) this.u8(b);
  }
  str(s) {
    const bytes = new TextEncoder().encode(s);
    this.u8(bytes.length);
    for (const b of bytes) this.u8(b);
  }
  bytes(arr) {
    for (let i = 0; i < arr.length; i++) this.u8(arr[i]);
  }
  toUint8Array() {
    return new Uint8Array(this.buf);
  }
};
var _R = class {
  constructor(src, pos = 0) {
    this.src = src;
    this.pos = pos;
  }
  src;
  pos;
  u8() {
    return this.src[this.pos++];
  }
  u16() {
    return this.u8() << 8 | this.u8();
  }
  u32() {
    return (this.u8() << 24 >>> 0) + (this.u8() << 16) + (this.u8() << 8) + this.u8();
  }
  i16() {
    const u = this.u16();
    return u >= 32768 ? u - 65536 : u;
  }
  i32() {
    const u = this.u32();
    return u >= 2147483648 ? u - 4294967296 : u;
  }
  vlq() {
    let v = 0;
    let b;
    do {
      b = this.u8();
      v = v << 7 | b & 127;
    } while (b & 128);
    return v;
  }
  str() {
    const len = this.u8();
    const slice = this.src.slice(this.pos, this.pos + len);
    this.pos += len;
    return new TextDecoder().decode(slice);
  }
};
function _writeEvent(w, e, prevTime) {
  const delta = Math.max(0, Math.floor(e.time - prevTime));
  w.vlq(delta);
  switch (e.type) {
    case "noteOn":
      w.u8(KIND.noteOn);
      w.u8(e.channel & 255);
      w.u8(e.pitch & 255);
      w.u16(e.velocity & 65535);
      w.str(e.noteId);
      w.i16(Math.round(e.pitchBend ?? 0));
      w.u16(e.timbre ?? 0);
      break;
    case "noteOff":
      w.u8(KIND.noteOff);
      w.u8(e.channel & 255);
      w.u8(e.pitch & 255);
      w.u16(e.velocity & 65535);
      w.str(e.noteId);
      break;
    case "cc":
      w.u8(KIND.cc);
      w.u8(e.channel & 255);
      w.u16(e.control & 65535);
      w.u16(e.value & 65535);
      break;
    case "pitchBend":
      w.u8(KIND.pitchBend);
      w.u8(e.channel & 255);
      w.i32(e.value);
      break;
    case "pressure":
      w.u8(KIND.pressure);
      w.u8(e.channel & 255);
      w.u8(e.pitch !== void 0 ? 1 : 0);
      if (e.pitch !== void 0) {
        w.u8(e.pitch & 255);
        w.str(e.noteId ?? "");
      }
      w.u16(e.value & 65535);
      break;
    case "programChange":
      w.u8(KIND.programChange);
      w.u8(e.channel & 255);
      w.u8(e.program & 255);
      w.u16(e.bank ?? 0);
      break;
    case "perNoteExpression":
      w.u8(KIND.perNoteExpression);
      w.u8(e.channel & 255);
      w.u8(e.pitch & 255);
      w.str(e.noteId);
      w.str(e.name);
      const buf = new ArrayBuffer(4);
      new DataView(buf).setFloat32(0, e.value, false);
      w.bytes(new Uint8Array(buf));
      break;
    case "tempo":
      w.u8(KIND.tempo);
      w.u32(e.uPerQ);
      break;
    case "timeSignature":
      w.u8(KIND.timeSignature);
      w.u8(e.numerator);
      w.u8(e.denominator);
      break;
    case "meta":
      w.u8(KIND.meta);
      w.str(e.name);
      w.str(e.value);
      break;
  }
  return e.time;
}
function _readEvent(r, prevTime) {
  const delta = r.vlq();
  const time = prevTime + delta;
  const kind = r.u8();
  const type = KIND_TO_TYPE[kind];
  switch (type) {
    case "noteOn": {
      const channel = r.u8();
      const pitch = r.u8();
      const velocity = r.u16();
      const noteId = r.str();
      const pitchBend = r.i16();
      const timbre = r.u16();
      const ev = { type, time, channel, pitch, velocity, noteId };
      if (pitchBend !== 0) ev.pitchBend = pitchBend;
      if (timbre !== 0) ev.timbre = timbre;
      return ev;
    }
    case "noteOff": {
      const channel = r.u8();
      const pitch = r.u8();
      const velocity = r.u16();
      const noteId = r.str();
      return { type, time, channel, pitch, velocity, noteId };
    }
    case "cc": {
      const channel = r.u8();
      const control = r.u16();
      const value = r.u16();
      return { type, time, channel, control, value };
    }
    case "pitchBend": {
      const channel = r.u8();
      const value = r.i32();
      return { type, time, channel, value };
    }
    case "pressure": {
      const channel = r.u8();
      const hasNote = r.u8();
      let noteId;
      let pitch;
      if (hasNote) {
        pitch = r.u8();
        noteId = r.str();
      }
      const value = r.u16();
      const ev = { type, time, channel, value };
      if (noteId !== void 0) ev.noteId = noteId;
      if (pitch !== void 0) ev.pitch = pitch;
      return ev;
    }
    case "programChange": {
      const channel = r.u8();
      const program = r.u8();
      const bank = r.u16();
      const ev = { type, time, channel, program };
      if (bank !== 0) ev.bank = bank;
      return ev;
    }
    case "perNoteExpression": {
      const channel = r.u8();
      const pitch = r.u8();
      const noteId = r.str();
      const name = r.str();
      const slice = r.src.slice(r.pos, r.pos + 4);
      r.pos += 4;
      const value = new DataView(slice.buffer, slice.byteOffset, 4).getFloat32(0, false);
      return { type, time, channel, noteId, pitch, name, value };
    }
    case "tempo":
      return { type, time, uPerQ: r.u32() };
    case "timeSignature":
      return { type, time, numerator: r.u8(), denominator: r.u8() };
    case "meta":
      return { type, time, name: r.str(), value: r.str() };
    default:
      throw new Error("Unknown event kind: " + kind);
  }
}
function writeBinary(song) {
  const w = new _W();
  w.u32(AMID_MAGIC);
  w.u16(AMID_VERSION);
  w.u16(0);
  w.u32(song.uPerQ);
  w.u16(song.ppq);
  w.u8(song.timeSignature[0]);
  w.u8(song.timeSignature[1]);
  w.str(song.title ?? "");
  w.str(song.author ?? "");
  w.u16(song.tracks.length);
  for (const tr of song.tracks) {
    w.str(tr.id);
    w.str(tr.name);
    w.u8(tr.channel & 255);
    w.str(tr.color ?? "");
    w.u32(tr.events.length);
    let prev = 0;
    for (const ev of tr.events) prev = _writeEvent(w, ev, prev);
  }
  return w.toUint8Array();
}
function readBinary(bytes) {
  const r = new _R(bytes);
  const magic = r.u32();
  if (magic !== AMID_MAGIC) throw new Error("AMID: bad magic");
  const version = r.u16();
  if (version !== AMID_VERSION) throw new Error("AMID: unsupported version " + version);
  r.u16();
  const uPerQ = r.u32();
  const ppq = r.u16();
  const num = r.u8();
  const den = r.u8();
  const title = r.str();
  const author = r.str();
  const trackCount = r.u16();
  const tracks = [];
  for (let i = 0; i < trackCount; i++) {
    const id = r.str();
    const name = r.str();
    const channel = r.u8();
    const color = r.str();
    const evCount = r.u32();
    const events = [];
    let prev = 0;
    for (let j = 0; j < evCount; j++) {
      const ev = _readEvent(r, prev);
      events.push(ev);
      prev = ev.time;
    }
    const tr = { id, name, channel, events };
    if (color) tr.color = color;
    tracks.push(tr);
  }
  const song = {
    $schema: "arianna.io/midi/v1",
    uPerQ,
    ppq,
    timeSignature: [num, den],
    tracks
  };
  if (title) song.title = title;
  if (author) song.author = author;
  return song;
}
var Midi = {
  Engine: MidiEngine,
  writeBinary,
  readBinary,
  noteToFreq,
  noteToName,
  nameToNote
};
var Midi_default = Midi;
if (typeof window !== "undefined") {
  try {
    delete window.Midi;
  } catch {
  }
  try {
    window.Midi = Midi;
  } catch {
  }
}

// additionals/Network.ts
var Network = {
  name: "AriannANetwork",
  version: "0.1.0",
  install(core, opts) {
    if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "AriannANetwork")) {
      try {
        Object.defineProperty(window, "AriannANetwork", {
          value: AriannANetworkAPI,
          writable: false,
          enumerable: false,
          configurable: false
        });
      } catch {
      }
    }
  }
};
var AriannANetworkAPI = {
  // TODO: implement Fetch wrapper, WebSocket, SSE ...
};
var Network_default = Network;

// additionals/Physics.ts
var V = {
  add: (a, b) => a.map((x, i) => x + b[i]),
  sub: (a, b) => a.map((x, i) => x - b[i]),
  scale: (a, s) => a.map((x) => x * s),
  dot: (a, b) => a.reduce((s, x, i) => s + x * b[i], 0),
  len: (a) => Math.hypot(...a),
  norm: (a) => {
    const l = Math.hypot(...a) || 1;
    return a.map((x) => x / l);
  },
  zero: (dim = 2) => dim === 2 ? [0, 0] : [0, 0, 0]
};
var Shape = class {
  area() {
    return 1;
  }
};
var Circle2 = class extends Shape {
  constructor(radius) {
    super();
    this.radius = radius;
  }
  radius;
  kind = "circle";
  bounds() {
    return { min: [-this.radius, -this.radius], max: [this.radius, this.radius] };
  }
  area() {
    return Math.PI * this.radius * this.radius;
  }
};
var Sphere2 = class extends Shape {
  constructor(radius) {
    super();
    this.radius = radius;
  }
  radius;
  kind = "sphere";
  bounds() {
    const r = this.radius;
    return { min: [-r, -r, -r], max: [r, r, r] };
  }
  area() {
    return 4 * Math.PI * this.radius * this.radius;
  }
};
var Box2 = class extends Shape {
  constructor(width, height, depth = 0) {
    super();
    this.width = width;
    this.height = height;
    this.depth = depth;
  }
  width;
  height;
  depth;
  kind = "box";
  bounds() {
    const hw = this.width / 2, hh = this.height / 2;
    if (this.depth) {
      const hd = this.depth / 2;
      return { min: [-hw, -hh, -hd], max: [hw, hh, hd] };
    }
    return { min: [-hw, -hh], max: [hw, hh] };
  }
  area() {
    return this.width * this.height;
  }
};
var Capsule = class extends Shape {
  constructor(start, end, radius) {
    super();
    this.start = start;
    this.end = end;
    this.radius = radius;
  }
  start;
  end;
  radius;
  kind = "capsule";
  bounds() {
    const min = this.start.map((s, i) => Math.min(s, this.end[i]) - this.radius);
    const max = this.start.map((s, i) => Math.max(s, this.end[i]) + this.radius);
    return { min, max };
  }
};
var Polygon2 = class extends Shape {
  constructor(verts) {
    super();
    this.verts = verts;
  }
  verts;
  kind = "polygon";
  bounds() {
    const xs = this.verts.map((v) => v[0]);
    const ys = this.verts.map((v) => v[1]);
    return {
      min: [Math.min(...xs), Math.min(...ys)],
      max: [Math.max(...xs), Math.max(...ys)]
    };
  }
};
var Body = class {
  shape;
  position;
  velocity;
  angle = 0;
  angularVelocity;
  mass;
  invMass;
  restitution;
  friction;
  static;
  constructor(opts) {
    this.shape = opts.shape;
    this.position = opts.position ?? [0, 0];
    this.velocity = opts.velocity ?? [0, 0];
    this.angularVelocity = opts.angularVelocity ?? 0;
    this.mass = opts.mass ?? this.shape.area();
    this.restitution = opts.restitution ?? 0.3;
    this.friction = opts.friction ?? 0.4;
    this.static = !!opts.static;
    this.invMass = this.static ? 0 : 1 / this.mass;
  }
  applyForce(f, dt) {
    if (this.static) return;
    this.velocity = V.add(this.velocity, V.scale(f, dt * this.invMass));
  }
};
var Spring2 = class {
  constructor(a, b, restLength, stiffness = 80, damping = 1) {
    this.a = a;
    this.b = b;
    this.restLength = restLength;
    this.stiffness = stiffness;
    this.damping = damping;
  }
  a;
  b;
  restLength;
  stiffness;
  damping;
};
var DistanceConstraint = class {
  constructor(a, b, dist) {
    this.a = a;
    this.b = b;
    this.dist = dist;
  }
  a;
  b;
  dist;
};
var Pin = class {
  constructor(body, at) {
    this.body = body;
    this.at = at;
  }
  body;
  at;
};
var Rope = class {
  constructor(from, to, count, radius = 0.05) {
    this.from = from;
    this.to = to;
    this.count = count;
    this.radius = radius;
  }
  from;
  to;
  count;
  radius;
  segments = [];
  constraints = [];
};
var Drag = class {
  constructor(coefficient = 0.1) {
    this.coefficient = coefficient;
  }
  coefficient;
};
var PointGravity = class {
  constructor(at, strength = 10) {
    this.at = at;
    this.strength = strength;
  }
  at;
  strength;
};
var Wind = class {
  constructor(direction, strength = 1, turbulence = 0) {
    this.direction = direction;
    this.strength = strength;
    this.turbulence = turbulence;
  }
  direction;
  strength;
  turbulence;
};
var World = class {
  gravity;
  dimension;
  substeps;
  timestep;
  bodies = [];
  constraints = [];
  fields = [];
  _raf = 0;
  _running = false;
  _accum = 0;
  _lastT = 0;
  constructor(opts = {}) {
    this.gravity = opts.gravity ?? [0, -9.81];
    this.dimension = opts.dimension ?? 2;
    this.substeps = opts.substeps ?? 4;
    this.timestep = opts.timestep ?? 1 / 60;
  }
  addBody(b) {
    this.bodies.push(b);
    return this;
  }
  removeBody(b) {
    this.bodies = this.bodies.filter((x) => x !== b);
    return this;
  }
  addConstraint(c) {
    this.constraints.push(c);
    return this;
  }
  addField(f) {
    this.fields.push(f);
    return this;
  }
  start() {
    if (this._running) return this;
    this._running = true;
    this._lastT = performance.now() / 1e3;
    const tick = () => {
      if (!this._running) return;
      const now = performance.now() / 1e3;
      const dt = Math.min(0.05, now - this._lastT);
      this._lastT = now;
      this._accum += dt;
      while (this._accum >= this.timestep) {
        this.step(this.timestep);
        this._accum -= this.timestep;
      }
      this._raf = requestAnimationFrame(tick);
    };
    this._raf = requestAnimationFrame(tick);
    return this;
  }
  stop() {
    this._running = false;
    if (this._raf) cancelAnimationFrame(this._raf);
    return this;
  }
  step(dt) {
    const sub = dt / this.substeps;
    for (let s = 0; s < this.substeps; s++) {
      for (const b of this.bodies) {
        if (b.static) continue;
        b.velocity = V.add(b.velocity, V.scale(this.gravity, sub));
        for (const f of this.fields) {
          if (f instanceof Drag) {
            b.velocity = V.scale(b.velocity, 1 - f.coefficient * sub);
          } else if (f instanceof Wind) {
            b.velocity = V.add(b.velocity, V.scale(f.direction, f.strength * sub));
          } else if (f instanceof PointGravity) {
            const d = V.sub(f.at, b.position);
            const r = V.len(d) || 1;
            b.velocity = V.add(b.velocity, V.scale(V.norm(d), f.strength * sub / (r * r)));
          }
        }
      }
      for (const b of this.bodies) {
        if (b.static) continue;
        b.position = V.add(b.position, V.scale(b.velocity, sub));
        b.angle += b.angularVelocity * sub;
      }
      for (const c of this.constraints) {
        if (c instanceof Spring2) {
          const delta = V.sub(c.b.position, c.a.position);
          const dist = V.len(delta) || 1e-6;
          const dir = V.scale(delta, 1 / dist);
          const x = dist - c.restLength;
          const force = V.scale(dir, c.stiffness * x);
          c.a.applyForce(force, sub);
          c.b.applyForce(V.scale(force, -1), sub);
        } else if (c instanceof Pin) {
          c.body.position = c.at.slice();
          c.body.velocity = V.zero(this.dimension);
        }
      }
      for (let i = 0; i < this.bodies.length; i++) {
        for (let j = i + 1; j < this.bodies.length; j++) {
          this._resolveCollision(this.bodies[i], this.bodies[j]);
        }
      }
    }
  }
  _resolveCollision(a, b) {
    if (a.static && b.static) return;
    if (a.shape.kind === "circle" && b.shape.kind === "circle") {
      const ra = a.shape.radius;
      const rb = b.shape.radius;
      const d = V.sub(b.position, a.position);
      const dist = V.len(d);
      const overlap = ra + rb - dist;
      if (overlap <= 0 || dist < 1e-6) return;
      const n = V.scale(d, 1 / dist);
      const totalInv = a.invMass + b.invMass;
      if (totalInv === 0) return;
      const correction = V.scale(n, overlap / totalInv);
      a.position = V.sub(a.position, V.scale(correction, a.invMass));
      b.position = V.add(b.position, V.scale(correction, b.invMass));
      const relV = V.sub(b.velocity, a.velocity);
      const velAlongN = V.dot(relV, n);
      if (velAlongN > 0) return;
      const e = Math.min(a.restitution, b.restitution);
      const jImpulse = -(1 + e) * velAlongN / totalInv;
      const impulse = V.scale(n, jImpulse);
      a.velocity = V.sub(a.velocity, V.scale(impulse, a.invMass));
      b.velocity = V.add(b.velocity, V.scale(impulse, b.invMass));
    } else {
      const ba = a.shape.bounds();
      const bb = b.shape.bounds();
      const aminX = a.position[0] + ba.min[0], amaxX = a.position[0] + ba.max[0];
      const bminX = b.position[0] + bb.min[0], bmaxX = b.position[0] + bb.max[0];
      const aminY = a.position[1] + ba.min[1], amaxY = a.position[1] + ba.max[1];
      const bminY = b.position[1] + bb.min[1], bmaxY = b.position[1] + bb.max[1];
      const overlapX = Math.min(amaxX - bminX, bmaxX - aminX);
      const overlapY = Math.min(amaxY - bminY, bmaxY - aminY);
      if (overlapX <= 0 || overlapY <= 0) return;
      const totalInv = a.invMass + b.invMass;
      if (totalInv === 0) return;
      const e = Math.min(a.restitution, b.restitution);
      if (overlapX < overlapY) {
        const sign = a.position[0] < b.position[0] ? -1 : 1;
        const corr = overlapX / totalInv;
        a.position[0] += sign * corr * a.invMass;
        b.position[0] -= sign * corr * b.invMass;
        const relV = b.velocity[0] - a.velocity[0];
        if (sign < 0 && relV < 0 || sign > 0 && relV > 0) {
          const j = -(1 + e) * relV / totalInv;
          a.velocity[0] -= j * a.invMass;
          b.velocity[0] += j * b.invMass;
        }
      } else {
        const sign = a.position[1] < b.position[1] ? -1 : 1;
        const corr = overlapY / totalInv;
        a.position[1] += sign * corr * a.invMass;
        b.position[1] -= sign * corr * b.invMass;
        const relV = b.velocity[1] - a.velocity[1];
        if (sign < 0 && relV < 0 || sign > 0 && relV > 0) {
          const j = -(1 + e) * relV / totalInv;
          a.velocity[1] -= j * a.invMass;
          b.velocity[1] += j * b.invMass;
        }
      }
    }
  }
  /**
   * Render every body on a 2D canvas. Useful for debug views and demos.
   *
   *   world.debugDraw(ctx, { scale: 50, offset: [400, 300] });
   */
  debugDraw(ctx, opts = {}) {
    const scale = opts.scale ?? 50;
    const offset = opts.offset ?? [ctx.canvas.width / 2, ctx.canvas.height * 0.7];
    const worldToScreen = (p) => [
      offset[0] + p[0] * scale,
      offset[1] - p[1] * scale
    ];
    for (const b of this.bodies) {
      ctx.save();
      const [sx, sy] = worldToScreen(b.position);
      ctx.translate(sx, sy);
      ctx.rotate(-b.angle);
      ctx.strokeStyle = b.static ? "#5a5a5a" : "#e40c88";
      ctx.lineWidth = 1.5;
      if (b.shape.kind === "circle") {
        const r = b.shape.radius * scale;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(r, 0);
        ctx.stroke();
      } else if (b.shape.kind === "box") {
        const w = b.shape.width * scale;
        const h = b.shape.height * scale;
        ctx.strokeRect(-w / 2, -h / 2, w, h);
      }
      ctx.restore();
    }
  }
};
var Physics = {
  V,
  Shape,
  Circle: Circle2,
  Sphere: Sphere2,
  Box: Box2,
  Capsule,
  Polygon: Polygon2,
  Body,
  Spring: Spring2,
  DistanceConstraint,
  Pin,
  Rope,
  Drag,
  PointGravity,
  Wind,
  World
};
if (typeof window !== "undefined" && !window.__ariannaPhysicsInstalled) {
  window.__ariannaPhysicsInstalled = true;
  for (const [k, v] of Object.entries(Physics)) {
    if (!Object.prototype.hasOwnProperty.call(window, k)) {
      try {
        window[k] = v;
      } catch {
      }
    }
  }
  try {
    window.Physics = Physics;
  } catch {
  }
}
var Physics_default = Physics;

// additionals/Three.ts
var Vec2 = class _Vec2 {
  constructor(x = 0, y = 0) {
    this.x = x;
    this.y = y;
  }
  x;
  y;
  set(x, y) {
    this.x = x;
    this.y = y;
    return this;
  }
  clone() {
    return new _Vec2(this.x, this.y);
  }
  add(v) {
    this.x += v.x;
    this.y += v.y;
    return this;
  }
  sub(v) {
    this.x -= v.x;
    this.y -= v.y;
    return this;
  }
  scale(s) {
    this.x *= s;
    this.y *= s;
    return this;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  }
  normalize() {
    const l = this.length() || 1;
    return this.scale(1 / l);
  }
  dot(v) {
    return this.x * v.x + this.y * v.y;
  }
  toArray() {
    return [this.x, this.y];
  }
  static from(a) {
    return new _Vec2(a[0], a[1]);
  }
};
var Vec3 = class _Vec3 {
  constructor(x = 0, y = 0, z = 0) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  x;
  y;
  z;
  set(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }
  clone() {
    return new _Vec3(this.x, this.y, this.z);
  }
  copy(v) {
    this.x = v.x;
    this.y = v.y;
    this.z = v.z;
    return this;
  }
  add(v) {
    this.x += v.x;
    this.y += v.y;
    this.z += v.z;
    return this;
  }
  addScalar(s) {
    this.x += s;
    this.y += s;
    this.z += s;
    return this;
  }
  sub(v) {
    this.x -= v.x;
    this.y -= v.y;
    this.z -= v.z;
    return this;
  }
  mul(v) {
    this.x *= v.x;
    this.y *= v.y;
    this.z *= v.z;
    return this;
  }
  scale(s) {
    this.x *= s;
    this.y *= s;
    this.z *= s;
    return this;
  }
  negate() {
    this.x = -this.x;
    this.y = -this.y;
    this.z = -this.z;
    return this;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
  }
  lengthSq() {
    return this.x * this.x + this.y * this.y + this.z * this.z;
  }
  normalize() {
    const l = this.length() || 1;
    return this.scale(1 / l);
  }
  dot(v) {
    return this.x * v.x + this.y * v.y + this.z * v.z;
  }
  cross(v) {
    return new _Vec3(
      this.y * v.z - this.z * v.y,
      this.z * v.x - this.x * v.z,
      this.x * v.y - this.y * v.x
    );
  }
  distanceTo(v) {
    return this.clone().sub(v).length();
  }
  lerp(v, t) {
    this.x += (v.x - this.x) * t;
    this.y += (v.y - this.y) * t;
    this.z += (v.z - this.z) * t;
    return this;
  }
  applyMat4(m) {
    const { x, y, z } = this;
    const e = m.elements;
    const w = 1 / (e[3] * x + e[7] * y + e[11] * z + e[15]);
    this.x = (e[0] * x + e[4] * y + e[8] * z + e[12]) * w;
    this.y = (e[1] * x + e[5] * y + e[9] * z + e[13]) * w;
    this.z = (e[2] * x + e[6] * y + e[10] * z + e[14]) * w;
    return this;
  }
  applyQuat(q) {
    const { x, y, z } = this;
    const qx = q.x, qy = q.y, qz = q.z, qw = q.w;
    const ix = qw * x + qy * z - qz * y;
    const iy = qw * y + qz * x - qx * z;
    const iz = qw * z + qx * y - qy * x;
    const iw = -qx * x - qy * y - qz * z;
    this.x = ix * qw + iw * -qx + iy * -qz - iz * -qy;
    this.y = iy * qw + iw * -qy + iz * -qx - ix * -qz;
    this.z = iz * qw + iw * -qz + ix * -qy - iy * -qx;
    return this;
  }
  toArray() {
    return [this.x, this.y, this.z];
  }
  toFloat32() {
    return new Float32Array([this.x, this.y, this.z]);
  }
  equals(v, eps = 1e-6) {
    return Math.abs(this.x - v.x) < eps && Math.abs(this.y - v.y) < eps && Math.abs(this.z - v.z) < eps;
  }
  static from(a) {
    return new _Vec3(a[0], a[1], a[2]);
  }
  static add(a, b) {
    return a.clone().add(b);
  }
  static sub(a, b) {
    return a.clone().sub(b);
  }
  static cross(a, b) {
    return a.cross(b);
  }
  static dot(a, b) {
    return a.dot(b);
  }
};
var Vec4 = class _Vec4 {
  constructor(x = 0, y = 0, z = 0, w = 1) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
  }
  x;
  y;
  z;
  w;
  set(x, y, z, w) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
    return this;
  }
  clone() {
    return new _Vec4(this.x, this.y, this.z, this.w);
  }
  toArray() {
    return [this.x, this.y, this.z, this.w];
  }
  toFloat32() {
    return new Float32Array([this.x, this.y, this.z, this.w]);
  }
};
var Quaternion2 = class _Quaternion {
  constructor(x = 0, y = 0, z = 0, w = 1) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
  }
  x;
  y;
  z;
  w;
  set(x, y, z, w) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
    return this;
  }
  clone() {
    return new _Quaternion(this.x, this.y, this.z, this.w);
  }
  copy(q) {
    this.x = q.x;
    this.y = q.y;
    this.z = q.z;
    this.w = q.w;
    return this;
  }
  identity() {
    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.w = 1;
    return this;
  }
  setFromAxisAngle(axis, angle) {
    const half = angle / 2;
    const s = Math.sin(half);
    this.x = axis.x * s;
    this.y = axis.y * s;
    this.z = axis.z * s;
    this.w = Math.cos(half);
    return this;
  }
  setFromEuler(x, y, z) {
    const cx = Math.cos(x / 2), sx = Math.sin(x / 2);
    const cy = Math.cos(y / 2), sy = Math.sin(y / 2);
    const cz = Math.cos(z / 2), sz = Math.sin(z / 2);
    this.x = sx * cy * cz + cx * sy * sz;
    this.y = cx * sy * cz - sx * cy * sz;
    this.z = cx * cy * sz + sx * sy * cz;
    this.w = cx * cy * cz - sx * sy * sz;
    return this;
  }
  multiply(q) {
    const ax = this.x, ay = this.y, az = this.z, aw = this.w;
    const bx = q.x, by = q.y, bz = q.z, bw = q.w;
    this.x = ax * bw + aw * bx + ay * bz - az * by;
    this.y = ay * bw + aw * by + az * bx - ax * bz;
    this.z = az * bw + aw * bz + ax * by - ay * bx;
    this.w = aw * bw - ax * bx - ay * by - az * bz;
    return this;
  }
  normalize() {
    const l = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w) || 1;
    this.x /= l;
    this.y /= l;
    this.z /= l;
    this.w /= l;
    return this;
  }
  slerp(q, t) {
    let dot = this.x * q.x + this.y * q.y + this.z * q.z + this.w * q.w;
    if (dot < 0) {
      dot = -dot;
      q = new _Quaternion(-q.x, -q.y, -q.z, -q.w);
    }
    if (dot > 0.9995) {
      this.x += t * (q.x - this.x);
      this.y += t * (q.y - this.y);
      this.z += t * (q.z - this.z);
      this.w += t * (q.w - this.w);
      return this.normalize();
    }
    const theta0 = Math.acos(dot);
    const theta = theta0 * t;
    const sin0 = Math.sin(theta0);
    const sinT = Math.sin(theta);
    const s1 = Math.cos(theta) - dot * sinT / sin0;
    const s2 = sinT / sin0;
    this.x = s1 * this.x + s2 * q.x;
    this.y = s1 * this.y + s2 * q.y;
    this.z = s1 * this.z + s2 * q.z;
    this.w = s1 * this.w + s2 * q.w;
    return this;
  }
  toArray() {
    return [this.x, this.y, this.z, this.w];
  }
};
var Mat4 = class _Mat4 {
  elements;
  constructor() {
    this.elements = new Float32Array(16);
    this.identity();
  }
  identity() {
    const e = this.elements;
    e.fill(0);
    e[0] = e[5] = e[10] = e[15] = 1;
    return this;
  }
  clone() {
    const m = new _Mat4();
    m.elements.set(this.elements);
    return m;
  }
  copy(m) {
    this.elements.set(m.elements);
    return this;
  }
  multiply(m) {
    const a = this.elements, b = m.elements, r = new Float32Array(16);
    for (let i = 0; i < 4; i++)
      for (let j = 0; j < 4; j++) {
        let s = 0;
        for (let k = 0; k < 4; k++) s += a[i * 4 + k] * b[k * 4 + j];
        r[i * 4 + j] = s;
      }
    this.elements.set(r);
    return this;
  }
  makeTranslation(x, y, z) {
    this.identity();
    this.elements[12] = x;
    this.elements[13] = y;
    this.elements[14] = z;
    return this;
  }
  makeScale(x, y, z) {
    this.identity();
    this.elements[0] = x;
    this.elements[5] = y;
    this.elements[10] = z;
    return this;
  }
  makeRotationFromQuat(q) {
    const { x, y, z, w } = q;
    const e = this.elements;
    e[0] = 1 - 2 * (y * y + z * z);
    e[1] = 2 * (x * y + z * w);
    e[2] = 2 * (x * z - y * w);
    e[3] = 0;
    e[4] = 2 * (x * y - z * w);
    e[5] = 1 - 2 * (x * x + z * z);
    e[6] = 2 * (y * z + x * w);
    e[7] = 0;
    e[8] = 2 * (x * z + y * w);
    e[9] = 2 * (y * z - x * w);
    e[10] = 1 - 2 * (x * x + y * y);
    e[11] = 0;
    e[12] = 0;
    e[13] = 0;
    e[14] = 0;
    e[15] = 1;
    return this;
  }
  compose(pos, rot, scl) {
    const te = this.elements;
    const { x, y, z, w } = rot;
    const x2 = x + x, y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2;
    const yy = y * y2, yz = y * z2, zz = z * z2;
    const wx = w * x2, wy = w * y2, wz = w * z2;
    const { x: sx, y: sy, z: sz } = scl;
    te[0] = (1 - (yy + zz)) * sx;
    te[1] = (xy + wz) * sx;
    te[2] = (xz - wy) * sx;
    te[3] = 0;
    te[4] = (xy - wz) * sy;
    te[5] = (1 - (xx + zz)) * sy;
    te[6] = (yz + wx) * sy;
    te[7] = 0;
    te[8] = (xz + wy) * sz;
    te[9] = (yz - wx) * sz;
    te[10] = (1 - (xx + yy)) * sz;
    te[11] = 0;
    te[12] = pos.x;
    te[13] = pos.y;
    te[14] = pos.z;
    te[15] = 1;
    return this;
  }
  makePerspective(fovY, aspect, near, far) {
    const f = 1 / Math.tan(fovY * Math.PI / 360);
    const e = this.elements;
    e.fill(0);
    e[0] = f / aspect;
    e[5] = f;
    e[10] = -(far + near) / (far - near);
    e[11] = -1;
    e[14] = -(2 * far * near) / (far - near);
    return this;
  }
  makeOrthographic(l, r, t, b, near, far) {
    const e = this.elements;
    e.fill(0);
    e[0] = 2 / (r - l);
    e[12] = -(r + l) / (r - l);
    e[5] = 2 / (t - b);
    e[13] = -(t + b) / (t - b);
    e[10] = -2 / (far - near);
    e[14] = -(far + near) / (far - near);
    e[15] = 1;
    return this;
  }
  lookAt(eye, target, up) {
    const f = Vec3.sub(eye, target).normalize();
    const r = Vec3.cross(up.clone().normalize(), f).normalize();
    const u = Vec3.cross(f, r);
    const e = this.elements;
    e[0] = r.x;
    e[4] = r.y;
    e[8] = r.z;
    e[12] = -(r.x * eye.x + r.y * eye.y + r.z * eye.z);
    e[1] = u.x;
    e[5] = u.y;
    e[9] = u.z;
    e[13] = -(u.x * eye.x + u.y * eye.y + u.z * eye.z);
    e[2] = f.x;
    e[6] = f.y;
    e[10] = f.z;
    e[14] = -(f.x * eye.x + f.y * eye.y + f.z * eye.z);
    e[3] = 0;
    e[7] = 0;
    e[11] = 0;
    e[15] = 1;
    return this;
  }
  invert() {
    const a = this.elements, inv = new Float32Array(16);
    inv[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10];
    inv[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10];
    inv[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9];
    inv[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9];
    inv[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10];
    inv[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10];
    inv[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9];
    inv[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9];
    inv[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6];
    inv[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6];
    inv[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5];
    inv[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5];
    inv[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6];
    inv[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6];
    inv[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5];
    inv[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5];
    let det = a[0] * inv[0] + a[1] * inv[4] + a[2] * inv[8] + a[3] * inv[12];
    if (Math.abs(det) < 1e-10) return this;
    det = 1 / det;
    for (let i = 0; i < 16; i++) this.elements[i] = inv[i] * det;
    return this;
  }
  transpose() {
    const e = this.elements;
    let t;
    t = e[1];
    e[1] = e[4];
    e[4] = t;
    t = e[2];
    e[2] = e[8];
    e[8] = t;
    t = e[3];
    e[3] = e[12];
    e[12] = t;
    t = e[6];
    e[6] = e[9];
    e[9] = t;
    t = e[7];
    e[7] = e[13];
    e[13] = t;
    t = e[11];
    e[11] = e[14];
    e[14] = t;
    return this;
  }
};
var Box3 = class {
  min = new Vec3(Infinity, Infinity, Infinity);
  max = new Vec3(-Infinity, -Infinity, -Infinity);
  expandByPoint(p) {
    this.min.x = Math.min(this.min.x, p.x);
    this.min.y = Math.min(this.min.y, p.y);
    this.min.z = Math.min(this.min.z, p.z);
    this.max.x = Math.max(this.max.x, p.x);
    this.max.y = Math.max(this.max.y, p.y);
    this.max.z = Math.max(this.max.z, p.z);
    return this;
  }
  getCenter(out = new Vec3()) {
    return out.set(
      (this.min.x + this.max.x) / 2,
      (this.min.y + this.max.y) / 2,
      (this.min.z + this.max.z) / 2
    );
  }
  getSize(out = new Vec3()) {
    return out.set(
      this.max.x - this.min.x,
      this.max.y - this.min.y,
      this.max.z - this.min.z
    );
  }
};
var Color = class _Color {
  r;
  g;
  b;
  a;
  constructor(r = 1, g = 1, b = 1, a = 1) {
    this.r = r;
    this.g = g;
    this.b = b;
    this.a = a;
  }
  setHex(hex) {
    const h = hex.replace("#", "");
    this.r = parseInt(h.slice(0, 2), 16) / 255;
    this.g = parseInt(h.slice(2, 4), 16) / 255;
    this.b = parseInt(h.slice(4, 6), 16) / 255;
    return this;
  }
  toArray() {
    return [this.r, this.g, this.b, this.a];
  }
  toFloat32() {
    return new Float32Array([this.r, this.g, this.b, this.a]);
  }
  clone() {
    return new _Color(this.r, this.g, this.b, this.a);
  }
  static fromHex(hex) {
    return new _Color().setHex(hex);
  }
  static white() {
    return new _Color(1, 1, 1, 1);
  }
  static black() {
    return new _Color(0, 0, 0, 1);
  }
};
var BufferGeometry = class _BufferGeometry {
  positions = new Float32Array(0);
  normals = new Float32Array(0);
  uvs = new Float32Array(0);
  indices = new Uint32Array(0);
  vertexCount = 0;
  indexCount = 0;
  boundingBox = new Box3();
  setPositions(data) {
    this.positions = data instanceof Float32Array ? data : new Float32Array(data);
    this.vertexCount = this.positions.length / 3;
    this.#computeBB();
    return this;
  }
  setNormals(data) {
    this.normals = data instanceof Float32Array ? data : new Float32Array(data);
    return this;
  }
  setUVs(data) {
    this.uvs = data instanceof Float32Array ? data : new Float32Array(data);
    return this;
  }
  setIndices(data) {
    this.indices = data instanceof Uint32Array ? data : new Uint32Array(data);
    this.indexCount = this.indices.length;
    return this;
  }
  #computeBB() {
    this.boundingBox = new Box3();
    for (let i = 0; i < this.positions.length; i += 3)
      this.boundingBox.expandByPoint(new Vec3(this.positions[i], this.positions[i + 1], this.positions[i + 2]));
  }
  computeNormals() {
    const pos = this.positions, idx = this.indices;
    const nrm = new Float32Array(pos.length);
    const process = (i0, i1, i2) => {
      const ax = pos[i0 * 3], ay = pos[i0 * 3 + 1], az = pos[i0 * 3 + 2];
      const bx = pos[i1 * 3], by = pos[i1 * 3 + 1], bz = pos[i1 * 3 + 2];
      const cx = pos[i2 * 3], cy = pos[i2 * 3 + 1], cz = pos[i2 * 3 + 2];
      const ex = bx - ax, ey = by - ay, ez = bz - az;
      const fx = cx - ax, fy = cy - ay, fz = cz - az;
      const nx = ey * fz - ez * fy, ny = ez * fx - ex * fz, nz = ex * fy - ey * fx;
      for (const ii of [i0, i1, i2]) {
        nrm[ii * 3] += nx;
        nrm[ii * 3 + 1] += ny;
        nrm[ii * 3 + 2] += nz;
      }
    };
    if (idx.length > 0)
      for (let i = 0; i < idx.length; i += 3) process(idx[i], idx[i + 1], idx[i + 2]);
    else
      for (let i = 0; i < pos.length / 3; i += 3) process(i, i + 1, i + 2);
    for (let i = 0; i < nrm.length; i += 3) {
      const l = Math.sqrt(nrm[i] * nrm[i] + nrm[i + 1] * nrm[i + 1] + nrm[i + 2] * nrm[i + 2]) || 1;
      nrm[i] /= l;
      nrm[i + 1] /= l;
      nrm[i + 2] /= l;
    }
    this.normals = nrm;
    return this;
  }
  clone() {
    const g = new _BufferGeometry();
    g.positions = new Float32Array(this.positions);
    g.normals = new Float32Array(this.normals);
    g.uvs = new Float32Array(this.uvs);
    g.indices = new Uint32Array(this.indices);
    g.vertexCount = this.vertexCount;
    g.indexCount = this.indexCount;
    return g;
  }
};
var BoxGeometry = class extends BufferGeometry {
  constructor(w = 1, h = 1, d = 1, wSeg = 1, hSeg = 1, dSeg = 1) {
    super();
    const hw = w / 2, hh = h / 2, hd = d / 2;
    const pos = [], nrm = [], uv = [], idx = [];
    let vi = 0;
    const addFace = (ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, nx, ny, nz) => {
      pos.push(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz);
      for (let i = 0; i < 4; i++) nrm.push(nx, ny, nz);
      uv.push(0, 0, 1, 0, 1, 1, 0, 1);
      idx.push(vi, vi + 1, vi + 2, vi, vi + 2, vi + 3);
      vi += 4;
    };
    addFace(-hw, -hh, hd, hw, -hh, hd, hw, hh, hd, -hw, hh, hd, 0, 0, 1);
    addFace(hw, -hh, -hd, -hw, -hh, -hd, -hw, hh, -hd, hw, hh, -hd, 0, 0, -1);
    addFace(-hw, hh, hd, hw, hh, hd, hw, hh, -hd, -hw, hh, -hd, 0, 1, 0);
    addFace(-hw, -hh, -hd, hw, -hh, -hd, hw, -hh, hd, -hw, -hh, hd, 0, -1, 0);
    addFace(hw, -hh, hd, hw, -hh, -hd, hw, hh, -hd, hw, hh, hd, 1, 0, 0);
    addFace(-hw, -hh, -hd, -hw, -hh, hd, -hw, hh, hd, -hw, hh, -hd, -1, 0, 0);
    this.setPositions(pos).setNormals(nrm).setUVs(uv).setIndices(idx);
  }
};
var SphereGeometry = class extends BufferGeometry {
  constructor(radius = 1, wSeg = 32, hSeg = 16) {
    super();
    const pos = [], nrm = [], uv = [], idx = [];
    for (let j = 0; j <= hSeg; j++) {
      const theta = j * Math.PI / hSeg;
      const sinT = Math.sin(theta), cosT = Math.cos(theta);
      for (let i = 0; i <= wSeg; i++) {
        const phi = i * 2 * Math.PI / wSeg;
        const x = -sinT * Math.cos(phi);
        const y = cosT;
        const z = sinT * Math.sin(phi);
        pos.push(x * radius, y * radius, z * radius);
        nrm.push(x, y, z);
        uv.push(i / wSeg, j / hSeg);
      }
    }
    for (let j = 0; j < hSeg; j++)
      for (let i = 0; i < wSeg; i++) {
        const a = j * (wSeg + 1) + i, b = a + wSeg + 1;
        idx.push(a, b, a + 1, b, b + 1, a + 1);
      }
    this.setPositions(pos).setNormals(nrm).setUVs(uv).setIndices(idx);
  }
};
var CylinderGeometry = class extends BufferGeometry {
  constructor(rTop = 0.5, rBot = 0.5, height = 1, radSeg = 32, hSeg = 1, openEnded = false) {
    super();
    const pos = [], nrm = [], uv = [], idx = [];
    let vi = 0;
    const hy = height / 2;
    for (let j = 0; j <= hSeg; j++) {
      const v = j / hSeg;
      const r = rTop + (rBot - rTop) * v;
      const y = hy - height * v;
      for (let i = 0; i <= radSeg; i++) {
        const theta = i * 2 * Math.PI / radSeg;
        const x = Math.sin(theta), z = Math.cos(theta);
        const slope = (rBot - rTop) / height;
        const nl = Math.sqrt(1 + slope * slope);
        pos.push(x * r, y, z * r);
        nrm.push(x / nl, slope / nl, z / nl);
        uv.push(i / radSeg, 1 - v);
      }
    }
    for (let j = 0; j < hSeg; j++)
      for (let i = 0; i < radSeg; i++) {
        const a = j * (radSeg + 1) + i, b = a + radSeg + 1;
        idx.push(a, b, a + 1, b, b + 1, a + 1);
        vi += 2;
      }
    const colCount = radSeg + 1;
    if (!openEnded) {
      const topY = hy, botY = -hy;
      const topCenter = pos.length / 3;
      pos.push(0, topY, 0);
      nrm.push(0, 1, 0);
      uv.push(0.5, 0.5);
      for (let i = 0; i <= radSeg; i++) {
        const theta = i * 2 * Math.PI / radSeg;
        pos.push(Math.sin(theta) * rTop, topY, Math.cos(theta) * rTop);
        nrm.push(0, 1, 0);
        uv.push(0.5 + 0.5 * Math.sin(theta), 0.5 + 0.5 * Math.cos(theta));
      }
      for (let i = 0; i < radSeg; i++) idx.push(topCenter, topCenter + 1 + i + 1, topCenter + 1 + i);
      const botCenter = pos.length / 3;
      pos.push(0, botY, 0);
      nrm.push(0, -1, 0);
      uv.push(0.5, 0.5);
      for (let i = 0; i <= radSeg; i++) {
        const theta = i * 2 * Math.PI / radSeg;
        pos.push(Math.sin(theta) * rBot, botY, Math.cos(theta) * rBot);
        nrm.push(0, -1, 0);
        uv.push(0.5 + 0.5 * Math.sin(theta), 0.5 + 0.5 * Math.cos(theta));
      }
      for (let i = 0; i < radSeg; i++) idx.push(botCenter, botCenter + 1 + i, botCenter + 1 + i + 1);
    }
    this.setPositions(pos).setNormals(nrm).setUVs(uv).setIndices(idx);
  }
};
var PlaneGeometry = class extends BufferGeometry {
  constructor(w = 1, h = 1, wSeg = 1, hSeg = 1) {
    super();
    const pos = [], nrm = [], uv = [], idx = [];
    const hw = w / 2, hh = h / 2;
    for (let j = 0; j <= hSeg; j++)
      for (let i = 0; i <= wSeg; i++) {
        pos.push(-hw + i * w / wSeg, hh - j * h / hSeg, 0);
        nrm.push(0, 0, 1);
        uv.push(i / wSeg, 1 - j / hSeg);
      }
    for (let j = 0; j < hSeg; j++)
      for (let i = 0; i < wSeg; i++) {
        const a = j * (wSeg + 1) + i, b = a + wSeg + 1;
        idx.push(a, b, a + 1, b, b + 1, a + 1);
      }
    this.setPositions(pos).setNormals(nrm).setUVs(uv).setIndices(idx);
  }
};
var ConeGeometry = class extends CylinderGeometry {
  constructor(radius = 1, height = 2, radSeg = 32, hSeg = 1) {
    super(0, radius, height, radSeg, hSeg);
  }
};
var TorusGeometry = class extends BufferGeometry {
  constructor(radius = 1, tube = 0.4, radSeg = 32, tubeSeg = 16) {
    super();
    const pos = [], nrm = [], uv = [], idx = [];
    for (let j = 0; j <= radSeg; j++) {
      for (let i = 0; i <= tubeSeg; i++) {
        const u = i / tubeSeg * 2 * Math.PI;
        const v = j / radSeg * 2 * Math.PI;
        const x = (radius + tube * Math.cos(v)) * Math.cos(u);
        const y = (radius + tube * Math.cos(v)) * Math.sin(u);
        const z = tube * Math.sin(v);
        pos.push(x, y, z);
        const cx = Math.cos(u) * Math.cos(v), cy = Math.sin(u) * Math.cos(v), cz = Math.sin(v);
        nrm.push(cx, cy, cz);
        uv.push(i / tubeSeg, j / radSeg);
      }
    }
    for (let j = 0; j < radSeg; j++)
      for (let i = 0; i < tubeSeg; i++) {
        const a = j * (tubeSeg + 1) + i, b = a + tubeSeg + 1;
        idx.push(a, b, a + 1, b, b + 1, a + 1);
      }
    this.setPositions(pos).setNormals(nrm).setUVs(uv).setIndices(idx);
  }
};
function _toColor(c) {
  if (!c) return Color.white();
  if (c instanceof Color) return c.clone();
  return Color.fromHex(c);
}
var Material = class {
  color;
  emissive;
  roughness;
  metalness;
  opacity;
  wireframe;
  side;
  type = "basic";
  constructor(opts = {}) {
    this.color = _toColor(opts.color);
    this.emissive = _toColor(opts.emissive ?? "#000000");
    this.roughness = opts.roughness ?? 0.5;
    this.metalness = opts.metalness ?? 0;
    this.opacity = opts.opacity ?? 1;
    this.wireframe = opts.wireframe ?? false;
    this.side = opts.side ?? "front";
  }
};
var MeshBasicMaterial = class extends Material {
  constructor(o = {}) {
    super(o);
    this.type = "basic";
  }
};
var MeshLambertMaterial = class extends Material {
  constructor(o = {}) {
    super(o);
    this.type = "lambert";
  }
};
var MeshPhongMaterial = class extends Material {
  shininess = 30;
  constructor(o = {}) {
    super(o);
    this.type = "phong";
    this.shininess = o.shininess ?? 30;
  }
};
var MeshPBRMaterial = class extends Material {
  constructor(o = {}) {
    super(o);
    this.type = "pbr";
  }
};
var WireframeMaterial = class extends Material {
  constructor(o = {}) {
    super({ ...o, wireframe: true });
    this.type = "wireframe";
  }
};
var LineMaterial = class extends Material {
  lineWidth = 1;
  constructor(o = {}) {
    super(o);
    this.type = "line";
    this.lineWidth = o.lineWidth ?? 1;
  }
};
var Light = class {
  color;
  intensity;
  type = "ambient";
  constructor(opts = {}) {
    this.color = _toColor(opts.color ?? "#ffffff");
    this.intensity = opts.intensity ?? 1;
  }
};
var AmbientLight = class extends Light {
  constructor(o = {}) {
    super(o);
    this.type = "ambient";
  }
};
var DirectionalLight = class extends Light {
  direction = new Vec3(0, -1, 0);
  castShadow = false;
  constructor(o = {}) {
    super(o);
    this.type = "directional";
    if (o.direction) this.direction.copy(o.direction);
  }
};
var PointLight = class extends Light {
  position = new Vec3();
  distance = 0;
  decay = 2;
  constructor(o = {}) {
    super(o);
    this.type = "point";
    if (o.position) this.position.copy(o.position);
    if (o.distance !== void 0) this.distance = o.distance;
  }
};
var SpotLight = class extends Light {
  position = new Vec3();
  direction = new Vec3(0, -1, 0);
  angle = Math.PI / 6;
  penumbra = 0.1;
  constructor(o = {}) {
    super(o);
    this.type = "spot";
    if (o.position) this.position.copy(o.position);
    if (o.direction) this.direction.copy(o.direction);
    if (o.angle !== void 0) this.angle = o.angle;
  }
};
var _objId = 0;
var Object3D = class _Object3D {
  id = ++_objId;
  name = "";
  position = new Vec3();
  rotation = new Vec3();
  // Euler XYZ radians
  quaternion = new Quaternion2();
  scale = new Vec3(1, 1, 1);
  matrix = new Mat4();
  matrixWorld = new Mat4();
  parent = null;
  children = [];
  visible = true;
  castShadow = false;
  receiveShadow = false;
  userData = {};
  add(...objects) {
    for (const o of objects) {
      if (o.parent) o.parent.remove(o);
      o.parent = this;
      this.children.push(o);
    }
    return this;
  }
  remove(...objects) {
    for (const o of objects) {
      const i = this.children.indexOf(o);
      if (i >= 0) {
        this.children.splice(i, 1);
        o.parent = null;
      }
    }
    return this;
  }
  updateMatrix() {
    this.quaternion.setFromEuler(this.rotation.x, this.rotation.y, this.rotation.z);
    this.matrix.compose(this.position, this.quaternion, this.scale);
  }
  updateMatrixWorld(force = false) {
    this.updateMatrix();
    if (!this.parent) {
      this.matrixWorld.copy(this.matrix);
    } else {
      this.matrixWorld.copy(this.parent.matrixWorld).multiply(this.matrix);
    }
    for (const child of this.children) child.updateMatrixWorld(force);
  }
  traverse(cb) {
    cb(this);
    for (const c of this.children) c.traverse(cb);
  }
  getWorldPosition(out = new Vec3()) {
    this.updateMatrixWorld();
    out.x = this.matrixWorld.elements[12];
    out.y = this.matrixWorld.elements[13];
    out.z = this.matrixWorld.elements[14];
    return out;
  }
  lookAt(target) {
    const pos = this.getWorldPosition();
    const m = new Mat4().lookAt(pos, target, new Vec3(0, 1, 0));
    this.quaternion.setFromEuler(
      Math.atan2(m.elements[6], m.elements[10]),
      Math.atan2(-m.elements[2], Math.sqrt(m.elements[6] ** 2 + m.elements[10] ** 2)),
      Math.atan2(m.elements[1], m.elements[0])
    );
  }
  clone(recursive = true) {
    const o = new _Object3D();
    o.name = this.name;
    o.position = this.position.clone();
    o.rotation = this.rotation.clone();
    o.scale = this.scale.clone();
    o.visible = this.visible;
    if (recursive) for (const c of this.children) o.add(c.clone(true));
    return o;
  }
};
var Group = class extends Object3D {
};
var Mesh = class _Mesh extends Object3D {
  geometry;
  material;
  // GPU buffer handles — set by renderer
  _gpuBuffers = {};
  // WebGL buffer handles — set by renderer
  _glBuffers = {};
  constructor(geometry, material = new MeshBasicMaterial()) {
    super();
    this.geometry = geometry;
    this.material = material;
  }
  clone(recursive = true) {
    const m = new _Mesh(this.geometry.clone(), this.material);
    m.position.copy(this.position);
    m.rotation.copy(this.rotation);
    m.scale.copy(this.scale);
    return m;
  }
};
var Camera = class extends Object3D {
  projectionMatrix = new Mat4();
  projectionMatrixInv = new Mat4();
  viewMatrix = new Mat4();
  near = 0.1;
  far = 1e3;
  updateProjectionMatrix() {
  }
  updateViewMatrix() {
    this.updateMatrixWorld();
    this.viewMatrix.copy(this.matrixWorld).invert();
  }
};
var PerspectiveCamera = class extends Camera {
  fov;
  aspect;
  constructor(fov = 60, aspect = 1, near = 0.1, far = 1e3) {
    super();
    this.fov = fov;
    this.aspect = aspect;
    this.near = near;
    this.far = far;
    this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    this.projectionMatrix.makePerspective(this.fov, this.aspect, this.near, this.far);
    this.projectionMatrixInv.copy(this.projectionMatrix).invert();
  }
  setAspect(aspect) {
    this.aspect = aspect;
    this.updateProjectionMatrix();
  }
};
var OrthographicCamera = class extends Camera {
  left;
  right;
  top;
  bottom;
  constructor(left = -1, right = 1, top = 1, bottom = -1, near = 0.1, far = 1e3) {
    super();
    this.left = left;
    this.right = right;
    this.top = top;
    this.bottom = bottom;
    this.near = near;
    this.far = far;
    this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    this.projectionMatrix.makeOrthographic(this.left, this.right, this.top, this.bottom, this.near, this.far);
    this.projectionMatrixInv.copy(this.projectionMatrix).invert();
  }
};
var Scene = class extends Object3D {
  background = null;
  fog = null;
  constructor() {
    super();
    this.name = "Scene";
  }
  get lights() {
    const result = [];
    this.traverse((o) => {
      if (o instanceof Light) result.push(o);
    });
    return result;
  }
  get meshes() {
    const result = [];
    this.traverse((o) => {
      if (o instanceof Mesh) result.push(o);
    });
    return result;
  }
};
var _WGSL_COMMON = (
  /* wgsl */
  `
struct Uniforms {
    modelMatrix      : mat4x4<f32>,
    viewMatrix       : mat4x4<f32>,
    projMatrix       : mat4x4<f32>,
    normalMatrix     : mat4x4<f32>,
    cameraPos        : vec3<f32>,
    time             : f32,
    color            : vec4<f32>,
    emissive         : vec4<f32>,
    roughness        : f32,
    metalness        : f32,
    opacity          : f32,
    _pad             : f32,
};

struct LightData {
    position  : vec4<f32>,
    color     : vec4<f32>,
    direction : vec4<f32>,
    params    : vec4<f32>,  // x=intensity, y=type(0=ambient,1=dir,2=point,3=spot), z=range, w=spotAngle
};

@group(0) @binding(0) var<uniform> u : Uniforms;
@group(0) @binding(1) var<storage, read> lights : array<LightData>;
`
);
var _WGSL_VERTEX = (
  /* wgsl */
  `
${_WGSL_COMMON}

struct VertexIn {
    @location(0) position : vec3<f32>,
    @location(1) normal   : vec3<f32>,
    @location(2) uv       : vec2<f32>,
};

struct VertexOut {
    @builtin(position) clip_pos : vec4<f32>,
    @location(0) world_pos      : vec3<f32>,
    @location(1) world_normal   : vec3<f32>,
    @location(2) uv             : vec2<f32>,
};

@vertex
fn vs_main(in: VertexIn) -> VertexOut {
    var out : VertexOut;
    let world_pos   = u.modelMatrix * vec4<f32>(in.position, 1.0);
    out.clip_pos    = u.projMatrix * u.viewMatrix * world_pos;
    out.world_pos   = world_pos.xyz;
    out.world_normal= normalize((u.normalMatrix * vec4<f32>(in.normal, 0.0)).xyz);
    out.uv          = in.uv;
    return out;
}
`
);
var _WGSL_FRAGMENT_PBR = (
  /* wgsl */
  `
${_WGSL_COMMON}

struct FragIn {
    @location(0) world_pos    : vec3<f32>,
    @location(1) world_normal : vec3<f32>,
    @location(2) uv           : vec2<f32>,
};

const PI = 3.14159265359;

fn distributionGGX(N: vec3<f32>, H: vec3<f32>, roughness: f32) -> f32 {
    let a  = roughness * roughness;
    let a2 = a * a;
    let NdH  = max(dot(N, H), 0.0);
    let denom = NdH*NdH*(a2-1.0)+1.0;
    return a2 / (PI * denom * denom);
}

fn geometrySchlick(NdV: f32, roughness: f32) -> f32 {
    let k = (roughness+1.0)*(roughness+1.0)/8.0;
    return NdV / (NdV*(1.0-k)+k);
}

fn fresnelSchlick(cosTheta: f32, F0: vec3<f32>) -> vec3<f32> {
    return F0 + (1.0-F0)*pow(clamp(1.0-cosTheta,0.0,1.0),5.0);
}

@fragment
fn fs_main(in: FragIn) -> @location(0) vec4<f32> {
    let N     = normalize(in.world_normal);
    let V     = normalize(u.cameraPos - in.world_pos);
    let albedo= u.color.rgb;
    let rough = clamp(u.roughness, 0.04, 1.0);
    let metal = u.metalness;

    var F0 = vec3<f32>(0.04);
    F0 = mix(F0, albedo, metal);

    var Lo = vec3<f32>(0.0);
    let numLights = i32(arrayLength(&lights));
    for (var i = 0; i < numLights; i++) {
        let light    = lights[i];
        let ltype    = i32(light.params.y);
        let lIntensity = light.params.x;
        var L        = vec3<f32>(0.0);
        var radiance = light.color.rgb * lIntensity;

        if (ltype == 0) {
            // Ambient
            Lo += albedo * radiance * 0.03;
            continue;
        } else if (ltype == 1) {
            L = normalize(-light.direction.xyz);
        } else {
            L = normalize(light.position.xyz - in.world_pos);
            let dist = length(light.position.xyz - in.world_pos);
            let atten = 1.0 / max(dist*dist, 0.0001);
            radiance *= atten;
        }

        let H     = normalize(V + L);
        let NdL   = max(dot(N, L), 0.0);
        let NdV   = max(dot(N, V), 0.0);

        let D  = distributionGGX(N, H, rough);
        let G  = geometrySchlick(NdV, rough) * geometrySchlick(NdL, rough);
        let F  = fresnelSchlick(max(dot(H,V),0.0), F0);

        let kD    = (vec3<f32>(1.0) - F) * (1.0 - metal);
        let spec  = D * G * F / max(4.0 * NdV * NdL, 0.001);
        Lo += (kD * albedo / PI + spec) * radiance * NdL;
    }

    Lo += u.emissive.rgb;
    let color = Lo / (Lo + vec3<f32>(1.0)); // Reinhard tonemapping
    return vec4<f32>(pow(color, vec3<f32>(1.0/2.2)), u.opacity);
}
`
);
var _WGSL_FRAGMENT_BASIC = (
  /* wgsl */
  `
${_WGSL_COMMON}

struct FragIn {
    @location(0) world_pos    : vec3<f32>,
    @location(1) world_normal : vec3<f32>,
    @location(2) uv           : vec2<f32>,
};

@fragment
fn fs_main(in: FragIn) -> @location(0) vec4<f32> {
    return vec4<f32>(u.color.rgb, u.opacity);
}
`
);
var _WGSL_FRAGMENT_LAMBERT = (
  /* wgsl */
  `
${_WGSL_COMMON}

struct FragIn {
    @location(0) world_pos    : vec3<f32>,
    @location(1) world_normal : vec3<f32>,
    @location(2) uv           : vec2<f32>,
};

@fragment
fn fs_main(in: FragIn) -> @location(0) vec4<f32> {
    let N = normalize(in.world_normal);
    var diffuse = vec3<f32>(0.0);
    let numLights = i32(arrayLength(&lights));
    for (var i = 0; i < numLights; i++) {
        let light = lights[i]; let ltype = i32(light.params.y);
        if (ltype == 0) { diffuse += light.color.rgb * light.params.x * 0.1; continue; }
        let L   = select(normalize(-light.direction.xyz), normalize(light.position.xyz - in.world_pos), ltype > 1);
        let NdL = max(dot(N, L), 0.0);
        diffuse += light.color.rgb * light.params.x * NdL;
    }
    return vec4<f32>(u.color.rgb * diffuse + u.emissive.rgb, u.opacity);
}
`
);
function _wgslFragForType(type) {
  switch (type) {
    case "pbr":
      return _WGSL_FRAGMENT_PBR;
    case "lambert":
      return _WGSL_FRAGMENT_LAMBERT;
    default:
      return _WGSL_FRAGMENT_BASIC;
  }
}
var _UNIFORM_SIZE = 256;
var _LIGHT_STRIDE = 64;
var _MAX_LIGHTS = 16;
var WebGPURenderer = class {
  canvas;
  #device = null;
  #context = null;
  #depthTexture = null;
  #lightBuffer = null;
  #bindGroupLayout = null;
  #pipelineCache = /* @__PURE__ */ new Map();
  #ready = false;
  constructor(canvas) {
    this.canvas = canvas;
  }
  async init() {
    if (!navigator.gpu) return false;
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) return false;
    this.#device = await adapter.requestDevice();
    this.#context = this.canvas.getContext("webgpu");
    if (!this.#context) return false;
    const fmt = navigator.gpu.getPreferredCanvasFormat();
    this.#context.configure({ device: this.#device, format: fmt, alphaMode: "premultiplied" });
    this.#bindGroupLayout = this.#device.createBindGroupLayout({
      entries: [
        {
          binding: 0,
          visibility: 1 | 2,
          buffer: { type: "uniform" }
        },
        {
          binding: 1,
          visibility: 2,
          buffer: { type: "read-only-storage" }
        }
      ]
    });
    this.#lightBuffer = this.#device.createBuffer({
      size: _LIGHT_STRIDE * _MAX_LIGHTS,
      usage: 128 | 8
    });
    this.#createDepthTexture();
    this.#ready = true;
    return true;
  }
  get ready() {
    return this.#ready;
  }
  #createDepthTexture() {
    this.#depthTexture?.destroy();
    this.#depthTexture = this.#device.createTexture({
      size: [this.canvas.width, this.canvas.height],
      format: "depth24plus",
      usage: 16
    });
  }
  resize(w, h) {
    this.canvas.width = w;
    this.canvas.height = h;
    if (this.#ready) this.#createDepthTexture();
  }
  #getPipeline(mat) {
    const key = mat.type + (mat.wireframe ? "_wire" : "");
    if (this.#pipelineCache.has(key)) return this.#pipelineCache.get(key);
    const device = this.#device;
    if (!navigator.gpu) throw new Error("WebGPU not supported");
    const fmt = navigator.gpu.getPreferredCanvasFormat();
    const shaderModule = device.createShaderModule({
      code: _WGSL_VERTEX + _wgslFragForType(mat.type)
    });
    const pipeline = device.createRenderPipeline({
      layout: device.createPipelineLayout({ bindGroupLayouts: [this.#bindGroupLayout] }),
      vertex: {
        module: shaderModule,
        entryPoint: "vs_main",
        buffers: [
          { arrayStride: 12, attributes: [{ shaderLocation: 0, offset: 0, format: "float32x3" }] },
          { arrayStride: 12, attributes: [{ shaderLocation: 1, offset: 0, format: "float32x3" }] },
          { arrayStride: 8, attributes: [{ shaderLocation: 2, offset: 0, format: "float32x2" }] }
        ]
      },
      fragment: {
        module: shaderModule,
        entryPoint: "fs_main",
        targets: [{ format: fmt, blend: {
          color: { srcFactor: "src-alpha", dstFactor: "one-minus-src-alpha", operation: "add" },
          alpha: { srcFactor: "one", dstFactor: "one-minus-src-alpha", operation: "add" }
        } }]
      },
      primitive: {
        topology: mat.wireframe ? "line-list" : "triangle-list",
        cullMode: mat.side === "both" ? "none" : mat.side === "back" ? "front" : "back"
      },
      depthStencil: { format: "depth24plus", depthWriteEnabled: true, depthCompare: "less" }
    });
    this.#pipelineCache.set(key, pipeline);
    return pipeline;
  }
  #uploadMeshBuffers(mesh) {
    const device = this.#device;
    const geo = mesh.geometry;
    const b = mesh._gpuBuffers;
    const makeBuffer = (data, usage) => {
      const buf = device.createBuffer({
        size: data.byteLength,
        usage: usage | 8
        /* GPUBufferUsage.COPY_DST */
      });
      device.queue.writeBuffer(buf, 0, data);
      return buf;
    };
    if (geo.positions.length > 0 && !b.vertex)
      b.vertex = makeBuffer(
        geo.positions,
        32
        /* GPUBufferUsage.VERTEX */
      );
    if (geo.normals.length > 0 && !b.normal)
      b.normal = makeBuffer(
        geo.normals,
        32
        /* GPUBufferUsage.VERTEX */
      );
    if (geo.uvs.length > 0)
      b.uv = makeBuffer(
        geo.uvs,
        32
        /* GPUBufferUsage.VERTEX */
      );
    else
      b.uv = makeBuffer(
        new Float32Array(geo.vertexCount * 2),
        32
        /* GPUBufferUsage.VERTEX */
      );
    if (geo.indices.length > 0 && !b.index)
      b.index = makeBuffer(
        geo.indices,
        16
        /* GPUBufferUsage.INDEX */
      );
    if (!b.uniform)
      b.uniform = device.createBuffer({
        size: _UNIFORM_SIZE,
        usage: 64 | 8
        /* GPUBufferUsage.COPY_DST */
      });
  }
  #uploadUniforms(mesh, camera, time) {
    const device = this.#device;
    const mat = mesh.material;
    mesh.updateMatrixWorld();
    const normalMat = mesh.matrixWorld.clone().invert().transpose();
    const data = new Float32Array(_UNIFORM_SIZE / 4);
    let off = 0;
    data.set(mesh.matrixWorld.elements, off);
    off += 16;
    data.set(camera.viewMatrix.elements, off);
    off += 16;
    data.set(camera.projectionMatrix.elements, off);
    off += 16;
    data.set(normalMat.elements, off);
    off += 16;
    const cp = camera.getWorldPosition();
    data.set([cp.x, cp.y, cp.z, time], off);
    off += 4;
    data.set(mat.color.toArray(), off);
    off += 4;
    data.set(mat.emissive.toArray(), off);
    off += 4;
    data.set([mat.roughness, mat.metalness, mat.opacity, 0], off);
    device.queue.writeBuffer(mesh._gpuBuffers.uniform, 0, data);
  }
  #uploadLights(scene) {
    const device = this.#device;
    const data = new Float32Array(_LIGHT_STRIDE / 4 * _MAX_LIGHTS);
    let off = 0;
    const lights = scene.lights.slice(0, _MAX_LIGHTS);
    for (const light of lights) {
      const typeId = light.type === "ambient" ? 0 : light.type === "directional" ? 1 : light.type === "point" ? 2 : 3;
      if (light instanceof PointLight) data.set([light.position.x, light.position.y, light.position.z, 1], off);
      else data.set([0, 0, 0, 0], off);
      off += 4;
      data.set(light.color.toArray(), off);
      off += 4;
      if (light instanceof DirectionalLight) data.set([light.direction.x, light.direction.y, light.direction.z, 0], off);
      else data.set([0, -1, 0, 0], off);
      off += 4;
      data.set([light.intensity, typeId, 0, 0], off);
      off += 4;
    }
    device.queue.writeBuffer(this.#lightBuffer, 0, data);
  }
  render(scene, camera, time = 0) {
    if (!this.#ready || !this.#device || !this.#context) return;
    camera.updateViewMatrix();
    const device = this.#device;
    const colorView = this.#context.getCurrentTexture().createView();
    const depthView = this.#depthTexture.createView();
    this.#uploadLights(scene);
    const encoder = device.createCommandEncoder();
    const bgColor = scene.background?.toArray() ?? [0, 0, 0, 1];
    const renderPass = encoder.beginRenderPass({
      colorAttachments: [{ view: colorView, clearValue: { r: bgColor[0], g: bgColor[1], b: bgColor[2], a: bgColor[3] }, loadOp: "clear", storeOp: "store" }],
      depthStencilAttachment: { view: depthView, depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" }
    });
    for (const mesh of scene.meshes) {
      if (!mesh.visible) continue;
      this.#uploadMeshBuffers(mesh);
      this.#uploadUniforms(mesh, camera, time);
      const pipeline = this.#getPipeline(mesh.material);
      const bindGroup = device.createBindGroup({
        layout: this.#bindGroupLayout,
        entries: [
          { binding: 0, resource: { buffer: mesh._gpuBuffers.uniform } },
          { binding: 1, resource: { buffer: this.#lightBuffer } }
        ]
      });
      renderPass.setPipeline(pipeline);
      renderPass.setBindGroup(0, bindGroup);
      renderPass.setVertexBuffer(0, mesh._gpuBuffers.vertex);
      renderPass.setVertexBuffer(1, mesh._gpuBuffers.normal);
      renderPass.setVertexBuffer(2, mesh._gpuBuffers.uv);
      if (mesh._gpuBuffers.index && mesh.geometry.indexCount > 0) {
        renderPass.setIndexBuffer(mesh._gpuBuffers.index, "uint32");
        renderPass.drawIndexed(mesh.geometry.indexCount);
      } else {
        renderPass.draw(mesh.geometry.vertexCount);
      }
    }
    renderPass.end();
    device.queue.submit([encoder.finish()]);
  }
  dispose() {
    this.#depthTexture?.destroy();
    this.#lightBuffer?.destroy();
    this.#device?.destroy();
    this.#ready = false;
  }
};
var _GL_VS = `#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNorm;
layout(location=2) in vec2 aUV;
uniform mat4 uModel, uView, uProj, uNormal;
out vec3 vWorldPos, vNormal;
out vec2 vUV;
void main() {
    vec4 wp = uModel * vec4(aPos,1.0);
    vWorldPos = wp.xyz;
    vNormal   = normalize((uNormal * vec4(aNorm,0.0)).xyz);
    vUV       = aUV;
    gl_Position = uProj * uView * wp;
}`;
var _GL_FS = `#version 300 es
precision highp float;
in vec3 vWorldPos, vNormal;
in vec2 vUV;
uniform vec4 uColor, uEmissive;
uniform vec3 uLightDir, uLightColor, uAmbient, uCamPos;
uniform float uRoughness, uMetalness, uOpacity;
out vec4 fragColor;
void main() {
    vec3 N = normalize(vNormal);
    vec3 L = normalize(-uLightDir);
    vec3 V = normalize(uCamPos - vWorldPos);
    vec3 H = normalize(L + V);
    float diff = max(dot(N,L),0.0);
    float spec = pow(max(dot(N,H),0.0), mix(4.0,128.0,1.0-uRoughness));
    vec3 col = uColor.rgb * (uAmbient + uLightColor * diff) + uLightColor * spec * (1.0-uRoughness) + uEmissive.rgb;
    fragColor = vec4(col, uOpacity);
}`;
var WebGL2Renderer = class {
  canvas;
  #gl = null;
  #program = null;
  #ready = false;
  constructor(canvas) {
    this.canvas = canvas;
  }
  init() {
    const gl = this.canvas.getContext("webgl2");
    if (!gl) return false;
    this.#gl = gl;
    const vs = this.#compileShader(gl.VERTEX_SHADER, _GL_VS);
    const fs = this.#compileShader(gl.FRAGMENT_SHADER, _GL_FS);
    if (!vs || !fs) return false;
    const prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return false;
    this.#program = prog;
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    this.#ready = true;
    return true;
  }
  get ready() {
    return this.#ready;
  }
  #compileShader(type, src) {
    const gl = this.#gl;
    const sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    return gl.getShaderParameter(sh, gl.COMPILE_STATUS) ? sh : null;
  }
  render(scene, camera) {
    if (!this.#ready || !this.#gl || !this.#program) return;
    const gl = this.#gl, prog = this.#program;
    const bg = scene.background?.toArray() ?? [0, 0, 0, 1];
    gl.clearColor(bg[0], bg[1], bg[2], bg[3]);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.useProgram(prog);
    camera.updateViewMatrix();
    const ul = (n) => gl.getUniformLocation(prog, n);
    const dir = scene.lights.find((l) => l instanceof DirectionalLight);
    const amb = scene.lights.find((l) => l instanceof AmbientLight);
    const lightDir = dir ? dir.direction.clone().normalize() : new Vec3(0, -1, 0);
    const lightColor = dir ? dir.color.toArray().slice(0, 3) : [1, 1, 1];
    const ambient = amb ? amb.color.toArray().slice(0, 3).map((v) => v * amb.intensity) : [0.1, 0.1, 0.1];
    const cp = camera.getWorldPosition();
    gl.uniform3fv(ul("uLightDir"), new Float32Array(lightDir.toArray()));
    gl.uniform3fv(ul("uLightColor"), new Float32Array(lightColor));
    gl.uniform3fv(ul("uAmbient"), new Float32Array(ambient));
    gl.uniform3fv(ul("uCamPos"), new Float32Array([cp.x, cp.y, cp.z]));
    gl.uniformMatrix4fv(ul("uView"), false, camera.viewMatrix.elements);
    gl.uniformMatrix4fv(ul("uProj"), false, camera.projectionMatrix.elements);
    for (const mesh of scene.meshes) {
      if (!mesh.visible) continue;
      mesh.updateMatrixWorld();
      const normalMat = mesh.matrixWorld.clone().invert().transpose();
      gl.uniformMatrix4fv(ul("uModel"), false, mesh.matrixWorld.elements);
      gl.uniformMatrix4fv(ul("uNormal"), false, normalMat.elements);
      const mat = mesh.material;
      gl.uniform4fv(ul("uColor"), mat.color.toFloat32());
      gl.uniform4fv(ul("uEmissive"), mat.emissive.toFloat32());
      gl.uniform1f(ul("uRoughness"), mat.roughness);
      gl.uniform1f(ul("uMetalness"), mat.metalness);
      gl.uniform1f(ul("uOpacity"), mat.opacity);
      const b = mesh._glBuffers;
      const geo = mesh.geometry;
      if (!b.vao) {
        b.vao = gl.createVertexArray();
        b.vertex = gl.createBuffer();
        b.normal = gl.createBuffer();
        b.uv = gl.createBuffer();
        if (geo.indices.length > 0) b.index = gl.createBuffer();
        gl.bindVertexArray(b.vao);
        gl.bindBuffer(gl.ARRAY_BUFFER, b.vertex);
        gl.bufferData(gl.ARRAY_BUFFER, geo.positions, gl.STATIC_DRAW);
        gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(0);
        gl.bindBuffer(gl.ARRAY_BUFFER, b.normal);
        gl.bufferData(gl.ARRAY_BUFFER, geo.normals.length > 0 ? geo.normals : new Float32Array(geo.positions.length), gl.STATIC_DRAW);
        gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(1);
        gl.bindBuffer(gl.ARRAY_BUFFER, b.uv);
        gl.bufferData(gl.ARRAY_BUFFER, geo.uvs.length > 0 ? geo.uvs : new Float32Array(geo.vertexCount * 2), gl.STATIC_DRAW);
        gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(2);
        if (b.index) {
          gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, b.index);
          gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, geo.indices, gl.STATIC_DRAW);
        }
        gl.bindVertexArray(null);
      }
      gl.bindVertexArray(b.vao);
      if (geo.indexCount > 0 && b.index) gl.drawElements(gl.TRIANGLES, geo.indexCount, gl.UNSIGNED_INT, 0);
      else gl.drawArrays(gl.TRIANGLES, 0, geo.vertexCount);
      gl.bindVertexArray(null);
    }
  }
  dispose() {
    if (this.#gl && this.#program) this.#gl.deleteProgram(this.#program);
    this.#ready = false;
  }
};
async function createRenderer(canvas) {
  const gpuRenderer = new WebGPURenderer(canvas);
  const gpuOk = await gpuRenderer.init();
  if (gpuOk) return gpuRenderer;
  const glRenderer = new WebGL2Renderer(canvas);
  const glOk = glRenderer.init();
  if (glOk) return glRenderer;
  throw new Error("Three: Neither WebGPU nor WebGL2 is available in this browser.");
}
var BSP_COPLANAR = 0;
var BSP_FRONT = 1;
var BSP_BACK = 2;
var BSP_SPANNING = 3;
var BSP_EPS = 1e-5;
function _bspPlaneFromVerts(verts) {
  const n = Vec3.cross(
    Vec3.sub(verts[1].pos, verts[0].pos),
    Vec3.sub(verts[2].pos, verts[0].pos)
  ).normalize();
  return { normal: n, w: n.dot(verts[0].pos) };
}
function _bspClassifyPoint(plane, p) {
  const d = plane.normal.dot(p) - plane.w;
  return d < -BSP_EPS ? BSP_BACK : d > BSP_EPS ? BSP_FRONT : BSP_COPLANAR;
}
function _bspSplitPolygon(plane, poly) {
  const front = [], back = [];
  const verts = poly.vertices, n = verts.length;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    const vi = verts[i], vj = verts[j];
    const ti = _bspClassifyPoint(plane, vi.pos);
    const tj = _bspClassifyPoint(plane, vj.pos);
    if (ti !== BSP_BACK) front.push(vi);
    if (ti !== BSP_FRONT) back.push(vi);
    if ((ti | tj) === BSP_SPANNING) {
      const t = (plane.w - plane.normal.dot(vi.pos)) / plane.normal.dot(Vec3.sub(vj.pos, vi.pos));
      const ip = vi.pos.clone().lerp(vj.pos, t);
      const in_ = vi.normal.clone().lerp(vj.normal, t).normalize();
      const iuv = vi.uv.clone().add(vj.uv.clone().sub(vi.uv).scale(t));
      const iv = { pos: ip, normal: in_, uv: iuv };
      front.push(iv);
      back.push(iv);
    }
  }
  const toPolys = (vs) => vs.length >= 3 ? [{ vertices: vs, plane: _bspPlaneFromVerts(vs) }] : [];
  return { front: toPolys(front), back: toPolys(back) };
}
var BSPNode = class _BSPNode {
  plane = null;
  front = null;
  back = null;
  polygons = [];
  build(polys) {
    if (!polys.length) return;
    if (!this.plane) this.plane = polys[0].plane;
    const f = [], b = [];
    for (const p of polys) {
      const types = p.vertices.map((v) => _bspClassifyPoint(this.plane, v.pos));
      const type = types.reduce((a, t) => a | t, 0);
      if (type === BSP_COPLANAR) this.polygons.push(p);
      else if (type === BSP_FRONT) f.push(p);
      else if (type === BSP_BACK) b.push(p);
      else {
        const { front, back } = _bspSplitPolygon(this.plane, p);
        f.push(...front);
        b.push(...back);
      }
    }
    if (f.length) {
      this.front = new _BSPNode();
      this.front.build(f);
    }
    if (b.length) {
      this.back = new _BSPNode();
      this.back.build(b);
    }
  }
  allPolygons() {
    let p = [...this.polygons];
    if (this.front) p = p.concat(this.front.allPolygons());
    if (this.back) p = p.concat(this.back.allPolygons());
    return p;
  }
  clone() {
    const n = new _BSPNode();
    n.plane = this.plane ? { normal: this.plane.normal.clone(), w: this.plane.w } : null;
    n.front = this.front ? this.front.clone() : null;
    n.back = this.back ? this.back.clone() : null;
    n.polygons = this.polygons.map((p) => ({ vertices: p.vertices.map((v) => ({ pos: v.pos.clone(), normal: v.normal.clone(), uv: v.uv.clone() })), plane: { normal: p.plane.normal.clone(), w: p.plane.w } }));
    return n;
  }
  invert() {
    for (const p of this.polygons) {
      p.vertices.reverse();
      p.vertices.forEach((v) => v.normal.negate());
      p.plane.normal.negate();
      p.plane.w = -p.plane.w;
    }
    if (this.plane) {
      this.plane.normal.negate();
      this.plane.w = -this.plane.w;
    }
    if (this.front) this.front.invert();
    if (this.back) this.back.invert();
    [this.front, this.back] = [this.back, this.front];
  }
  clipPolygons(polys) {
    if (!this.plane) return [...polys];
    let f = [], b = [];
    for (const p of polys) {
      const { front, back } = _bspSplitPolygon(this.plane, p);
      f.push(...front);
      b.push(...back);
    }
    if (this.front) f = this.front.clipPolygons(f);
    b = this.back ? this.back.clipPolygons(b) : [];
    return f.concat(b);
  }
  clipTo(bsp) {
    this.polygons = bsp.clipPolygons(this.polygons);
    if (this.front) this.front.clipTo(bsp);
    if (this.back) this.back.clipTo(bsp);
  }
};
function _geomToPolygons(mesh) {
  const geo = mesh.geometry;
  const pos = geo.positions, nrm = geo.normals, uvd = geo.uvs;
  const idx = geo.indices;
  const out = [];
  const makeVert = (i) => ({
    pos: new Vec3(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]).applyMat4(mesh.matrixWorld),
    normal: new Vec3(nrm[i * 3] ?? 0, nrm[i * 3 + 1] ?? 0, nrm[i * 3 + 2] ?? 1),
    uv: new Vec2(uvd[i * 2] ?? 0, uvd[i * 2 + 1] ?? 0)
  });
  if (idx.length > 0) {
    for (let i = 0; i < idx.length; i += 3) {
      const verts = [makeVert(idx[i]), makeVert(idx[i + 1]), makeVert(idx[i + 2])];
      out.push({ vertices: verts, plane: _bspPlaneFromVerts(verts) });
    }
  } else {
    for (let i = 0; i < pos.length / 3; i += 3) {
      const verts = [makeVert(i), makeVert(i + 1), makeVert(i + 2)];
      out.push({ vertices: verts, plane: _bspPlaneFromVerts(verts) });
    }
  }
  return out;
}
function _polygonsToGeom(polys) {
  const pos = [], nrm = [], uv = [], idx = [];
  let vi = 0;
  for (const p of polys) {
    const n = p.vertices.length;
    for (const v of p.vertices) {
      pos.push(v.pos.x, v.pos.y, v.pos.z);
      nrm.push(v.normal.x, v.normal.y, v.normal.z);
      uv.push(v.uv.x, v.uv.y);
    }
    for (let i = 1; i < n - 1; i++) idx.push(vi, vi + i, vi + i + 1);
    vi += n;
  }
  return new BufferGeometry().setPositions(pos).setNormals(nrm).setUVs(uv).setIndices(idx);
}
var CSG = {
  /**
   * Boolean union — merges two meshes.
   * @example
   *   const result = CSG.union(meshA, meshB);
   */
  union(a, b) {
    a.updateMatrixWorld();
    b.updateMatrixWorld();
    const na = new BSPNode(), nb = new BSPNode();
    na.build(_geomToPolygons(a));
    nb.build(_geomToPolygons(b));
    na.clipTo(nb);
    nb.clipTo(na);
    nb.invert();
    nb.clipTo(na);
    nb.invert();
    na.build(nb.allPolygons());
    return new Mesh(_polygonsToGeom(na.allPolygons()), a.material);
  },
  /**
   * Boolean subtract — subtracts mesh b from mesh a.
   * @example
   *   const result = CSG.subtract(box, sphere);
   */
  subtract(a, b) {
    a.updateMatrixWorld();
    b.updateMatrixWorld();
    const na = new BSPNode(), nb = new BSPNode();
    na.build(_geomToPolygons(a));
    nb.build(_geomToPolygons(b));
    na.invert();
    na.clipTo(nb);
    nb.clipTo(na);
    nb.invert();
    nb.clipTo(na);
    nb.invert();
    na.build(nb.allPolygons());
    na.invert();
    return new Mesh(_polygonsToGeom(na.allPolygons()), a.material);
  },
  /**
   * Boolean intersect — keeps only the overlapping volume.
   * @example
   *   const result = CSG.intersect(meshA, meshB);
   */
  intersect(a, b) {
    a.updateMatrixWorld();
    b.updateMatrixWorld();
    const na = new BSPNode(), nb = new BSPNode();
    na.build(_geomToPolygons(a));
    nb.build(_geomToPolygons(b));
    na.invert();
    nb.clipTo(na);
    nb.invert();
    na.clipTo(nb);
    nb.clipTo(na);
    na.build(nb.allPolygons());
    na.invert();
    return new Mesh(_polygonsToGeom(na.allPolygons()), a.material);
  }
};
var SubdivisionModifier = {
  /**
   * Catmull-Clark subdivision surface.
   * Smooths a mesh by iterating subdivision steps.
   * @param mesh       - Source mesh
   * @param iterations - Subdivision steps (1-4, default: 1)
   */
  apply(mesh, iterations = 1) {
    let geo = mesh.geometry.clone();
    for (let iter = 0; iter < iterations; iter++) geo = _catmullClark(geo);
    return new Mesh(geo, mesh.material);
  }
};
function _catmullClark(geo) {
  const pos = geo.positions;
  const idx = geo.indices;
  const verts = geo.vertexCount;
  const faces = [];
  for (let i = 0; i < idx.length; i += 3) faces.push([idx[i], idx[i + 1], idx[i + 2]]);
  const newPos = [];
  const newIdx = [];
  const facePts = faces.map((f) => {
    const c = new Vec3();
    for (const vi of f) c.add(new Vec3(pos[vi * 3], pos[vi * 3 + 1], pos[vi * 3 + 2]));
    return c.scale(1 / f.length);
  });
  const edgeMap = /* @__PURE__ */ new Map();
  const edgeKey = (a, b) => a < b ? `${a}_${b}` : `${b}_${a}`;
  const edgeAvg = (a, b, fi) => {
    const k = edgeKey(a, b);
    if (!edgeMap.has(k)) edgeMap.set(k, { mid: new Vec3(), faces: [] });
    const e = edgeMap.get(k);
    e.faces.push(fi);
    return k;
  };
  faces.forEach((f, fi) => {
    const n = f.length;
    for (let i = 0; i < n; i++) edgeAvg(f[i], f[(i + 1) % n], fi);
  });
  edgeMap.forEach((e, k) => {
    const [ai, bi] = k.split("_").map(Number);
    const a = new Vec3(pos[ai * 3], pos[ai * 3 + 1], pos[ai * 3 + 2]);
    const b = new Vec3(pos[bi * 3], pos[bi * 3 + 1], pos[bi * 3 + 2]);
    const fc = e.faces.length === 2 ? facePts[e.faces[0]].clone().add(facePts[e.faces[1]]).scale(0.5) : a.clone().add(b).scale(0.5);
    e.mid = a.clone().add(b).add(fc).scale(1 / 3);
  });
  const vFaces = Array.from({ length: verts }, () => []);
  const vEdgeMid = Array.from({ length: verts }, () => []);
  faces.forEach((f, fi) => {
    for (const vi of f) vFaces[vi].push(facePts[fi]);
  });
  edgeMap.forEach((e, k) => {
    const [ai, bi] = k.split("_").map(Number);
    vEdgeMid[ai].push(e.mid);
    vEdgeMid[bi].push(e.mid);
  });
  const newVerts = [];
  for (let i = 0; i < verts; i++) {
    const p = new Vec3(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]);
    const n = vFaces[i].length;
    if (n === 0) {
      newVerts.push(p);
      continue;
    }
    const fp = vFaces[i].reduce((a, v) => a.add(v), new Vec3()).scale(1 / n);
    const ep = vEdgeMid[i].reduce((a, v) => a.add(v), new Vec3()).scale(1 / vEdgeMid[i].length);
    newVerts.push(fp.scale(1 / n).add(ep.scale(2 / n)).add(p.clone().scale((n - 3) / n)));
  }
  const allVerts = [...newVerts];
  const faceVtxIdx = facePts.map((fp) => {
    allVerts.push(fp);
    return allVerts.length - 1;
  });
  const edgeVtxIdx = /* @__PURE__ */ new Map();
  edgeMap.forEach((e, k) => {
    allVerts.push(e.mid);
    edgeVtxIdx.set(k, allVerts.length - 1);
  });
  const outPos = [];
  const outIdx = [];
  allVerts.forEach((v) => outPos.push(v.x, v.y, v.z));
  faces.forEach((f, fi) => {
    const n = f.length;
    const fp = faceVtxIdx[fi];
    for (let i = 0; i < n; i++) {
      const vi = f[i], vj = f[(i + 1) % n], vk = f[(i + n - 1) % n];
      const eij = edgeVtxIdx.get(edgeKey(vi, vj));
      const eki = edgeVtxIdx.get(edgeKey(vk, vi));
      outIdx.push(vi, eij, fp, eki);
    }
  });
  const tris = [];
  for (let i = 0; i < outIdx.length; i += 4)
    tris.push(outIdx[i], outIdx[i + 1], outIdx[i + 2], outIdx[i], outIdx[i + 2], outIdx[i + 3]);
  return new BufferGeometry().setPositions(outPos).setIndices(tris).computeNormals();
}
var DecimateModifier = {
  /**
   * Reduce vertex count by half-edge collapse.
   * @param mesh  - Source mesh
   * @param ratio - Target ratio of original vertex count (0–1, default: 0.5)
   */
  apply(mesh, ratio = 0.5) {
    const geo = mesh.geometry.clone();
    const pos = Array.from(geo.positions);
    const idx = Array.from(geo.indices);
    const target = Math.max(4, Math.floor(geo.vertexCount * ratio));
    const adj = new Array(geo.vertexCount).fill(null).map(() => /* @__PURE__ */ new Set());
    for (let i = 0; i < idx.length; i += 3) {
      const a = idx[i], b = idx[i + 1], c = idx[i + 2];
      adj[a].add(b);
      adj[a].add(c);
      adj[b].add(a);
      adj[b].add(c);
      adj[c].add(a);
      adj[c].add(b);
    }
    const removed = /* @__PURE__ */ new Set();
    let current = geo.vertexCount;
    while (current > target) {
      let best = Infinity, bestA = -1, bestB = -1;
      for (let i = 0; i < geo.vertexCount; i++) {
        if (removed.has(i)) continue;
        for (const j of adj[i]) {
          if (removed.has(j) || j <= i) continue;
          const dx = pos[i * 3] - pos[j * 3], dy = pos[i * 3 + 1] - pos[j * 3 + 1], dz = pos[i * 3 + 2] - pos[j * 3 + 2];
          const cost = dx * dx + dy * dy + dz * dz;
          if (cost < best) {
            best = cost;
            bestA = i;
            bestB = j;
          }
        }
      }
      if (bestA < 0) break;
      pos[bestA * 3] = (pos[bestA * 3] + pos[bestB * 3]) / 2;
      pos[bestA * 3 + 1] = (pos[bestA * 3 + 1] + pos[bestB * 3 + 1]) / 2;
      pos[bestA * 3 + 2] = (pos[bestA * 3 + 2] + pos[bestB * 3 + 2]) / 2;
      removed.add(bestB);
      for (let i = 0; i < idx.length; i++) if (idx[i] === bestB) idx[i] = bestA;
      current--;
    }
    const cleanIdx = [];
    for (let i = 0; i < idx.length; i += 3) {
      const a = idx[i], b = idx[i + 1], c = idx[i + 2];
      if (a !== b && b !== c && a !== c && !removed.has(a) && !removed.has(b) && !removed.has(c))
        cleanIdx.push(a, b, c);
    }
    return new Mesh(new BufferGeometry().setPositions(pos).setIndices(cleanIdx).computeNormals(), mesh.material);
  }
};
var MirrorModifier = {
  /**
   * Mirror geometry across a given axis.
   * @param mesh - Source mesh
   * @param axis - 'x' | 'y' | 'z' (default: 'x')
   */
  apply(mesh, axis = "x") {
    const geo = mesh.geometry;
    const origPos = Array.from(geo.positions);
    const origNrm = Array.from(geo.normals);
    const origIdx = Array.from(geo.indices);
    const offset = geo.vertexCount;
    const mirrorPos = origPos.slice();
    const mirrorNrm = origNrm.slice();
    const ax = axis === "x" ? 0 : axis === "y" ? 1 : 2;
    for (let i = ax; i < mirrorPos.length; i += 3) mirrorPos[i] *= -1;
    for (let i = ax; i < mirrorNrm.length; i += 3) mirrorNrm[i] *= -1;
    const mirrorIdx = origIdx.map((i) => i + offset);
    for (let i = 0; i < mirrorIdx.length; i += 3) [mirrorIdx[i], mirrorIdx[i + 2]] = [mirrorIdx[i + 2], mirrorIdx[i]];
    const newPos = new Float32Array([...origPos, ...mirrorPos]);
    const newNrm = new Float32Array([...origNrm, ...mirrorNrm]);
    const newIdx = new Uint32Array([...origIdx, ...mirrorIdx]);
    return new Mesh(new BufferGeometry().setPositions(newPos).setNormals(newNrm).setIndices(newIdx), mesh.material);
  }
};
var ArrayModifier = {
  /**
   * Repeat geometry N times along an axis.
   * @param mesh   - Source mesh
   * @param count  - Number of copies (default: 3)
   * @param offset - Offset per copy as Vec3 (default: x+1 per step)
   */
  apply(mesh, count = 3, offset = new Vec3(1, 0, 0)) {
    const geo = mesh.geometry;
    const allPos = [];
    const allNrm = [];
    const allIdx = [];
    for (let c = 0; c < count; c++) {
      const dx = offset.x * c, dy = offset.y * c, dz = offset.z * c;
      const base = allPos.length / 3;
      for (let i = 0; i < geo.positions.length; i += 3) {
        allPos.push(geo.positions[i] + dx, geo.positions[i + 1] + dy, geo.positions[i + 2] + dz);
      }
      allNrm.push(...geo.normals);
      allIdx.push(...geo.indices.map((i) => i + base));
    }
    return new Mesh(new BufferGeometry().setPositions(allPos).setNormals(allNrm).setIndices(allIdx), mesh.material);
  }
};
var BendModifier = {
  /**
   * Bend geometry along the Y axis.
   * @param mesh  - Source mesh
   * @param angle - Bend angle in radians (default: π/4)
   */
  apply(mesh, angle = Math.PI / 4) {
    const geo = mesh.geometry.clone();
    const pos = geo.positions;
    let minY = Infinity, maxY = -Infinity;
    for (let i = 1; i < pos.length; i += 3) {
      if (pos[i] < minY) minY = pos[i];
      if (pos[i] > maxY) maxY = pos[i];
    }
    const span = maxY - minY || 1;
    for (let i = 0; i < pos.length; i += 3) {
      const y = pos[i + 1];
      const t = (y - minY) / span;
      const a = t * angle;
      const r = span / (angle || 1e-4);
      pos[i] = (r + pos[i]) * Math.sin(a) - r * Math.sin(0);
      pos[i + 1] = r - (r + pos[i + 2]) * Math.cos(a);
    }
    return new Mesh(geo.computeNormals(), mesh.material);
  }
};
var TwistModifier = {
  /**
   * Twist geometry around the Y axis.
   * @param mesh  - Source mesh
   * @param angle - Total twist angle in radians (default: π)
   */
  apply(mesh, angle = Math.PI) {
    const geo = mesh.geometry.clone();
    const pos = geo.positions;
    let minY = Infinity, maxY = -Infinity;
    for (let i = 1; i < pos.length; i += 3) {
      if (pos[i] < minY) minY = pos[i];
      if (pos[i] > maxY) maxY = pos[i];
    }
    const span = maxY - minY || 1;
    for (let i = 0; i < pos.length; i += 3) {
      const y = pos[i + 1];
      const t = (y - minY) / span;
      const a = t * angle;
      const x = pos[i], z = pos[i + 2];
      pos[i] = x * Math.cos(a) - z * Math.sin(a);
      pos[i + 2] = x * Math.sin(a) + z * Math.cos(a);
    }
    return new Mesh(geo.computeNormals(), mesh.material);
  }
};
var BevelModifier = {
  /**
   * Simple vertex bevel — offsets each vertex slightly inward.
   * For production-quality chamfering, use CSG.
   * @param mesh   - Source mesh
   * @param amount - Bevel distance (default: 0.05)
   */
  apply(mesh, amount = 0.05) {
    const geo = mesh.geometry.clone();
    const pos = geo.positions;
    const nrm = geo.normals;
    for (let i = 0; i < pos.length; i++) pos[i] -= nrm[i] * amount;
    return new Mesh(geo, mesh.material);
  }
};
var STLLoader = {
  /**
   * Parse STL (binary or ASCII) into a BufferGeometry.
   * @example
   *   const geo = STLLoader.parse(arrayBuffer);
   */
  parse(buf) {
    const u8 = new Uint8Array(buf);
    const isBinary = !_isAsciiSTL(u8);
    return isBinary ? _parseBinarySTL(buf) : _parseAsciiSTL(new TextDecoder().decode(u8));
  }
};
function _isAsciiSTL(u8) {
  const start = Math.min(256, u8.length);
  for (let i = 0; i < start; i++) if (u8[i] > 127) return false;
  const text = new TextDecoder().decode(u8.slice(0, start));
  return text.trimStart().startsWith("solid");
}
function _parseBinarySTL(buf) {
  const view = new DataView(buf);
  const count = view.getUint32(80, true);
  const pos = [], nrm = [];
  let off = 84;
  for (let i = 0; i < count; i++, off += 50) {
    const nx = view.getFloat32(off, true), ny = view.getFloat32(off + 4, true), nz = view.getFloat32(off + 8, true);
    for (let v = 0; v < 3; v++) {
      const o = off + 12 + v * 12;
      pos.push(view.getFloat32(o, true), view.getFloat32(o + 4, true), view.getFloat32(o + 8, true));
      nrm.push(nx, ny, nz);
    }
  }
  return new BufferGeometry().setPositions(pos).setNormals(nrm);
}
function _parseAsciiSTL(text) {
  const pos = [], nrm = [];
  const lines = text.split("\n");
  let cn = [0, 0, 0];
  for (const line of lines) {
    const t = line.trim();
    if (t.startsWith("facet normal")) {
      const [, , , nx, ny, nz] = t.split(/\s+/);
      cn = [parseFloat(nx), parseFloat(ny), parseFloat(nz)];
    } else if (t.startsWith("vertex")) {
      const [, x, y, z] = t.split(/\s+/);
      pos.push(parseFloat(x), parseFloat(y), parseFloat(z));
      nrm.push(...cn);
    }
  }
  return new BufferGeometry().setPositions(pos).setNormals(nrm);
}
var STLExporter = {
  /**
   * Export a mesh to binary STL.
   * @example
   *   const buf = STLExporter.toBinary(mesh);
   *   Docs.download(new DocsDocument('stl', buf), 'model.stl');
   */
  toBinary(mesh) {
    const geo = mesh.geometry;
    const idx = geo.indices;
    const pos = geo.positions;
    const nrm = geo.normals;
    const count = idx.length > 0 ? idx.length / 3 : pos.length / 9;
    const buf = new ArrayBuffer(84 + count * 50);
    const view = new DataView(buf);
    view.setUint32(80, count, true);
    let off = 84;
    const writeV = (i) => {
      view.setFloat32(off, pos[i * 3], true);
      view.setFloat32(off + 4, pos[i * 3 + 1], true);
      view.setFloat32(off + 8, pos[i * 3 + 2], true);
      off += 12;
    };
    const writeFace = (i0, i1, i2) => {
      view.setFloat32(off, nrm[i0 * 3] ?? 0, true);
      view.setFloat32(off + 4, nrm[i0 * 3 + 1] ?? 0, true);
      view.setFloat32(off + 8, nrm[i0 * 3 + 2] ?? 1, true);
      off += 12;
      writeV(i0);
      writeV(i1);
      writeV(i2);
      view.setUint16(off, 0, true);
      off += 2;
    };
    if (idx.length > 0) for (let i = 0; i < idx.length; i += 3) writeFace(idx[i], idx[i + 1], idx[i + 2]);
    else for (let i = 0; i < pos.length / 3; i += 3) writeFace(i, i + 1, i + 2);
    return buf;
  },
  toAscii(mesh) {
    const geo = mesh.geometry;
    const idx = geo.indices, pos = geo.positions, nrm = geo.normals;
    const lines = ["solid mesh"];
    const v = (i) => `${pos[i * 3]} ${pos[i * 3 + 1]} ${pos[i * 3 + 2]}`;
    const n = (i) => `${nrm[i * 3] ?? 0} ${nrm[i * 3 + 1] ?? 0} ${nrm[i * 3 + 2] ?? 1}`;
    const face = (i0, i1, i2) => `  facet normal ${n(i0)}
    outer loop
      vertex ${v(i0)}
      vertex ${v(i1)}
      vertex ${v(i2)}
    endloop
  endfacet`;
    if (idx.length > 0) for (let i = 0; i < idx.length; i += 3) lines.push(face(idx[i], idx[i + 1], idx[i + 2]));
    else for (let i = 0; i < pos.length / 3; i += 3) lines.push(face(i, i + 1, i + 2));
    lines.push("endsolid mesh");
    return lines.join("\n");
  }
};
var OBJLoader = {
  /**
   * Parse OBJ text into a BufferGeometry.
   */
  parse(text) {
    const vp = [], vn = [], vt = [];
    const pos = [], nrm = [], uv = [];
    for (const line of text.split("\n")) {
      const t = line.trim();
      if (t.startsWith("v ")) {
        const [, x, y, z] = t.split(/\s+/);
        vp.push(parseFloat(x), parseFloat(y), parseFloat(z));
      }
      if (t.startsWith("vn ")) {
        const [, x, y, z] = t.split(/\s+/);
        vn.push(parseFloat(x), parseFloat(y), parseFloat(z));
      }
      if (t.startsWith("vt ")) {
        const [, u, v] = t.split(/\s+/);
        vt.push(parseFloat(u), parseFloat(v));
      }
      if (t.startsWith("f ")) {
        const parts = t.split(/\s+/).slice(1);
        for (let i = 1; i < parts.length - 1; i++) {
          for (const pi of [parts[0], parts[i], parts[i + 1]]) {
            const [vi, ti, ni] = pi.split("/").map((s) => s ? parseInt(s) - 1 : -1);
            pos.push(vp[vi * 3], vp[vi * 3 + 1], vp[vi * 3 + 2]);
            if (ni >= 0) nrm.push(vn[ni * 3], vn[ni * 3 + 1], vn[ni * 3 + 2]);
            if (ti >= 0) uv.push(vt[ti * 2], vt[ti * 2 + 1]);
          }
        }
      }
    }
    const geo = new BufferGeometry().setPositions(pos);
    if (nrm.length) geo.setNormals(nrm);
    else geo.computeNormals();
    if (uv.length) geo.setUVs(uv);
    return geo;
  }
};
var OBJExporter = {
  export(mesh, name = "mesh") {
    const geo = mesh.geometry;
    const pos = geo.positions, nrm = geo.normals, uvd = geo.uvs, idx = geo.indices;
    const lines = [`# AriannA Three export`, `o ${name}`];
    for (let i = 0; i < pos.length; i += 3) lines.push(`v ${pos[i]} ${pos[i + 1]} ${pos[i + 2]}`);
    for (let i = 0; i < nrm.length; i += 3) lines.push(`vn ${nrm[i]} ${nrm[i + 1]} ${nrm[i + 2]}`);
    for (let i = 0; i < uvd.length; i += 2) lines.push(`vt ${uvd[i]} ${uvd[i + 1]}`);
    const fi = (i) => `${i + 1}/${uvd.length > 0 ? i + 1 : ""}/${nrm.length > 0 ? i + 1 : ""}`;
    if (idx.length > 0) for (let i = 0; i < idx.length; i += 3) lines.push(`f ${fi(idx[i])} ${fi(idx[i + 1])} ${fi(idx[i + 2])}`);
    else for (let i = 0; i < pos.length / 3; i += 3) lines.push(`f ${fi(i)} ${fi(i + 1)} ${fi(i + 2)}`);
    return lines.join("\n");
  }
};
var GLTFExporter = {
  /**
   * Export a mesh or scene to GLB binary.
   * Outputs a valid glTF 2.0 binary container.
   */
  toGLB(mesh) {
    const geo = mesh.geometry;
    const pos = geo.positions;
    const idx = geo.indices;
    const nrm = geo.normals;
    const posBytes = pos.buffer.slice(pos.byteOffset, pos.byteOffset + pos.byteLength);
    const idxU32 = idx.length > 0 ? idx : new Uint32Array(Array.from({ length: pos.length / 3 }, (v, i) => i));
    const idxBytes = idxU32.buffer.slice(idxU32.byteOffset, idxU32.byteOffset + idxU32.byteLength);
    const nrmBytes = nrm.length > 0 ? nrm.buffer.slice(nrm.byteOffset, nrm.byteOffset + nrm.byteLength) : new ArrayBuffer(0);
    const bufView = [];
    let bOff = 0;
    const addBV = (buf, target) => {
      bufView.push({ buffer: 0, byteOffset: bOff, byteLength: buf.byteLength, ...target ? { target } : {} });
      bOff += buf.byteLength + (buf.byteLength % 4 ? 4 - buf.byteLength % 4 : 0);
      return bufView.length - 1;
    };
    const posView = addBV(posBytes, 34962);
    const idxView = addBV(idxBytes, 34963);
    const nrmView = nrmBytes.byteLength > 0 ? addBV(nrmBytes, 34962) : -1;
    const accessors = [
      {
        bufferView: posView,
        componentType: 5126,
        count: geo.vertexCount,
        type: "VEC3",
        min: [geo.boundingBox.min.x, geo.boundingBox.min.y, geo.boundingBox.min.z],
        max: [geo.boundingBox.max.x, geo.boundingBox.max.y, geo.boundingBox.max.z]
      },
      { bufferView: idxView, componentType: 5125, count: idxU32.length, type: "SCALAR" }
    ];
    if (nrmView >= 0) accessors.push({ bufferView: nrmView, componentType: 5126, count: geo.vertexCount, type: "VEC3" });
    const prim = { attributes: { POSITION: 0 }, indices: 1, mode: 4 };
    if (nrmView >= 0) prim.attributes["NORMAL"] = 2;
    const col = mesh.material.color;
    const json = {
      asset: { version: "2.0", generator: "AriannA Three" },
      bufferViews: bufView,
      accessors,
      meshes: [{ name: "mesh", primitives: [prim] }],
      nodes: [{ mesh: 0, name: "node" }],
      scenes: [{ nodes: [0] }],
      scene: 0,
      materials: [{ name: "mat", pbrMetallicRoughness: { baseColorFactor: col.toArray(), metallicFactor: mesh.material.metalness, roughnessFactor: mesh.material.roughness } }],
      buffers: [{ byteLength: bOff }]
    };
    const jsonStr = JSON.stringify(json);
    const jsonBytes = new TextEncoder().encode(jsonStr);
    const jsonPad = jsonBytes.length % 4 ? 4 - jsonBytes.length % 4 : 0;
    const allBufs = [posBytes, idxBytes];
    if (nrmBytes.byteLength > 0) allBufs.push(nrmBytes);
    const binLen = allBufs.reduce((s, b) => s + b.byteLength + (b.byteLength % 4 ? 4 - b.byteLength % 4 : 0), 0);
    const total = 12 + 8 + jsonBytes.length + jsonPad + 8 + binLen;
    const out = new ArrayBuffer(total);
    const view = new DataView(out);
    const u8 = new Uint8Array(out);
    let off = 0;
    view.setUint32(0, 1179937895, true);
    view.setUint32(4, 2, true);
    view.setUint32(8, total, true);
    off = 12;
    view.setUint32(off, jsonBytes.length + jsonPad, true);
    view.setUint32(off + 4, 1313821514, true);
    off += 8;
    u8.set(jsonBytes, off);
    off += jsonBytes.length;
    for (let i = 0; i < jsonPad; i++) u8[off++] = 32;
    view.setUint32(off, binLen, true);
    view.setUint32(off + 4, 5130562, true);
    off += 8;
    for (const b of allBufs) {
      const src = new Uint8Array(b);
      u8.set(src, off);
      off += src.length;
      const pad = src.length % 4 ? 4 - src.length % 4 : 0;
      for (let i = 0; i < pad; i++) u8[off++] = 0;
    }
    return out;
  }
};
var OrbitControls = class {
  camera;
  canvas;
  target = new Vec3();
  minDistance = 0.5;
  maxDistance = 100;
  minPolarAngle = 0;
  maxPolarAngle = Math.PI;
  enableDamping = true;
  dampingFactor = 0.05;
  enableZoom = true;
  enableRotate = true;
  enablePan = true;
  #spherical = { r: 5, theta: 0, phi: Math.PI / 4 };
  #isDragging = false;
  #isPanning = false;
  #lastX = 0;
  #lastY = 0;
  #dTheta = 0;
  #dPhi = 0;
  #dispose = [];
  constructor(camera, canvas) {
    this.camera = camera;
    this.canvas = canvas;
    this.#init();
    this.#updateCamera();
  }
  #init() {
    const on = (type, fn) => {
      this.canvas.addEventListener(type, fn);
      this.#dispose.push(() => this.canvas.removeEventListener(type, fn));
    };
    const onW = (type, fn) => {
      window.addEventListener(type, fn);
      this.#dispose.push(() => window.removeEventListener(type, fn));
    };
    on("mousedown", (e) => {
      if (e.button === 0) {
        this.#isDragging = true;
        this.#isPanning = false;
      }
      if (e.button === 2) {
        this.#isPanning = true;
        this.#isDragging = false;
      }
      this.#lastX = e.clientX;
      this.#lastY = e.clientY;
    });
    onW("mouseup", () => {
      this.#isDragging = false;
      this.#isPanning = false;
    });
    onW("mousemove", (e) => {
      const dx = e.clientX - this.#lastX, dy = e.clientY - this.#lastY;
      this.#lastX = e.clientX;
      this.#lastY = e.clientY;
      if (this.#isDragging && this.enableRotate) {
        this.#dTheta -= dx * 0.01;
        this.#dPhi -= dy * 0.01;
      }
      if (this.#isPanning && this.enablePan) {
        this.target.x -= dx * 5e-3;
        this.target.y += dy * 5e-3;
      }
    });
    on("wheel", (e) => {
      if (!this.enableZoom) return;
      this.#spherical.r = Math.min(this.maxDistance, Math.max(this.minDistance, this.#spherical.r + e.deltaY * 0.01));
      this.#updateCamera();
    });
    on("contextmenu", (e) => e.preventDefault());
    let touches = [];
    on("touchstart", (e) => {
      touches = Array.from(e.touches);
    });
    on("touchmove", (e) => {
      if (e.touches.length === 1 && this.enableRotate) {
        const dx = e.touches[0].clientX - touches[0].clientX;
        const dy = e.touches[0].clientY - touches[0].clientY;
        this.#dTheta -= dx * 0.01;
        this.#dPhi -= dy * 0.01;
        touches = Array.from(e.touches);
      }
      if (e.touches.length === 2 && this.enableZoom) {
        const d0 = Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
        const d1 = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        this.#spherical.r = Math.min(this.maxDistance, Math.max(this.minDistance, this.#spherical.r * (d0 / d1)));
        touches = Array.from(e.touches);
      }
    });
  }
  update() {
    if (this.enableDamping) {
      this.#spherical.theta += this.#dTheta;
      this.#spherical.phi += this.#dPhi;
      this.#dTheta *= 1 - this.dampingFactor;
      this.#dPhi *= 1 - this.dampingFactor;
    } else {
      this.#spherical.theta += this.#dTheta;
      this.#dTheta = 0;
      this.#spherical.phi += this.#dPhi;
      this.#dPhi = 0;
    }
    this.#spherical.phi = Math.max(this.minPolarAngle + 0.01, Math.min(this.maxPolarAngle - 0.01, this.#spherical.phi));
    this.#updateCamera();
  }
  #updateCamera() {
    const { r, theta, phi } = this.#spherical;
    const sp = Math.sin(phi), cp = Math.cos(phi);
    const st = Math.sin(theta), ct = Math.cos(theta);
    this.camera.position.set(
      this.target.x + r * sp * st,
      this.target.y + r * cp,
      this.target.z + r * sp * ct
    );
    this.camera.lookAt(this.target);
  }
  dispose() {
    this.#dispose.forEach((fn) => fn());
  }
};
var AnimationLoop2 = class {
  #rafId = 0;
  #running = false;
  #time = 0;
  #last = 0;
  onFrame;
  constructor(fn) {
    this.onFrame = fn;
  }
  start() {
    if (this.#running) return this;
    this.#running = true;
    this.#last = performance.now();
    const loop = (now) => {
      if (!this.#running) return;
      const dt = (now - this.#last) / 1e3;
      this.#last = now;
      this.#time += dt;
      this.onFrame(this.#time, dt);
      this.#rafId = requestAnimationFrame(loop);
    };
    this.#rafId = requestAnimationFrame(loop);
    return this;
  }
  stop() {
    this.#running = false;
    cancelAnimationFrame(this.#rafId);
    return this;
  }
  get running() {
    return this.#running;
  }
};
var Three = {
  // Scene graph
  Scene,
  Group,
  Mesh,
  Object3D,
  // Cameras
  PerspectiveCamera,
  OrthographicCamera,
  // Geometries
  BufferGeometry,
  BoxGeometry,
  SphereGeometry,
  CylinderGeometry,
  PlaneGeometry,
  ConeGeometry,
  TorusGeometry,
  // Materials
  Material,
  MeshBasicMaterial,
  MeshLambertMaterial,
  MeshPhongMaterial,
  MeshPBRMaterial,
  WireframeMaterial,
  LineMaterial,
  // Lights
  AmbientLight,
  DirectionalLight,
  PointLight,
  SpotLight,
  // Math
  Vec2,
  Vec3,
  Vec4,
  Mat4,
  Quaternion: Quaternion2,
  Color,
  Box3,
  // Renderer
  createRenderer,
  WebGPURenderer,
  WebGL2Renderer,
  // Controls
  OrbitControls,
  AnimationLoop: AnimationLoop2,
  // CSG
  CSG,
  // Modifiers
  SubdivisionModifier,
  DecimateModifier,
  MirrorModifier,
  ArrayModifier,
  BendModifier,
  TwistModifier,
  BevelModifier,
  // Import/Export
  STLLoader,
  STLExporter,
  OBJLoader,
  OBJExporter,
  GLTFExporter
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Three")) {
  try {
    Object.defineProperty(window, "Three", {
      value: Three,
      writable: false,
      enumerable: false,
      configurable: false
    });
  } catch {
  }
}
var Three_default = Three;

// additionals/Two.ts
var Vec2D = class _Vec2D {
  constructor(x = 0, y = 0) {
    this.x = x;
    this.y = y;
  }
  x;
  y;
  set(x, y) {
    this.x = x;
    this.y = y;
    return this;
  }
  clone() {
    return new _Vec2D(this.x, this.y);
  }
  add(v) {
    this.x += v.x;
    this.y += v.y;
    return this;
  }
  sub(v) {
    this.x -= v.x;
    this.y -= v.y;
    return this;
  }
  scale(s) {
    this.x *= s;
    this.y *= s;
    return this;
  }
  length() {
    return Math.sqrt(this.x ** 2 + this.y ** 2);
  }
  normalize() {
    const l = this.length() || 1;
    return this.scale(1 / l);
  }
  dot(v) {
    return this.x * v.x + this.y * v.y;
  }
  angle() {
    return Math.atan2(this.y, this.x);
  }
  rotate(a) {
    const c = Math.cos(a), s = Math.sin(a);
    const x = this.x, y = this.y;
    this.x = x * c - y * s;
    this.y = x * s + y * c;
    return this;
  }
  lerp(v, t) {
    this.x += (v.x - this.x) * t;
    this.y += (v.y - this.y) * t;
    return this;
  }
  distanceTo(v) {
    return Math.sqrt((this.x - v.x) ** 2 + (this.y - v.y) ** 2);
  }
  toArray() {
    return [this.x, this.y];
  }
  static from(a) {
    return new _Vec2D(a[0], a[1]);
  }
  static add(a, b) {
    return a.clone().add(b);
  }
  static sub(a, b) {
    return a.clone().sub(b);
  }
};
var Mat3 = class _Mat3 {
  // [a, b, 0]
  // [c, d, 0]
  // [tx,ty,1]
  e;
  constructor() {
    this.e = new Float32Array(9);
    this.identity();
  }
  identity() {
    const e = this.e;
    e.fill(0);
    e[0] = e[4] = e[8] = 1;
    return this;
  }
  clone() {
    const m = new _Mat3();
    m.e.set(this.e);
    return m;
  }
  copy(m) {
    this.e.set(m.e);
    return this;
  }
  multiply(m) {
    const a = this.e, b = m.e, r = new Float32Array(9);
    for (let i = 0; i < 3; i++)
      for (let j = 0; j < 3; j++) {
        let s = 0;
        for (let k = 0; k < 3; k++) s += a[i * 3 + k] * b[k * 3 + j];
        r[i * 3 + j] = s;
      }
    this.e.set(r);
    return this;
  }
  translate(tx, ty) {
    const m = new _Mat3();
    m.e[6] = tx;
    m.e[7] = ty;
    return this.multiply(m);
  }
  rotate(angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    const m = new _Mat3();
    m.e[0] = c;
    m.e[1] = s;
    m.e[3] = -s;
    m.e[4] = c;
    return this.multiply(m);
  }
  scale(sx, sy = sx) {
    const m = new _Mat3();
    m.e[0] = sx;
    m.e[4] = sy;
    return this.multiply(m);
  }
  skewX(angle) {
    const m = new _Mat3();
    m.e[3] = Math.tan(angle);
    return this.multiply(m);
  }
  skewY(angle) {
    const m = new _Mat3();
    m.e[1] = Math.tan(angle);
    return this.multiply(m);
  }
  applyToPoint(x, y) {
    const e = this.e;
    return [e[0] * x + e[3] * y + e[6], e[1] * x + e[4] * y + e[7]];
  }
  toCSSMatrix() {
    const e = this.e;
    return `matrix(${e[0]},${e[1]},${e[3]},${e[4]},${e[6]},${e[7]})`;
  }
  toSVGTransform() {
    return `matrix(${Array.from(this.e).slice(0, 6).join(" ")})`;
  }
  invert() {
    const e = this.e;
    const det = e[0] * (e[4] * e[8] - e[5] * e[7]) - e[1] * (e[3] * e[8] - e[5] * e[6]) + e[2] * (e[3] * e[7] - e[4] * e[6]);
    if (Math.abs(det) < 1e-10) return this;
    const inv = 1 / det;
    const r = new Float32Array(9);
    r[0] = (e[4] * e[8] - e[5] * e[7]) * inv;
    r[1] = -(e[1] * e[8] - e[2] * e[7]) * inv;
    r[2] = (e[1] * e[5] - e[2] * e[4]) * inv;
    r[3] = -(e[3] * e[8] - e[5] * e[6]) * inv;
    r[4] = (e[0] * e[8] - e[2] * e[6]) * inv;
    r[5] = -(e[0] * e[5] - e[2] * e[3]) * inv;
    r[6] = (e[3] * e[7] - e[4] * e[6]) * inv;
    r[7] = -(e[0] * e[7] - e[1] * e[6]) * inv;
    r[8] = (e[0] * e[4] - e[1] * e[3]) * inv;
    this.e.set(r);
    return this;
  }
};
var BBox2D = class {
  minX = Infinity;
  minY = Infinity;
  maxX = -Infinity;
  maxY = -Infinity;
  expandBy(x, y) {
    this.minX = Math.min(this.minX, x);
    this.minY = Math.min(this.minY, y);
    this.maxX = Math.max(this.maxX, x);
    this.maxY = Math.max(this.maxY, y);
    return this;
  }
  get width() {
    return this.maxX - this.minX;
  }
  get height() {
    return this.maxY - this.minY;
  }
  get cx() {
    return (this.minX + this.maxX) / 2;
  }
  get cy() {
    return (this.minY + this.maxY) / 2;
  }
  contains(x, y) {
    return x >= this.minX && x <= this.maxX && y >= this.minY && y <= this.maxY;
  }
};
var _id2d = 0;
var Shape2D = class _Shape2D {
  id = ++_id2d;
  visible = true;
  style = {};
  transform = new Mat3();
  parent = null;
  userData = {};
  // local transform components
  _tx = 0;
  _ty = 0;
  _rot = 0;
  _sx = 1;
  _sy = 1;
  _dirty = true;
  get x() {
    return this._tx;
  }
  get y() {
    return this._ty;
  }
  translate(tx, ty) {
    this._tx += tx;
    this._ty += ty;
    this._dirty = true;
    return this;
  }
  moveTo(x, y) {
    this._tx = x;
    this._ty = y;
    this._dirty = true;
    return this;
  }
  rotate(angle) {
    this._rot += angle;
    this._dirty = true;
    return this;
  }
  rotateTo(angle) {
    this._rot = angle;
    this._dirty = true;
    return this;
  }
  scale(sx, sy = sx) {
    this._sx *= sx;
    this._sy *= sy;
    this._dirty = true;
    return this;
  }
  scaleTo(sx, sy = sx) {
    this._sx = sx;
    this._sy = sy;
    this._dirty = true;
    return this;
  }
  fill(color) {
    this.style.fill = color;
    return this;
  }
  stroke(color, width) {
    this.style.stroke = color;
    if (width !== void 0) this.style.strokeWidth = width;
    return this;
  }
  opacity(v) {
    this.style.opacity = v;
    return this;
  }
  shadow(x, y, blur, color) {
    this.style.shadow = { offsetX: x, offsetY: y, blur, color };
    return this;
  }
  show() {
    this.visible = true;
    return this;
  }
  hide() {
    this.visible = false;
    return this;
  }
  updateTransform() {
    if (!this._dirty) return this;
    this.transform.identity().translate(this._tx, this._ty).rotate(this._rot).scale(this._sx, this._sy);
    this._dirty = false;
    return this;
  }
  getWorldTransform() {
    this.updateTransform();
    if (!this.parent) return this.transform.clone();
    return this.parent.getWorldTransform().multiply(this.transform);
  }
  getBBox() {
    return new BBox2D();
  }
  // SVG serialization — implemented by subclasses
  toSVGElement(defs) {
    return "";
  }
  // Canvas draw — implemented by subclasses
  drawCanvas(ctx) {
  }
  clone() {
    return new _Shape2D();
  }
  on(event, handler) {
    _eventMap.set(this.id + ":" + event, handler);
    return this;
  }
  off(event) {
    _eventMap.delete(this.id + ":" + event);
    return this;
  }
  fire(event, e) {
    _eventMap.get(this.id + ":" + event)?.(e, this);
  }
};
var _eventMap = /* @__PURE__ */ new Map();
var SVGDefsAccum = class {
  items = [];
  ids = /* @__PURE__ */ new Map();
  add(key, svg) {
    if (this.ids.has(key)) return this.ids.get(key);
    const id = `d${_id2d++}`;
    this.ids.set(key, id);
    this.items.push(svg.replace("__ID__", id));
    return id;
  }
  render() {
    return this.items.join("\n");
  }
};
function _styleAttrs(s, defs) {
  const parts = [];
  if (s.fill === "none") parts.push('fill="none"');
  else if (typeof s.fill === "string") parts.push(`fill="${s.fill}"`);
  else if (s.fill && typeof s.fill === "object") parts.push(`fill="url(#${_gradientDef(s.fill, defs)})" `);
  else parts.push('fill="black"');
  if (s.stroke === "none") parts.push('stroke="none"');
  else if (s.stroke) parts.push(`stroke="${s.stroke}"`);
  if (s.strokeWidth) parts.push(`stroke-width="${s.strokeWidth}"`);
  if (s.strokeDasharray) parts.push(`stroke-dasharray="${s.strokeDasharray.join(" ")}"`);
  if (s.strokeLinecap) parts.push(`stroke-linecap="${s.strokeLinecap}"`);
  if (s.strokeLinejoin) parts.push(`stroke-linejoin="${s.strokeLinejoin}"`);
  if (s.opacity !== void 0) parts.push(`opacity="${s.opacity}"`);
  if (s.fillOpacity !== void 0) parts.push(`fill-opacity="${s.fillOpacity}"`);
  if (s.strokeOpacity !== void 0) parts.push(`stroke-opacity="${s.strokeOpacity}"`);
  if (s.filter) parts.push(`filter="${s.filter}"`);
  return parts.join(" ");
}
function _gradientDef(g, defs) {
  const key = JSON.stringify(g);
  const stops = g.stops.map((s) => `<stop offset="${s.offset}" stop-color="${s.color}" ${s.opacity !== void 0 ? `stop-opacity="${s.opacity}"` : ""}/>`).join("");
  if (g.type === "linear") {
    return defs.add(key, `<linearGradient id="__ID__" x1="${g.x1}" y1="${g.y1}" x2="${g.x2}" y2="${g.y2}" gradientUnits="userSpaceOnUse">${stops}</linearGradient>`);
  } else {
    return defs.add(key, `<radialGradient id="__ID__" cx="${g.cx}" cy="${g.cy}" r="${g.r}" ${g.fx !== void 0 ? `fx="${g.fx}"` : ""} ${g.fy !== void 0 ? `fy="${g.fy}"` : ""} gradientUnits="userSpaceOnUse">${stops}</radialGradient>`);
  }
}
function _applyCanvasStyle(ctx, s, canvas) {
  ctx.globalAlpha = s.opacity ?? 1;
  if (s.blendMode) ctx.globalCompositeOperation = s.blendMode;
  if (s.shadow) {
    ctx.shadowOffsetX = s.shadow.offsetX;
    ctx.shadowOffsetY = s.shadow.offsetY;
    ctx.shadowBlur = s.shadow.blur;
    ctx.shadowColor = s.shadow.color;
  } else {
    ctx.shadowColor = "transparent";
  }
  if (s.fill && s.fill !== "none") {
    if (typeof s.fill === "string") {
      ctx.fillStyle = s.fill;
    } else {
      const g = s.fill;
      if (g.type === "linear") {
        const grad = ctx.createLinearGradient(g.x1, g.y1, g.x2, g.y2);
        g.stops.forEach((st) => grad.addColorStop(st.offset, st.color));
        ctx.fillStyle = grad;
      } else {
        const grad = ctx.createRadialGradient(g.cx, g.cy, 0, g.cx, g.cy, g.r);
        g.stops.forEach((st) => grad.addColorStop(st.offset, st.color));
        ctx.fillStyle = grad;
      }
    }
  } else ctx.fillStyle = "transparent";
  if (s.stroke && s.stroke !== "none") ctx.strokeStyle = s.stroke;
  ctx.lineWidth = s.strokeWidth ?? 1;
  ctx.lineCap = s.strokeLinecap ?? "butt";
  ctx.lineJoin = s.strokeLinejoin ?? "miter";
  if (s.strokeDasharray) ctx.setLineDash(s.strokeDasharray);
  else ctx.setLineDash([]);
  if (s.strokeDashoffset !== void 0) ctx.lineDashOffset = s.strokeDashoffset;
}
var Group2D = class _Group2D extends Shape2D {
  children = [];
  add(...shapes) {
    for (const s of shapes) {
      s.parent = this;
      this.children.push(s);
    }
    return this;
  }
  remove(shape) {
    const i = this.children.indexOf(shape);
    if (i >= 0) {
      this.children.splice(i, 1);
      shape.parent = null;
    }
    return this;
  }
  clear() {
    this.children.forEach((c) => {
      c.parent = null;
    });
    this.children = [];
    return this;
  }
  toSVGElement(defs) {
    this.updateTransform();
    const inner = this.children.map((c) => c.toSVGElement(defs)).join("\n");
    return `<g transform="${this.transform.toCSSMatrix()}" opacity="${this.style.opacity ?? 1}">
${inner}
</g>`;
  }
  drawCanvas(ctx) {
    if (!this.visible) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    if (this.style.opacity !== void 0) ctx.globalAlpha *= this.style.opacity;
    for (const c of this.children) c.drawCanvas(ctx);
    ctx.restore();
  }
  getBBox() {
    const box = new BBox2D();
    for (const c of this.children) {
      const b = c.getBBox();
      box.expandBy(b.minX, b.minY).expandBy(b.maxX, b.maxY);
    }
    return box;
  }
  clone() {
    const g = new _Group2D();
    g.style = { ...this.style };
    g.children = this.children.map((c) => {
      const nc = c.clone();
      nc.parent = g;
      return nc;
    });
    return g;
  }
};
var Stage2D = class extends Group2D {
  width;
  height;
  background = null;
  constructor(w = 800, h = 600) {
    super();
    this.width = w;
    this.height = h;
  }
  getWorldTransform() {
    this.updateTransform();
    return this.transform.clone();
  }
};
var Circle3 = class _Circle extends Shape2D {
  cx;
  cy;
  r;
  constructor(opts = {}) {
    super();
    this.cx = opts.cx ?? 0;
    this.cy = opts.cy ?? 0;
    this.r = opts.r ?? 50;
    if (opts.style) this.style = { ...opts.style };
  }
  getBBox() {
    return new BBox2D().expandBy(this.cx - this.r, this.cy - this.r).expandBy(this.cx + this.r, this.cy + this.r);
  }
  toSVGElement(defs) {
    if (!this.visible) return "";
    this.updateTransform();
    return `<circle cx="${this.cx}" cy="${this.cy}" r="${this.r}" ${_styleAttrs(this.style, defs)} transform="${this.transform.toCSSMatrix()}"/>`;
  }
  drawCanvas(ctx) {
    if (!this.visible) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    _applyCanvasStyle(ctx, this.style, ctx.canvas);
    ctx.beginPath();
    ctx.arc(this.cx, this.cy, this.r, 0, Math.PI * 2);
    if (this.style.fill && this.style.fill !== "none") ctx.fill();
    if (this.style.stroke && this.style.stroke !== "none") ctx.stroke();
    ctx.restore();
  }
  clone() {
    const c = new _Circle({ cx: this.cx, cy: this.cy, r: this.r, style: { ...this.style } });
    return c;
  }
};
var Rect = class _Rect extends Shape2D {
  left;
  top;
  width;
  height;
  rx;
  ry;
  constructor(opts = {}) {
    super();
    this.left = opts.x ?? 0;
    this.top = opts.y ?? 0;
    this.width = opts.width ?? 100;
    this.height = opts.height ?? 60;
    this.rx = opts.rx ?? 0;
    this.ry = opts.ry ?? 0;
    if (opts.style) this.style = { ...opts.style };
  }
  getBBox() {
    return new BBox2D().expandBy(this.left, this.top).expandBy(this.left + this.width, this.top + this.height);
  }
  toSVGElement(defs) {
    if (!this.visible) return "";
    this.updateTransform();
    return `<rect x="${this.left}" y="${this.top}" width="${this.width}" height="${this.height}" rx="${this.rx}" ry="${this.ry}" ${_styleAttrs(this.style, defs)} transform="${this.transform.toCSSMatrix()}"/>`;
  }
  drawCanvas(ctx) {
    if (!this.visible) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    _applyCanvasStyle(ctx, this.style, ctx.canvas);
    ctx.beginPath();
    if (this.rx > 0 || this.ry > 0) {
      const rx = this.rx, ry = this.ry || rx;
      ctx.moveTo(this.left + rx, this.top);
      ctx.lineTo(this.left + this.width - rx, this.top);
      ctx.quadraticCurveTo(this.left + this.width, this.top, this.left + this.width, this.top + ry);
      ctx.lineTo(this.left + this.width, this.top + this.height - ry);
      ctx.quadraticCurveTo(this.left + this.width, this.top + this.height, this.left + this.width - rx, this.top + this.height);
      ctx.lineTo(this.left + rx, this.top + this.height);
      ctx.quadraticCurveTo(this.left, this.top + this.height, this.left, this.top + this.height - ry);
      ctx.lineTo(this.left, this.top + ry);
      ctx.quadraticCurveTo(this.left, this.top, this.left + rx, this.top);
    } else {
      ctx.rect(this.left, this.top, this.width, this.height);
    }
    if (this.style.fill && this.style.fill !== "none") ctx.fill();
    if (this.style.stroke && this.style.stroke !== "none") ctx.stroke();
    ctx.restore();
  }
  clone() {
    return new _Rect({ x: this.left, y: this.top, width: this.width, height: this.height, rx: this.rx, ry: this.ry, style: { ...this.style } });
  }
};
var Ellipse = class _Ellipse extends Shape2D {
  cx;
  cy;
  rx;
  ry;
  constructor(opts = {}) {
    super();
    this.cx = opts.cx ?? 0;
    this.cy = opts.cy ?? 0;
    this.rx = opts.rx ?? 60;
    this.ry = opts.ry ?? 40;
    if (opts.style) this.style = { ...opts.style };
  }
  getBBox() {
    return new BBox2D().expandBy(this.cx - this.rx, this.cy - this.ry).expandBy(this.cx + this.rx, this.cy + this.ry);
  }
  toSVGElement(defs) {
    if (!this.visible) return "";
    this.updateTransform();
    return `<ellipse cx="${this.cx}" cy="${this.cy}" rx="${this.rx}" ry="${this.ry}" ${_styleAttrs(this.style, defs)} transform="${this.transform.toCSSMatrix()}"/>`;
  }
  drawCanvas(ctx) {
    if (!this.visible) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    _applyCanvasStyle(ctx, this.style, ctx.canvas);
    ctx.beginPath();
    ctx.ellipse(this.cx, this.cy, this.rx, this.ry, 0, 0, Math.PI * 2);
    if (this.style.fill && this.style.fill !== "none") ctx.fill();
    if (this.style.stroke && this.style.stroke !== "none") ctx.stroke();
    ctx.restore();
  }
  clone() {
    return new _Ellipse({ cx: this.cx, cy: this.cy, rx: this.rx, ry: this.ry, style: { ...this.style } });
  }
};
var Line = class _Line extends Shape2D {
  x1;
  y1;
  x2;
  y2;
  constructor(opts = {}) {
    super();
    this.x1 = opts.x1 ?? 0;
    this.y1 = opts.y1 ?? 0;
    this.x2 = opts.x2 ?? 100;
    this.y2 = opts.y2 ?? 0;
    if (opts.style) this.style = { ...opts.style };
  }
  getBBox() {
    return new BBox2D().expandBy(Math.min(this.x1, this.x2), Math.min(this.y1, this.y2)).expandBy(Math.max(this.x1, this.x2), Math.max(this.y1, this.y2));
  }
  toSVGElement(defs) {
    if (!this.visible) return "";
    this.updateTransform();
    return `<line x1="${this.x1}" y1="${this.y1}" x2="${this.x2}" y2="${this.y2}" ${_styleAttrs(this.style, defs)} transform="${this.transform.toCSSMatrix()}"/>`;
  }
  drawCanvas(ctx) {
    if (!this.visible) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    _applyCanvasStyle(ctx, this.style, ctx.canvas);
    ctx.beginPath();
    ctx.moveTo(this.x1, this.y1);
    ctx.lineTo(this.x2, this.y2);
    ctx.stroke();
    ctx.restore();
  }
  clone() {
    return new _Line({ x1: this.x1, y1: this.y1, x2: this.x2, y2: this.y2, style: { ...this.style } });
  }
};
var Polygon3 = class _Polygon extends Shape2D {
  points;
  closed;
  constructor(opts = {}) {
    super();
    this.points = opts.points ?? [];
    this.closed = opts.closed ?? true;
    if (opts.style) this.style = { ...opts.style };
  }
  getBBox() {
    const box = new BBox2D();
    for (const [x, y] of this.points) box.expandBy(x, y);
    return box;
  }
  toSVGElement(defs) {
    if (!this.visible || !this.points.length) return "";
    this.updateTransform();
    const pts = this.points.map(([x, y]) => `${x},${y}`).join(" ");
    const tag = this.closed ? "polygon" : "polyline";
    return `<${tag} points="${pts}" ${_styleAttrs(this.style, defs)} transform="${this.transform.toCSSMatrix()}"/>`;
  }
  drawCanvas(ctx) {
    if (!this.visible || !this.points.length) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    _applyCanvasStyle(ctx, this.style, ctx.canvas);
    ctx.beginPath();
    ctx.moveTo(this.points[0][0], this.points[0][1]);
    for (let i = 1; i < this.points.length; i++) ctx.lineTo(this.points[i][0], this.points[i][1]);
    if (this.closed) ctx.closePath();
    if (this.style.fill && this.style.fill !== "none") ctx.fill();
    if (this.style.stroke && this.style.stroke !== "none") ctx.stroke();
    ctx.restore();
  }
  clone() {
    return new _Polygon({ points: this.points.map((p) => [...p]), closed: this.closed, style: { ...this.style } });
  }
};
var Path = class _Path extends Shape2D {
  d;
  constructor(opts = {}) {
    super();
    this.d = opts.d ?? "";
    if (opts.style) this.style = { ...opts.style };
  }
  toSVGElement(defs) {
    if (!this.visible) return "";
    this.updateTransform();
    return `<path d="${this.d}" ${_styleAttrs(this.style, defs)} transform="${this.transform.toCSSMatrix()}"/>`;
  }
  drawCanvas(ctx) {
    if (!this.visible || !this.d) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    _applyCanvasStyle(ctx, this.style, ctx.canvas);
    const p2d = new Path2D(this.d);
    if (this.style.fill && this.style.fill !== "none") ctx.fill(p2d);
    if (this.style.stroke && this.style.stroke !== "none") ctx.stroke(p2d);
    ctx.restore();
  }
  getBBox() {
    return new BBox2D();
  }
  clone() {
    return new _Path({ d: this.d, style: { ...this.style } });
  }
};
var Text2D = class _Text2D extends Shape2D {
  text;
  tx;
  ty;
  fontSize;
  fontFamily;
  fontWeight;
  textAnchor;
  dominantBaseline;
  constructor(opts = {}) {
    super();
    this.text = opts.text ?? "";
    this.tx = opts.x ?? 0;
    this.ty = opts.y ?? 0;
    this.fontSize = opts.fontSize ?? 16;
    this.fontFamily = opts.fontFamily ?? "sans-serif";
    this.fontWeight = opts.fontWeight ?? "normal";
    this.textAnchor = opts.textAnchor ?? "start";
    this.dominantBaseline = opts.dominantBaseline ?? "auto";
    if (opts.style) this.style = { ...opts.style };
  }
  toSVGElement(defs) {
    if (!this.visible) return "";
    this.updateTransform();
    const fill = typeof this.style.fill === "string" ? this.style.fill : "#000";
    return `<text x="${this.tx}" y="${this.ty}" font-size="${this.fontSize}" font-family="${this.fontFamily}" font-weight="${this.fontWeight}" text-anchor="${this.textAnchor}" dominant-baseline="${this.dominantBaseline}" fill="${fill}" opacity="${this.style.opacity ?? 1}" transform="${this.transform.toCSSMatrix()}">${_escXml2(this.text)}</text>`;
  }
  drawCanvas(ctx) {
    if (!this.visible) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    _applyCanvasStyle(ctx, this.style, ctx.canvas);
    ctx.font = `${this.fontWeight} ${this.fontSize}px ${this.fontFamily}`;
    ctx.textAlign = this.textAnchor === "middle" ? "center" : this.textAnchor === "end" ? "right" : "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillText(this.text, this.tx, this.ty);
    if (this.style.stroke && this.style.stroke !== "none") ctx.strokeText(this.text, this.tx, this.ty);
    ctx.restore();
  }
  getBBox() {
    return new BBox2D().expandBy(this.tx, this.ty - this.fontSize).expandBy(this.tx + this.text.length * this.fontSize * 0.6, this.ty);
  }
  clone() {
    return new _Text2D({ text: this.text, x: this.tx, y: this.ty, fontSize: this.fontSize, fontFamily: this.fontFamily, fontWeight: this.fontWeight, textAnchor: this.textAnchor, style: { ...this.style } });
  }
};
var Image2D = class _Image2D extends Shape2D {
  href;
  ix;
  iy;
  iw;
  ih;
  #img = null;
  constructor(opts = {}) {
    super();
    this.href = opts.href ?? "";
    this.ix = opts.x ?? 0;
    this.iy = opts.y ?? 0;
    this.iw = opts.width ?? 0;
    this.ih = opts.height ?? 0;
    if (opts.style) this.style = { ...opts.style };
  }
  load() {
    return new Promise((res, rej) => {
      const img = new Image();
      img.onload = () => {
        this.#img = img;
        if (!this.iw) this.iw = img.naturalWidth;
        if (!this.ih) this.ih = img.naturalHeight;
        res(this);
      };
      img.onerror = rej;
      img.src = this.href;
    });
  }
  toSVGElement(defs) {
    if (!this.visible) return "";
    this.updateTransform();
    return `<image href="${this.href}" x="${this.ix}" y="${this.iy}" width="${this.iw}" height="${this.ih}" transform="${this.transform.toCSSMatrix()}" opacity="${this.style.opacity ?? 1}"/>`;
  }
  drawCanvas(ctx) {
    if (!this.visible || !this.#img) return;
    this.updateTransform();
    ctx.save();
    const e = this.transform.e;
    ctx.transform(e[0], e[1], e[3], e[4], e[6], e[7]);
    if (this.style.opacity !== void 0) ctx.globalAlpha = this.style.opacity;
    ctx.drawImage(this.#img, this.ix, this.iy, this.iw, this.ih);
    ctx.restore();
  }
  clone() {
    return new _Image2D({ href: this.href, x: this.ix, y: this.iy, width: this.iw, height: this.ih, style: { ...this.style } });
  }
};
function _escXml2(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
var SVGRenderer = class {
  stage;
  #svg = null;
  #container = null;
  width;
  height;
  background;
  constructor(opts = {}) {
    this.width = opts.width ?? 800;
    this.height = opts.height ?? 600;
    this.background = opts.background ?? "transparent";
    this.stage = new Stage2D(this.width, this.height);
  }
  mount(target) {
    const el = typeof target === "string" ? document.querySelector(target) : target;
    if (!el) return this;
    this.#container = el;
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("width", String(this.width));
    svg.setAttribute("height", String(this.height));
    svg.setAttribute("viewBox", `0 0 ${this.width} ${this.height}`);
    svg.style.background = this.background;
    el.appendChild(svg);
    this.#svg = svg;
    svg.addEventListener("click", (e) => this.#hitTest(e, "click"));
    svg.addEventListener("mousemove", (e) => this.#hitTest(e, "mousemove"));
    svg.addEventListener("mousedown", (e) => this.#hitTest(e, "mousedown"));
    return this;
  }
  render() {
    if (!this.#svg) {
      this.#renderToString();
      return this;
    }
    const defs = new SVGDefsAccum();
    const inner = this.stage.children.map((c) => c.toSVGElement(defs)).join("\n");
    const defsXml = defs.render();
    this.#svg.innerHTML = defsXml ? `<defs>${defsXml}</defs>
${inner}` : inner;
    return this;
  }
  #renderToString() {
    const defs = new SVGDefsAccum();
    const inner = this.stage.children.map((c) => c.toSVGElement(defs)).join("\n");
    const d = defs.render();
    const bg = this.background !== "transparent" ? `<rect width="${this.width}" height="${this.height}" fill="${this.background}"/>` : "";
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.width}" height="${this.height}" viewBox="0 0 ${this.width} ${this.height}">${d ? `<defs>${d}</defs>` : ""}${bg}${inner}</svg>`;
  }
  toSVG() {
    return this.#renderToString();
  }
  #hitTest(e, type) {
    const rect = e.target.closest("svg")?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    this.stage.children.forEach((c) => this.#testShape(c, x, y, e, type));
  }
  #testShape(shape, x, y, e, type) {
    if (!shape.visible) return;
    if (shape instanceof Group2D) {
      shape.children.forEach((c) => this.#testShape(c, x, y, e, type));
      return;
    }
    const bb = shape.getBBox();
    if (bb.contains(x, y)) shape.fire(type, e);
  }
  dispose() {
    this.#svg?.remove();
  }
};
var CanvasRenderer = class {
  stage;
  canvas;
  #ctx;
  width;
  height;
  background;
  pixelRatio;
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.width = opts.width ?? canvas.width ?? 800;
    this.height = opts.height ?? canvas.height ?? 600;
    this.background = opts.background ?? "transparent";
    this.pixelRatio = opts.pixelRatio ?? (typeof devicePixelRatio !== "undefined" ? devicePixelRatio : 1);
    this.stage = new Stage2D(this.width, this.height);
    canvas.width = this.width * this.pixelRatio;
    canvas.height = this.height * this.pixelRatio;
    canvas.style.width = `${this.width}px`;
    canvas.style.height = `${this.height}px`;
    this.#ctx = canvas.getContext("2d", { alpha: true });
    this.#ctx.scale(this.pixelRatio, this.pixelRatio);
    canvas.addEventListener("click", (e) => this.#hitTest(e, "click"));
    canvas.addEventListener("mousemove", (e) => this.#hitTest(e, "mousemove"));
    canvas.addEventListener("mousedown", (e) => this.#hitTest(e, "mousedown"));
  }
  render() {
    const ctx = this.#ctx;
    ctx.clearRect(0, 0, this.width, this.height);
    if (this.background && this.background !== "transparent") {
      ctx.fillStyle = this.background;
      ctx.fillRect(0, 0, this.width, this.height);
    }
    for (const child of this.stage.children) child.drawCanvas(ctx);
    return this;
  }
  #hitTest(e, type) {
    const rect = this.canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (this.width / rect.width);
    const y = (e.clientY - rect.top) * (this.height / rect.height);
    this.stage.children.forEach((c) => this.#testShape(c, x, y, e, type));
  }
  #testShape(shape, x, y, e, type) {
    if (!shape.visible) return;
    if (shape instanceof Group2D) {
      shape.children.forEach((c) => this.#testShape(c, x, y, e, type));
      return;
    }
    if (shape.getBBox().contains(x, y)) shape.fire(type, e);
  }
  toSVG() {
    const r = new SVGRenderer({ width: this.width, height: this.height, background: this.background });
    r.stage.children.push(...this.stage.children);
    return r.toSVG();
  }
  async toPNG(quality = 0.92) {
    return new Promise((res, rej) => {
      this.canvas.toBlob((b) => b ? res(b) : rej(new Error("Canvas toBlob failed")), "image/png", quality);
    });
  }
  async toJPEG(quality = 0.85) {
    return new Promise((res, rej) => {
      this.canvas.toBlob((b) => b ? res(b) : rej(new Error("Canvas toBlob failed")), "image/jpeg", quality);
    });
  }
  resize(w, h) {
    this.width = w;
    this.height = h;
    this.canvas.width = w * this.pixelRatio;
    this.canvas.height = h * this.pixelRatio;
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.#ctx.scale(this.pixelRatio, this.pixelRatio);
    this.stage.width = w;
    this.stage.height = h;
    return this;
  }
  dispose() {
  }
};
function createRenderer2(target, opts = {}) {
  const mode = opts.mode ?? (target instanceof HTMLCanvasElement ? "canvas" : "svg");
  if (mode === "canvas") {
    const canvas = target instanceof HTMLCanvasElement ? target : (() => {
      const c = document.createElement("canvas");
      (target instanceof HTMLElement ? target : document.querySelector(target) ?? document.body).appendChild(c);
      return c;
    })();
    return new CanvasRenderer(canvas, opts);
  } else {
    const r = new SVGRenderer(opts);
    const el = typeof target === "string" ? document.querySelector(target) : target;
    if (el) r.mount(el);
    return r;
  }
}
var _easings = {
  linear: (t) => t,
  easeIn: (t) => t * t,
  easeOut: (t) => t * (2 - t),
  easeInOut: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  easeInQuad: (t) => t * t,
  easeOutQuad: (t) => 1 - (1 - t) * (1 - t),
  easeInOutQuad: (t) => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2,
  easeInCubic: (t) => t * t * t,
  easeOutCubic: (t) => 1 - Math.pow(1 - t, 3),
  easeInOutCubic: (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
  easeInQuart: (t) => t * t * t * t,
  easeOutQuart: (t) => 1 - Math.pow(1 - t, 4),
  easeInOutQuart: (t) => t < 0.5 ? 8 * t * t * t * t : 1 - Math.pow(-2 * t + 2, 4) / 2,
  easeInBounce: (t) => 1 - _easings.easeOutBounce(1 - t),
  easeOutBounce: (t) => {
    if (t < 1 / 2.75) return 7.5625 * t * t;
    if (t < 2 / 2.75) return 7.5625 * (t -= 1.5 / 2.75) * t + 0.75;
    if (t < 2.5 / 2.75) return 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375;
    return 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
  },
  easeInOutBounce: (t) => t < 0.5 ? (1 - _easings.easeOutBounce(1 - 2 * t)) / 2 : (1 + _easings.easeOutBounce(2 * t - 1)) / 2,
  easeInElastic: (t) => t === 0 ? 0 : t === 1 ? 1 : -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * (2 * Math.PI / 3)),
  easeOutElastic: (t) => t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1,
  easeInBack: (t) => {
    const c1 = 1.70158, c3 = c1 + 1;
    return c3 * t * t * t - c1 * t * t;
  },
  easeOutBack: (t) => {
    const c1 = 1.70158, c3 = c1 + 1;
    return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
  },
  spring: (t) => {
    const s = 1 - Math.exp(-t * 6) * Math.cos(t * 20);
    return Math.max(0, Math.min(1, s));
  }
};
var Tween2 = class {
  #target;
  #from;
  #to;
  #duration;
  #elapsed = 0;
  #easing = _easings.linear;
  #delay = 0;
  #repeat = 0;
  #yoyo = false;
  #done = false;
  #dir = 1;
  // 1 = forward, -1 = backward (yoyo)
  #repeatCount = 0;
  onUpdate = null;
  onComplete = null;
  onStart = null;
  #started = false;
  constructor(target, to, duration = 400) {
    this.#target = target;
    this.#to = to;
    this.#duration = duration;
    this.#from = {};
    for (const k in to) this.#from[k] = target[k];
  }
  easing(e) {
    this.#easing = typeof e === "function" ? e : _easings[e] ?? _easings.linear;
    return this;
  }
  delay(ms) {
    this.#delay = ms;
    return this;
  }
  repeat(n) {
    this.#repeat = n;
    return this;
  }
  yoyo(v = true) {
    this.#yoyo = v;
    return this;
  }
  start() {
    _tweens.add(this);
    return this;
  }
  stop() {
    _tweens.delete(this);
    this.#done = true;
    return this;
  }
  get done() {
    return this.#done;
  }
  /** Called by Timeline/loop — dt in ms */
  tick(dt) {
    if (this.#done) return true;
    this.#elapsed += dt;
    if (this.#elapsed < this.#delay) return false;
    const t = Math.min((this.#elapsed - this.#delay) / this.#duration, 1);
    if (!this.#started) {
      this.#started = true;
      this.onStart?.(this.#target);
    }
    const et = this.#dir === 1 ? this.#easing(t) : this.#easing(1 - t);
    for (const k in this.#to) {
      const from = this.#from[k] ?? 0;
      const to = this.#to[k] ?? 0;
      this.#target[k] = from + (to - from) * et;
    }
    this.onUpdate?.(this.#target, t);
    if (t >= 1) {
      if (this.#yoyo) this.#dir *= -1;
      if (this.#repeatCount < this.#repeat) {
        this.#elapsed = this.#delay;
        this.#repeatCount++;
      } else {
        this.#done = true;
        this.onComplete?.(this.#target);
        _tweens.delete(this);
        return true;
      }
    }
    return false;
  }
};
var _tweens = /* @__PURE__ */ new Set();
var Timeline2 = class {
  #entries = [];
  #elapsed = 0;
  #done = false;
  #loop = false;
  onComplete = null;
  add(tween, startAt) {
    const at = startAt ?? this.#entries.reduce((m, e) => Math.max(m, e.startAt), 0);
    this.#entries.push({ tween, startAt: at });
    return this;
  }
  loop(v = true) {
    this.#loop = v;
    return this;
  }
  play() {
    _timelines.add(this);
    return this;
  }
  stop() {
    _timelines.delete(this);
    return this;
  }
  tick(dt) {
    if (this.#done) return true;
    this.#elapsed += dt;
    let allDone = true;
    for (const { tween, startAt } of this.#entries) {
      if (this.#elapsed >= startAt) {
        const localDt = this.#elapsed - startAt;
        if (!tween.done) {
          tween.tick(localDt);
          allDone = false;
        }
      } else {
        allDone = false;
      }
    }
    if (allDone) {
      if (this.#loop) this.#elapsed = 0;
      else {
        this.#done = true;
        this.onComplete?.();
        _timelines.delete(this);
        return true;
      }
    }
    return false;
  }
};
var _timelines = /* @__PURE__ */ new Set();
var AnimationLoop2D = class {
  #rafId = 0;
  #running = false;
  #last = 0;
  onFrame;
  constructor(fn) {
    this.onFrame = fn;
  }
  start() {
    if (this.#running) return this;
    this.#running = true;
    this.#last = performance.now();
    const loop = (now) => {
      if (!this.#running) return;
      const dt = now - this.#last;
      this.#last = now;
      _tweens.forEach((tw) => tw.tick(dt));
      _timelines.forEach((tl) => tl.tick(dt));
      this.onFrame(dt, now);
      this.#rafId = requestAnimationFrame(loop);
    };
    this.#rafId = requestAnimationFrame(loop);
    return this;
  }
  stop() {
    this.#running = false;
    cancelAnimationFrame(this.#rafId);
    return this;
  }
  get running() {
    return this.#running;
  }
};
var PathBuilder = class {
  #cmds = [];
  moveTo(x, y) {
    this.#cmds.push(`M${x},${y}`);
    return this;
  }
  lineTo(x, y) {
    this.#cmds.push(`L${x},${y}`);
    return this;
  }
  hLineTo(x) {
    this.#cmds.push(`H${x}`);
    return this;
  }
  vLineTo(y) {
    this.#cmds.push(`V${y}`);
    return this;
  }
  close() {
    this.#cmds.push("Z");
    return this;
  }
  curveTo(cx1, cy1, cx2, cy2, x, y) {
    this.#cmds.push(`C${cx1},${cy1},${cx2},${cy2},${x},${y}`);
    return this;
  }
  smoothCurveTo(cx2, cy2, x, y) {
    this.#cmds.push(`S${cx2},${cy2},${x},${y}`);
    return this;
  }
  quadTo(cx, cy, x, y) {
    this.#cmds.push(`Q${cx},${cy},${x},${y}`);
    return this;
  }
  smoothQuadTo(x, y) {
    this.#cmds.push(`T${x},${y}`);
    return this;
  }
  arc(rx, ry, angle, largeArc, sweep, x, y) {
    this.#cmds.push(`A${rx},${ry},${angle},${largeArc},${sweep},${x},${y}`);
    return this;
  }
  /** Draw a circular arc centered at (cx,cy) from startAngle to endAngle (radians). */
  arcAround(cx, cy, r, startAngle, endAngle, antiClockwise = false) {
    const start = { x: cx + r * Math.cos(startAngle), y: cy + r * Math.sin(startAngle) };
    const end = { x: cx + r * Math.cos(endAngle), y: cy + r * Math.sin(endAngle) };
    const large = Math.abs(endAngle - startAngle) > Math.PI ? 1 : 0;
    const sweep = antiClockwise ? 0 : 1;
    this.moveTo(start.x, start.y);
    this.#cmds.push(`A${r},${r},0,${large},${sweep},${end.x},${end.y}`);
    return this;
  }
  /** Generate a smooth curve through an array of points (Catmull-Rom → cubic Bezier). */
  spline(points, tension = 0.5) {
    if (points.length < 2) return this;
    this.moveTo(points[0][0], points[0][1]);
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[Math.max(0, i - 1)];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[Math.min(points.length - 1, i + 2)];
      const cp1x = p1[0] + (p2[0] - p0[0]) * tension / 3;
      const cp1y = p1[1] + (p2[1] - p0[1]) * tension / 3;
      const cp2x = p2[0] - (p3[0] - p1[0]) * tension / 3;
      const cp2y = p2[1] - (p3[1] - p1[1]) * tension / 3;
      this.curveTo(cp1x, cp1y, cp2x, cp2y, p2[0], p2[1]);
    }
    return this;
  }
  toString() {
    return this.#cmds.join(" ");
  }
  toPath(style) {
    return new Path({ d: this.toString(), style });
  }
};
function scaleLinear() {
  let domain = [0, 1];
  let range = [0, 1];
  const scale = (v) => {
    const t = (v - domain[0]) / (domain[1] - domain[0]);
    return range[0] + t * (range[1] - range[0]);
  };
  scale.domain = (d) => {
    domain = d;
    return scale;
  };
  scale.range = (r) => {
    range = r;
    return scale;
  };
  scale.ticks = (n = 5) => {
    const step = (domain[1] - domain[0]) / n;
    return Array.from({ length: n + 1 }, (_, i) => +(domain[0] + i * step).toPrecision(6));
  };
  scale.invert = (px) => {
    const t = (px - range[0]) / (range[1] - range[0]);
    return domain[0] + t * (domain[1] - domain[0]);
  };
  return scale;
}
function scaleBand() {
  let domain = [];
  let range = [0, 1];
  let pad = 0.1;
  const scale = (key) => {
    const idx = domain.indexOf(key);
    if (idx < 0) return NaN;
    const bw = scale.bandwidth();
    const gap = (range[1] - range[0]) * pad / domain.length;
    return range[0] + idx * (bw + gap) + gap / 2;
  };
  scale.domain = (d) => {
    domain = d;
    return scale;
  };
  scale.range = (r) => {
    range = r;
    return scale;
  };
  scale.bandwidth = () => {
    const total = range[1] - range[0];
    const gaps = total * pad;
    return (total - gaps) / Math.max(domain.length, 1);
  };
  scale.padding = (p) => {
    pad = p;
    return scale;
  };
  return scale;
}
var Export2D = {
  /**
   * Export a renderer's stage as SVG string.
   */
  toSVG(renderer) {
    return renderer.toSVG();
  },
  /**
   * Download SVG string as a .svg file.
   */
  downloadSVG(renderer, filename = "image.svg") {
    const blob = new Blob([renderer.toSVG()], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement("a"), { href: url, download: filename });
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  },
  /**
   * Download canvas renderer output as .png.
   */
  async downloadPNG(renderer, filename = "image.png") {
    const blob = await renderer.toPNG();
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement("a"), { href: url, download: filename });
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  },
  /**
   * Export stage to a minimal single-page PDF (via Canvas).
   */
  async toPDF(renderer) {
    const jpeg = await renderer.toJPEG(0.85);
    const buf = await jpeg.arrayBuffer();
    const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
    const w = renderer.width, h = renderer.height;
    const obj = [];
    let xref = [], pos = 0;
    const write = (s) => {
      obj.push(s);
      pos += new TextEncoder().encode(s).length;
    };
    write("%PDF-1.4\n");
    xref[1] = pos;
    write(`1 0 obj
<</Type/Catalog/Pages 2 0 R>>
endobj
`);
    xref[2] = pos;
    write(`2 0 obj
<</Type/Pages/Kids[3 0 R]/Count 1>>
endobj
`);
    xref[3] = pos;
    write(`3 0 obj
<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${w} ${h}]/Contents 4 0 R/Resources<</XObject<</I0 5 0 R>>>>>>
endobj
`);
    const stream = `q ${w} 0 0 ${h} 0 0 cm /I0 Do Q`;
    xref[4] = pos;
    write(`4 0 obj
<</Length ${stream.length}>>
stream
${stream}
endstream
endobj
`);
    const imgData = atob(b64);
    xref[5] = pos;
    write(`5 0 obj
<</Type/XObject/Subtype/Image/Width ${w}/Height ${h}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ${imgData.length}>>
stream
`);
    write(imgData);
    write("\nendstream\nendobj\n");
    const xrefPos = pos;
    write(`xref
0 6
0000000000 65535 f 
`);
    for (let i = 1; i <= 5; i++) write(`${String(xref[i]).padStart(10, "0")} 00000 n 
`);
    write(`trailer
<</Size 6/Root 1 0 R>>
startxref
${xrefPos}
%%EOF
`);
    return new Blob([obj.join("")], { type: "application/pdf" });
  }
};
var Two = {
  // Renderer factory
  createRenderer: createRenderer2,
  SVGRenderer,
  CanvasRenderer,
  // Shapes
  Shape2D,
  Group2D,
  Stage2D,
  Circle: Circle3,
  Rect,
  Ellipse,
  Line,
  Polygon: Polygon3,
  Path,
  Text: Text2D,
  Image: Image2D,
  // Math
  Vec2D,
  Mat3,
  BBox2D,
  // Path builder
  PathBuilder,
  path: () => new PathBuilder(),
  // Scales (D3-style)
  scaleLinear,
  scaleBand,
  // Animation
  Tween: Tween2,
  Timeline: Timeline2,
  AnimationLoop: AnimationLoop2D,
  // Easing functions (accessible for custom use)
  easings: {
    linear: (t) => t,
    easeIn: (t) => t * t,
    easeOut: (t) => t * (2 - t),
    easeInOut: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
    easeInCubic: (t) => t * t * t,
    easeOutCubic: (t) => 1 - Math.pow(1 - t, 3),
    easeInOutCubic: (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
    easeOutBounce: (t) => {
      if (t < 1 / 2.75) return 7.5625 * t * t;
      if (t < 2 / 2.75) return 7.5625 * (t -= 1.5 / 2.75) * t + 0.75;
      if (t < 2.5 / 2.75) return 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375;
      return 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
    },
    spring: (t) => Math.max(0, Math.min(1, 1 - Math.exp(-t * 6) * Math.cos(t * 20)))
  },
  // Export
  Export: Export2D
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Two")) {
  try {
    Object.defineProperty(window, "Two", {
      value: Two,
      writable: false,
      enumerable: false,
      configurable: false
    });
  } catch {
  }
}
var Two_default = Two;

// additionals/Video.ts
var ScreenCapture = class {
  #stream = null;
  #recorder = null;
  #chunks = [];
  #opts;
  constructor(opts = {}) {
    this.#opts = { width: 1920, height: 1080, frameRate: 30, audio: false, ...opts };
  }
  async start() {
    const constraints = {
      video: { width: this.#opts.width, height: this.#opts.height },
      audio: this.#opts.audio
    };
    this.#stream = await navigator.mediaDevices.getDisplayMedia(constraints);
    this.#chunks = [];
    const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm";
    this.#recorder = new MediaRecorder(this.#stream, { mimeType });
    this.#recorder.ondataavailable = (e) => {
      if (e.data.size > 0) this.#chunks.push(e.data);
    };
    this.#recorder.start(100);
    return this;
  }
  async stop() {
    return new Promise((res) => {
      if (!this.#recorder) {
        res(new Blob());
        return;
      }
      this.#recorder.onstop = () => res(new Blob(this.#chunks, { type: "video/webm" }));
      this.#recorder.stop();
      this.#stream?.getTracks().forEach((t) => t.stop());
    });
  }
  get stream() {
    return this.#stream;
  }
};
var CameraCapture = class {
  #stream = null;
  #recorder = null;
  #chunks = [];
  #opts;
  constructor(opts = {}) {
    this.#opts = { width: 1280, height: 720, frameRate: 30, audio: true, ...opts };
  }
  async start() {
    this.#stream = await navigator.mediaDevices.getUserMedia({
      video: { width: this.#opts.width, height: this.#opts.height, frameRate: this.#opts.frameRate },
      audio: this.#opts.audio
    });
    this.#chunks = [];
    const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm";
    this.#recorder = new MediaRecorder(this.#stream, { mimeType });
    this.#recorder.ondataavailable = (e) => {
      if (e.data.size > 0) this.#chunks.push(e.data);
    };
    this.#recorder.start(100);
    return this;
  }
  async stop() {
    return new Promise((res) => {
      if (!this.#recorder) {
        res(new Blob());
        return;
      }
      this.#recorder.onstop = () => res(new Blob(this.#chunks, { type: "video/webm" }));
      this.#recorder.stop();
      this.#stream?.getTracks().forEach((t) => t.stop());
    });
  }
  mountPreview(container) {
    const el = typeof container === "string" ? document.querySelector(container) : container;
    if (el && this.#stream) {
      const v = document.createElement("video");
      v.srcObject = this.#stream;
      v.autoplay = true;
      v.muted = true;
      v.playsInline = true;
      v.style.cssText = "width:100%;height:auto;";
      el.appendChild(v);
    }
    return this;
  }
  get stream() {
    return this.#stream;
  }
};
var VideoPlayer = class {
  #el;
  constructor(container, opts = {}) {
    this.#el = document.createElement("video");
    this.#el.controls = opts.controls ?? true;
    this.#el.autoplay = opts.autoplay ?? false;
    this.#el.loop = opts.loop ?? false;
    this.#el.muted = opts.muted ?? false;
    this.#el.playsInline = true;
    if (opts.width) this.#el.style.width = `${opts.width}px`;
    if (opts.height) this.#el.style.height = `${opts.height}px`;
    const parent = typeof container === "string" ? document.querySelector(container) : container;
    parent?.appendChild(this.#el);
  }
  src(url) {
    this.#el.src = url instanceof Blob ? URL.createObjectURL(url) : url;
    return this;
  }
  play() {
    return this.#el.play();
  }
  pause() {
    this.#el.pause();
    return this;
  }
  seek(t) {
    this.#el.currentTime = t;
    return this;
  }
  on(event, handler) {
    this.#el.addEventListener(event, handler);
    return this;
  }
  get duration() {
    return this.#el.duration;
  }
  get currentTime() {
    return this.#el.currentTime;
  }
  get paused() {
    return this.#el.paused;
  }
  get element() {
    return this.#el;
  }
  /** Capture current frame as PNG Blob. */
  async captureFrame() {
    const canvas = document.createElement("canvas");
    canvas.width = this.#el.videoWidth;
    canvas.height = this.#el.videoHeight;
    canvas.getContext("2d")?.drawImage(this.#el, 0, 0);
    return new Promise((res) => canvas.toBlob((b) => res(b ?? new Blob()), "image/png"));
  }
};
var VideoCompositor = class {
  #canvas;
  #ctx;
  #layers = [];
  #rafId = 0;
  #time = 0;
  #running = false;
  constructor(canvas) {
    this.#canvas = canvas;
    this.#ctx = canvas.getContext("2d");
  }
  addLayer(layer) {
    this.#layers.push(layer);
    return this;
  }
  clearLayers() {
    this.#layers = [];
    return this;
  }
  renderFrame(time) {
    const ctx = this.#ctx;
    const { width, height } = this.#canvas;
    ctx.clearRect(0, 0, width, height);
    for (const layer of this.#layers) {
      if (layer.startTime !== void 0 && time < layer.startTime) continue;
      if (layer.endTime !== void 0 && time > layer.endTime) continue;
      ctx.save();
      ctx.globalAlpha = layer.opacity ?? 1;
      const x = layer.x ?? 0, y = layer.y ?? 0, w = layer.width ?? width, h = layer.height ?? height;
      if (layer.type === "color" && layer.color) {
        ctx.fillStyle = layer.color;
        ctx.fillRect(x, y, w, h);
      } else if (layer.type === "image" && layer.source) {
        ctx.drawImage(layer.source, x, y, w, h);
      } else if (layer.type === "video" && layer.source) {
        ctx.drawImage(layer.source, x, y, w, h);
      } else if (layer.type === "text" && layer.text) {
        const s = layer.style ?? {};
        ctx.font = `${s.fontWeight ?? "normal"} ${s.fontSize ?? "24px"} ${s.fontFamily ?? "sans-serif"}`;
        ctx.fillStyle = s.color ?? "#ffffff";
        ctx.fillText(layer.text, x, y);
      }
      ctx.restore();
    }
    return this;
  }
  start() {
    if (this.#running) return this;
    this.#running = true;
    const loop = (ts) => {
      if (!this.#running) return;
      this.#time = ts / 1e3;
      this.renderFrame(this.#time);
      this.#rafId = requestAnimationFrame(loop);
    };
    this.#rafId = requestAnimationFrame(loop);
    return this;
  }
  stop() {
    this.#running = false;
    cancelAnimationFrame(this.#rafId);
    return this;
  }
  async record(duration, frameRate = 30) {
    const stream = this.#canvas.captureStream(frameRate);
    const recorder = new MediaRecorder(stream);
    const chunks = [];
    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.start();
    await new Promise((res) => setTimeout(res, duration * 1e3));
    return new Promise((res) => {
      recorder.onstop = () => res(new Blob(chunks, { type: "video/webm" }));
      recorder.stop();
    });
  }
};
var GIFEncoder = class {
  #frames = [];
  addFrame(canvas, delay = 100) {
    const ctx = canvas.getContext("2d");
    const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
    this.#frames.push({ data: data.data, delay, width: canvas.width, height: canvas.height });
    return this;
  }
  encode() {
    const { width, height } = this.#frames[0] ?? { width: 1, height: 1 };
    const parts = [];
    const push = (bytes) => bytes.forEach((b) => parts.push(b));
    push([71, 73, 70, 56, 57, 97]);
    push([width & 255, width >> 8 & 255, height & 255, height >> 8 & 255]);
    push([247, 0, 0]);
    for (let i = 0; i < 256; i++) push([i, i, i]);
    push([33, 255, 11, 78, 69, 84, 83, 67, 65, 80, 69, 50, 46, 48, 3, 1, 0, 0, 0]);
    for (const frame of this.#frames) {
      push([33, 249, 4, 0, frame.delay & 255, frame.delay >> 8 & 255, 0, 0]);
      push([44, 0, 0, 0, 0, frame.width & 255, frame.width >> 8 & 255, frame.height & 255, frame.height >> 8 & 255, 0]);
      const indices = new Uint8Array(frame.width * frame.height);
      for (let i = 0; i < indices.length; i++) {
        const j = i * 4;
        indices[i] = Math.round(0.299 * frame.data[j] + 0.587 * frame.data[j + 1] + 0.114 * frame.data[j + 2]);
      }
      const lzw = _lzwEncode(indices, 8);
      push([8]);
      for (let i = 0; i < lzw.length; i += 255) {
        const chunk = lzw.subarray(i, i + 255);
        push([chunk.length, ...chunk]);
      }
      push([0]);
    }
    push([59]);
    return new Uint8Array(parts);
  }
};
function _lzwEncode(data, minCodeSize) {
  const clearCode = 1 << minCodeSize;
  const eoi = clearCode + 1;
  const table = /* @__PURE__ */ new Map();
  let codeSize = minCodeSize + 1, nextCode = eoi + 1;
  const bits = [], output = [];
  let bitBuf = 0, bitLen = 0;
  const writeBit = (code) => {
    bitBuf |= code << bitLen;
    bitLen += codeSize;
    while (bitLen >= 8) {
      output.push(bitBuf & 255);
      bitBuf >>= 8;
      bitLen -= 8;
    }
  };
  for (let i = 0; i < 1 << minCodeSize; i++) table.set(String.fromCharCode(i), i);
  writeBit(clearCode);
  let buf = "";
  for (let i = 0; i < data.length; i++) {
    const c = String.fromCharCode(data[i]);
    const bc = buf + c;
    if (table.has(bc)) {
      buf = bc;
    } else {
      writeBit(table.get(buf));
      if (nextCode < 4096) {
        table.set(bc, nextCode++);
        if (nextCode > 1 << codeSize) codeSize = Math.min(codeSize + 1, 12);
      } else {
        writeBit(clearCode);
        table.clear();
        for (let j = 0; j < 1 << minCodeSize; j++) table.set(String.fromCharCode(j), j);
        codeSize = minCodeSize + 1;
        nextCode = eoi + 1;
      }
      buf = c;
    }
  }
  if (buf) writeBit(table.get(buf));
  writeBit(eoi);
  if (bitLen > 0) output.push(bitBuf & 255);
  return new Uint8Array(output);
}
var VideoUtils = {
  download(blob, filename = "recording.webm") {
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement("a"), { href: url, download: filename });
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  },
  blobToDataURL(blob) {
    return new Promise((res) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.readAsDataURL(blob);
    });
  },
  async canvasToGIF(canvases, delay = 100) {
    const enc = new GIFEncoder();
    for (const c of canvases) enc.addFrame(c, delay);
    return new Blob([enc.encode().buffer], { type: "image/gif" });
  }
};
var Video = { ScreenCapture, CameraCapture, VideoPlayer, VideoCompositor, GIFEncoder, utils: VideoUtils };
if (typeof window !== "undefined") {
  try {
    delete window.Video;
  } catch {
  }
  try {
    window.Video = Video;
  } catch {
  }
}
var Video_default = Video;
export {
  AI_default as AI,
  Animation_default as Animation,
  Audio_default as Audio,
  Body,
  Box2 as Box,
  Capsule,
  Circle2 as Circle,
  Colors_default as Colors,
  Data_default as Data,
  DistanceConstraint,
  Drag,
  Finance_default as Finance,
  Geometry_default as Geometry,
  IO_default as IO,
  Latex_default as Latex,
  Math_default as Math,
  Midi_default as Midi,
  Network_default as Network,
  Physics_default as Physics,
  V as PhysicsVec,
  Pin,
  PointGravity,
  Polygon2 as Polygon,
  Rope,
  Shape,
  Sphere2 as Sphere,
  Spring2 as Spring,
  Three_default as Three,
  Two_default as Two,
  Video_default as Video,
  Wind,
  World
};
/**
 * @module    AI
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. AI — WebGPU compute-accelerated machine learning engine.
 * Zero dependencies. Pure TypeScript.
 *
 * ── BACKENDS ──────────────────────────────────────────────────────────────────
 *   WebGPU compute shaders (WGSL) — primary, GPU-parallel
 *   Float32Array CPU            — automatic fallback
 *
 * ── TENSOR ────────────────────────────────────────────────────────────────────
 *   Tensor(shape, data?)        — n-dimensional typed array
 *   .add .sub .mul .div .matmul .transpose .reshape .slice .concat
 *   .relu .sigmoid .tanh .softmax .log .exp .sum .mean .max .min
 *
 * ── LAYERS ────────────────────────────────────────────────────────────────────
 *   Dense / Conv2D / MaxPool2D / Flatten / Dropout / BatchNorm
 *   Embedding / LSTM / GRU / Attention / LayerNorm
 *
 * ── MODELS ────────────────────────────────────────────────────────────────────
 *   Sequential — stack of layers, compile/fit/predict
 *   Transformer — encoder-only, decoder-only, encoder-decoder
 *
 * ── INFERENCE ────────────────────────────────────────────────────────────────
 *   LLMRunner   — run quantized GGUF-like models (text generation)
 *   MarkovChain — n-gram text generation
 *
 * ── UTILS ────────────────────────────────────────────────────────────────────
 *   Tokenizer   — BPE-like character/word tokenizer
 *   oneHot / normalize / standardize / shuffle
 */
/**
 * @module    Animation
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2024 All Rights Reserved
 * @license   AGPL-3.0 / Commercial
 *
 * Migrated and extended from Golem CSS Animation system (2012-2018).
 *
 * ── Original Golem Animation system ──────────────────────────────────────────
 *
 *   The original was an IIFE (Immediately Invoked Function Expression) that:
 *   - Maintained a requestAnimationFrame loop at 60fps
 *   - Tracked _animationElements (map of elements being animated)
 *   - Maintained _animationFrames (array of frame snapshots)
 *   - Had _animationFrameRate (default 60fps)
 *   - Exposed Start(AnimationEventArguments) / Stop(Id) functions
 *   - Fired 4 callbacks:
 *       onAnimation          — every frame
 *       onAnimationStart     — when animation begins
 *       onAnimationStop      — when animation ends
 *       onAnimationIteration — on each iteration/loop
 *
 *   All of this is preserved in the AnimationLoop class below.
 *
 * ── Extensions (new in AriannA 1.0) ──────────────────────────────────────────
 *
 *   Tween    — value interpolation with 12 easing functions
 *   Spring   — physics-based animation (stiffness/damping/mass)
 *   Timeline — sequence/parallel composition of tweens
 *   Keyframe — CSS keyframe equivalent
 *
 * @example
 *   import { Animation, AnimationLoop, Tween, Spring } from "./Animation.ts";
 *   Core.use(Animation);
 *
 *   // Original Golem API preserved
 *   const loop = new AnimationLoop({ frameRate: 60 });
 *   loop.onAnimation = (frame) => { myEl.style.left = frame.Index + "px"; };
 *   loop.Start();
 *   setTimeout(() => loop.Stop(), 3000);
 *
 *   // New Tween API
 *   new Tween(el.style, {
 *     opacity : [0, 1],
 *     duration: 0.6,
 *     easing  : "easeOutCubic",
 *   });
 *
 *   // Spring
 *   const spring = new Spring(0, 100, { stiffness: 200, damping: 20 }, v => {
 *     el.style.transform = `translateX(${v}px)`;
 *   });
 */
/**
 * @module    Audio
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. Audio — Web Audio API engine: synthesis, effects, sequencer.
 * Zero dependencies.
 *
 * MIDI moved to additionals/Midi.ts (separate addon, supports MPE / MIDI 2.0
 * binary format and Web MIDI hardware I/O).
 *
 * ── CORE ──────────────────────────────────────────────────────────────────────
 *   AudioEngine   — AudioContext wrapper, master chain, context lifecycle
 *
 * ── PLAYBACK ──────────────────────────────────────────────────────────────────
 *   AudioPlayer   — load + play audio files / ArrayBuffer
 *   AudioRecorder — microphone capture via MediaRecorder
 *
 * ── SYNTHESIS ────────────────────────────────────────────────────────────────
 *   Oscillator    — waveform generator (sine/square/sawtooth/triangle/custom)
 *   Sampler       — sample player with pitch shifting
 *   NoiseGenerator— white/pink/brown noise
 *
 * ── EFFECTS ──────────────────────────────────────────────────────────────────
 *   Reverb / Delay / Compressor / Filter / EQ / Distortion / Panner / Chorus
 *
 * ── ANALYSIS ─────────────────────────────────────────────────────────────────
 *   Analyser     — FFT spectrum, waveform, peak/RMS
 *
 * ── SEQUENCER ────────────────────────────────────────────────────────────────
 *   Sequencer    — step sequencer, BPM clock, pattern scheduling
 */
/**
 * @module    additionals/Colors
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * AriannA Colors addon — pure colour-space conversion library shared by
 * every colour-picker and gradient-editor component. Single module, zero
 * dependencies, all pure functions. Sits alongside the other AriannA
 * addons (Three, Two, AI, Finance, Video, Audio, IO) and provides the
 * mathematics layer the components in `components/graphics/colors/`
 * assemble into UI.
 *
 * Supported spaces:
 *
 *   • RGB     — sRGB linearised through the standard companding curve.
 *   • HEX     — `#rgb` / `#rrggbb` / `#rrggbbaa` parsing & formatting.
 *   • HSL     — derived from sRGB.
 *   • HSV     — derived from sRGB.
 *   • CMYK    — naive CMYK from sRGB (suitable for screen mock-ups; for
 *               print accuracy you must round-trip through ICC profiles —
 *               not in scope here).
 *   • CIELUV  — D65 illuminant, CIE 1976 L*u*v* polar form (Lch_uv).
 *   • OKLCH   — Björn Ottosson's 2020 OKLab in cylindrical (L, C, h).
 *   • Cube    — 256-step uniform RGB cube indexed by R*65536 + G*256 + B,
 *               useful for palette quantisation / lookup tables.
 *
 * All functions are stateless and side-effect-free. Inputs are clamped /
 * normalised at every public entry point so callers can pass typed user
 * input without worrying about ranges.
 *
 * @example
 *   import { parseHex, rgbToOklch, oklchToRgb, formatCss } from 'ariannajs/additionals/Colors';
 *
 *   const rgb   = parseHex('#e40c88')!;
 *   const oklch = rgbToOklch(rgb);            // { L, C, h, a? }
 *   const back  = oklchToRgb(oklch);          // approximate round-trip
 *   const css   = formatCss('oklch', oklch);  // "oklch(...)"
 */
/**
 * @module    Data
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. Data — essential data structures and abstract models.
 * Zero dependencies.
 *
 * ── GRAPH ─────────────────────────────────────────────────────────────────────
 *   DAG           — Directed Acyclic Graph with topological sort + cycle detect
 *   Graph         — Weighted directed graph: BFS, DFS, Dijkstra, A*
 *
 * ── STATE MACHINES ────────────────────────────────────────────────────────────
 *   FSM           — Finite State Machine with guards, actions, history
 *   StatechartFSM — Hierarchical statechart (HSM) with regions
 *
 * ── TREES ─────────────────────────────────────────────────────────────────────
 *   Trie          — Prefix tree for autocomplete / IP routing
 *   BinaryTree    — BST with insert/search/delete/inorder/balance
 *   SegmentTree   — Range queries (sum, min, max) with lazy propagation
 *
 * ── QUEUES ────────────────────────────────────────────────────────────────────
 *   PriorityQueue — Binary min/max heap
 *   Deque         — Double-ended queue (O(1) push/pop both ends)
 *
 * ── CACHE ─────────────────────────────────────────────────────────────────────
 *   LRUCache      — Least-Recently-Used cache (O(1) get/put)
 *   LFUCache      — Least-Frequently-Used cache
 *
 * ── UNION-FIND ────────────────────────────────────────────────────────────────
 *   DisjointSet   — Union-Find with path compression + rank
 *
 * ── OBSERVABLE COLLECTIONS ───────────────────────────────────────────────────
 *   ObservableMap   — Map that fires onChange on mutations
 *   ObservableArray — Array with reactive splice/push/pop
 */
/**
 * @module    Finance
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. Finance — quantitative finance engine.
 * Zero dependencies. WebGPU-accelerated Monte Carlo.
 *
 * ── INDICATORS ────────────────────────────────────────────────────────────────
 *   SMA / EMA / WMA / DEMA / TEMA
 *   RSI / MACD / BollingerBands / ATR / Stochastic
 *   VWAP / OBV / PSAR / CCI / WilliamsR / ADX
 *
 * ── PORTFOLIO ─────────────────────────────────────────────────────────────────
 *   Markowitz mean-variance optimization (efficient frontier)
 *   Sharpe / Sortino / Calmar / MaxDrawdown
 *
 * ── DERIVATIVES ──────────────────────────────────────────────────────────────
 *   Black-Scholes (call/put price + full Greeks)
 *   Binomial tree option pricing
 *   Monte Carlo option pricing (CPU + WebGPU)
 *
 * ── BACKTESTING ──────────────────────────────────────────────────────────────
 *   Strategy runner — event-driven, bar-by-bar
 *   Position / Trade / Portfolio management
 */
/**
 * @module    Math
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2024 All Rights Reserved
 * @license   AGPL-3.0 / Commercial
 *
 * Originally developed 2012-2018, refined and extended for AriannA.
 * Every class and function from the original is preserved.
 * New additions: Vector2/3/4, Quaternion, Matrix4, LinearFunction,
 * QuadraticFunction, Complex, Statistics.
 * Dedicated with love to Arianna. ♡
 *
 * @example
 *   import { Math, MathConstants, Fraction, Vector3 } from "./Math.ts";
 *   Core.use(Math);
 *
 *   // Original the legacy library API
 *   const f = new Fraction(3, 4);
 *   f.Sum(new Fraction(1, 4)).toString();  // "1/1"
 *
 *   // New AriannA API
 *   const v = new Vector3(1, 2, 3);
 *   const m = Matrix4.perspective(Math.PI/4, 16/9, 0.1, 1000);
 */
/**
 * @module    Geometry
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2024 All Rights Reserved
 * @license   AGPL-3.0 / Commercial
 *
 * Migrated and extended from AriannA Geometry (2012-2018).
 *
 * ── Original the legacy library classes preserved ──────────────────────────────────────────
 *
 *   Angle     — full unit system: Radians, Degrees, Turns, Quadrants,
 *               Grads, Mils, Sextants, Points, BinaryDegrees, Hours,
 *               Minutes, Seconds + all trig values
 *   Rotation  — 3D rotation with Psi/Theta/Phi (Euler angles)
 *   Size      — Width/Height/Depth
 *   Point     — X/Y/Z coordinate
 *   Vector    — N-dimensional vector (Sum, Subtract, Dot, Cross, Normalize)
 *   Vector2d  → now exported as Vector2 (see Math.ts)
 *   Vector3d  → now exported as Vector3 (see Math.ts)
 *   Matrix    — full NxN matrix with LUP, QR, EigenValues, EigenVectors
 *   Transform — CSS/3D transform (Translate, Scale, Rotate, Skew, Reflect)
 *   Shapes    — Rectangle, Line, Curve, Path, Triangle, Circle, Plane, Polygon
 *   Solids    — Frustum, TetraHedron, Pyramid, Box, Sphere, Octahedron,
 *               Torus, ChamferBox, Cylinder, Tube
 *
 * ── New additions ─────────────────────────────────────────────────────────────
 *
 *   AABB      — Axis-Aligned Bounding Box (collision detection)
 *   Ray       — Ray casting (mouse picking, raycasting)
 *   Plane3D   — Infinite plane in 3D space
 *   BVH       — Bounding Volume Hierarchy (TODO: Phase 3)
 *   CSG       — Constructive Solid Geometry (TODO: Phase 3, manifold WASM)
 *
 * @example
 *   import { Geometry, Angle, Matrix, Shapes, AABB, Ray } from "./Geometry.ts";
 *   Core.use(Geometry);
 *
 *   // Original the legacy library API preserved
 *   const a = new Angle(Math.PI / 4, "Radians");
 *   console.log(a.Degrees);   // → 45
 *   console.log(a.Sine);      // → 0.7071...
 *
 *   const m = Matrix.identity(4);
 *   m.Determinant();          // → 1
 *
 *   // New
 *   const box = new AABB(new Vector3(-1,-1,-1), new Vector3(1,1,1));
 *   const ray = new Ray(new Vector3(0,5,0), new Vector3(0,-1,0));
 *   console.log(ray.intersectAABB(box)); // → { hit: true, t: 4 }
 */
/**
 * @module    IO
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. IO — File I/O, network, storage, clipboard, drag & drop.
 * Zero dependencies.
 *
 * ── FILE ──────────────────────────────────────────────────────────────────────
 *   FileIO     — File API, drag-drop, download helpers
 *   FSAccess   — File System Access API (read/write files & directories)
 *
 * ── NETWORK ──────────────────────────────────────────────────────────────────
 *   Http       — Fetch wrapper with retries, timeout, interceptors
 *   SSE        — Server-Sent Events reactive wrapper
 *   WebSocketIO— WebSocket wrapper with reconnect + message queue
 *
 * ── STORAGE ──────────────────────────────────────────────────────────────────
 *   LocalStore — localStorage reactive wrapper
 *   IndexedDB  — IndexedDB promise-based wrapper
 *
 * ── CLIPBOARD ────────────────────────────────────────────────────────────────
 *   Clipboard  — read/write text, images, rich content
 *
 * ── SHARE ────────────────────────────────────────────────────────────────────
 *   Share      — Web Share API wrapper
 */
/**
 * @module    additionals/Midi
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. MIDI — addon
 *
 * Three things in one file:
 *   1. Live Web MIDI engine (formerly Audio.MIDIEngine, moved here).
 *      Supports legacy 1.0 messages on the wire because that is what
 *      hardware still sends, but normalises everything into the high-res
 *      MidiEvent shape used by the rest of the addon.
 *   2. AriannA proprietary binary format (.amid).
 *      Designed from day one for MPE and MIDI 2.0:
 *        - per-note pitch bend (cents, signed 14-bit)
 *        - high-res velocity (16-bit)
 *        - per-note expression / pressure / brightness / timbre
 *        - explicit note ID linking on/off pairs (no 'last on' guesswork)
 *      No backwards compatibility with SMF — that's a separate import path
 *      we'll add later (Midi.fromSMF).
 *   3. Helpers: noteToFreq, noteToName, hex utils, validation.
 *
 * Wire format (.amid) — overview
 * -------------------------------
 *   Header  : "AMID" magic (4B) + version u16 + flags u16
 *   Songmeta: tempo (u32 µ-quarter), ppq (u16), timeSig (u8 num, u8 den)
 *   Tracks  : count u16, then per track: nameLen u8, name UTF-8, eventCount u32, events
 *   Events  : delta u32 (varint, ticks), kind u8, payload (variable, kind-defined)
 *
 * The full byte layout is in `_writeBinary` / `_readBinary`. Schema is
 * versioned; bump the version field when changing.
 */
/**
 * @module    AriannANetwork
 * @author    Riccardo Angeli
 * @version   0.1.0
 * @copyright Riccardo Angeli 2024 All Rights Reserved
 * @license   AGPL-3.0 / Commercial
 *
 * HTTP, WebSocket, SSE, GraphQL helpers
 *
 * Includes: Fetch wrapper, WebSocket, SSE, GraphQL client, REST builder, Retry/timeout
 * Weight:   ~14KB gzipped
 * Deps:     none
 *
 * @example
 *   import AriannA from "../core/index.ts";
 *   import { Network } from "./Network.ts";
 *
 *   Core.use(Network);
 *
 * Usage:
 *   // After Core.use(Network), all classes are available globally
 *   // and integrate with Real, State, Observable automatically
 */
/**
 * @module    additionals/Physics
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026 All Rights Reserved
 * @license   AGPL-3.0 / Commercial
 *
 * AriannA Physics — 2D / 3D rigid-body simulation additional.
 *
 * Mirrors the namespace shape of additionals/Three.ts and additionals/Two.ts:
 * a single `Physics` namespace exports every class, and they are ALSO mirrored
 * flat onto `window` so existing demos can write `new World(...)` without
 * going through `AriannA.Physics.World`.
 *
 * ── PUBLIC API ────────────────────────────────────────────────────────────────
 *
 *   World        - top-level simulation; gravity, substeps, broadphase, integrator
 *   Body         - rigid body with mass / shape / pose / velocity
 *   Shape        - abstract shape; subclasses: Circle, Sphere, Box, Capsule, Polygon
 *   Spring / DistanceConstraint / Pin / Rope - constraints
 *   Drag / PointGravity / Wind               - force fields
 *   V            - vector helpers (add / sub / scale / dot / len / norm)
 *
 * ── USAGE ─────────────────────────────────────────────────────────────────────
 *
 *   import { World, Body, Box, Circle } from 'arianna/additionals/Physics';
 *
 *   const world = new World({ gravity: [0, -9.81], dimension: 2, substeps: 4 });
 *   world.addBody(new Body({ shape: new Box(20, 0.5), static: true }));
 *   world.addBody(new Body({ shape: new Circle(0.3), position: [0, 5],
 *                            restitution: 0.7 }));
 *   world.start();
 *
 *   // Or, once the additional is loaded as a side-effect script:
 *   const w = new World({ gravity: [0, -9.81] });
 */
/**
 * @module    Three
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * AriannA Three — WebGPU 3D renderer + scene graph + modifiers.
 * Zero dependencies. Pure TypeScript.
 *
 * ── RENDERER ─────────────────────────────────────────────────────────────────
 *   WebGPU primary  (Chrome 113+, Safari 18+, Edge 113+)
 *   WebGL2 fallback (disposable — will be removed when WebGPU is universal)
 *
 * ── SCENE GRAPH ──────────────────────────────────────────────────────────────
 *   Scene → Object3D → Mesh | Light | Camera | Group
 *   Every node: position / rotation / scale / matrix / children
 *
 * ── GEOMETRIES ───────────────────────────────────────────────────────────────
 *   BoxGeometry / SphereGeometry / CylinderGeometry / PlaneGeometry
 *   ConeGeometry / TorusGeometry / BufferGeometry (custom)
 *
 * ── MATERIALS ────────────────────────────────────────────────────────────────
 *   MeshBasicMaterial / MeshLambertMaterial / MeshPhongMaterial
 *   MeshPBRMaterial / WireframeMaterial / LineMaterial
 *
 * ── LIGHTS ───────────────────────────────────────────────────────────────────
 *   AmbientLight / DirectionalLight / PointLight / SpotLight
 *
 * ── CAMERAS ──────────────────────────────────────────────────────────────────
 *   PerspectiveCamera / OrthographicCamera
 *
 * ── MODIFIERS (pure JS BSP/geometry) ─────────────────────────────────────────
 *   CSG.union / CSG.subtract / CSG.intersect  (BSP tree)
 *   SubdivisionModifier  (Catmull-Clark)
 *   BevelModifier        (edge bevel)
 *   DecimateModifier     (vertex collapse)
 *   MirrorModifier       (axis mirror)
 *   ArrayModifier        (repeat along axis)
 *   BendModifier / TwistModifier
 *
 * ── IMPORT / EXPORT ──────────────────────────────────────────────────────────
 *   STL  (binary + ASCII) read/write
 *   OBJ  read/write
 *   glTF / GLB  read/write
 *
 * ── USAGE ────────────────────────────────────────────────────────────────────
 *   const renderer = await Three.createRenderer(canvas);
 *   const scene    = new Three.Scene();
 *   const camera   = new Three.PerspectiveCamera(60, canvas.width / canvas.height);
 *   camera.position.set(0, 1, 5);
 *
 *   const geo  = new Three.BoxGeometry(1, 1, 1);
 *   const mat  = new Three.MeshPBRMaterial({ color: '#e40c88' });
 *   const mesh = new Three.Mesh(geo, mat);
 *   scene.add(mesh);
 *
 *   renderer.render(scene, camera);
 *
 * @example
 *   // CSG — subtract a sphere from a box
 *   const box    = new Three.Mesh(new Three.BoxGeometry(2,2,2));
 *   const sphere = new Three.Mesh(new Three.SphereGeometry(1.2));
 *   const result = Three.CSG.subtract(box, sphere);
 *   scene.add(result);
 */
/**
 * @module    Two
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. Two — 2D vector graphics engine.
 * Zero dependencies. Pure TypeScript.
 *
 * ── RENDERERS ─────────────────────────────────────────────────────────────────
 *   SVGRenderer    — live SVG DOM, resolution-independent, CSS-animatable
 *   CanvasRenderer — Canvas2D, high-performance raster, pixel-perfect
 *   Auto-select via Two.createRenderer(canvas | 'svg' | 'canvas')
 *
 * ── SCENE GRAPH ──────────────────────────────────────────────────────────────
 *   Stage → Shape2D → Path | Circle | Rect | Ellipse | Line | Polygon
 *                           Text | Group2D | Image2D
 *
 * ── STYLE ────────────────────────────────────────────────────────────────────
 *   Fill / Stroke / Gradient (linear + radial) / Pattern / Shadow
 *
 * ── TRANSFORMS ───────────────────────────────────────────────────────────────
 *   translate / rotate / scale / skewX / skewY / matrix (Mat3)
 *
 * ── ANIMATION ────────────────────────────────────────────────────────────────
 *   Tween — property interpolation (linear / ease / spring)
 *   Timeline — sequenced tweens with delay / repeat / yoyo
 *
 * ── EXPORT ───────────────────────────────────────────────────────────────────
 *   .toSVG()    → SVG string
 *   .toPNG()    → Promise<Blob>  (via OffscreenCanvas)
 *   .toPDF()    → Blob           (via minimal PDF engine)
 *
 * ── USAGE ────────────────────────────────────────────────────────────────────
 *   const two   = Two.createRenderer('#canvas', { mode: 'svg', width: 800, height: 600 });
 *   const stage = two.stage;
 *
 *   const circle = new Two.Circle({ cx: 200, cy: 200, r: 80, fill: '#e40c88' });
 *   stage.add(circle);
 *   two.render();
 *
 *   // Animate
 *   new Two.Tween(circle, { r: 120 }, 600).easing('easeInOut').start();
 *   two.loop();
 */
/**
 * @module    Video
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * A.r.i.a.n.n.A. Video — browser video capture, playback, and composition.
 * Zero dependencies.
 *
 * ── CAPTURE ───────────────────────────────────────────────────────────────────
 *   ScreenCapture  — getDisplayMedia recording
 *   CameraCapture  — getUserMedia recording
 *   MediaRecorder  — record to Blob (webm/mp4)
 *
 * ── PLAYBACK ──────────────────────────────────────────────────────────────────
 *   VideoPlayer    — fluent <video> wrapper
 *   VideoSprite    — sprite sheet frame animation
 *
 * ── COMPOSITION ──────────────────────────────────────────────────────────────
 *   VideoCompositor — Canvas2D multi-layer renderer
 *   TextOverlay     — text track rendering
 *   Timeline        — time-based layer sequencer
 *
 * ── EXPORT ────────────────────────────────────────────────────────────────────
 *   .toGIF()   — animated GIF via Canvas2D + LZW
 *   .download() — trigger Blob download
 */
