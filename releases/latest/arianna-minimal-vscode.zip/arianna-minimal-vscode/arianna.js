// core/Core.ts
function uuid() {
  const b = [];
  for (let i = 0; i < 9; i++)
    b.push(Math.floor(1 + Math.random() * 65536).toString(16).slice(1));
  return `${b[1]}${b[2]}-${b[3]}-${b[4]}-${b[5]}-${b[6]}${b[7]}${b[8]}`;
}
var version = Object.freeze(
  {
    major: 1,
    minor: 0,
    patch: 0,
    get string() {
      return `${this.major}.${this.minor}.${this.patch}`;
    }
  }
);
var Scopes = Object.freeze(
  {
    Private: { configurable: false, enumerable: false, writable: false },
    Readonly: { configurable: false, enumerable: true, writable: false },
    Writable: { configurable: false, enumerable: true, writable: true },
    Configurable: { configurable: true, enumerable: true, writable: false }
  }
);
function GetPrototypeChain(obj) {
  const chain = [];
  let proto = typeof obj === "function" ? obj.prototype : Object.getPrototypeOf(obj);
  while (proto !== null) {
    const ctor = proto.constructor;
    if (ctor?.name) chain.push(ctor.name);
    proto = Object.getPrototypeOf(proto);
  }
  return chain;
}
function SetDescriptors(target, scope, recurse = false) {
  const d = { ...scope };
  for (const key of Object.keys(target)) {
    d.value = target[key];
    try {
      Object.defineProperty(target, key, d);
    } catch {
    }
    if (recurse && target[key] && typeof target[key] === "object" && !Array.isArray(target[key])) {
      SetDescriptors(
        target[key],
        scope,
        true
      );
    }
  }
}
var Namespaces = {};
function RegisterNamespace(key, ns) {
  if (Namespaces[key]) {
    console.warn(`Core.RegisterNamespace: '${key}' already registered \u2014 skipping.`);
    return;
  }
  Namespaces[key] = ns;
}
function GetDescriptor(obj) {
  if (!obj) return false;
  let key;
  const t = typeof obj;
  if (t === "string") {
    key = obj.toLowerCase();
  } else if (t === "function") {
    key = obj.name.toLowerCase();
  } else if (obj instanceof Node) {
    key = obj.nodeName.toLowerCase();
  } else {
    const o = obj;
    const tagKey = Object.keys(o).find((k) => k.toUpperCase() === "TAG");
    if (!tagKey) return false;
    key = String(o[tagKey]).toLowerCase();
  }
  for (const nsKey of Object.keys(Namespaces)) {
    const ns = Namespaces[nsKey];
    const std = ns.types.standard;
    const cst = ns.types.custom;
    const found = std.tags[key] ?? std.interfaces[key] ?? cst.tags[key] ?? cst.interfaces[key];
    if (found) return found;
    if (typeof obj === "function") {
      for (const k of Object.keys(std.interfaces)) {
        const d = std.interfaces[k];
        if (k.toLowerCase() === key || d.Constructor === obj || d.Interface === obj) return d;
      }
      for (const k of Object.keys(cst.interfaces)) {
        const d = cst.interfaces[k];
        if (k.toLowerCase() === key || d.Constructor === obj || d.Interface === obj) return d;
      }
    }
  }
  return false;
}
function Define(tag, constructor, base = HTMLElement, style = {}) {
  const ct = tag.toLowerCase();
  const existing = GetDescriptor(ct);
  if (existing) {
    console.warn(`Core.Define: '${ct}' already registered.`);
    return existing;
  }
  let ns = null;
  const baseDsc = GetDescriptor(base);
  if (baseDsc && baseDsc.Namespace) {
    ns = baseDsc.Namespace;
  } else {
    for (const nsKey of Object.keys(Namespaces)) {
      const candidate = Namespaces[nsKey];
      if (candidate.base === base) {
        ns = candidate;
        break;
      }
      for (const k of Object.keys(candidate.types.standard.interfaces)) {
        const d = candidate.types.standard.interfaces[k];
        if (d.Constructor === base || d.Interface === base) {
          ns = candidate;
          break;
        }
      }
      if (ns) break;
    }
  }
  if (!ns) {
    ns = Namespaces["html"] ?? Object.values(Namespaces)[0];
    console.warn(`Core.Define: base '${base.name}' not found in any registered namespace \u2014 defaulting to html.`);
  }
  const isClass = /^class[\s{]/.test(constructor.toString());
  const descriptor = {
    Name: constructor.name,
    Tags: [ct],
    Namespace: ns,
    Constructor: constructor,
    Interface: base,
    Prototype: constructor.prototype,
    Supported: true,
    Defined: true,
    Declaration: isClass ? "CLASS" : "FUNCTION",
    Type: "CUSTOM",
    Standard: false,
    Custom: true,
    Style: style,
    Update: (el) => {
      Object.setPrototypeOf(constructor.prototype, base.prototype);
      Object.setPrototypeOf(el, constructor.prototype);
      if (isClass) {
        try {
          const src = constructor.toString();
          const m = src.match(/constructor\s*\(\s*\)\s*\{([\s\S]*?)\}(?=\s*\})/);
          if (m) {
            const fn = new Function(`return function(){${m[1]}}`)();
            fn.call(el);
          }
        } catch (_) {
        }
      } else {
        constructor.call(el);
      }
    }
  };
  ns.types.custom.interfaces[constructor.name] = descriptor;
  ns.types.custom.tags[ct] = descriptor;
  document.dispatchEvent(new CustomEvent("arianna-wip:defined", {
    detail: { tag: ct, descriptor }
  }));
  return descriptor;
}
var Events = Object.freeze(
  {
    /**
     * Add a DOM event listener to one or more targets.
     * Prefer `Observable.On` for full listener shipments and registry.
     * @example
     *   Core.Events.On(element, 'click', handler);
     *   Core.Events.On('.btn', 'click mouseenter', handler, { passive: true });
     */
    On(target, types, callback, options) {
      _resolveTargets(target).forEach((el) => _splitTypes(types).forEach((t) => el.addEventListener(t, callback, options)));
    },
    /**
     * Remove a DOM event listener from one or more targets.
     * @example
     *   Core.Events.Off(element, 'click', handler);
     */
    Off(target, types, callback, options) {
      _resolveTargets(target).forEach((el) => _splitTypes(types).forEach((t) => el.removeEventListener(t, callback, options)));
    },
    /**
     * Dispatch a CustomEvent on one or more targets.
     * @example
     *   Core.Events.Fire(button, 'click', { detail: { value: 42 } });
     */
    Fire(target, type, init) {
      const ev = new CustomEvent(type, { bubbles: true, composed: true, ...init });
      _resolveTargets(target).forEach((el) => el.dispatchEvent(ev));
    }
  }
);
function _resolveTargets(t) {
  if (typeof t === "string")
    return Array.from(document.querySelectorAll(t));
  return Array.isArray(t) ? t : [t];
}
function _splitTypes(s) {
  return s.split(/\s+|,|\|/g).filter(Boolean);
}
var Observer = new MutationObserver((mutations) => {
  for (const m of mutations) {
    if (m.type === "attributes" && m.target instanceof Element) {
      const attr = m.target.attributes.getNamedItem(m.attributeName ?? "");
      if (attr) {
        const evName = /^(\w+)/.exec(attr.name)?.[1]?.toLowerCase() ?? attr.name;
        m.target.dispatchEvent(new CustomEvent(`${evName}-change`, {
          detail: { element: m.target, attribute: attr }
        }));
      }
    }
    if (m.type === "childList") {
      for (const node of Array.from(m.addedNodes)) {
        const d = node instanceof Element ? GetDescriptor(node) : false;
        const detail = {
          node,
          descriptor: d,
          state: { loading: true, loaded: false, name: "Loading" }
        };
        if (node instanceof Element)
          node.dispatchEvent(new CustomEvent("arianna-wip:nodeadding", { detail }));
        if (d && d.Custom && d.Constructor && d.Update)
          d.Update(node);
        detail.state = { loading: false, loaded: true, name: "Loaded" };
        document.dispatchEvent(new CustomEvent("arianna-wip:nodeadded", { detail }));
      }
      for (const node of Array.from(m.removedNodes)) {
        const d = node instanceof Element ? GetDescriptor(node) : false;
        document.dispatchEvent(new CustomEvent("arianna-wip:noderemoved", {
          detail: { node, descriptor: d }
        }));
      }
    }
  }
});
if (typeof document !== "undefined") {
  Observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeOldValue: true
  });
}
var _installedPlugins = /* @__PURE__ */ new Set();
function use(plugin, options = {}) {
  if (_installedPlugins.has(plugin.name)) {
    console.warn(`Core.use: plugin '${plugin.name}' is already installed.`);
    return;
  }
  plugin.install(_coreApi, options);
  _installedPlugins.add(plugin.name);
}
function plugins() {
  return Array.from(_installedPlugins);
}
function Is(value, ...types) {
  if (value === null || value === void 0 || types.length === 0) return false;
  const native = /* @__PURE__ */ new Set(["string", "number", "boolean", "symbol", "function", "object"]);
  for (const t of types) {
    if (typeof t === "string") {
      if (t === "class") {
        if (typeof value !== "function" || !/^class\b/.test(Function.prototype.toString.call(value))) return false;
      } else if (native.has(t)) {
        if (typeof value !== t) return false;
      }
    } else if (typeof t === "function") {
      if (!(value instanceof t)) return false;
    }
  }
  return true;
}
function Equals(...args) {
  let elements = args;
  if (args.length === 1 && Array.isArray(args[0])) elements = args[0];
  if (elements.length < 2) return true;
  for (let i = elements.length - 1; i > 0; i--) {
    const x = elements[i];
    const y = elements[i - 1];
    if (Object.is(x, y)) continue;
    if ((x === null || x === void 0) && (y === null || y === void 0)) continue;
    if (x === null || y === null || x === void 0 || y === void 0) return false;
    const tx = typeof x, ty = typeof y;
    if (tx !== ty) return false;
    if (tx === "object") {
      if (x instanceof Date && y instanceof Date) {
        if (x.getTime() !== y.getTime()) return false;
        continue;
      }
      if (x instanceof RegExp && y instanceof RegExp) {
        if (x.toString() !== y.toString()) return false;
        continue;
      }
      if (Array.isArray(x) || Array.isArray(y)) {
        if (!Array.isArray(x) || !Array.isArray(y)) return false;
        if (x.length !== y.length) return false;
        for (let k = 0; k < x.length; k++) if (!Equals(x[k], y[k])) return false;
        continue;
      }
      const xo = x;
      const yo = y;
      const xk = Object.keys(xo);
      const yk = Object.keys(yo);
      if (xk.length !== yk.length) return false;
      for (const k of xk) {
        if (!Object.prototype.hasOwnProperty.call(yo, k)) return false;
        if (!Equals(xo[k], yo[k])) return false;
      }
      continue;
    }
    if (tx === "function") {
      if (x.toString() !== y.toString()) return false;
      continue;
    }
    return false;
  }
  return true;
}
function Empty(value) {
  if (value === null || value === void 0 || typeof value !== "object") return true;
  for (const _ in value) return false;
  return true;
}
function Has(target, ...members) {
  if (!target || typeof target !== "object") return false;
  if (members.length === 0) return true;
  const isElement = typeof HTMLElement !== "undefined" && target instanceof HTMLElement;
  for (const m of members) {
    if (isElement) {
      if (target.getAttribute(m) === null) return false;
    } else {
      if (!(m in target)) return false;
    }
  }
  return true;
}
function Clone(value) {
  if (value === null || value === void 0) return value;
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === "symbol" || t === "bigint") return value;
  if (t === "function") {
    const fn = value;
    const out = new Function("return " + fn.toString())();
    const fnRec = fn;
    const outRec = out;
    for (const k of Object.keys(fnRec)) outRec[k] = fnRec[k];
    return out;
  }
  if (typeof Node !== "undefined" && value instanceof Node) {
    return value.cloneNode(true);
  }
  if (value instanceof Date) return new Date(value.getTime());
  if (value instanceof RegExp) return new RegExp(value.source, value.flags);
  if (Array.isArray(value)) {
    return value.map((v) => Clone(v));
  }
  if (t === "object") {
    const obj = value;
    const out = {};
    for (const k of Object.keys(obj)) out[k] = Clone(obj[k]);
    return out;
  }
  return value;
}
function Assign(target, ...sources) {
  if (target === null || target === void 0) throw new TypeError("Cannot convert first argument to object");
  const to = Object(target);
  for (const source of sources) {
    if (source === null || source === void 0) continue;
    if (typeof source === "function" && Is(source, "class")) {
      const ctor = source;
      const targetCtor = target;
      if (!targetCtor.prototype) continue;
      for (const k of Object.getOwnPropertyNames(ctor.prototype)) {
        if (k !== "constructor") {
          targetCtor.prototype[k] = ctor.prototype[k];
        }
      }
      try {
        const instance = new ctor();
        const proto = Object.getPrototypeOf(targetCtor.prototype);
        if (proto) {
          for (const k of Object.getOwnPropertyNames(instance)) {
            if (k !== "constructor") proto[k] = instance[k];
          }
        }
      } catch {
      }
      continue;
    }
    const src = Object(source);
    for (const k of Object.keys(src)) {
      const desc = Object.getOwnPropertyDescriptor(src, k);
      if (desc?.enumerable) to[k] = src[k];
    }
  }
  return target;
}
function Replace(target, replacement) {
  if (!target || !(target instanceof Node) || !target.parentNode) return void 0;
  if (replacement === null || replacement === void 0) return void 0;
  let next = null;
  if (typeof replacement === "string") {
    const tpl = document.createElement("template");
    tpl.innerHTML = replacement;
    next = tpl.content.firstElementChild ?? tpl.content.firstChild;
  } else if (replacement instanceof Node) {
    next = replacement;
  }
  if (!next) return void 0;
  if (next.parentNode) next.parentNode.removeChild(next);
  target.parentNode.replaceChild(next, target);
  return next;
}
function Extends(...classes) {
  if (classes.length < 2) return classes[0];
  for (let i = 0; i < classes.length - 1; i++) {
    const Sub = classes[i];
    const Super = classes[i + 1];
    if (typeof Sub !== "function" || typeof Super !== "function") continue;
    const SubF = Sub;
    const SuperF = Super;
    if (!SubF.prototype || !SuperF.prototype) continue;
    try {
      Object.setPrototypeOf(SubF.prototype, SuperF.prototype);
      Object.setPrototypeOf(SubF, SuperF);
    } catch {
    }
  }
  return classes[0];
}
function _propertyMatchesType(v, t) {
  if (typeof t === "function") return t(v);
  switch (t) {
    case "string":
      return typeof v === "string";
    case "number":
      return typeof v === "number" && !Number.isNaN(v);
    case "integer":
      return typeof v === "number" && Number.isInteger(v);
    case "boolean":
      return typeof v === "boolean";
    case "function":
      return typeof v === "function";
    case "object":
      return typeof v === "object" && v !== null && !Array.isArray(v);
    case "array":
      return Array.isArray(v);
    case "any":
      return true;
  }
}
function _propertyResolveDomElement(host) {
  if (typeof HTMLElement === "undefined") return null;
  if (host instanceof HTMLElement) return host;
  const wrapper = host;
  if (wrapper.element instanceof HTMLElement) return wrapper.element;
  return null;
}
var Property = class {
  name;
  opts;
  _value;
  _hosts = /* @__PURE__ */ new Set();
  _eventTarget;
  _changingEvt;
  _changedEvt;
  _silent;
  constructor(name, options = {}) {
    this.name = name;
    this.opts = Object.freeze({ ...options });
    this._value = options.initial;
    this._silent = options.silent ?? false;
    const obs = options.observable ?? {};
    this._eventTarget = obs.target ?? new EventTarget();
    this._changingEvt = obs.changingEvent ?? `${name}Changing`;
    this._changedEvt = obs.changedEvent ?? `${name}Changed`;
  }
  /** Direct read of the current value. */
  get() {
    return this._value;
  }
  /**
   * Direct write through transform → type check → validate → changing event
   * → commit → sync → changed event. Returns true if applied, false if
   * rejected (by type/validator/listener preventDefault).
   */
  set(value) {
    const opts = this.opts;
    const old = this._value;
    let next = value;
    if (opts.transform) next = opts.transform(next);
    if (opts.type !== void 0 && !_propertyMatchesType(next, opts.type)) return false;
    if (opts.validate && !opts.validate(next)) return false;
    if (Object.is(old, next)) return true;
    if (!this._silent) {
      const detail = { name: this.name, oldValue: old, newValue: next };
      const cancelable = opts.observable?.cancelable ?? true;
      const ev = new CustomEvent(this._changingEvt, {
        detail,
        cancelable,
        bubbles: opts.observable?.propagation ?? false
      });
      const ok = this._eventTarget.dispatchEvent(ev);
      if (!ok && cancelable) return false;
      if (detail.override !== void 0) next = detail.override;
    }
    this._value = next;
    for (const host of this._hosts) this._sync(host, next);
    if (!this._silent) {
      const detail = {
        name: this.name,
        oldValue: old,
        newValue: next,
        bind: opts.bind,
        bound: opts.bound
      };
      const ev = new CustomEvent(this._changedEvt, {
        detail,
        cancelable: false,
        bubbles: opts.observable?.propagation ?? false
      });
      this._eventTarget.dispatchEvent(ev);
    }
    return true;
  }
  /**
   * Install this Property as a real getter/setter on `host` via
   * `Object.defineProperty`. Multiple hosts share the same value.
   * Returns `this` for chaining.
   */
  install(host) {
    const self = this;
    Object.defineProperty(host, this.name, {
      enumerable: this.opts.enumerable ?? true,
      configurable: this.opts.configurable ?? true,
      get() {
        return self._value;
      },
      set(v) {
        self.set(v);
      }
    });
    this._hosts.add(host);
    this._sync(host, this._value);
    return this;
  }
  /** Subscribe to the cancelable changing event. Chainable. */
  onChanging(cb) {
    this._eventTarget.addEventListener(this._changingEvt, ((ev) => {
      cb(ev.detail, ev);
    }));
    return this;
  }
  /** Subscribe to the post-set changed event. Chainable. */
  onChanged(cb) {
    this._eventTarget.addEventListener(this._changedEvt, ((ev) => {
      cb(ev.detail, ev);
    }));
    return this;
  }
  /** The internal EventTarget — for advanced subscription patterns. */
  get target() {
    return this._eventTarget;
  }
  _sync(host, value) {
    const dom = _propertyResolveDomElement(host);
    const apply = (spec) => {
      if (!spec) return;
      if (dom) {
        const attrs = [];
        if (spec.attribute) attrs.push(spec.attribute);
        if (spec.attributes) attrs.push(...spec.attributes);
        for (const a of attrs) {
          const str = value === null || value === void 0 ? "" : String(value);
          if (dom.getAttribute(a) !== str) dom.setAttribute(a, str);
        }
      }
      const props = [];
      if (spec.property) props.push(spec.property);
      if (spec.properties) props.push(...spec.properties);
      for (const p of props) {
        const cur = host[p];
        if (!Object.is(cur, value)) {
          host[p] = value;
        }
      }
    };
    apply(this.opts.bind);
    apply(this.opts.bound);
  }
};
var _coreApi;
function _buildCore() {
  return {
    version,
    Uuid: uuid,
    GetPrototypeChain,
    SetDescriptors,
    Scopes,
    Namespaces,
    RegisterNamespace,
    GetDescriptor,
    Define,
    Events,
    Observer,
    Property,
    // Helpers
    Is,
    Equals,
    Empty,
    Has,
    Clone,
    Assign,
    Replace,
    Extends,
    use,
    plugins,
    Root: typeof document !== "undefined" ? document.documentElement : null
  };
}
var Core = Object.freeze(_buildCore());
_coreApi = Core;
if (typeof window !== "undefined") {
  Object.defineProperty(window, "Core", {
    enumerable: true,
    configurable: false,
    writable: false,
    value: Core
  });
}
var Core_default = Core;

// core/Observable.ts
function uuid2() {
  const b = [];
  for (let i = 0; i < 9; i++)
    b.push(Math.floor(1 + Math.random() * 65536).toString(16).slice(1));
  return `${b[1]}${b[2]}-${b[3]}-${b[4]}-${b[5]}-${b[6]}${b[7]}${b[8]}`;
}
var _activeEffect = null;
var _batchDepth = 0;
var _pendingEffects = [];
function _notify(subs) {
  if (_batchDepth > 0) {
    subs.forEach((e) => {
      if (!_pendingEffects.includes(e)) _pendingEffects.push(e);
    });
    return;
  }
  [...subs].forEach((e) => e.run());
}
function signal(value) {
  const subs = /* @__PURE__ */ new Set();
  return {
    get() {
      if (_activeEffect) subs.add(_activeEffect);
      return value;
    },
    set(v) {
      if (Object.is(v, value)) return;
      value = v;
      _notify(subs);
    },
    peek() {
      return value;
    },
    readonly() {
      return { get: () => {
        if (_activeEffect) subs.add(_activeEffect);
        return value;
      }, peek: () => value };
    }
  };
}
function signalMono(value) {
  const s = {
    _sub: null,
    get() {
      return value;
    },
    set(v) {
      if (!Object.is(v, value)) {
        value = v;
        s._sub?.();
      }
    },
    peek() {
      return value;
    }
  };
  return s;
}
function sinkText(s, node) {
  node.nodeValue = s.peek();
  s._sub = () => {
    node.nodeValue = s.peek();
  };
}
function sinkClass(el, cls, getter) {
  const update = () => {
    if (getter()) el.classList.add(cls);
    else el.classList.remove(cls);
  };
  update();
  return update;
}
function effect(fn) {
  const runner = {
    deps: /* @__PURE__ */ new Set(),
    run() {
      runner.deps.forEach((d) => d.delete(runner));
      runner.deps.clear();
      const prev = _activeEffect;
      _activeEffect = runner;
      try {
        fn();
      } finally {
        _activeEffect = prev;
      }
    }
  };
  runner.run();
  return () => {
    runner.deps.forEach((d) => d.delete(runner));
    runner.deps.clear();
  };
}
function computed(fn) {
  const s = signal(void 0);
  effect(() => s.set(fn()));
  return s.readonly();
}
function batch(fn) {
  _batchDepth++;
  try {
    fn();
  } finally {
    if (--_batchDepth === 0) {
      const p = _pendingEffects.splice(0);
      p.forEach((e) => e.run());
    }
  }
}
function untrack(fn) {
  const prev = _activeEffect;
  _activeEffect = null;
  try {
    return fn();
  } finally {
    _activeEffect = prev;
  }
}
var AriannATemplate = class {
  #tpl;
  constructor(html) {
    this.#tpl = document.createElement("template");
    this.#tpl.innerHTML = html;
  }
  /**
   * Clona il primo elemento del template — O(1) in C++.
   * Zero HTML parsing. Zero allocazione JS oltre il nodo clonato.
   */
  clone() {
    return this.#tpl.content.firstElementChild.cloneNode(true);
  }
  /**
   * Clona l'intero content come DocumentFragment.
   * Per template con più elementi root.
   */
  cloneAll() {
    return this.#tpl.content.cloneNode(true);
  }
  /**
   * Accesso O(1) a un nodo interno tramite path di indici childNodes.
   * Evita querySelector — accesso diretto via childNodes[i] chain.
   *
   * @example
   *   const tr    = tpl.clone();
   *   const idTxt = tpl.walk(tr, [0, 0]) as Text;
   *   // tr.childNodes[0].childNodes[0]
   */
  walk(root, path) {
    let n = root;
    for (const i of path) n = n.childNodes[i];
    return n;
  }
  /**
   * Accesso O(1) a più nodi interni in una singola chiamata.
   * Restituisce array di nodi nell'ordine dei path forniti.
   *
   * @example
   *   const [idTxt, labelTxt] = tpl.walkAll(tr, [0,0], [1,0,0]);
   */
  walkAll(root, ...paths) {
    return paths.map((p) => this.walk(root, p));
  }
  /** Il DocumentFragment interno — read-only. */
  get content() {
    return this.#tpl.content;
  }
};
function _safeEventCtor(name, resolver) {
  try {
    const ctor = resolver();
    if (ctor) return ctor;
  } catch {
  }
  return { [name]: class extends Event {
  } }[name];
}
var _TouchEvent = _safeEventCtor("TouchEvent", () => typeof TouchEvent !== "undefined" ? TouchEvent : void 0);
var DOM_TYPES = Object.freeze(
  {
    click: { Name: "click", Interface: MouseEvent },
    dblclick: { Name: "dblclick", Interface: MouseEvent },
    mouseenter: { Name: "mouseenter", Interface: MouseEvent },
    mouseleave: { Name: "mouseleave", Interface: MouseEvent },
    mousemove: { Name: "mousemove", Interface: MouseEvent },
    mouseout: { Name: "mouseout", Interface: MouseEvent },
    mouseover: { Name: "mouseover", Interface: MouseEvent },
    mouseup: { Name: "mouseup", Interface: MouseEvent },
    mousedown: { Name: "mousedown", Interface: MouseEvent },
    contextmenu: { Name: "contextmenu", Interface: MouseEvent },
    drag: { Name: "drag", Interface: DragEvent },
    dragend: { Name: "dragend", Interface: DragEvent },
    dragenter: { Name: "dragenter", Interface: DragEvent },
    dragleave: { Name: "dragleave", Interface: DragEvent },
    dragover: { Name: "dragover", Interface: DragEvent },
    dragstart: { Name: "dragstart", Interface: DragEvent },
    drop: { Name: "drop", Interface: DragEvent },
    wheel: { Name: "wheel", Interface: WheelEvent },
    keypress: { Name: "keypress", Interface: KeyboardEvent },
    keydown: { Name: "keydown", Interface: KeyboardEvent },
    keyup: { Name: "keyup", Interface: KeyboardEvent },
    animationstart: { Name: "animationstart", Interface: AnimationEvent },
    animationend: { Name: "animationend", Interface: AnimationEvent },
    animationiteration: { Name: "animationiteration", Interface: AnimationEvent },
    abort: { Name: "abort", Interface: UIEvent },
    load: { Name: "load", Interface: UIEvent },
    resize: { Name: "resize", Interface: UIEvent },
    scroll: { Name: "scroll", Interface: UIEvent },
    select: { Name: "select", Interface: UIEvent },
    unload: { Name: "unload", Interface: UIEvent },
    focusin: { Name: "focusin", Interface: FocusEvent },
    focusout: { Name: "focusout", Interface: FocusEvent },
    focus: { Name: "focus", Interface: FocusEvent },
    blur: { Name: "blur", Interface: FocusEvent },
    cut: { Name: "cut", Interface: ClipboardEvent },
    copy: { Name: "copy", Interface: ClipboardEvent },
    paste: { Name: "paste", Interface: ClipboardEvent },
    compositionstart: { Name: "compositionstart", Interface: CompositionEvent },
    compositionend: { Name: "compositionend", Interface: CompositionEvent },
    change: { Name: "change", Interface: Event },
    input: { Name: "input", Interface: Event },
    submit: { Name: "submit", Interface: Event },
    reset: { Name: "reset", Interface: Event },
    DOMContentLoaded: { Name: "DOMContentLoaded", Interface: Event },
    message: { Name: "message", Interface: Event },
    online: { Name: "online", Interface: Event },
    offline: { Name: "offline", Interface: Event },
    popstate: { Name: "popstate", Interface: Event },
    hashchange: { Name: "hashchange", Interface: Event },
    beforeunload: { Name: "beforeunload", Interface: Event },
    touchstart: { Name: "touchstart", Interface: _TouchEvent },
    touchend: { Name: "touchend", Interface: _TouchEvent },
    touchmove: { Name: "touchmove", Interface: _TouchEvent },
    touchcancel: { Name: "touchcancel", Interface: _TouchEvent },
    pointerdown: { Name: "pointerdown", Interface: PointerEvent },
    pointerup: { Name: "pointerup", Interface: PointerEvent },
    pointermove: { Name: "pointermove", Interface: PointerEvent },
    pointercancel: { Name: "pointercancel", Interface: PointerEvent },
    pointerenter: { Name: "pointerenter", Interface: PointerEvent },
    pointerleave: { Name: "pointerleave", Interface: PointerEvent },
    transitionstart: { Name: "transitionstart", Interface: TransitionEvent },
    transitionend: { Name: "transitionend", Interface: TransitionEvent },
    transitioncancel: { Name: "transitioncancel", Interface: TransitionEvent }
  }
);
var DOM_INTERFACES = {};
for (const [name, desc] of Object.entries(DOM_TYPES)) {
  const iname = desc.Interface.name;
  if (!DOM_INTERFACES[iname]) DOM_INTERFACES[iname] = { Name: iname, Types: {} };
  DOM_INTERFACES[iname].Types[name] = desc;
}
var _globalListeners = /* @__PURE__ */ new Map();
function _toTargets(target) {
  if (typeof target === "string") return typeof document !== "undefined" ? Array.from(document.querySelectorAll(target)) : [];
  return Array.isArray(target) ? target : [target];
}
function _toTypes(types) {
  return types.split(/[\s,|]+/).filter(Boolean);
}
var _MUTATING_ARRAY = /* @__PURE__ */ new Set([
  "push",
  "pop",
  "shift",
  "unshift",
  "splice",
  "sort",
  "reverse",
  "fill",
  "copyWithin"
]);
var _MUTATING_MAP = /* @__PURE__ */ new Set(["set", "delete", "clear"]);
var _MUTATING_SET = /* @__PURE__ */ new Set(["add", "delete", "clear"]);
var _RAW = /* @__PURE__ */ Symbol("arianna.observable.raw");
function _isReactiveTarget(v) {
  if (v === null || typeof v !== "object") return false;
  if (Object.isFrozen(v) || Object.isSealed(v)) return false;
  return true;
}
function _makeReactive(root, emit) {
  const cache = /* @__PURE__ */ new WeakMap();
  function wrap(value, path) {
    if (!_isReactiveTarget(value)) return value;
    const cached = cache.get(value);
    if (cached) return cached;
    if (value instanceof Map || value instanceof WeakMap || value instanceof Set || value instanceof WeakSet) {
      const proxy = _wrapCollection(value, path, emit, wrap);
      cache.set(value, proxy);
      return proxy;
    }
    if (Array.isArray(value)) {
      const proxy = _wrapArray(value, path, emit, wrap);
      cache.set(value, proxy);
      return proxy;
    }
    _installObjectTraps(value, path, emit, wrap);
    cache.set(value, value);
    return value;
  }
  return wrap(root, []);
}
function _wrapArray(arr, path, emit, wrap) {
  for (let i = 0; i < arr.length; i++) {
    const w = wrap(arr[i], [...path, String(i)]);
    if (w !== arr[i]) arr[i] = w;
  }
  return new Proxy(arr, {
    get(target, key) {
      if (key === _RAW) return target;
      const v = target[key];
      if (typeof key === "string" && _MUTATING_ARRAY.has(key) && typeof v === "function") {
        return function(...args) {
          const before = target.slice();
          const result = v.apply(target, args);
          emit([...path], target, key, before, target.slice(), "mutate");
          for (let i = 0; i < target.length; i++) {
            const w = wrap(target[i], [...path, String(i)]);
            if (w !== target[i]) target[i] = w;
          }
          return result;
        };
      }
      return v;
    },
    set(target, key, value) {
      if (key === "length") {
        const old2 = target.length;
        if (Object.is(old2, value)) return true;
        if (!emit([...path], target, key, old2, value, "set")) return false;
        target.length = value;
        return true;
      }
      const old = target[key];
      if (Object.is(old, value)) return true;
      if (!emit([...path], target, key, old, value, "set")) return false;
      const wrapped = wrap(value, [...path, key]);
      target[key] = wrapped;
      return true;
    },
    deleteProperty(target, key) {
      if (!(key in target)) return true;
      const old = target[key];
      if (!emit([...path], target, key, old, void 0, "delete")) return false;
      delete target[key];
      return true;
    }
  });
}
function _wrapCollection(coll, path, emit, wrap) {
  const isMap = coll instanceof Map || coll instanceof WeakMap;
  const mutating = isMap ? _MUTATING_MAP : _MUTATING_SET;
  return new Proxy(coll, {
    get(target, key) {
      if (key === _RAW) return target;
      const v = Reflect.get(target, key);
      if (typeof v !== "function") return v;
      if (typeof key === "string" && mutating.has(key)) {
        return function(...args) {
          const before = isMap ? new Map(target instanceof Map ? target.entries() : []) : new Set(target instanceof Set ? target.values() : []);
          if (isMap && key === "set" && args.length === 2) {
            args[1] = wrap(args[1], [...path, "<map-value>"]);
          } else if (!isMap && key === "add" && args.length === 1) {
            args[0] = wrap(args[0], [...path, "<set-value>"]);
          }
          const result = v.apply(target, args);
          emit([...path], target, key, before, void 0, "mutate");
          return result;
        };
      }
      return v.bind(target);
    }
  });
}
function _installObjectTraps(obj, path, emit, wrap) {
  for (const key of Object.keys(obj)) {
    const desc = Object.getOwnPropertyDescriptor(obj, key);
    if (!desc || !desc.configurable) continue;
    if (desc.get || desc.set) continue;
    let value = wrap(obj[key], [...path, key]);
    Object.defineProperty(obj, key, {
      enumerable: true,
      configurable: true,
      get() {
        return value;
      },
      set(next) {
        if (Object.is(value, next)) return;
        const old = value;
        if (!emit([...path], obj, key, old, next, "set")) return;
        value = wrap(next, [...path, key]);
      }
    });
  }
}
var Observable = class _Observable {
  #events = /* @__PURE__ */ new Map();
  #target;
  #effects = [];
  #opts;
  #history = [];
  #reactive;
  /**
   * Wraps `value` (or `this`) into a reactive observer.
   *
   * - Pass an object/array/Map/Set: it becomes deep-reactive. Read it via
   *   `obs.value`. All assignments emit 'change-before' (cancelable) and
   *   'change-after' on the instance, plus '<key>-change-before' /
   *   '<key>-change-after' scoped events.
   * - Pass nothing: behaves as the legacy event bus on `this`.
   */
  constructor(value, options = {}) {
    this.#opts = options;
    if (value !== void 0 && value !== null && typeof value === "object") {
      this.#target = value;
      this.#reactive = _makeReactive(value, (path, target, key, old, nw, kind) => this.#emit(path, target, key, old, nw, kind));
    } else {
      this.#target = this;
      this.#reactive = void 0;
    }
  }
  /**
   * The reactive view of the wrapped value. Mutations through this
   * proxy fire 'change-before' / 'change-after' on this Observable.
   */
  get value() {
    return this.#reactive ?? this.#target;
  }
  /**
   * Reverts the most recent change recorded in the history stack.
   * No-op if history is disabled or empty. Does not fire change events
   * on undo (silent).
   */
  undo() {
    const entry = this.#history.pop();
    if (!entry) return false;
    const t = entry.target;
    if (entry.kind === "set" || entry.kind === "mutate") t[entry.key] = entry.old;
    else if (entry.kind === "delete") t[entry.key] = entry.old;
    return true;
  }
  /** Number of recorded entries in the history stack. */
  get historyLength() {
    return this.#history.length;
  }
  /**
   * Internal: fired by the reactive Proxy/setter layer. Emits the
   * 4-event pattern (change-before, <key>-change-before, change-after,
   * <key>-change-after) and records to history if enabled.
   * Returns false if any 'change-before' listener cancels the event.
   */
  #emit(path, target, key, old, nw, kind) {
    const keyStr = typeof key === "symbol" ? key.description ?? "" : String(key);
    const evBefore = {
      Type: "change-before",
      Target: target,
      Key: key,
      Path: [...path, key],
      Old: old,
      New: nw,
      Kind: kind
    };
    let cancelled = false;
    for (const l of this.#events.get("change-before") ?? []) {
      const before = evBefore.New;
      l.Handler.call(l.Target, evBefore);
      if (evBefore.Cancelled) cancelled = true;
      if (evBefore.New !== before) {
      }
    }
    if (keyStr) for (const l of this.#events.get(`${keyStr}-change-before`) ?? []) {
      const ev = { ...evBefore, Type: `${keyStr}-change-before` };
      l.Handler.call(l.Target, ev);
      if (ev.Cancelled) cancelled = true;
    }
    if (cancelled) return false;
    if (this.#opts.history) {
      this.#history.push({ path, target, key, old, nw: evBefore.New, kind });
      const limit = this.#opts.historyLimit ?? 100;
      if (this.#history.length > limit) this.#history.shift();
    }
    const evAfter = {
      Type: "change-after",
      Target: target,
      Key: key,
      Path: [...path, key],
      Old: old,
      New: evBefore.New,
      Kind: kind
    };
    for (const l of this.#events.get("change-after") ?? [])
      l.Handler.call(l.Target, evAfter);
    if (keyStr) for (const l of this.#events.get(`${keyStr}-change-after`) ?? [])
      l.Handler.call(l.Target, { ...evAfter, Type: `${keyStr}-change-after` });
    return true;
  }
  // ── Instance Signal API ───────────────────────────────────────────────────
  signal(value) {
    return signal(value);
  }
  signalMono(value) {
    return signalMono(value);
  }
  effect(fn) {
    this.#effects.push(effect(fn));
    return this;
  }
  computed(fn) {
    const s = signal(void 0);
    this.#effects.push(effect(() => s.set(fn())));
    return s.readonly();
  }
  // ── Instance pub/sub ──────────────────────────────────────────────────────
  on(types, cb) {
    const ls = { Id: uuid2(), Handler: cb, Target: this.#target };
    types.split(/(?!-)\W/g).filter(Boolean).forEach((t) => {
      const b = this.#events.get(t) ?? /* @__PURE__ */ new Set();
      b.add(ls);
      this.#events.set(t, b);
    });
    return this;
  }
  off(type, cb) {
    this.#events.get(type)?.forEach((l) => l.Handler === cb && this.#events.get(type).delete(l));
    return this;
  }
  fire(event) {
    if (!event?.Type) return this;
    this.#events.get(event.Type)?.forEach((l) => l.Handler.call(l.Target, event));
    return this;
  }
  once(event, cb) {
    const w = (e) => {
      cb(e);
      this.off(event.Type, w);
    };
    return this.on(event.Type, w);
  }
  all(event) {
    return this.fire(event);
  }
  destroy() {
    this.#effects.forEach((s) => s());
    this.#effects.length = 0;
    this.#events.clear();
    return this;
  }
  // ── Static DOM bus ────────────────────────────────────────────────────────
  static On(target, types, handler, opts) {
    const ids = [];
    const addOpts = { passive: opts?.Passive, capture: opts?.Capture ?? opts?.Phase === "capture", once: opts?.Once, signal: opts?.Signal };
    for (const t of _toTargets(target)) for (const type of _toTypes(types)) {
      const id = uuid2();
      t.addEventListener(type, handler, addOpts);
      _globalListeners.set(id, { UUID: id, Type: type, Target: t, Function: handler, Propagation: addOpts.capture ? "capture" : "bubble", XML: "" });
      ids.push(id);
    }
    return ids;
  }
  static Off(target, types, handler, opts) {
    for (const t of _toTargets(target)) for (const type of _toTypes(types)) t.removeEventListener(type, handler, { capture: opts?.Capture ?? opts?.Phase === "capture" });
  }
  static Fire(target, type, init, detail) {
    const ev = detail !== void 0 ? new CustomEvent(type, { ...init, ...detail }) : new Event(type, init);
    _toTargets(target).forEach((t) => t.dispatchEvent(ev));
  }
  static Once(target, types, handler, opts) {
    return _Observable.On(target, types, handler, { ...opts, Once: true });
  }
  static Trigger(target, type) {
    _Observable.Fire(target, type);
  }
  static All = _Observable.On;
  static get Listeners() {
    return _globalListeners;
  }
  static GetListener(id) {
    return _globalListeners.get(id);
  }
  static GetListeners(target, type) {
    return [..._globalListeners.values()].filter((r) => r.Target === target && (type === void 0 || r.Type === type));
  }
  static Dom = { Types: DOM_TYPES, Interfaces: DOM_INTERFACES };
  static GetInterface(eventType) {
    return DOM_TYPES[eventType]?.Interface?.name;
  }
  static GetTypes(interfaceName) {
    return Object.keys(DOM_INTERFACES[interfaceName]?.Types ?? {});
  }
  // ── Static Signal + Template shorthands ───────────────────────────────────
  static signal = signal;
  static signalMono = signalMono;
  static sinkText = sinkText;
  static sinkClass = sinkClass;
  static effect = effect;
  static computed = computed;
  static batch = batch;
  static untrack = untrack;
  /**
   * Crea un AriannATemplate — parse HTML una volta, clone O(1) N volte.
   * @example
   *   const tpl = Observable.template('<tr><td></td></tr>');
   *   const tr  = tpl.clone();
   */
  static template(html) {
    return new AriannATemplate(html);
  }
};
if (typeof window !== "undefined" && !Object.prototype.hasOwnProperty.call(window, "Observable")) {
  try {
    Object.defineProperty(window, "Observable", { enumerable: true, configurable: false, writable: false, value: Observable });
  } catch {
  }
}
var Observable_default = Observable;

// core/State.ts
var COLLECTION_MUTATORS = /* @__PURE__ */ new Set(["set", "add", "delete", "clear", "push", "pop", "shift", "unshift", "splice", "fill", "sort", "reverse", "copyWithin"]);
var State = class {
  #events = /* @__PURE__ */ new Map();
  #states = /* @__PURE__ */ new Map();
  #history = [];
  #source;
  #state;
  // ── Static fine-grain API ─────────────────────────────────────────────────
  static signal = signal;
  static signalMono = signalMono;
  static sinkText = sinkText;
  static effect = effect;
  static computed = computed;
  static batch = batch;
  static untrack = untrack;
  constructor(source) {
    this.#source = source;
    this.#state = this.#load(source);
    this.#history.push({ key: "__init__", old: void 0, new: source, ts: Date.now() });
    Object.defineProperty(this, "State", { enumerable: true, configurable: false, get: () => this.#state, set: (v) => {
      if (v && typeof v === "object") {
        this.#source = v;
        this.#state = this.#load(v);
      }
    } });
    Object.defineProperty(this, "States", { enumerable: true, configurable: false, get: () => this.#states });
    Object.defineProperty(this, "History", { enumerable: true, configurable: false, get: () => this.#history });
  }
  on(types, cb) {
    const ls = { Id: uuid2(), Handler: cb, Target: this };
    types.split(/(?!-)\W/g).filter(Boolean).forEach((t) => {
      const b = this.#events.get(t) ?? /* @__PURE__ */ new Set();
      b.add(ls);
      this.#events.set(t, b);
    });
    return this;
  }
  off(type, cb) {
    this.#events.get(type)?.forEach((l) => l.Handler === cb && this.#events.get(type).delete(l));
    return this;
  }
  fire(event) {
    if (!event?.Type) return this;
    this.#events.get(event.Type)?.forEach((l) => l.Handler.call(l.Target, event));
    return this;
  }
  match(types, cb) {
    return this.on(types, cb);
  }
  addState(name, snapshot) {
    this.#states.set(name, snapshot);
    return this;
  }
  removeState(name) {
    this.#states.delete(name);
    return this;
  }
  #emit(key, old, newVal, target) {
    const k = String(key);
    const ev = { Type: "", Target: target, State: this, Property: { Name: key, Old: old, New: newVal } };
    const fire = (type) => {
      ev.Type = type;
      this.fire(ev);
    };
    fire("State-Changing");
    fire(`State-${k}-Changing`);
    fire(`State-${k}-Changed`);
    fire("State-Changed");
    this.#history.push({ key, old, new: newVal, ts: Date.now() });
    if (this.#states.size) this.#states.forEach((snap) => {
      if (snap[k] === newVal) {
        const se = { ...ev };
        se.Type = "State-Reached";
        this.fire(se);
        se.Type = `State-${k}-Reached`;
        this.fire(se);
      }
    });
  }
  #proxyHandler(parent) {
    const self = this;
    return {
      get(target, key, recv) {
        const val = Reflect.get(target, key, recv);
        if (typeof val === "function" && COLLECTION_MUTATORS.has(String(key).toLowerCase()))
          return function(...args) {
            const old = Array.isArray(target) ? [...target] : void 0;
            self.#emit(key, old, args[0], target);
            return val.apply(target, args);
          };
        return val;
      },
      set(target, key, value, recv) {
        const old = target[key];
        if (old === value) return true;
        Reflect.set(target, key, value, recv);
        self.#emit(key, old, value, target);
        return true;
      }
    };
  }
  #load(source) {
    const s = { ...source };
    const wrap = (o) => {
      for (const k of Object.keys(o)) {
        let v = o[k];
        Object.defineProperty(o, k, {
          enumerable: true,
          configurable: true,
          get: () => v,
          set: (V) => {
            if (v === V) return;
            const old = v;
            v = V;
            this.#emit(k, old, V, o);
            if (V && typeof V === "object" && !(V instanceof Map) && !(V instanceof Set) && !(V instanceof WeakMap) && !(V instanceof WeakSet) && !Array.isArray(V))
              v = wrap(V);
          }
        });
        if (v && typeof v === "object") {
          if (v instanceof Map || v instanceof WeakMap || v instanceof Set || v instanceof WeakSet || Array.isArray(v))
            o[k] = v = new Proxy(v, this.#proxyHandler(o));
          else o[k] = v = wrap(v);
        }
      }
      return o;
    };
    return wrap(s);
  }
};
if (typeof window !== "undefined")
  Object.defineProperty(window, "State", { enumerable: true, configurable: false, writable: false, value: State });
var State_default = State;

// core/Rule.ts
var PAGE_MARGIN_BOXES = /* @__PURE__ */ new Set([
  "TopLeftCorner",
  "TopLeft",
  "TopCenter",
  "TopRight",
  "TopRightCorner",
  "BottomLeftCorner",
  "BottomLeft",
  "BottomCenter",
  "BottomRight",
  "BottomRightCorner",
  "LeftTop",
  "LeftMiddle",
  "LeftBottom",
  "RightTop",
  "RightMiddle",
  "RightBottom"
]);
function toKebab(s) {
  return s.replace(/([A-Z])/g, (c) => `-${c.toLowerCase()}`);
}
function toCamel(s) {
  const lc = s.charAt(0).toLowerCase() + s.slice(1);
  return lc.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
}
function trimVal(v) {
  return v.trim().replace(/;$/, "");
}
function parseDeclarations(text) {
  const props = {};
  text.split(";").forEach((decl) => {
    const colon = decl.indexOf(":");
    if (colon < 0) return;
    const key = toCamel(decl.slice(0, colon).trim());
    const val = trimVal(decl.slice(colon + 1));
    if (key && val) props[key] = val;
  });
  return props;
}
function serializeDeclarations(props) {
  return Object.entries(props).map(([k, v]) => `${toKebab(k)}: ${v}`).join("; ");
}
function normaliseProps(raw) {
  const out = {};
  for (const [k, v] of Object.entries(raw))
    out[toCamel(k)] = String(v).trim();
  return out;
}
function buildMediaCondition(obj) {
  const parts = [];
  for (const [k, v] of Object.entries(obj)) {
    const lk = k.toLowerCase();
    if (lk === "or") {
      parts.push(`, ${buildMediaCondition(v)}`);
    } else if (lk === "and") {
      parts.push(` and ${buildMediaCondition(v)}`);
    } else if (lk === "not") {
      parts.push(` not (${buildMediaCondition(v)})`);
    } else {
      const prop = toKebab(k).toLowerCase();
      parts.push(`(${prop}: ${v})`);
    }
  }
  return parts.join("");
}
function buildSelector(sel) {
  const type = sel.Type.toLowerCase().trim();
  if (type === "@charset")
    return `@charset "${(sel.Value ?? "UTF-8").replace(/["']/g, "")}"`;
  if (type === "@namespace") {
    const prefix = sel.Prefix ? `${sel.Prefix} ` : "";
    return `@namespace ${prefix}${sel.Url ?? ""}`;
  }
  if (type === "@import") {
    const url = sel.Url ?? "";
    const media = sel.Media ? ` ${sel.Media}` : "";
    const cond = sel.And ? buildMediaCondition(sel.And) : "";
    return `@import ${url}${media}${cond}`;
  }
  if (type === "@media") {
    const media = sel.Media ? ` ${sel.Media}` : "";
    const cond = sel.And ? buildMediaCondition(sel.And) : "";
    return `@media${media}${cond}`;
  }
  if (type === "@supports") {
    const parts = [];
    if (sel.Not)
      parts.push(`not (${buildMediaCondition(sel.Not)})`);
    for (const [k, v] of Object.entries(sel)) {
      const lk = k.toLowerCase();
      if (["type", "not"].includes(lk)) continue;
      if (lk === "or")
        parts.push(`, ${buildMediaCondition(v)}`);
      else if (lk === "and")
        parts.push(` and ${buildMediaCondition(v)}`);
      else
        parts.push(`(${toKebab(k).toLowerCase()}: ${v})`);
    }
    return `@supports ${parts.join(" ")}`;
  }
  if (type === "@document") {
    const conditions = [];
    if (sel.Url) conditions.push(`url("${sel.Url}")`);
    if (sel.Prefix) conditions.push(`url-prefix("${sel.Prefix}")`);
    if (sel.Domain) conditions.push(`domain("${sel.Domain}")`);
    if (sel.Regex) conditions.push(`regexp("${sel.Regex}")`);
    return `@document ${conditions.join(", ")}`;
  }
  if (type === "@page") {
    const name = sel.Name ? ` ${sel.Name}` : "";
    const right = sel.Right ? " :right" : "";
    const left = sel.Left ? " :left" : "";
    return `@page${name}${right}${left}`;
  }
  if (type === "@keyframes")
    return `@keyframes ${sel.Name ?? ""}`;
  if (type === "@counter-style")
    return `@counter-style ${sel.Name ?? ""}`;
  if (type === "@font-face") return "@font-face";
  if (type === "@viewport") return "@viewport";
  return sel.Type;
}
function buildKeyframesText(name, contents) {
  const frames = [];
  for (const [key, val] of Object.entries(contents)) {
    const lk = key.toLowerCase();
    let position;
    let style;
    if (lk === "from") {
      position = "from";
      style = normaliseProps(val);
    } else if (lk === "to") {
      position = "to";
      style = normaliseProps(val);
    } else {
      const frame = val;
      position = frame.Position ?? key;
      style = frame.Style ? normaliseProps(frame.Style) : {};
    }
    const decls = serializeDeclarations(style);
    frames.push(`  ${position} { ${decls}${decls ? ";" : ""} }`);
  }
  return `@keyframes ${name} {
${frames.join("\n")}
}`;
}
function buildPageText(selector, contents) {
  const mainDecls = {};
  const marginBoxes = [];
  for (const [k, v] of Object.entries(contents)) {
    if (PAGE_MARGIN_BOXES.has(k)) {
      const boxSelector = toKebab(k).toLowerCase();
      const props = normaliseProps(v);
      const decls = serializeDeclarations(props);
      marginBoxes.push(`  @${boxSelector} { ${decls}${decls ? ";" : ""} }`);
    } else {
      mainDecls[toCamel(k)] = String(v).trim();
    }
  }
  const main = serializeDeclarations(mainDecls);
  const inner = [
    main ? `  ${main};` : "",
    ...marginBoxes
  ].filter(Boolean).join("\n");
  return `${selector} {
${inner}
}`;
}
var Rule = class _Rule {
  #id;
  #selector;
  #properties;
  #children = [];
  #rawContents = null;
  #selectorObj = null;
  #events = /* @__PURE__ */ new Map();
  constructor(arg0, arg1) {
    this.#id = uuid2();
    if (arg0 instanceof CSSRule) {
      const text = arg0.cssText;
      const m = /^([^{]+)\{([\s\S]*)\}/.exec(text);
      this.#selector = m?.[1]?.trim() ?? "";
      this.#properties = parseDeclarations(m?.[2] ?? "");
    } else if (typeof arg0 === "string") {
      this.#selector = arg0;
      if (!arg1) this.#properties = {};
      else if (typeof arg1 === "string") this.#properties = parseDeclarations(arg1);
      else this.#properties = normaliseProps(arg1);
    } else {
      const def = arg0;
      const rawSel = def.Selector;
      if (rawSel && typeof rawSel === "object") {
        this.#selectorObj = rawSel;
        this.#selector = buildSelector(this.#selectorObj);
      } else {
        this.#selector = rawSel ?? "";
      }
      const body = def.Contents ?? def.Content ?? def.Body ?? def.Rule ?? {};
      if (typeof body === "string") {
        this.#properties = parseDeclarations(body);
      } else {
        const bodyObj = body;
        const type = this.#selectorObj?.Type?.toLowerCase() ?? "";
        if (type === "@keyframes") {
          this.#rawContents = bodyObj;
          this.#properties = {};
        } else if (type === "@page") {
          this.#rawContents = bodyObj;
          this.#properties = {};
        } else {
          this.#properties = normaliseProps(bodyObj);
        }
      }
      if (def.Rules)
        this.#children = Object.values(def.Rules).map((d) => new _Rule(d));
    }
    this.#properties ??= {};
  }
  // ── Identity ──────────────────────────────────────────────────────────────
  get Id() {
    return this.#id;
  }
  // ── Selector ──────────────────────────────────────────────────────────────
  get Selector() {
    return this.#selector;
  }
  set Selector(v) {
    const old = this.#selector;
    this.#selector = v;
    this.#emit("Selector", old, v);
  }
  // ── Type (convenience getter) ─────────────────────────────────────────────
  /** The @-rule keyword, e.g. '@media', '@keyframes', or '' for style rules. */
  get Type() {
    const m = /^(@[\w-]+)/.exec(this.#selector.trim());
    return m?.[1] ?? "";
  }
  // ── Children ──────────────────────────────────────────────────────────────
  /** Nested child Rules (for @media, @supports, @document, @import). */
  get Children() {
    return [...this.#children];
  }
  set Children(v) {
    this.#children = v;
  }
  // ── Properties ───────────────────────────────────────────────────────────
  get Properties() {
    return { ...this.#properties };
  }
  get(name) {
    return this.#properties[toCamel(name)];
  }
  set(name, value) {
    const key = toCamel(name);
    const old = this.#properties[key];
    if (old === value) return this;
    this.#properties[key] = trimVal(value);
    this.#emit(key, old, value);
    return this;
  }
  remove(name) {
    const key = toCamel(name);
    const old = this.#properties[key];
    if (old === void 0) return this;
    delete this.#properties[key];
    this.#emit(key, old, void 0);
    return this;
  }
  merge(props) {
    for (const [k, v] of Object.entries(props)) this.set(k, v);
    return this;
  }
  replace(props) {
    const old = { ...this.#properties };
    this.#properties = typeof props === "string" ? parseDeclarations(props) : normaliseProps(props);
    this.#emit("*", old, this.#properties);
    return this;
  }
  has(name) {
    return toCamel(name) in this.#properties;
  }
  // ── Serialization ─────────────────────────────────────────────────────────
  /**
   * Full CSS rule text ready to insert into a stylesheet.
   * Handles: standard rules, @keyframes with frames, @page with margin-boxes,
   * nested rules (@media/@supports/@document/@import with child rules).
   */
  get Text() {
    const type = this.Type.toLowerCase();
    if (type === "@charset" || type === "@namespace")
      return `${this.#selector};`;
    if (type === "@keyframes" && this.#rawContents) {
      const name = this.#selectorObj?.Name ?? this.#selector.replace("@keyframes", "").trim();
      return buildKeyframesText(name, this.#rawContents);
    }
    if (type === "@page" && this.#rawContents)
      return buildPageText(this.#selector, this.#rawContents);
    if (this.#children.length > 0) {
      const inner = this.#children.map((c) => "  " + c.Text.replace(/\n/g, "\n  ")).join("\n");
      return `${this.#selector} {
${inner}
}`;
    }
    const decls = serializeDeclarations(this.#properties);
    return `${this.#selector} { ${decls}${decls ? ";" : ""} }`;
  }
  get cssText() {
    return this.Text;
  }
  toString() {
    return this.Text;
  }
  // ── Pub/sub ───────────────────────────────────────────────────────────────
  on(types, cb) {
    types.split(/\s+|,|\|/g).filter(Boolean).forEach((t) => {
      const b = this.#events.get(t) ?? /* @__PURE__ */ new Set();
      b.add(cb);
      this.#events.set(t, b);
    });
    return this;
  }
  off(type, cb) {
    this.#events.get(type)?.forEach((l) => l === cb && this.#events.get(type).delete(l));
    return this;
  }
  fire(event) {
    if (!event?.Type) return this;
    this.#events.get(event.Type)?.forEach((l) => l(event));
    return this;
  }
  #emit(name, old, nv) {
    const ev = {
      Type: `Rule-${name}-Changed`,
      Rule: this,
      Property: { Name: name, Old: old, New: nv }
    };
    this.fire(ev);
    ev.Type = "Rule-Changed";
    this.fire(ev);
  }
  // ── Comparison ────────────────────────────────────────────────────────────
  matches(other) {
    if (typeof other === "string") return this.#selector.trim() === other.trim();
    if (other instanceof CSSRule) return this.#selector.trim() === other.selectorText?.trim();
    return this.#selector.trim() === other.Selector.trim();
  }
  clone() {
    const r = new _Rule(this.#selector, { ...this.#properties });
    r.#children = this.#children.map((c) => c.clone());
    r.#rawContents = this.#rawContents ? { ...this.#rawContents } : null;
    r.#selectorObj = this.#selectorObj ? { ...this.#selectorObj } : null;
    return r;
  }
  // ── Static helpers ────────────────────────────────────────────────────────
  /**
   * Parse a CSS text string into Rule instances via browser parser.
   */
  static Parse(text) {
    const style = document.createElement("style");
    style.textContent = text;
    document.head.appendChild(style);
    const rules = Array.from(style.sheet?.cssRules ?? []).map((r) => new _Rule(r));
    document.head.removeChild(style);
    return rules;
  }
  static From(cssRule) {
    return new _Rule(cssRule);
  }
  // ── Golem static API ──────────────────────────────────────────────────────
  /**
   * Return the selector string from a RuleDefinition.
   * Mirrors Golem's Css.GetSelector().
   *
   * @example
   *   Rule.GetSelector({ Selector: { Type: '@media', Media: 'screen' } })
   *   // '@media screen'
   */
  static GetSelector(def) {
    const sel = def.Selector;
    if (!sel) return "";
    if (typeof sel === "string") return sel;
    return buildSelector(sel);
  }
  /**
   * Return the @-rule type keyword from a RuleDefinition.
   * Mirrors Golem's Css.GetType().
   *
   * @example
   *   Rule.GetType({ Selector: { Type: '@keyframes', Name: 'spin' } })
   *   // '@keyframes'
   */
  static GetType(def) {
    const sel = def.Selector;
    if (!sel) return "";
    if (typeof sel === "string") {
      const m = /^(@[\w-]+)/.exec(sel.trim());
      return m?.[1] ?? "";
    }
    return sel.Type ?? "";
  }
  /**
   * Return the contents/properties object from a RuleDefinition.
   * Mirrors Golem's Css.GetContents().
   */
  static GetContents(def) {
    const body = def.Contents ?? def.Content ?? def.Body ?? def.Rule ?? {};
    if (typeof body === "string") return parseDeclarations(body);
    return body;
  }
  /**
   * Serialize a RuleDefinition to its CSS text string.
   * Mirrors Golem's Css.GetText().
   */
  static GetText(def) {
    return new _Rule(def).Text;
  }
  /**
   * Parse a CSS text string into a structured JS object.
   * Mirrors Golem's Css.GetObject().
   *
   * Returns an object keyed by selector with contents as nested objects.
   *
   * @example
   *   Rule.GetObject('@media screen { .btn { color: red } }')
   *   // { '@media screen': { '.btn': { color: 'red' } } }
   *
   *   Rule.GetObject('@keyframes spin { from { transform: rotate(0) } }')
   *   // { '@keyframes spin': { from: { transform: 'rotate(0)' } } }
   */
  static GetObject(cssText) {
    if (!cssText?.trim()) return {};
    const result = {};
    const style = document.createElement("style");
    style.textContent = cssText;
    document.head.appendChild(style);
    try {
      const rules = Array.from(style.sheet?.cssRules ?? []);
      for (const rule of rules) {
        if (rule instanceof CSSStyleRule) {
          const decls = {};
          for (let i = 0; i < rule.style.length; i++) {
            const p = rule.style[i] ?? "";
            if (p) decls[toCamel(p)] = rule.style.getPropertyValue(p).trim();
          }
          result[rule.selectorText] = decls;
        } else if (rule instanceof CSSKeyframesRule) {
          const frames = {};
          Array.from(rule.cssRules).forEach((fr) => {
            const kf = fr;
            const decls = {};
            for (let i = 0; i < kf.style.length; i++) {
              const p = kf.style[i] ?? "";
              if (p) decls[toCamel(p)] = kf.style.getPropertyValue(p).trim();
            }
            frames[kf.keyText] = decls;
          });
          result[`@keyframes ${rule.name}`] = frames;
        } else if (rule instanceof CSSMediaRule) {
          const inner = {};
          Array.from(rule.cssRules).forEach((r) => {
            if (r instanceof CSSStyleRule) {
              const d = {};
              for (let i = 0; i < r.style.length; i++) {
                const p = r.style[i] ?? "";
                if (p) d[toCamel(p)] = r.style.getPropertyValue(p).trim();
              }
              inner[r.selectorText] = d;
            }
          });
          const mediaKey = rule.conditionText ? `@media ${rule.conditionText}` : (rule.cssText.split("{")[0] ?? "").trim();
          result[mediaKey] = inner;
        } else if (rule instanceof CSSSupportsRule) {
          const inner = {};
          Array.from(rule.cssRules).forEach((r) => {
            const obj = _Rule.GetObject(r.cssText);
            Object.assign(inner, obj);
          });
          result[`@supports ${rule.conditionText}`] = inner;
        } else if (rule instanceof CSSFontFaceRule) {
          const d = {};
          for (let i = 0; i < rule.style.length; i++) {
            const p = rule.style[i] ?? "";
            if (p) d[toCamel(p)] = rule.style.getPropertyValue(p).trim();
          }
          result["@font-face"] = d;
        } else if (rule instanceof CSSImportRule) {
          result[`@import ${rule.href}`] = { href: rule.href, media: rule.media?.mediaText ?? "" };
        } else if (rule instanceof CSSNamespaceRule) {
          result["@namespace"] = { prefix: rule.prefix, namespaceURI: rule.namespaceURI };
        } else if (rule instanceof CSSPageRule) {
          const d = {};
          for (let i = 0; i < rule.style.length; i++) {
            const p = rule.style[i] ?? "";
            if (p) d[toCamel(p)] = rule.style.getPropertyValue(p).trim();
          }
          result[`@page ${rule.selectorText}`.trim()] = d;
        } else {
          const m = /^([^{]+)\{([\s\S]*)\}/.exec(rule.cssText);
          if (m) {
            const key = m[1]?.trim();
            const val = m[2];
            if (key && val !== void 0) result[key] = parseDeclarations(val);
          }
        }
      }
    } finally {
      document.head.removeChild(style);
    }
    return result;
  }
};
var CssState = class {
  #element;
  #eventName;
  #baseRule;
  #stateProps;
  #keyframes = null;
  action;
  constructor(element, eventName, baseRule, stateProps, action, keyframeSelector, keyframeContents) {
    this.#element = element;
    this.#eventName = eventName.toLowerCase().replace(/^mouse/, "mouse");
    this.#baseRule = baseRule;
    this.#stateProps = normaliseProps(stateProps);
    this.action = action ?? null;
    if (keyframeSelector && keyframeContents) {
      const name = keyframeSelector.replace(/@[Kk]eyframes\s+/, "").trim();
      this.#keyframes = new Rule({
        Selector: { Type: "@keyframes", Name: name },
        Contents: keyframeContents
      });
      const style = document.createElement("style");
      style.textContent = this.#keyframes.Text;
      document.head.appendChild(style);
    }
    const domEvent = this.#mapEvent(eventName);
    element.addEventListener(domEvent, (e) => {
      this.#baseRule.merge(this.#stateProps);
      this.action?.(e);
    });
  }
  #mapEvent(name) {
    const map = {
      "mousedown": "mousedown",
      "mouseup": "mouseup",
      "mouseout": "mouseout",
      "mouseover": "mouseover",
      "mousemove": "mousemove",
      "mouseenter": "mouseenter",
      "mouseleave": "mouseleave",
      "click": "click",
      "focus": "focus",
      "blur": "blur"
    };
    return map[name.toLowerCase()] ?? name.toLowerCase();
  }
  get Keyframes() {
    return this.#keyframes;
  }
};
if (typeof window !== "undefined") {
  Object.defineProperty(window, "Rule", {
    enumerable: true,
    configurable: false,
    writable: false,
    value: Rule
  });
  const CssNamespace = {
    GetSelector: (def) => Rule.GetSelector(def),
    GetType: (def) => Rule.GetType(def),
    GetContents: (def) => Rule.GetContents(def),
    GetText: (def) => Rule.GetText(def),
    GetObject: (cssText) => Rule.GetObject(cssText),
    State: CssState
  };
  if (!("Css" in window))
    Object.defineProperty(window, "Css", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: CssNamespace
    });
}
var Rule_default = Rule;

// core/Stylesheet.ts
function toCamel2(s) {
  return s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
}
function parseLess(source) {
  const lines = source.replace(/\/\/[^\n]*/g, "").split("\n");
  const vars = {};
  const cleanLines = lines.map((line) => {
    const m = /^\s*[@$]([\w-]+)\s*[:=]\s*(.+)$/.exec(line ?? "");
    if (m && m[1] && m[2]) {
      vars[m[1]] = m[2].trim();
      return null;
    }
    return line;
  }).filter((l) => l !== null);
  const substituted = cleanLines.map((line) => {
    return line.replace(/[@$]([\w-]+)/g, (_, name) => vars[name] ?? `@${name}`);
  });
  return buildCss(substituted, 0, []).css;
}
function getIndent(line) {
  const m = /^(\s*)/.exec(line);
  return m ? m[1]?.length ?? 0 : 0;
}
function buildCss(lines, start, parentSelectors) {
  let out = "";
  let i = start;
  let decls = [];
  function flushDecls(selectors) {
    if (!decls.length) return;
    const sel = selectors.join(", ");
    out += `${sel} { ${decls.join("; ")}; }
`;
    decls = [];
  }
  const baseIndent = start < lines.length ? getIndent(lines[start] ?? "") : 0;
  while (i < lines.length) {
    const raw = lines[i] ?? "";
    const trimmed = raw.trim();
    if (!trimmed) {
      i++;
      continue;
    }
    const indent = getIndent(raw);
    if (indent < baseIndent && i > start) break;
    const nextLine = lines[i + 1];
    const nextIndent = i + 1 < lines.length && nextLine && nextLine.trim() ? getIndent(nextLine) : 0;
    if (trimmed.endsWith("{")) {
      flushDecls(parentSelectors.length ? parentSelectors : [trimmed.slice(0, -1).trim()]);
      out += raw + "\n";
      i++;
      let depth = 1;
      while (i < lines.length && depth > 0) {
        const l = lines[i] ?? "";
        out += l + "\n";
        depth += (l.match(/\{/g) ?? []).length - (l.match(/\}/g) ?? []).length;
        i++;
      }
      continue;
    }
    if (nextIndent > indent && !trimmed.includes(":")) {
      flushDecls(parentSelectors.length ? parentSelectors : []);
      const selectors = parentSelectors.length ? parentSelectors.map((p) => `${p} ${trimmed}`) : [trimmed];
      const child = buildCss(lines, i + 1, selectors);
      out += child.css;
      i = child.end;
      continue;
    }
    if (trimmed.includes(":") || trimmed.includes(" ") && !trimmed.startsWith("@")) {
      const decl = trimmed.includes(":") ? trimmed.replace(/:\s*/, ": ") : trimmed.replace(/\s+/, ": ");
      decls.push(decl.replace(/;$/, ""));
    } else if (trimmed.startsWith("@")) {
      flushDecls(parentSelectors.length ? parentSelectors : []);
      out += trimmed + "\n";
    }
    i++;
  }
  flushDecls(parentSelectors.length ? parentSelectors : []);
  return { css: out, end: i };
}
var Sheet = class _Sheet {
  // ── Private fields ─────────────────────────────────────────────────────────
  #head;
  #link = null;
  #sheet = null;
  #rules = [];
  #loaded = false;
  #loading = true;
  #state = "Loading";
  #index = -1;
  #name = "";
  #obs = false;
  // ── Constructor ─────────────────────────────────────────────────────────────
  constructor(...args) {
    this.#head = document.head ?? document.documentElement;
    const input = args.length === 0 ? void 0 : args.length === 1 ? args[0] : (
      /* multiple args */
      args.filter((a) => a instanceof Rule)
    );
    if (input !== void 0) {
      if (typeof input === "string") {
        if (/^https?:\/\/|^\/\//.test(input.trim())) {
          this.#loadUrl(input.trim());
        } else {
          this.#parseText(input);
        }
      } else if (typeof input === "object") {
        if (input instanceof _Sheet) {
          this.#sheet = input.Sheet;
          this.#rules = input.#rules.map((r) => r.clone());
        } else if (input instanceof CSSStyleSheet) {
          this.#sheet = input;
        } else if (input instanceof CSSRuleList) {
          this.#rules = Array.from(input).map((r) => new Rule(r));
        } else if (input instanceof HTMLLinkElement) {
          this.#link = input;
        } else if (input instanceof Rule) {
          this.#rules = [input];
        } else if (Array.isArray(input)) {
          this.#rules = input.map(
            (r) => r instanceof Rule ? r : new Rule(r)
          );
        } else {
          this.#parseObject(input);
        }
      }
    }
    if (!this.#link) {
      this.#link = document.createElement("link");
      this.#link.type = "text/css";
      this.#link.rel = "stylesheet";
    }
    if (!this.#link.href) {
      const blob = new Blob([""], { type: "text/css" });
      this.#link.href = URL.createObjectURL(blob);
      this.#head.appendChild(this.#link);
    }
    if (!this.#sheet) {
      const style = document.createElement("style");
      this.#head.appendChild(style);
      this.#sheet = style.sheet;
    }
    if (this.#rules.length) this.#flushRules();
    this.#loaded = true;
    this.#loading = false;
    this.#state = "Loaded";
    this.#index = Array.from(document.styleSheets).indexOf(this.#sheet);
  }
  // ── Private helpers ─────────────────────────────────────────────────────────
  #parseText(text) {
    const style = document.createElement("style");
    style.textContent = text;
    this.#head.appendChild(style);
    if (style.sheet)
      this.#rules = Array.from(style.sheet.cssRules).map((r) => new Rule(r));
    this.#head.removeChild(style);
  }
  #parseObject(obj) {
    for (const [, def] of Object.entries(obj)) {
      const d = def;
      if (d.Selector || d.Contents || d.Content || d.Rule || d.Body) {
        this.#rules.push(new Rule(d));
      } else {
        for (const [sel, props] of Object.entries(obj)) {
          if (typeof props === "object" && !("Selector" in props))
            this.#rules.push(new Rule(sel, props));
        }
        break;
      }
    }
  }
  /**
   * Fetch an external stylesheet URL and parse its rules.
   * Fires 'Sheet-Loaded' on completion, 'Sheet-Error' on failure.
   */
  #loadUrl(url) {
    this.#loading = true;
    this.#loaded = false;
    this.#state = "Loading";
    fetch(url).then((r) => r.text()).then((text) => {
      this.#parseText(text);
      this.#loaded = true;
      this.#loading = false;
      this.#state = "Loaded";
      this.#flushRules();
      this.#emit("Sheet-Loaded", { url });
    }).catch((err) => {
      this.#state = "Error";
      this.#loading = false;
      this.#emit("Sheet-Error", { url, error: err });
    });
  }
  #flushRules() {
    if (!this.#sheet) return;
    while (this.#sheet.cssRules.length)
      this.#sheet.deleteRule(0);
    this.#rules.forEach((r, i) => {
      try {
        this.#sheet.insertRule(r.Text, i);
      } catch (e) {
        console.warn(`Sheet: could not insert rule "${r.Selector}":`, e);
      }
    });
  }
  #emit(type, detail) {
    if (this.#obs instanceof Observable_default)
      this.#obs.fire({ Type: type, Sheet: this, Detail: detail });
  }
  // ── Static API ───────────────────────────────────────────────────────────────
  static get Sheets() {
    return Array.from(document.styleSheets).map((s) => new _Sheet(s));
  }
  static get Links() {
    return Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
  }
  static get Paths() {
    return _Sheet.Links.map((l) => l.href).filter(Boolean);
  }
  static ToString(source) {
    if (typeof source === "string") return source;
    if (Array.isArray(source))
      return source.map((r) => r instanceof Rule ? r.Text : r.cssText).join("\n");
    if (source instanceof _Sheet)
      return source.#rules.map((r) => r.Text).join("\n");
    if (source instanceof CSSStyleSheet)
      return Array.from(source.cssRules).map((r) => r.cssText).join("\n");
    return "";
  }
  static Parse(text) {
    const style = document.createElement("style");
    style.textContent = text;
    document.head.appendChild(style);
    const sheet = style.sheet;
    document.head.removeChild(style);
    return sheet;
  }
  static ToArray(text) {
    const s = _Sheet.Parse(text);
    return s ? Array.from(s.cssRules) : [];
  }
  /**
   * Parse Less/Stylus-style indented CSS to a standard CSS string.
   * Mirrors Golem's SheetES5.Less(text).
   *
   * Supports: indented nesting, variables (@var: val / $var: val / $var = val),
   * variable substitution, single-line comments (//).
   *
   * @example
   *   Sheet.Less(`
   *     @primary: dodgerblue
   *     .box
   *       background: @primary
   *       .inner
   *         color: white
   *   `);
   *   // → '.box { background: dodgerblue; }\n.box .inner { color: white; }\n'
   */
  static Less(text) {
    return parseLess(text);
  }
  // ── Getters ────────────────────────────────────────────────────────────────
  get Index() {
    return this.#index;
  }
  get Length() {
    return this.#rules.length;
  }
  get Loading() {
    return this.#loading;
  }
  get Loaded() {
    return this.#loaded;
  }
  get State() {
    return this.#state;
  }
  get Object() {
    const out = {};
    if (!this.#sheet) return out;
    try {
      for (const rule of Array.from(this.#sheet.cssRules)) {
        if (rule instanceof CSSStyleRule) {
          const decl = rule.style;
          for (let i = 0; i < decl.length; i++) {
            const prop = decl[i] ?? "";
            if (prop) out[toCamel2(prop)] = decl.getPropertyValue(prop).trim();
          }
        }
      }
    } catch {
    }
    return out;
  }
  get Name() {
    return this.#name;
  }
  set Name(v) {
    this.#name = v;
  }
  /** Full serialized CSS text of all rules. */
  get Text() {
    return this.#rules.map((r) => r.Text).join("\n");
  }
  set Text(v) {
    this.parse(v);
  }
  get Link() {
    return this.#link;
  }
  set Link(v) {
    if (typeof v === "string") {
      this.#link = document.createElement("link");
      this.#link.rel = "stylesheet";
      this.#link.href = v;
      this.#head.appendChild(this.#link);
    } else {
      this.#link = v;
    }
  }
  get Sheet() {
    return this.#sheet;
  }
  set Sheet(v) {
    if (v instanceof CSSStyleSheet) {
      this.#sheet = v;
      this.#rules = Array.from(v.cssRules).map((r) => new Rule(r));
    }
  }
  get Rules() {
    return [...this.#rules];
  }
  set Rules(v) {
    if (typeof v === "string") {
      this.add(v);
      return;
    }
    if (v instanceof CSSRuleList) {
      Array.from(v).forEach((r) => this.add(new Rule(r)));
      return;
    }
    v.forEach((r) => this.add(r));
  }
  get Observable() {
    return this.#obs;
  }
  set Observable(v) {
    if (v === true) {
      this.#obs = new Observable_default(this);
      return;
    }
    if (v === false) {
      this.#obs = false;
      return;
    }
    if (v instanceof Observable_default) this.#obs = v;
  }
  on(types, cb) {
    if (!this.#obs) this.#obs = new Observable_default(this);
    this.#obs.on(types, cb);
    return this;
  }
  // ── CRUD methods ──────────────────────────────────────────────────────────
  parse(input) {
    this.#rules = [];
    if (typeof input === "string") {
      if (/^https?:\/\/|^\/\//.test(input.trim()))
        this.#loadUrl(input.trim());
      else
        this.#parseText(input);
    } else if (input instanceof CSSStyleSheet) {
      this.#rules = Array.from(input.cssRules).map((r) => new Rule(r));
      this.#sheet = input;
    } else if (input instanceof CSSRuleList) {
      this.#rules = Array.from(input).map((r) => new Rule(r));
    } else if (Array.isArray(input)) {
      this.#rules = input.map((r) => r instanceof Rule ? r : new Rule(r));
    } else if (typeof input === "object" && input !== null) {
      if (input instanceof _Sheet)
        this.#rules = input.#rules.map((r) => r.clone());
      else
        this.#parseObject(input);
    }
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "parse" });
    return this;
  }
  getIndex(rule) {
    const selector = typeof rule === "string" ? rule.trim() : rule instanceof Rule ? rule.Selector.trim() : rule.selectorText?.trim() ?? "";
    return this.#rules.findIndex((r) => r.Selector.trim().replace(/\s+/g, "") === selector.replace(/\s+/g, ""));
  }
  contains(...rules) {
    return rules.every((r) => this.getIndex(r) >= 0);
  }
  /**
   * Get one or more rules by selector string, Rule instance, or CSSRule.
   * Also accepts @-rule selectors: sheet.get('@keyframes spin')
   * Mirrors Golem: sheet.Get('@keyframes Settete')
   */
  get(...rules) {
    if (rules.length === 1) {
      const rule0 = rules[0];
      if (rule0 === void 0) return void 0;
      const i = this.getIndex(rule0);
      return i >= 0 ? this.#rules[i] : void 0;
    }
    return rules.map((r) => {
      const i = this.getIndex(r);
      return i >= 0 ? this.#rules[i] : void 0;
    }).filter(Boolean);
  }
  /**
   * Golem alias for .get() — mirrors sheet.Get('@keyframes Settete').
   */
  Get(...rules) {
    return this.get(...rules);
  }
  set(rule, value) {
    const i = this.getIndex(rule);
    if (i < 0) return this;
    const r = this.#rules[i];
    if (!r) return this;
    if (typeof value === "string")
      r.replace(value);
    else
      r.merge(value);
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "set", index: i, rule: r });
    return this;
  }
  insert(rules, index) {
    const arr = Array.isArray(rules) ? rules : [rules];
    const newRules = arr.map(
      (r) => r instanceof Rule ? r : typeof r === "string" ? Rule.Parse(r)[0] : new Rule(r)
    ).filter(Boolean);
    this.#rules.splice(index, 0, ...newRules);
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "insert", index, count: newRules.length });
    return this;
  }
  /** Golem alias: sheet.Insert(rule, idx) */
  Insert(rules, index) {
    return this.insert(rules, index);
  }
  add(...args) {
    const last = args[args.length - 1];
    const hasIdx = typeof last === "number";
    const idx = hasIdx ? last : void 0;
    const src = hasIdx ? args.slice(0, -1) : args;
    const flat = src.flat();
    const newRules = flat.map(
      (r) => r instanceof Rule ? r : typeof r === "string" ? Rule.Parse(r)[0] ?? null : new Rule(r)
    ).filter(Boolean);
    if (hasIdx && idx >= 0 && idx <= this.#rules.length)
      this.#rules.splice(idx, 0, ...newRules);
    else
      this.#rules.push(...newRules);
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "add", count: newRules.length });
    return this;
  }
  /** Golem alias: sheet.Add(rule1, rule2) */
  Add(...args) {
    return this.add(...args);
  }
  unshift(...rules) {
    return this.insert(rules.flat(), 0);
  }
  remove(...rules) {
    for (const r of rules) {
      const i = typeof r === "number" ? r : this.getIndex(r);
      if (i >= 0) this.#rules.splice(i, 1);
    }
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "remove" });
    return this;
  }
  shift(n = 1) {
    this.#rules.splice(0, n);
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "shift", count: n });
    return this;
  }
  pop(n = 1) {
    this.#rules.splice(this.#rules.length - n, n);
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "pop", count: n });
    return this;
  }
  clear() {
    this.#rules = [];
    this.#flushRules();
    this.#emit("Sheet-Changed", { action: "clear" });
    return this;
  }
  toString() {
    return this.Text;
  }
};
if (typeof window !== "undefined") {
  let SheetES5 = function(url) {
    return url ? new Sheet(url) : new Sheet();
  };
  SheetES52 = SheetES5;
  Object.defineProperty(window, "Sheet", {
    enumerable: true,
    configurable: false,
    writable: false,
    value: Sheet
  });
  SheetES5.Less = (text) => Sheet.Less(text);
  if (!("SheetES5" in window))
    Object.defineProperty(window, "SheetES5", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SheetES5
    });
}
var SheetES52;
var Stylesheet_default = Sheet;

// core/Virtual.ts
function _alpha(color, a) {
  const rgba = color.match(/rgba?\(([^)]+)\)/);
  if (rgba) {
    const p = rgba[1].split(",").map((s) => s.trim());
    if (p.length >= 3) return `rgba(${p[0]},${p[1]},${p[2]},${a})`;
  }
  const hex = color.match(/^#([0-9a-fA-F]{3,8})$/);
  if (hex) {
    const h = hex[1];
    const r = parseInt(h.length >= 6 ? h.slice(0, 2) : h[0] + h[0], 16);
    const g = parseInt(h.length >= 6 ? h.slice(2, 4) : h[1] + h[1], 16);
    const b = parseInt(h.length >= 6 ? h.slice(4, 6) : h[2] + h[2], 16);
    return `rgba(${r},${g},${b},${a})`;
  }
  return color;
}
function _preset(mode, o) {
  const color = o.color ?? "rgba(0,0,0,0.25)", blur = o.blur ?? 8, spread = o.spread ?? 0, x = o.x ?? 0;
  switch (mode) {
    case "drop":
      return `${x}px ${o.y ?? 4}px ${blur}px ${spread}px ${color}`;
    case "inset":
      return `inset ${x}px ${o.y ?? 0}px ${blur}px ${spread}px ${color}`;
    case "glow":
      return `0 0 ${blur}px ${spread + 2}px ${color}, 0 0 ${blur * 2}px ${spread}px ${_alpha(color, 0.5)}`;
    case "layered": {
      const y = o.y ?? 4;
      return `${x}px ${y}px ${blur}px ${color}, ${x}px ${y * 2}px ${blur * 2}px ${_alpha(color, 0.15)}`;
    }
  }
}
function _layerCSS(l) {
  return `${l.inset ? "inset " : ""}${l.x ?? 0}px ${l.y ?? 4}px ${l.blur ?? 8}px ${l.spread ?? 0}px ${l.color ?? "rgba(0,0,0,0.25)"}`;
}
function _shadowCSS(state, mode = "drop", opts = {}) {
  if (state === "close") return "none";
  if (mode instanceof Rule_default) {
    const v = mode.Properties["boxShadow"] ?? mode.Properties["box-shadow"];
    return v ?? _preset("drop", opts);
  }
  if (mode instanceof Stylesheet_default) {
    for (const r of mode.Rules) {
      const v = r.Properties["boxShadow"] ?? r.Properties["box-shadow"];
      if (v) return v;
    }
    return _preset("drop", opts);
  }
  if (Array.isArray(mode)) return mode.map(_layerCSS).join(", ");
  return _preset(mode, opts);
}
var _counter = 0;
var _nodes = {};
function uid() {
  return `vn-${++_counter}-${Math.random().toString(36).slice(2, 6)}`;
}
function normalizeChild(c) {
  if (c instanceof VirtualNode) return c;
  const n = new VirtualNode("span");
  n.set("textContent", c == null ? "" : String(c));
  return n;
}
var VirtualNode = class _VirtualNode {
  #id;
  #tag;
  #attrs;
  #children;
  #text;
  #dom = null;
  #parent = null;
  #mounted = false;
  #domQueue = [];
  #effects = [];
  #sinks = [];
  static Instances = [];
  constructor(def, attrs, ...children) {
    if (def instanceof AriannATemplate) {
      const el = def.clone();
      this.#tag = el.tagName.toLowerCase();
      this.#attrs = {};
      this.#children = [];
      this.#text = "";
      this.#id = uid();
      _nodes[this.#id] = this;
      _VirtualNode.Instances.push(this);
      this.#dom = el;
      return;
    }
    if (typeof def === "string") {
      this.#tag = def.toLowerCase();
      this.#attrs = { ...attrs ?? {} };
      this.#children = children.map(normalizeChild);
      this.#text = "";
    } else {
      this.#tag = (def.Tag ?? "div").toLowerCase();
      this.#attrs = { ...def.Attributes ?? {} };
      this.#children = (def.Children ?? []).map(normalizeChild);
      this.#text = def.Text ?? "";
      this.#parent = def.Parent ?? null;
    }
    this.#id = uid();
    _nodes[this.#id] = this;
    _VirtualNode.Instances.push(this);
  }
  render() {
    if (this.#dom) return this.#dom;
    const d = Core_default.GetDescriptor(this.#tag);
    this.#dom = d && d.Namespace?.functions?.create ? d.Namespace.functions.create(this.#tag) : document.createElement(this.#tag);
    for (const [k, v] of Object.entries(this.#attrs)) if (v !== null) this.#dom.setAttribute(k, String(v));
    if (this.#text) this.#dom.textContent = this.#text;
    for (const child of this.#children) this.#dom.appendChild(child.render());
    this.#applySinks();
    for (const { type, cb, opts } of this.#domQueue) this.#dom.addEventListener(type, cb, opts);
    this.#domQueue = [];
    this.#mounted = true;
    return this.#dom;
  }
  #applySinks() {
    if (!this.#dom) return;
    for (const sink of this.#sinks) {
      switch (sink.type) {
        case "text": {
          const node = document.createTextNode(String(sink.getter()));
          this.#dom.appendChild(node);
          this.#effects.push(effect(() => {
            node.nodeValue = sink.getter();
          }));
          break;
        }
        case "textMono": {
          const node = sink.node ?? document.createTextNode(sink.mono.peek());
          if (!sink.node) this.#dom.appendChild(node);
          sinkText(sink.mono, node);
          break;
        }
        case "attr": {
          const el = this.#dom;
          this.#effects.push(effect(() => {
            const v = sink.getter();
            if (v === null) el.removeAttribute(sink.name);
            else el.setAttribute(sink.name, v);
          }));
          break;
        }
        case "cls": {
          const el = this.#dom;
          this.#effects.push(effect(() => {
            if (sink.getter()) el.classList.add(sink.name);
            else el.classList.remove(sink.name);
          }));
          break;
        }
        case "prop": {
          const rec = this.#dom;
          this.#effects.push(effect(() => {
            rec[sink.name] = sink.getter();
          }));
          break;
        }
        case "style": {
          const el = this.#dom;
          const p = sink.name.replace(/([A-Z])/g, (c) => `-${c.toLowerCase()}`);
          this.#effects.push(effect(() => {
            el.style.setProperty(p, sink.getter());
          }));
          break;
        }
        case "bind": {
          const rec = this.#dom;
          this.#effects.push(effect(() => {
            rec["value"] = sink.getter();
          }));
          if (sink.setter) this.#dom.addEventListener("input", (e) => sink.setter(e.target.value));
          break;
        }
        case "shadow": {
          const mode = sink.shadowModeRule ?? sink.shadowMode ?? "drop";
          this.#dom.style.boxShadow = _shadowCSS("open", mode, sink.shadowOpts ?? {});
          break;
        }
      }
    }
    this.#sinks = [];
  }
  valueOf() {
    return this.render();
  }
  log(v) {
    console.log(v ?? this.#dom ?? `[VirtualNode <${this.#tag}> unmounted]`);
    return this;
  }
  on(type, cb, opts) {
    if (this.#dom) this.#dom.addEventListener(type, cb, opts);
    else this.#domQueue.push({ type, cb, ...opts !== void 0 ? { opts } : {} });
    return this;
  }
  off(type, cb, opts) {
    this.#dom?.removeEventListener(type, cb, opts);
    return this;
  }
  fire(type, init) {
    this.#dom?.dispatchEvent(new CustomEvent(type, init));
    return this;
  }
  append(parent) {
    const p = typeof parent === "string" ? document.querySelector(parent) : parent instanceof _VirtualNode ? parent.render() : typeof parent?.render === "function" ? parent.render() : parent instanceof Element ? parent : null;
    if (p) p.appendChild(this.render());
    this.#mounted = true;
    return this;
  }
  mount(parent) {
    return this.append(parent ?? null);
  }
  unmount() {
    this.#dom?.parentNode?.removeChild(this.#dom);
    this.#mounted = false;
    return this;
  }
  add(...args) {
    const last = args[args.length - 1];
    const items = typeof last === "number" ? args.slice(0, -1) : args;
    const index = typeof last === "number" ? last : this.#children.length;
    const vnodes = items.map(normalizeChild);
    this.#children.splice(index, 0, ...vnodes);
    if (this.#dom) {
      const ref = this.#dom.childNodes[index] ?? null;
      const frag = document.createDocumentFragment();
      vnodes.forEach((n) => frag.appendChild(n.render()));
      this.#dom.insertBefore(frag, ref);
    }
    return this;
  }
  push(...nodes) {
    return this.add(...nodes);
  }
  unshift(...nodes) {
    return this.add(...nodes, 0);
  }
  remove(...targets) {
    for (const t of targets) {
      if (typeof t === "number") {
        const vn = this.#children.splice(t, 1)[0];
        if (vn) {
          const el = vn.render();
          el.parentNode?.removeChild(el);
        }
      } else if (typeof t === "string") {
        const el = this.#dom?.querySelector(t);
        el?.parentNode?.removeChild(el);
      } else if (t instanceof _VirtualNode) {
        const i = this.#children.indexOf(t);
        if (i >= 0) this.#children.splice(i, 1);
        if (t.#dom) t.#dom.parentNode?.removeChild(t.#dom);
      }
    }
    return this;
  }
  shift(n = 1) {
    for (let i = 0; i < n; i++) {
      const vn = this.#children.shift();
      if (vn) {
        const el = vn.render();
        el.parentNode?.removeChild(el);
      }
    }
    return this;
  }
  pop(n = 1) {
    for (let i = 0; i < n; i++) {
      const vn = this.#children.pop();
      if (vn) {
        const el = vn.render();
        el.parentNode?.removeChild(el);
      }
    }
    return this;
  }
  get(name) {
    return this.#dom?.getAttribute(name) ?? (this.#attrs[name] !== void 0 && this.#attrs[name] !== null ? String(this.#attrs[name]) : void 0);
  }
  set(name, value) {
    if (this.#dom) {
      if (name in this.#dom) this.#dom[name] = value;
      else if (value !== null) this.#dom.setAttribute(name, String(value));
      else this.#dom.removeAttribute(name);
    } else this.#attrs[name] = value;
    return this;
  }
  css(prop, val) {
    if (this.#dom) this.#dom.style.setProperty(prop, val);
    return this;
  }
  show() {
    this.css("display", "");
    return this;
  }
  hide() {
    this.css("display", "none");
    return this;
  }
  child(path) {
    let n = this.render();
    for (const i of path) n = n.childNodes[i];
    return n;
  }
  shadow(state, mode = "drop", opts = {}) {
    if (this.#dom) this.#dom.style.boxShadow = _shadowCSS(state, mode, opts);
    else if (state === "close") this.#sinks.push({ type: "shadow", getter: () => null, shadowOpts: {} });
    else if (mode instanceof Rule_default || mode instanceof Stylesheet_default) this.#sinks.push({ type: "shadow", getter: () => null, shadowModeRule: mode, shadowOpts: opts });
    else this.#sinks.push({ type: "shadow", getter: () => null, shadowMode: mode, shadowOpts: opts });
    return this;
  }
  signal(value) {
    return signal(value);
  }
  signalMono(value) {
    return signalMono(value);
  }
  effect(fn) {
    if (this.#dom) this.#effects.push(effect(fn));
    else this.#sinks.push({ type: "text", getter: fn });
    return this;
  }
  computed(fn) {
    const s = signal(void 0);
    this.#effects.push(effect(() => s.set(fn())));
    return s.readonly();
  }
  text(getter) {
    if (this.#dom) {
      const n = document.createTextNode(getter());
      this.#dom.appendChild(n);
      this.#effects.push(effect(() => {
        n.nodeValue = getter();
      }));
    } else this.#sinks.push({ type: "text", getter });
    return this;
  }
  textMono(s, node) {
    if (this.#dom) {
      const n = node ?? document.createTextNode(s.peek());
      if (!node) this.#dom.appendChild(n);
      sinkText(s, n);
    } else this.#sinks.push({ type: "textMono", getter: s.peek, mono: s, ...node !== void 0 ? { node } : {} });
    return this;
  }
  attr(name, getter) {
    if (this.#dom) {
      const el = this.#dom;
      this.#effects.push(effect(() => {
        const v = getter();
        if (v === null) el.removeAttribute(name);
        else el.setAttribute(name, v);
      }));
    } else this.#sinks.push({ type: "attr", getter, name });
    return this;
  }
  cls(name, getter) {
    if (this.#dom) {
      const el = this.#dom;
      this.#effects.push(effect(() => {
        if (getter()) el.classList.add(name);
        else el.classList.remove(name);
      }));
    } else this.#sinks.push({ type: "cls", getter, name });
    return this;
  }
  clsMono(name) {
    const el = this.render();
    return (v) => {
      if (v) el.classList.add(name);
      else el.classList.remove(name);
    };
  }
  prop(name, getter) {
    if (this.#dom) {
      const rec = this.#dom;
      this.#effects.push(effect(() => {
        rec[name] = getter();
      }));
    } else this.#sinks.push({ type: "prop", getter, name });
    return this;
  }
  style(prop, getter) {
    if (this.#dom) {
      const el = this.#dom;
      const p = prop.replace(/([A-Z])/g, (c) => `-${c.toLowerCase()}`);
      this.#effects.push(effect(() => {
        el.style.setProperty(p, getter());
      }));
    } else this.#sinks.push({ type: "style", getter, name: prop });
    return this;
  }
  bind(getter, setter) {
    this.prop("value", getter);
    if (setter) this.on("input", (e) => setter(e.target.value));
    return this;
  }
  destroy() {
    this.#effects.forEach((s) => s());
    this.#effects = [];
    this.#sinks = [];
    return this;
  }
  static signal = signal;
  static signalMono = signalMono;
  static sinkText = sinkText;
  static effect = effect;
  static computed = computed;
  static batch = batch;
  static untrack = untrack;
  static tpl = (html) => new AriannATemplate(html);
  static template = (html) => new AriannATemplate(html);
};
if (typeof window !== "undefined") Object.defineProperty(window, "Virtual", { value: VirtualNode, writable: false, enumerable: false, configurable: false });
var Virtual_default = VirtualNode;

// core/Real.ts
function _alpha2(color, a) {
  const rgba = color.match(/rgba?\(([^)]+)\)/);
  if (rgba) {
    const p = rgba[1].split(",").map((s) => s.trim());
    if (p.length >= 3) return `rgba(${p[0]},${p[1]},${p[2]},${a})`;
  }
  const hex = color.match(/^#([0-9a-fA-F]{3,8})$/);
  if (hex) {
    const h = hex[1];
    const r = parseInt(h.length >= 6 ? h.slice(0, 2) : h[0] + h[0], 16);
    const g = parseInt(h.length >= 6 ? h.slice(2, 4) : h[1] + h[1], 16);
    const b = parseInt(h.length >= 6 ? h.slice(4, 6) : h[2] + h[2], 16);
    return `rgba(${r},${g},${b},${a})`;
  }
  return color;
}
function _preset2(mode, o) {
  const color = o.color ?? "rgba(0,0,0,0.25)", blur = o.blur ?? 8, spread = o.spread ?? 0, x = o.x ?? 0;
  switch (mode) {
    case "drop":
      return `${x}px ${o.y ?? 4}px ${blur}px ${spread}px ${color}`;
    case "inset":
      return `inset ${x}px ${o.y ?? 0}px ${blur}px ${spread}px ${color}`;
    case "glow":
      return `0 0 ${blur}px ${spread + 2}px ${color}, 0 0 ${blur * 2}px ${spread}px ${_alpha2(color, 0.5)}`;
    case "layered": {
      const y = o.y ?? 4;
      return `${x}px ${y}px ${blur}px ${color}, ${x}px ${y * 2}px ${blur * 2}px ${_alpha2(color, 0.15)}`;
    }
  }
}
function _layerCSS2(l) {
  return `${l.inset ? "inset " : ""}${l.x ?? 0}px ${l.y ?? 4}px ${l.blur ?? 8}px ${l.spread ?? 0}px ${l.color ?? "rgba(0,0,0,0.25)"}`;
}
function _shadowCSS2(state, mode = "drop", opts = {}) {
  if (state === "close") return "none";
  if (mode instanceof Rule_default) {
    const v = mode.Properties["boxShadow"] ?? mode.Properties["box-shadow"];
    return v ?? _preset2("drop", opts);
  }
  if (mode instanceof Stylesheet_default) {
    for (const r of mode.Rules) {
      const v = r.Properties["boxShadow"] ?? r.Properties["box-shadow"];
      if (v) return v;
    }
    return _preset2("drop", opts);
  }
  if (Array.isArray(mode)) return mode.map(_layerCSS2).join(", ");
  return _preset2(mode, opts);
}
function toNodes(items) {
  return items.flatMap((item) => {
    if (!item) return [];
    if (item instanceof Node) return [item];
    if (item instanceof Real) return [item.render()];
    if (item instanceof VirtualNode) return [item.render()];
    if (item instanceof AriannATemplate) return [item.clone()];
    if (typeof item === "string") {
      const t = document.createElement("template");
      t.innerHTML = item;
      return Array.from(t.content.childNodes);
    }
    if (typeof item === "object" && "Tag" in item) {
      const el = document.createElement(item.Tag ?? "div");
      if (item.Attributes) for (const [k, v] of Object.entries(item.Attributes)) el.setAttribute(k, v);
      return [el];
    }
    return [];
  });
}
var Real = class _Real {
  #el;
  #mode;
  #descriptor;
  #value;
  #effects = [];
  static Instances = [];
  static get Namespaces() {
    return Core_default.Namespaces;
  }
  constructor(arg0, arg1, arg2) {
    this.#mode = new.target !== void 0;
    this.#el = document.createElement("div");
    this.#descriptor = false;
    this.#value = this;
    this.#init(arg0, arg1, arg2);
    if (this.#mode) {
      _Real.Instances.push(this);
      if (!this.#el.id) {
        this.#el.id = `Real-Instance-${_Real.Instances.length}`;
        this.#el.className = this.#el.id;
      }
    }
  }
  #init(arg0, arg1, arg2) {
    if (arg0 instanceof AriannATemplate) {
      this.#el = arg0.clone();
      this.#mode = true;
      return;
    }
    if (!this.#mode) {
      if (typeof arg0 === "string") {
        if (arg1 && typeof arg1 === "function") {
          Core_default.Define(arg0, arg1, arg2 ?? HTMLElement);
          this.#value = arg1;
          return;
        }
        const d = Core_default.GetDescriptor(arg0);
        if (d) {
          this.#descriptor = d;
          this.#value = d.Constructor ?? d.Interface;
          return;
        }
        const el = document.querySelector(arg0);
        if (el) {
          this.#el = el;
          this.#descriptor = Core_default.GetDescriptor(el);
          this.#value = new _Real(el);
        }
        return;
      }
      if (typeof arg0 === "function") {
        const d = Core_default.GetDescriptor(arg0);
        if (d) {
          this.#descriptor = d;
          this.#value = d.Interface ?? arg0;
        }
        return;
      }
      if (arg0 instanceof Element) {
        this.#el = arg0;
        this.#descriptor = Core_default.GetDescriptor(arg0);
        this.#value = new _Real(arg0);
        this.#mode = true;
        return;
      }
      return;
    }
    if (typeof arg0 === "string") {
      const d = Core_default.GetDescriptor(arg0);
      this.#el = d && d.Namespace?.functions?.create ? d.Namespace.functions.create(arg0) : document.createElement(arg0);
      if (d) this.#descriptor = d;
    } else if (arg0 instanceof Element) {
      this.#el = arg0;
      this.#descriptor = Core_default.GetDescriptor(arg0);
    } else if (arg0 instanceof _Real) {
      this.#el = arg0.render();
    } else if (arg0 instanceof VirtualNode) {
      this.#el = arg0.render();
    } else if (typeof arg0 === "object" && "Tag" in arg0) {
      const def = arg0;
      this.#el = document.createElement(def.Tag ?? "div");
      if (def.Attributes) for (const [k, v] of Object.entries(def.Attributes)) this.#el.setAttribute(k, v);
    }
    if (arg1 && typeof arg1 === "object" && typeof arg1 !== "function") {
      const opts = arg1;
      if (opts.id) this.#el.id = String(opts.id);
      if (opts.class || opts.className) this.#el.className = String(opts.class ?? opts.className);
    }
  }
  render() {
    return this.#el;
  }
  valueOf() {
    return this.#el;
  }
  log(v) {
    console.log(v ?? this.#el);
    return this;
  }
  on(type, cb, opts) {
    this.#el.addEventListener(type, cb, opts);
    return this;
  }
  off(type, cb, opts) {
    this.#el.removeEventListener(type, cb, opts);
    return this;
  }
  fire(event, init) {
    this.#el.dispatchEvent(typeof event === "string" ? new CustomEvent(event, init) : event);
    return this;
  }
  append(parent) {
    const p = typeof parent === "string" ? document.querySelector(parent) : parent instanceof _Real ? parent.render() : parent instanceof VirtualNode ? parent.render() : parent;
    if (p) p.appendChild(this.#el);
    return this;
  }
  add(...args) {
    const last = args[args.length - 1];
    const items = typeof last === "number" ? args.slice(0, -1) : args;
    const index = typeof last === "number" ? last : this.#el.childNodes.length;
    const nodes = toNodes(items);
    const ref = this.#el.childNodes[index] ?? null;
    const frag = document.createDocumentFragment();
    nodes.forEach((n) => frag.appendChild(n));
    this.#el.insertBefore(frag, ref);
    return this;
  }
  push(...nodes) {
    return this.add(...nodes);
  }
  unshift(...nodes) {
    return this.add(...nodes, 0);
  }
  remove(...targets) {
    for (const t of targets) {
      let node = null;
      if (typeof t === "number") node = this.#el.childNodes[t] ?? null;
      else if (typeof t === "string") node = this.#el.querySelector(t);
      else if (t instanceof _Real) node = t.render();
      else if (t instanceof Node) node = t;
      if (node && this.#el.contains(node)) this.#el.removeChild(node);
    }
    return this;
  }
  shift(n = 1) {
    for (let i = 0; i < n && this.#el.firstChild; i++) this.#el.removeChild(this.#el.firstChild);
    return this;
  }
  pop(n = 1) {
    for (let i = 0; i < n && this.#el.lastChild; i++) this.#el.removeChild(this.#el.lastChild);
    return this;
  }
  get(name) {
    const u = name.toUpperCase();
    for (let i = 0; i < this.#el.attributes.length; i++) {
      const a = this.#el.attributes.item(i);
      if (a.name.toUpperCase() === u) return a.value;
    }
    const rec = this.#el;
    for (const k of Object.keys(rec)) if (k.toUpperCase() === u) return String(rec[k]);
    return void 0;
  }
  set(name, value) {
    const u = name.toUpperCase();
    for (let i = 0; i < this.#el.attributes.length; i++) {
      const a = this.#el.attributes.item(i);
      if (a.name.toUpperCase() === u) {
        this.#el.setAttribute(a.name, value);
        return this;
      }
    }
    const rec = this.#el;
    for (const k of Object.keys(rec)) if (k.toUpperCase() === u) {
      rec[k] = value;
      return this;
    }
    this.#el.setAttribute(name.toLowerCase(), value);
    return this;
  }
  show() {
    this.#el.style.display = "";
    return this;
  }
  hide() {
    this.#el.style.display = "none";
    return this;
  }
  contains(...nodes) {
    for (const n of nodes) {
      const el = typeof n === "string" ? this.#el.querySelector(n) : n instanceof _Real ? n.render() : n;
      if (!el || !this.#el.contains(el)) return false;
    }
    return true;
  }
  child(path) {
    let n = this.#el;
    for (const i of path) n = n.childNodes[i];
    return n;
  }
  shadow(state, mode = "drop", opts = {}) {
    this.#el.style.boxShadow = _shadowCSS2(state, mode, opts);
    return this;
  }
  signal(value) {
    return signal(value);
  }
  signalMono(value) {
    return signalMono(value);
  }
  effect(fn) {
    this.#effects.push(effect(fn));
    return this;
  }
  computed(fn) {
    const s = signal(void 0);
    this.#effects.push(effect(() => s.set(fn())));
    return s.readonly();
  }
  text(getter) {
    const node = document.createTextNode(getter());
    this.#el.appendChild(node);
    this.#effects.push(effect(() => {
      node.nodeValue = getter();
    }));
    return this;
  }
  textMono(s, node) {
    if (!node) {
      node = document.createTextNode(s.peek());
      this.#el.appendChild(node);
    }
    sinkText(s, node);
    return this;
  }
  attr(name, getter) {
    const el = this.#el;
    this.#effects.push(effect(() => {
      const v = getter();
      if (v === null) el.removeAttribute(name);
      else el.setAttribute(name, v);
    }));
    return this;
  }
  cls(name, getter) {
    const el = this.#el;
    this.#effects.push(effect(() => {
      if (getter()) el.classList.add(name);
      else el.classList.remove(name);
    }));
    return this;
  }
  clsMono(name) {
    const el = this.#el;
    return (v) => {
      if (v) el.classList.add(name);
      else el.classList.remove(name);
    };
  }
  prop(name, getter) {
    const rec = this.#el;
    this.#effects.push(effect(() => {
      rec[name] = getter();
    }));
    return this;
  }
  style(prop, getter) {
    const el = this.#el;
    const cssProp = prop.replace(/([A-Z])/g, (c) => `-${c.toLowerCase()}`);
    this.#effects.push(effect(() => {
      el.style.setProperty(cssProp, getter());
    }));
    return this;
  }
  bind(getter, setter) {
    this.prop("value", getter);
    if (setter) this.#el.addEventListener("input", (e) => setter(e.target.value));
    return this;
  }
  destroy() {
    this.#effects.forEach((s) => s());
    this.#effects = [];
    return this;
  }
  static tpl(html) {
    return new AriannATemplate(html);
  }
  static Define(tag, ctor, base = HTMLElement, style = {}) {
    return Core_default.Define(tag, ctor, base, style);
  }
  static GetDescriptor = Core_default.GetDescriptor;
  static Render(obj) {
    if (obj instanceof Element) return obj;
    if (obj instanceof _Real) return obj.render();
    if (obj instanceof VirtualNode) return obj.render();
    if (obj instanceof AriannATemplate) return obj.clone();
    if (typeof obj === "object" && "Tag" in obj) {
      const el = document.createElement(obj.Tag ?? "div");
      if (obj.Attributes) for (const [k, v] of Object.entries(obj.Attributes)) el.setAttribute(k, v);
      return el;
    }
    return null;
  }
  static signal = signal;
  static signalMono = signalMono;
  static sinkText = sinkText;
  static effect = effect;
  static computed = computed;
  static batch = batch;
  static untrack = untrack;
  static template = (html) => new AriannATemplate(html);
};
if (typeof window !== "undefined") Object.defineProperty(window, "Real", { enumerable: true, configurable: false, writable: false, value: Real });
var Real_default = Real;

// core/Component.ts
var Component = class _Component {
  #delegate;
  mode;
  static Instances = [];
  constructor(arg0, arg1, ...children) {
    const opts = arg1 ?? {};
    const mode = opts.mode ?? "real";
    const attrs = { ...opts };
    delete attrs["mode"];
    this.mode = mode;
    if (mode === "virtual") {
      this.#delegate = arg0 instanceof VirtualNode ? arg0 : new VirtualNode(
        arg0,
        attrs,
        ...children
      );
    } else {
      this.#delegate = arg0 instanceof VirtualNode ? new Real_default(arg0.render()) : new Real_default(arg0, attrs, ...children);
    }
    _Component.Instances.push(this);
  }
  // ── Core API ──────────────────────────────────────────────────────────────
  render() {
    return this.#delegate.render();
  }
  valueOf() {
    return this.render();
  }
  log(v) {
    this.#delegate.log(v);
    return this;
  }
  on(type, cb, opts) {
    this.#delegate.on(type, cb, opts);
    return this;
  }
  off(type, cb, opts) {
    this.#delegate.off(type, cb, opts);
    return this;
  }
  fire(type, init) {
    this.#delegate.fire(type, init);
    return this;
  }
  append(parent) {
    const target = parent instanceof _Component ? parent.render() : parent;
    this.#delegate.append(target);
    return this;
  }
  add(...args) {
    const normalized = args.map((a) => a instanceof _Component ? a.render() : a);
    this.#delegate.add(...normalized);
    return this;
  }
  unshift(...nodes) {
    return this.add(...nodes, 0);
  }
  push(...nodes) {
    return this.add(...nodes);
  }
  remove(...targets) {
    const normalized = targets.map((t) => t instanceof _Component ? t.render() : t);
    this.#delegate.remove(...normalized);
    return this;
  }
  shift(n = 1) {
    this.#delegate.shift(n);
    return this;
  }
  pop(n = 1) {
    this.#delegate.pop(n);
    return this;
  }
  get(name) {
    return this.#delegate.get(name) ?? void 0;
  }
  set(name, value) {
    this.#delegate.set(name, value);
    return this;
  }
  show() {
    this.#delegate.show();
    return this;
  }
  hide() {
    this.#delegate.hide();
    return this;
  }
  /**
   * Returns true if the rendered element contains all given nodes.
   * FIX: implemented directly on the DOM element — Real/VirtualNode
   * do not expose a .contains() method.
   */
  contains(...nodes) {
    const root = this.render();
    return nodes.every((n) => {
      if (n instanceof _Component) return root.contains(n.render());
      if (n instanceof VirtualNode) return root.contains(n.render());
      if (n instanceof Element) return root.contains(n);
      if (typeof n === "string") return !!root.querySelector(n);
      return false;
    });
  }
  css(prop, value) {
    const el = this.render();
    if (el instanceof HTMLElement)
      el.style[prop] = value;
    return this;
  }
  // ── Fine-grain Signal+Sink API ─────────────────────────────────────────────
  text(getter) {
    this.#delegate.text(getter);
    return this;
  }
  attr(name, getter) {
    this.#delegate.attr(name, getter);
    return this;
  }
  cls(name, getter) {
    this.#delegate.cls(name, getter);
    return this;
  }
  prop(name, getter) {
    this.#delegate.prop(name, getter);
    return this;
  }
  style(prop, getter) {
    this.#delegate.style(prop, getter);
    return this;
  }
  bind(getter, setter) {
    this.#delegate.bind(getter, setter);
    return this;
  }
  destroy() {
    this.#delegate.destroy();
    return this;
  }
  /**
   * Applica o rimuove un box-shadow delegando a Real / VirtualNode.
   * @example
   *   new Component('div').shadow('open', 'glow', { color: '#e40c88', blur: 24 })
   *   new Component('div').shadow('close')
   */
  shadow(state, mode = "drop", opts = {}) {
    this.#delegate.shadow(state, mode, opts);
    return this;
  }
  // ── Static API ────────────────────────────────────────────────────────────
  static Define(tag, ctor, base = HTMLElement, style = {}) {
    return Core_default.Define(tag, ctor, base, style);
  }
  static get Namespaces() {
    return Core_default.Namespaces;
  }
};
function _cFactory(arg0, arg1, ...rest) {
  return new Component(arg0, arg1, ...rest);
}
Object.defineProperties(_cFactory, {
  prototype: { value: Component.prototype, writable: false },
  name: { value: "Component" }
});
if (typeof window !== "undefined") {
  Object.defineProperty(window, "Component", {
    value: _cFactory,
    writable: false,
    enumerable: false,
    configurable: false
  });
}
var Component_default = Component;

// core/Directive.ts
function _resolve(condition) {
  return typeof condition === "function" ? condition() : Boolean(condition);
}
function _toNode(content) {
  if (!content) return null;
  if (content instanceof Element || content instanceof DocumentFragment) return content;
  if (typeof content === "string") {
    const t = document.createElement("template");
    t.innerHTML = content;
    return t.content.cloneNode(true);
  }
  return null;
}
function _resolveParent(parent) {
  if (typeof parent === "string") return document.querySelector(parent);
  return parent;
}
var Directive = class _Directive {
  // ── if ─────────────────────────────────────────────────────────────────────
  /**
   * Conditionally insert/remove content based on a condition.
   * Uses an anchor comment node to track position in the DOM.
   * Returns an update() function — call it when the condition may have changed.
   *
   * @param parent    - Parent element or CSS selector
   * @param condition - Boolean or () => boolean
   * @param then_     - Content to show when true  (string | Element | null)
   * @param else_     - Content to show when false (string | Element | null)
   * @returns UpdateFn — call to re-evaluate
   *
   * @example
   *   const update = Directive.if(el, () => user.loggedIn, loginHtml, logoutHtml);
   *   // When condition changes:
   *   update();
   */
  static if(parent, condition, then_, else_) {
    const par = _resolveParent(parent);
    if (!par) return () => {
    };
    const anchor = document.createComment(" a:if ");
    par.appendChild(anchor);
    let current = null;
    function update() {
      const val = _resolve(condition);
      const src = val ? then_ : else_;
      if (current) {
        if (Array.isArray(current))
          current.forEach((n) => {
            if (n.parentNode) n.parentNode.removeChild(n);
          });
        else if (current.parentNode)
          current.parentNode.removeChild(current);
        current = null;
      }
      if (src) {
        const next = _toNode(src);
        if (next) {
          const nodes = next.nodeType === 11 ? Array.from(next.childNodes) : [next];
          anchor.parentNode.insertBefore(next, anchor);
          current = nodes.length === 1 ? nodes[0] : nodes;
        }
      }
    }
    update();
    return update;
  }
  // ── for ────────────────────────────────────────────────────────────────────
  /**
   * Render a list from an array. Clears and re-renders on each update().
   *
   * @param parent   - Parent element
   * @param items    - Array or () => Array
   * @param renderFn - (item, index) => string | Element
   * @returns UpdateFn
   *
   * @example
   *   const update = Directive.for(ul, () => items, (item, i) =>
   *     `<li data-i="${i}">${item.name}</li>`);
   */
  static for(parent, items, renderFn) {
    const par = _resolveParent(parent);
    if (!par) return () => {
    };
    const anchor = document.createComment(" a:for ");
    par.appendChild(anchor);
    const rendered = [];
    function update() {
      rendered.forEach((n) => {
        if (n.parentNode) n.parentNode.removeChild(n);
      });
      rendered.length = 0;
      const list = typeof items === "function" ? items() : items;
      const frag = document.createDocumentFragment();
      list.forEach((item, i) => {
        const node = _toNode(renderFn(item, i));
        if (node) {
          frag.appendChild(node);
          rendered.push(node);
        }
      });
      anchor.parentNode.insertBefore(frag, anchor);
    }
    update();
    return update;
  }
  // ── foreach ────────────────────────────────────────────────────────────────
  /**
   * Render an object's key/value pairs into a parent element.
   * Matches the the legacy library `foreach="var planet in object"` HTML attribute pattern.
   *
   * @param parent   - Parent element
   * @param obj      - Object or () => Object to iterate
   * @param renderFn - (key, value, index) => string | Element
   * @returns UpdateFn
   *
   * @example
   *   // Matches: <ol foreach="var planet in object">
   *   //            <li>{{ planet }} : {{ object[planet] }}</li>
   *   //          </ol>
   *   const update = Directive.foreach(ol, () => planets, (key, value) =>
   *     `<li class="Value">${key} : ${value}</li>`);
   */
  static foreach(parent, obj, renderFn) {
    const par = _resolveParent(parent);
    if (!par) return () => {
    };
    const anchor = document.createComment(" a:foreach ");
    par.appendChild(anchor);
    const rendered = [];
    function update() {
      rendered.forEach((n) => {
        if (n.parentNode) n.parentNode.removeChild(n);
      });
      rendered.length = 0;
      const source = typeof obj === "function" ? obj() : obj;
      const frag = document.createDocumentFragment();
      Object.entries(source).forEach(([key, value], i) => {
        const node = _toNode(renderFn(key, value, i));
        if (node) {
          frag.appendChild(node);
          rendered.push(node);
        }
      });
      anchor.parentNode.insertBefore(frag, anchor);
    }
    update();
    return update;
  }
  // ── while ──────────────────────────────────────────────────────────────────
  /**
   * Render while a condition is truthy, calling renderFn(iteration) each time.
   * Has a built-in safety limit of 10000 iterations to prevent infinite loops.
   *
   * @param parent    - Parent element
   * @param condition - () => boolean — evaluated each iteration
   * @param renderFn  - (iteration: number) => string | Element
   * @returns UpdateFn
   *
   * @example
   *   let i = 0;
   *   const update = Directive.while(ul, () => i < 5, () => {
   *     const html = `<li>Item ${i}</li>`;
   *     i++;
   *     return html;
   *   });
   */
  static while(parent, condition, renderFn) {
    const par = _resolveParent(parent);
    if (!par) return () => {
    };
    const anchor = document.createComment(" a:while ");
    par.appendChild(anchor);
    const rendered = [];
    function update() {
      rendered.forEach((n) => {
        if (n.parentNode) n.parentNode.removeChild(n);
      });
      rendered.length = 0;
      const frag = document.createDocumentFragment();
      let i = 0;
      const MAX = 1e4;
      while (condition() && i < MAX) {
        const node = _toNode(renderFn(i));
        if (node) {
          frag.appendChild(node);
          rendered.push(node);
        }
        i++;
      }
      anchor.parentNode.insertBefore(frag, anchor);
    }
    update();
    return update;
  }
  // ── switch ─────────────────────────────────────────────────────────────────
  /**
   * Render the matching case from a map. Falls back to 'default' key if present.
   *
   * @param parent - Parent element
   * @param value  - Current value or () => value
   * @param cases  - { [caseValue]: content, default?: content }
   * @returns UpdateFn
   *
   * @example
   *   const update = Directive.switch(el, () => tab, {
   *     home    : '<div>Home</div>',
   *     about   : '<div>About</div>',
   *     default : '<div>404</div>',
   *   });
   */
  static switch(parent, value, cases) {
    const par = _resolveParent(parent);
    if (!par) return () => {
    };
    const anchor = document.createComment(" a:switch ");
    par.appendChild(anchor);
    let current = null;
    function update() {
      const val = typeof value === "function" ? value() : value;
      const src = cases[String(val)] ?? cases["default"] ?? null;
      if (current) {
        if (Array.isArray(current))
          current.forEach((n) => {
            if (n.parentNode) n.parentNode.removeChild(n);
          });
        else if (current.parentNode)
          current.parentNode.removeChild(current);
        current = null;
      }
      if (src) {
        const next = _toNode(src);
        if (next) {
          const nodes = next.nodeType === 11 ? Array.from(next.childNodes) : [next];
          anchor.parentNode.insertBefore(next, anchor);
          current = nodes.length === 1 ? nodes[0] : nodes;
        }
      }
    }
    update();
    return update;
  }
  // ── bind ───────────────────────────────────────────────────────────────────
  /**
   * One-way bind: element[prop] ← source().
   * Supports string and function sources. For State-based binding,
   * use with state.on('State-Changed', update).
   *
   * @param el   - Target element
   * @param prop - Property name (e.g. 'textContent', 'value', 'href')
   * @param source - Value or () => value
   * @returns UpdateFn
   *
   * @example
   *   const update = Directive.bind(span, 'textContent', () => state.State.name);
   *   state.on('State-Changed', update);
   */
  static bind(el, prop, source) {
    function update() {
      const val = typeof source === "function" ? source() : source;
      el[prop] = val;
    }
    update();
    return update;
  }
  // ── show ───────────────────────────────────────────────────────────────────
  /**
   * Toggle visibility without removing from DOM (sets display none/empty).
   *
   * @param el        - Target element
   * @param condition - Boolean or () => boolean
   * @returns UpdateFn
   *
   * @example
   *   const update = Directive.show(panel, () => isVisible);
   *   state.on('State-Changed', update);
   */
  static show(el, condition) {
    function update() {
      el.style.display = _resolve(condition) ? "" : "none";
    }
    update();
    return update;
  }
  // ── model ──────────────────────────────────────────────────────────────────
  /**
   * Two-way binding between an input element and a State property.
   * input.value → state.State[key] on 'input' event.
   * state.State[key] → input.value on State-Changed.
   *
   * @param input - Input, textarea, or select element
   * @param state - AriannA State instance
   * @param key   - Property key in state.State
   *
   * @example
   *   const state = new State({ name: 'AriannA', version: 2 });
   *   Directive.model(nameInput, state, 'name');
   *   // nameInput.value ↔ state.State.name
   */
  static model(input, state, key) {
    input.addEventListener("input", () => {
      state.State[key] = input.value;
    });
    state.on("State-Changed", () => {
      const v = String(state.State[key] ?? "");
      if (input.value !== v) input.value = v;
    });
    input.value = String(state.State[key] ?? "");
  }
  // ── on ─────────────────────────────────────────────────────────────────────
  /**
   * Add a DOM event listener — thin wrapper matching v-on / @event syntax.
   * Types may be space/comma/pipe-separated.
   *
   * @example
   *   Directive.on(btn, 'click', handler);
   *   Directive.on(form, 'submit', e => { e.preventDefault(); submit(); });
   */
  static on(el, types, handler, opts) {
    const target = typeof el === "string" ? document.querySelector(el) : el;
    if (!target) return;
    types.split(/\s+|,|\|/g).filter(Boolean).forEach((t) => target.addEventListener(t, handler, opts));
  }
  // ── template ───────────────────────────────────────────────────────────────
  /**
   * Process {{ expression }} template literals in an element's innerHTML.
   *
   * Supports:
   *   {{ varName }}                  — simple variable lookup
   *   {{ obj.prop }}                 — dot-path lookup (Level1A.Level2A)
   *   {{ obj[key] }}                 — bracket notation
   *
   * Matches the the legacy library legacy {{ planet }} / {{ object[planet] }} /
   * {{ Level1A.Level2A }} syntax from the legacy library-Components-Directives-TemplateLiterals.html
   * and the legacy library-Components-Directives-ForEach.html.
   *
   * @param el   - Element containing {{ }} placeholders
   * @param data - Data context object (defaults to window globals)
   *
   * @example
   *   var example = 'EXAMPLE'; var literals = 'LITERALS';
   *   Directive.template(div, { example, literals });
   *   // <p>This is an EXAMPLE of Template LITERALS</p>
   *
   * @example
   *   // Nested path
   *   Directive.template(el, { Level1A: { Level2A: 'Data Level2A Value' } });
   *   // {{ Level1A.Level2A }} → 'Data Level2A Value'
   */
  static template(el, data) {
    const ctx = data ?? (typeof window !== "undefined" ? window : {});
    function resolve(expr) {
      expr = expr.trim();
      try {
        const parts = expr.split(/\.|\[['"]?|['"]?\]/g).filter(Boolean);
        let val = ctx;
        for (const part of parts) {
          if (val == null) return "";
          val = val[part];
        }
        return val != null ? String(val) : "";
      } catch {
        return "";
      }
    }
    el.innerHTML = el.innerHTML.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (_, expr) => resolve(expr));
  }
  // ── bootstrap ──────────────────────────────────────────────────────────────
  /**
   * Scan a root element for directive HTML attributes and apply them.
   * Supports: a-if, a-for, a-foreach, a-while, a-switch, a-bind, a-show, a-model, a-on.
   * Also processes {{ }} template literals in elements with a-template or data-template.
   *
   * This enables declarative HTML-first usage without writing JS:
   * ```html
   * <ol a-foreach="item in items"><li>{{ item }}</li></ol>
   * <div a-if="user.loggedIn">Welcome!</div>
   * <input a-model="state.name">
   * <button a-on="click:submitForm">Submit</button>
   * ```
   *
   * @param root    - Root element to scan (default: document.body)
   * @param context - Data context for expression evaluation (default: window)
   *
   * @example
   *   Directive.bootstrap(document.body, { items, user, state });
   */
  static bootstrap(root = document.body, context = {}) {
    const ctx = { ...typeof window !== "undefined" ? window : {}, ...context };
    function evalExpr(expr) {
      try {
        const keys = Object.keys(ctx);
        const vals = Object.values(ctx);
        return new Function(...keys, `return (${expr})`)(...vals);
      } catch {
        return void 0;
      }
    }
    root.querySelectorAll("[a-template],[data-template]").forEach((el) => {
      _Directive.template(el, ctx);
    });
    root.querySelectorAll("[a-if]").forEach((el) => {
      const expr = el.getAttribute("a-if") ?? "false";
      _Directive.if(el.parentElement ?? root, () => Boolean(evalExpr(expr)), el);
    });
    root.querySelectorAll("[a-show]").forEach((el) => {
      const expr = el.getAttribute("a-show") ?? "false";
      _Directive.show(el, () => Boolean(evalExpr(expr)));
    });
    root.querySelectorAll("[a-model]").forEach((el) => {
      const path = el.getAttribute("a-model") ?? "";
      const [stateKey, propKey] = path.split(".");
      const state = ctx[stateKey];
      if (state && propKey) _Directive.model(el, state, propKey);
    });
    root.querySelectorAll("[a-on]").forEach((el) => {
      const spec = el.getAttribute("a-on") ?? "";
      const [type, fnName] = spec.split(":").map((s) => s.trim());
      if (type && fnName) {
        const handler = ctx[fnName];
        if (typeof handler === "function")
          _Directive.on(el, type, handler);
      }
    });
    root.querySelectorAll("[a-bind]").forEach((el) => {
      const spec = el.getAttribute("a-bind") ?? "";
      const [prop, expr] = spec.split(":").map((s) => s.trim());
      if (prop && expr) _Directive.bind(el, prop, () => evalExpr(expr));
    });
  }
  // ────────────────────────────────────────────────────────────────────────────
  // Instance API + custom directive registry
  //
  // In addition to the static helpers above, Directive can be instantiated to
  // create reusable, named directive behaviors with optional `mounted` and
  // `unmounted` lifecycle hooks. Both styles are supported in parallel:
  //
  //   1. Static one-shot:        Directive.if(el, () => x)
  //   2. Static custom register: Directive.register('tooltip', { mounted, unmounted });
  //                              Directive.apply('tooltip', el, 'Hello!');
  //   3. Instance custom:        const tip = new Directive('tooltip', { mounted, unmounted });
  //                              tip.apply(el, 'Hello!');
  //                              tip.apply(otherEl, 'World!');     // reuse instance
  //                              tip.unmount(el);                  // optional cleanup
  //
  // Pattern (3) gives you a stable handle on a directive — useful when you
  // need to track multiple bindings, dispose them later, or pass the directive
  // around as a first-class object.
  //
  // ────────────────────────────────────────────────────────────────────────────
  /** Directive instance hooks. */
  /* (CustomDirectiveHooks declared module-level — see below) */
  /** Name of this custom directive instance. */
  name;
  /** Mount/unmount hooks for this instance. */
  hooks;
  /** Map of element → user-supplied value, for unmount cleanup. */
  #bindings = /* @__PURE__ */ new WeakMap();
  /**
   * Create a custom, named directive that auto-registers itself in the global
   * registry, so both `inst.apply(...)` and `Directive.apply(name, ...)` work.
   *
   * @param name  Unique directive name (e.g. 'tooltip', 'autosize').
   * @param hooks Lifecycle hooks. Both are optional but at least one is
   *              recommended; `mounted` is called on apply, `unmounted` on
   *              `unmount(el)` or `Directive.unmount(name, el)`.
   *
   * @example
   *   const tooltip = new Directive('tooltip', {
   *       mounted(el, value) { el.setAttribute('title', String(value)); },
   *       unmounted(el)      { el.removeAttribute('title'); },
   *   });
   *   tooltip.apply(buttonEl, 'Click to submit');
   */
  constructor(name, hooks) {
    this.name = name;
    this.hooks = hooks;
    _Directive._registry.set(name, this);
  }
  /**
   * Apply this directive instance to a DOM element, calling its `mounted`
   * hook if defined. Returns `this` for chaining.
   */
  apply(el, value = void 0) {
    this.#bindings.set(el, value);
    this.hooks.mounted?.(el, value);
    return this;
  }
  /**
   * Run the `unmounted` hook for `el` (if defined) and forget the binding.
   * Returns `true` if a binding existed, `false` otherwise.
   */
  unmount(el) {
    if (!this.#bindings.has(el)) return false;
    const value = this.#bindings.get(el);
    this.#bindings.delete(el);
    this.hooks.unmounted?.(el, value);
    return true;
  }
  // ── Static registry ────────────────────────────────────────────────────────
  /** @internal */
  static _registry = /* @__PURE__ */ new Map();
  /**
   * Register a custom directive in the global registry. Equivalent to
   * `new Directive(name, hooks)` but reads more declaratively when you
   * don't need to keep the instance handle around.
   *
   * @returns The created Directive instance, in case you want it.
   *
   * @example
   *   Directive.register('autofocus', {
   *       mounted(el) { (el as HTMLElement).focus(); },
   *   });
   */
  static register(name, hooks) {
    return new _Directive(name, hooks);
  }
  /**
   * Look up a registered custom directive by name and apply it to `el`.
   * Returns the Directive instance, or `undefined` if no directive with that
   * name was registered.
   *
   * @example
   *   Directive.register('tooltip', { mounted(el, v) { ... } });
   *   Directive.apply('tooltip', someElement, 'Hello!');
   */
  static apply(name, el, value = void 0) {
    const inst = _Directive._registry.get(name);
    if (!inst) return void 0;
    return inst.apply(el, value);
  }
  /** Run the unmount hook of a registered directive on an element. */
  static unmount(name, el) {
    const inst = _Directive._registry.get(name);
    if (!inst) return false;
    return inst.unmount(el);
  }
  /** Look up a registered Directive instance by name. */
  static get(name) {
    return _Directive._registry.get(name);
  }
};
if (typeof window !== "undefined")
  Object.defineProperty(window, "Directive", {
    enumerable: true,
    configurable: false,
    writable: false,
    value: Directive
  });
var Directive_default = Directive;

// core/Context.ts
var _registry = /* @__PURE__ */ new Map();
function _get(key) {
  if (!_registry.has(key))
    _registry.set(key, { value: void 0, $signal: signal(void 0), providers: /* @__PURE__ */ new Set(), consumers: /* @__PURE__ */ new Set() });
  return _registry.get(key);
}
function _fire(record, key, nv, old) {
  record.$signal.set(nv);
  const ev = { Type: "Context-Changed", Key: key, Value: nv, Old: old };
  for (const c of record.consumers) {
    const bucket = c.events.get("Context-Changed");
    if (bucket) for (const cb of bucket) cb(ev);
  }
}
var Context = class {
  #key;
  #rec;
  constructor(key, value) {
    this.#key = key;
    this.#rec = _get(key);
    if (value !== void 0) {
      this.#rec.value = value;
      this.#rec.$signal.set(value);
    }
  }
  get key() {
    return this.#key;
  }
  get value() {
    return this.#rec.value;
  }
  /**
   * Espone il valore come Signal reattivo.
   * Gli Effect che lo leggono reagiscono automaticamente a update().
   * @example
   *   const $theme = ThemeCtx.asSignal();
   *   real.style('background', () => $theme.get()?.primary ?? 'gray');
   */
  asSignal() {
    return this.#rec.$signal;
  }
  provide(element) {
    this.#rec.providers.add(element);
    element.addEventListener("arianna:context-request", (e) => {
      const ce = e;
      if (ce.detail.key === this.#key) {
        ce.stopPropagation();
        ce.detail.resolve(this.#rec.value);
      }
    });
    return this;
  }
  update(value) {
    const old = this.#rec.value;
    if (Object.is(old, value)) return this;
    this.#rec.value = value;
    _fire(this.#rec, this.#key, value, old);
    return this;
  }
  destroy() {
    this.#rec.providers.clear();
    this.#rec.consumers.clear();
    _registry.delete(this.#key);
  }
  static consume(key, element) {
    const rec = _get(key);
    const cr = { id: uuid2(), element, events: /* @__PURE__ */ new Map() };
    rec.consumers.add(cr);
    let resolved = false;
    element.dispatchEvent(new CustomEvent("arianna:context-request", {
      bubbles: true,
      composed: true,
      detail: { key, resolve: (v) => {
        if (!resolved) {
          resolved = true;
          rec.value = v;
          rec.$signal.set(v);
        }
      } }
    }));
    const handle = {
      get value() {
        return rec.value;
      },
      signal() {
        return rec.$signal;
      },
      on(types, cb) {
        types.split(/\s+|,|\|/g).filter(Boolean).forEach((t) => {
          const b = cr.events.get(t) ?? /* @__PURE__ */ new Set();
          b.add(cb);
          cr.events.set(t, b);
        });
        return handle;
      },
      off(type, cb) {
        cr.events.get(type)?.forEach((l) => l === cb && cr.events.get(type).delete(l));
        return handle;
      },
      detach() {
        rec.consumers.delete(cr);
      }
    };
    return handle;
  }
  static has(key, element) {
    let found = false;
    element.dispatchEvent(new CustomEvent("arianna:context-request", { bubbles: true, composed: true, detail: { key, resolve: () => {
      found = true;
    } } }));
    return found;
  }
  static keys() {
    return Array.from(_registry.keys());
  }
};
if (typeof window !== "undefined")
  Object.defineProperty(window, "Context", { enumerable: true, configurable: false, writable: false, value: Context });
var Context_default = Context;

// core/Namespace.ts
function iface(name, tags) {
  return {
    Name: name,
    Tags: tags,
    Namespace: null,
    // filled during init
    Constructor: null,
    Interface: null,
    Prototype: null,
    Supported: false,
    Defined: false,
    Declaration: "FUNCTION",
    Type: "STANDARD",
    Standard: true,
    Custom: false,
    Style: {}
  };
}
var htmlFunctions = {
  create(tag) {
    let t = tag;
    if (typeof t === "function") {
      const d = Core_default.GetDescriptor(t);
      t = d ? d.Tags[0] : void 0;
    }
    if (typeof t === "string") return document.createElement(t.toLowerCase());
    return false;
  },
  patch(constructorName) {
    const win = window;
    const iface2 = win[constructorName];
    if (!iface2 || typeof iface2 !== "function") return;
    const name = iface2.name;
    const create = htmlFunctions.create;
    const wrapped = function() {
      const p = this.constructor.prototype;
      return Object.setPrototypeOf(
        create(this.constructor),
        p
      );
    };
    Object.defineProperty(wrapped, "name", { value: name });
    wrapped.prototype = iface2.prototype;
    wrapped.prototype.constructor = wrapped;
    win[name] = wrapped;
  }
};
var htmlInterfaces = {
  HTMLElement: iface("HTMLElement", ["address", "article", "footer", "header", "section", "nav", "dd", "dt", "figcaption", "figure", "main", "abbr", "b", "bdi", "bdo", "cite", "code", "dfn", "em", "i", "mark", "rt", "rtc", "ruby", "s", "samp", "small", "strong", "sub", "sup", "u", "var", "wbr", "area", "noscript", "noembed", "plaintext", "strike", "tt", "summary", "acronym", "basefont", "big", "center"]),
  HTMLUnknownElement: iface("HTMLUnknownElement", ["isindex", "spacer", "menuitem", "decorator", "applet", "blink", "keygen"]),
  HTMLHtmlElement: iface("HTMLHtmlElement", ["html"]),
  HTMLHeadElement: iface("HTMLHeadElement", ["head"]),
  HTMLBaseElement: iface("HTMLBaseElement", ["base"]),
  HTMLLinkElement: iface("HTMLLinkElement", ["link"]),
  HTMLMetaElement: iface("HTMLMetaElement", ["meta"]),
  HTMLStyleElement: iface("HTMLStyleElement", ["style"]),
  HTMLTitleElement: iface("HTMLTitleElement", ["title"]),
  HTMLPreElement: iface("HTMLPreElement", ["pre", "listing", "xmp"]),
  HTMLHeadingElement: iface("HTMLHeadingElement", ["h1", "h2", "h3", "h4", "h5", "h6"]),
  HTMLDivElement: iface("HTMLDivElement", ["div"]),
  HTMLDListElement: iface("HTMLDListElement", ["dl"]),
  HTMLHRElement: iface("HTMLHRElement", ["hr"]),
  HTMLLIElement: iface("HTMLLIElement", ["li"]),
  HTMLOListElement: iface("HTMLOListElement", ["ol"]),
  HTMLParagraphElement: iface("HTMLParagraphElement", ["p"]),
  HTMLUListElement: iface("HTMLUListElement", ["ul"]),
  HTMLAnchorElement: iface("HTMLAnchorElement", ["a"]),
  HTMLBRElement: iface("HTMLBRElement", ["br"]),
  HTMLSpanElement: iface("HTMLSpanElement", ["span"]),
  HTMLAudioElement: iface("HTMLAudioElement", ["audio"]),
  HTMLImageElement: iface("HTMLImageElement", ["img"]),
  HTMLVideoElement: iface("HTMLVideoElement", ["video"]),
  HTMLCanvasElement: iface("HTMLCanvasElement", ["canvas"]),
  HTMLIFrameElement: iface("HTMLIFrameElement", ["iframe"]),
  HTMLScriptElement: iface("HTMLScriptElement", ["script"]),
  HTMLInputElement: iface("HTMLInputElement", ["input"]),
  HTMLButtonElement: iface("HTMLButtonElement", ["button"]),
  HTMLTextAreaElement: iface("HTMLTextAreaElement", ["textarea"]),
  HTMLSelectElement: iface("HTMLSelectElement", ["select"]),
  HTMLOptionElement: iface("HTMLOptionElement", ["option"]),
  HTMLFormElement: iface("HTMLFormElement", ["form"]),
  HTMLFieldSetElement: iface("HTMLFieldSetElement", ["fieldset"]),
  HTMLLabelElement: iface("HTMLLabelElement", ["label"]),
  HTMLTableElement: iface("HTMLTableElement", ["table"]),
  HTMLTableRowElement: iface("HTMLTableRowElement", ["tr"]),
  HTMLTableCellElement: iface("HTMLTableCellElement", ["td", "th"]),
  HTMLTableSectionElement: iface("HTMLTableSectionElement", ["tbody", "thead", "tfoot"]),
  HTMLTableColElement: iface("HTMLTableColElement", ["col", "colgroup"]),
  HTMLTableCaptionElement: iface("HTMLTableCaptionElement", ["caption"]),
  HTMLProgressElement: iface("HTMLProgressElement", ["progress"]),
  HTMLDataListElement: iface("HTMLDataListElement", ["datalist"]),
  HTMLOptGroupElement: iface("HTMLOptGroupElement", ["optgroup"]),
  HTMLMapElement: iface("HTMLMapElement", ["map"]),
  HTMLTrackElement: iface("HTMLTrackElement", ["track"]),
  HTMLSourceElement: iface("HTMLSourceElement", ["source"]),
  HTMLEmbedElement: iface("HTMLEmbedElement", ["embed"]),
  HTMLObjectElement: iface("HTMLObjectElement", ["object"]),
  HTMLParamElement: iface("HTMLParamElement", ["param"]),
  HTMLModElement: iface("HTMLModElement", ["ins", "del"]),
  HTMLQuoteElement: iface("HTMLQuoteElement", ["blockquote", "q"]),
  HTMLMenuElement: iface("HTMLMenuElement", ["menu"]),
  HTMLDialogElement: iface("HTMLDialogElement", ["dialog"]),
  HTMLTemplateElement: iface("HTMLTemplateElement", ["template"]),
  HTMLSlotElement: iface("HTMLSlotElement", ["slot"])
};
var htmlNS = {
  name: "html",
  schema: "http://www.w3.org/1999/xhtml",
  state: "enabled",
  enabled: true,
  disabled: false,
  base: HTMLElement,
  tags: {},
  types: {
    standard: { interfaces: htmlInterfaces, tags: {} },
    custom: { interfaces: {}, tags: {} }
  },
  functions: htmlFunctions,
  documentation: { w3c: "https://html.spec.whatwg.org/" }
};
var svgFunctions = {
  create(tag) {
    let t = tag;
    if (typeof t === "function") {
      const d = Core_default.GetDescriptor(t);
      t = d ? d.Tags[0] : void 0;
    }
    if (typeof t === "string")
      return document.createElementNS("http://www.w3.org/2000/svg", t.toLowerCase());
    return false;
  },
  patch: htmlFunctions.patch
  // reuse HTML patcher
};
var svgInterfaces = {
  SVGSVGElement: iface("SVGSVGElement", ["svg"]),
  SVGGElement: iface("SVGGElement", ["g"]),
  SVGPathElement: iface("SVGPathElement", ["path"]),
  SVGRectElement: iface("SVGRectElement", ["rect"]),
  SVGCircleElement: iface("SVGCircleElement", ["circle"]),
  SVGEllipseElement: iface("SVGEllipseElement", ["ellipse"]),
  SVGLineElement: iface("SVGLineElement", ["line"]),
  SVGPolylineElement: iface("SVGPolylineElement", ["polyline"]),
  SVGPolygonElement: iface("SVGPolygonElement", ["polygon"]),
  SVGTextElement: iface("SVGTextElement", ["text"]),
  SVGTSpanElement: iface("SVGTSpanElement", ["tspan"]),
  SVGImageElement: iface("SVGImageElement", ["image"]),
  SVGUseElement: iface("SVGUseElement", ["use"]),
  SVGDefsElement: iface("SVGDefsElement", ["defs"]),
  SVGSymbolElement: iface("SVGSymbolElement", ["symbol"]),
  SVGMarkerElement: iface("SVGMarkerElement", ["marker"]),
  SVGLinearGradientElement: iface("SVGLinearGradientElement", ["lineargradient"]),
  SVGRadialGradientElement: iface("SVGRadialGradientElement", ["radialgradient"]),
  SVGStopElement: iface("SVGStopElement", ["stop"]),
  SVGClipPathElement: iface("SVGClipPathElement", ["clippath"]),
  SVGMaskElement: iface("SVGMaskElement", ["mask"]),
  SVGFilterElement: iface("SVGFilterElement", ["filter"]),
  SVGAnimateElement: iface("SVGAnimateElement", ["animate"]),
  SVGAnimateMotionElement: iface("SVGAnimateMotionElement", ["animatemotion"]),
  SVGAnimateTransformElement: iface("SVGAnimateTransformElement", ["animatetransform"]),
  SVGSetElement: iface("SVGSetElement", ["set"]),
  SVGViewElement: iface("SVGViewElement", ["view"]),
  SVGScriptElement: iface("SVGScriptElement", ["script"]),
  SVGStyleElement: iface("SVGStyleElement", ["style"]),
  SVGTitleElement: iface("SVGTitleElement", ["title"]),
  SVGDescElement: iface("SVGDescElement", ["desc"]),
  SVGMetadataElement: iface("SVGMetadataElement", ["metadata"]),
  SVGForeignObjectElement: iface("SVGForeignObjectElement", ["foreignobject"]),
  SVGSwitchElement: iface("SVGSwitchElement", ["switch"])
};
var svgNS = {
  name: "svg",
  schema: "http://www.w3.org/2000/svg",
  state: "enabled",
  enabled: true,
  disabled: false,
  base: SVGElement,
  tags: {},
  types: {
    standard: { interfaces: svgInterfaces, tags: {} },
    custom: { interfaces: {}, tags: {} }
  },
  functions: svgFunctions,
  documentation: { w3c: "https://www.w3.org/TR/SVG2/" }
};
var mathMLNS = {
  name: "mathML",
  schema: "http://www.w3.org/1998/Math/MathML",
  state: "enabled",
  enabled: true,
  disabled: false,
  base: typeof MathMLElement !== "undefined" ? MathMLElement : HTMLElement,
  tags: {},
  types: {
    standard: {
      interfaces: {
        MathMLElement: iface("MathMLElement", ["math", "mi", "mo", "mn", "ms", "mspace", "mtext", "mfrac", "msqrt", "mroot", "mstyle", "merror", "mpadded", "mphantom", "mrow", "mfenced", "menclose", "msub", "msup", "msubsup", "munder", "mover", "munderover", "mmultiscripts", "mtable", "mtr", "mtd", "mlabeledtr", "maction"])
      },
      tags: {}
    },
    custom: { interfaces: {}, tags: {} }
  },
  functions: {
    create(tag) {
      const t = typeof tag === "string" ? tag : void 0;
      if (!t) return false;
      return document.createElementNS(
        "http://www.w3.org/1998/Math/MathML",
        t.toLowerCase()
      );
    },
    patch: htmlFunctions.patch
  },
  documentation: { w3c: "https://www.w3.org/TR/MathML3/" }
};
var x3dNS = {
  name: "x3d",
  schema: "http://www.web3d.org/specifications/x3d-namespace",
  state: "enabled",
  enabled: true,
  disabled: false,
  base: HTMLElement,
  tags: {},
  types: {
    standard: { interfaces: {}, tags: {} },
    custom: { interfaces: {}, tags: {} }
  },
  functions: {
    create(tag) {
      const t = typeof tag === "string" ? tag : void 0;
      if (!t) return false;
      return document.createElementNS(
        "http://www.web3d.org/specifications/x3d-namespace",
        t
      );
    },
    patch: htmlFunctions.patch
  },
  documentation: { w3c: "https://www.web3d.org/specifications/x3d-4.0/" }
};
function initNamespace(ns) {
  const std = ns.types.standard;
  for (const key of Object.keys(std.interfaces)) {
    const d = std.interfaces[key];
    d.Namespace = ns;
    if (ns.functions.patch) ns.functions.patch(key);
    const win = window;
    d.Supported = Boolean(win[key]);
    d.Defined = true;
    d.Constructor = win[key] ?? null;
    d.Interface = win[key] ?? null;
    d.Prototype = d.Supported ? win[key].prototype : null;
    for (const tag of d.Tags) {
      std.tags[tag] = d;
      ns.tags[tag] = d;
      std.tags[tag].Name = tag;
    }
  }
}
Core_default.RegisterNamespace("html", htmlNS);
Core_default.RegisterNamespace("svg", svgNS);
Core_default.RegisterNamespace("mathML", mathMLNS);
Core_default.RegisterNamespace("x3d", x3dNS);
for (const key of Object.keys(Core_default.Namespaces)) {
  initNamespace(Core_default.Namespaces[key]);
}
var Namespace_default = Core_default.Namespaces;

// core/SSR.ts
var VOID_ELEMENTS = /* @__PURE__ */ new Set([
  "area",
  "base",
  "br",
  "col",
  "embed",
  "hr",
  "img",
  "input",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]);
var RAW_ATTRS = /* @__PURE__ */ new Set(["innerHTML", "dangerouslySetInnerHTML"]);
var BOOLEAN_ATTRS = /* @__PURE__ */ new Set([
  "allowfullscreen",
  "async",
  "autofocus",
  "autoplay",
  "checked",
  "controls",
  "default",
  "defer",
  "disabled",
  "formnovalidate",
  "hidden",
  "ismap",
  "loop",
  "multiple",
  "muted",
  "nomodule",
  "novalidate",
  "open",
  "readonly",
  "required",
  "reversed",
  "selected",
  "typemustmatch"
]);
function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function accessNode(node) {
  const tag = node.Tag ?? "div";
  const rawAttrs = node["__attrs"] ?? node["#attrs"] ?? {};
  const attrs = {};
  for (const [k, v] of Object.entries(rawAttrs)) {
    if (v === null || v === false || v === void 0) continue;
    if (v === true) {
      attrs[k] = "";
      continue;
    }
    attrs[k] = String(v);
  }
  const rawText = node["__text"] ?? node["#text"] ?? "";
  const rawChildren = node["__children"] ?? node["#children"] ?? [];
  return {
    tag,
    attrs,
    text: rawText,
    children: rawChildren.map(accessNode),
    id: node.Id ?? ""
  };
}
function renderAttrs(attrs, ssrId) {
  let s = "";
  for (const [k, v] of Object.entries(attrs)) {
    if (RAW_ATTRS.has(k)) continue;
    if (k === "textContent" || k === "innerHTML") continue;
    if (BOOLEAN_ATTRS.has(k.toLowerCase())) {
      if (v !== "" && v !== "false") s += ` ${k}`;
      continue;
    }
    s += ` ${escapeHtml(k)}="${escapeHtml(v)}"`;
  }
  if (ssrId) s += ` data-arianna-id="${escapeHtml(ssrId)}"`;
  return s;
}
function renderToString(node, options = {}) {
  const { hydration = false, indent = 0 } = options;
  return _renderNode(accessNode(node), hydration, indent, 0);
}
function _renderNode(node, hydration, indent, depth) {
  const pad = indent > 0 ? "\n" + " ".repeat(indent * depth) : "";
  const cPad = indent > 0 ? "\n" + " ".repeat(indent * (depth + 1)) : "";
  const ssrId = hydration ? node.id : void 0;
  const attrs = renderAttrs(node.attrs, ssrId);
  const textContent = node.attrs["textContent"] ?? node.text;
  const innerHTML = node.attrs["innerHTML"];
  if (VOID_ELEMENTS.has(node.tag))
    return `${pad}<${node.tag}${attrs}>`;
  const open = `${pad}<${node.tag}${attrs}>`;
  const close = `${indent > 0 ? "\n" + " ".repeat(indent * depth) : ""}</${node.tag}>`;
  if (innerHTML !== void 0)
    return `${open}${innerHTML}${close}`;
  if (textContent)
    return `${open}${escapeHtml(textContent)}${close}`;
  if (node.children.length === 0)
    return `${open}${close}`;
  const inner = node.children.map((c) => _renderNode(c, hydration, indent, depth + 1)).join("");
  return `${open}${inner}${indent > 0 ? cPad.slice(0, -indent) : ""}${close}`;
}
async function* renderToStream(node, options = {}) {
  const { hydration = false, chunkSize = 512 } = options;
  let buffer = "";
  for (const chunk of _walkNode(accessNode(node), hydration)) {
    buffer += chunk;
    if (buffer.length >= chunkSize) {
      yield buffer;
      buffer = "";
    }
  }
  if (buffer) yield buffer;
}
function* _walkNode(node, hydration) {
  const ssrId = hydration ? node.id : void 0;
  const attrs = renderAttrs(node.attrs, ssrId);
  const textContent = node.attrs["textContent"] ?? node.text;
  const innerHTML = node.attrs["innerHTML"];
  if (VOID_ELEMENTS.has(node.tag)) {
    yield `<${node.tag}${attrs}>`;
    return;
  }
  yield `<${node.tag}${attrs}>`;
  if (innerHTML !== void 0) {
    yield innerHTML;
  } else if (textContent) {
    yield escapeHtml(textContent);
  } else for (const c of node.children) yield* _walkNode(c, hydration);
  yield `</${node.tag}>`;
}
function hydrate(vnode, root, state) {
  _hydrateNode(accessNode(vnode), root);
  if (state) {
    state.on("State-Changed", () => _hydrateNode(accessNode(vnode), root));
  }
}
function _hydrateNode(node, container) {
  if (!node.id) return;
  const el = container.querySelector(`[data-arianna-id="${node.id}"]`) ?? container;
  if (!el) return;
  el.setAttribute("data-arianna-wip-hydrated", "true");
  for (const child of node.children)
    _hydrateNode(child, el);
}
var Island = {
  /**
   * Mark a VirtualNode as static — rendered server-side, never hydrated.
   * Adds data-arianna-wip-island="static" to the node's root element.
   */
  static(node) {
    node.set("data-arianna-wip-island", "static");
    return node;
  },
  /**
   * Mark a VirtualNode as an interactive island.
   * On the client, hydrate() will re-attach AriannA reactivity to this subtree.
   *
   * @param node - The interactive subtree
   * @param id   - Stable identifier for client-side matching
   */
  interactive(node, id) {
    node.set("data-arianna-wip-island", "interactive");
    node.set("data-arianna-wip-island-id", id);
    return node;
  },
  /**
   * Hydrate all interactive islands in a container.
   * Call this once on page load, after server HTML is in the DOM.
   *
   * @example
   *   Island.hydrateAll(document.body, islandMap);
   *   // islandMap: Record<id, VirtualNode>
   */
  hydrateAll(container, islandMap) {
    const islands = container.querySelectorAll('[data-arianna-wip-island="interactive"]');
    for (const el of Array.from(islands)) {
      const id = el.getAttribute("data-arianna-wip-island-id");
      const node = id ? islandMap[id] : null;
      if (node) hydrate(node, el);
    }
  }
};
var SSR = {
  name: "AriannASSR",
  version: "1.0.0",
  install(_core) {
    const api = { renderToString, renderToStream, hydrate, escapeHtml, Island };
    const g = typeof window !== "undefined" ? window : typeof globalThis !== "undefined" ? globalThis : null;
    if (g) {
      Object.defineProperty(g, "AriannASSR", {
        value: api,
        writable: false,
        enumerable: false,
        configurable: false
      });
    }
  }
};
var SSR_default = SSR;

// core/Workers.ts
var WorkerPool = class {
  #workers = [];
  #queue = [];
  #idle = [];
  constructor(size, url) {
    for (let i = 0; i < size; i++) {
      const w = new Worker(url, { type: "module" });
      w.onmessage = (e) => this.#onResult(w, e.data);
      w.onerror = (e) => this.#onError(w, e);
      this.#workers.push(w);
      this.#idle.push(w);
    }
  }
  /**
   * Esegue fn in un worker del pool.
   * Il worker deve esporre un handler che risponde a { fn, args }.
   */
  run(fn, args = []) {
    return new Promise((resolve, reject) => {
      const task = { fn, args, resolve, reject };
      const worker = this.#idle.pop();
      if (worker) this.#dispatch(worker, task);
      else this.#queue.push(task);
    });
  }
  /** Termina tutti i worker del pool. */
  terminate() {
    this.#workers.forEach((w) => w.terminate());
    this.#workers = [];
    this.#idle = [];
    this.#queue = [];
  }
  #dispatch(worker, task) {
    worker["__task__"] = task;
    worker.postMessage({ fn: task.fn.toString(), args: task.args });
  }
  #onResult(worker, data) {
    const task = worker["__task__"];
    task?.resolve(data);
    const next = this.#queue.shift();
    if (next) this.#dispatch(worker, next);
    else this.#idle.push(worker);
  }
  #onError(worker, e) {
    const task = worker["__task__"];
    task?.reject(e.error ?? e.message);
    this.#idle.push(worker);
  }
};
var _sharedSignals = /* @__PURE__ */ new Map();
function sharedSignal(key, initial) {
  if (_sharedSignals.has(key)) return _sharedSignals.get(key);
  const s = signal(initial);
  _sharedSignals.set(key, s);
  return s;
}
function _installWorkerListener() {
  if (typeof window === "undefined") return;
  window.addEventListener("message", (e) => {
    const { type, key, value } = e.data ?? {};
    if (type === "arianna:signal" && _sharedSignals.has(key)) {
      _sharedSignals.get(key).set(value);
    }
  });
}
function offscreen(canvas, worker) {
  if (!("transferControlToOffscreen" in canvas)) {
    console.warn("[AriannA Workers] OffscreenCanvas not supported in this browser");
    return;
  }
  const offscreenCanvas = canvas.transferControlToOffscreen();
  worker.postMessage({ type: "arianna:offscreen", canvas: offscreenCanvas }, [offscreenCanvas]);
}
var Workers = {
  name: "AriannAWorkers",
  version: "0.2.0",
  install(core, _opts) {
    _installWorkerListener();
    const API = {
      WorkerPool,
      sharedSignal,
      offscreen,
      /** Tutti i Signal condivisi attivi — utile per debug. */
      get signals() {
        return _sharedSignals;
      }
    };
    Object.defineProperty(window, "AriannAWorkers", {
      value: API,
      writable: false,
      enumerable: false,
      configurable: false
    });
  }
};
var Workers_default = Workers;
export {
  AriannATemplate,
  Component_default as Component,
  Context_default as Context,
  Core_default as Core,
  CssState,
  Directive_default as Directive,
  Namespace_default as Namespace,
  Observable_default as Observable,
  Real_default as Real,
  Rule,
  SSR_default as SSR,
  Stylesheet_default as Sheet,
  State_default as State,
  Virtual_default as Virtual,
  Workers_default as Workers,
  batch,
  computed,
  effect,
  signal,
  signalMono,
  untrack,
  uuid2 as uuid
};
/**
 * @module    SSR
 * @author    Riccardo Angeli
 * @version   1.0.0
 * @copyright Riccardo Angeli 2026
 * @license   MIT / Commercial (dual license)
 *
 * Copyright (c) 2012-2026 Riccardo Angeli
 * MIT License — see AriannA.ts for full text.
 *
 * Server-side rendering for AriannA.
 * Works in Node.js, Deno, Bun, and Rust (via Axum + Workers bridge).
 *
 * ── FEATURES ──────────────────────────────────────────────────────────────────
 *
 *   renderToString   — synchronous VirtualNode tree → HTML string
 *   renderToStream   — streaming HTML via async generator (chunked for Axum)
 *   hydrate          — attach live AriannA state to server-rendered HTML
 *   Island           — mark selective subtrees for client hydration only
 *   escapeHtml       — XSS-safe attribute/text escaping (exported utility)
 *
 * ── INTEGRATION ───────────────────────────────────────────────────────────────
 *
 *   Node.js (Express/Fastify):
 *     import { renderToString } from './SSR.ts';
 *     app.get('/', (req, res) => res.send(renderToString(appNode)));
 *
 *   Bun / Deno:
 *     import { renderToStream } from './SSR.ts';
 *     return new Response(readableFromAsyncGen(renderToStream(appNode)));
 *
 *   Rust / Axum (via Workers bridge):
 *     Workers pool runs SSR.ts in parallel; Axum streams the chunks.
 *     See Workers.ts → WorkerPool for the bridge pattern.
 *
 *   Browser (hydration):
 *     import { hydrate } from './SSR.ts';
 *     hydrate(appNode, document.getElementById('app'), appState);
 *
 * ── ISLAND ARCHITECTURE ───────────────────────────────────────────────────────
 *
 *   Islands = only some parts of the page are interactive.
 *   Static parts are rendered server-side and never hydrated.
 *   Interactive parts (islands) are hydrated client-side.
 *
 *   Usage:
 *     const page = Virtual('div', {},
 *       Island.static(headerNode),           // SSR only, no client JS
 *       Island.interactive(counterNode, id), // hydrated on client
 *     );
 *
 * ── PERFORMANCE NOTES ─────────────────────────────────────────────────────────
 *
 *   renderToString:  ~2-5ms for 1000-node trees (no DOM API calls — pure string concat)
 *   renderToStream:  first byte < 1ms — chunks emitted as nodes are processed
 *   hydrate:         O(n) walk, uses data-arianna-wip-id for node matching
 */
/**
 * @module    core
 * @author    Riccardo Angeli
 * @copyright Riccardo Angeli 2012-2026
 * @license   MIT / Commercial (dual license)
 *
 * AriannA core — public package barrel. Re-exports the foundational
 * primitives every component and addon depends on. Sub-modules are also
 * importable individually:
 *
 *   import { Core }            from 'arianna/core';
 *   import { signal, effect }  from 'arianna/observable';
 *   import { Real }            from 'arianna/real';
 *
 * The default export of each module is re-exported here as a named
 * binding so downstream code can use the familiar `import { Core } from
 * '../core/index.ts'` pattern.
 */
